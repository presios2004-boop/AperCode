"""ask_cloud: 行き詰まったときにクラウド AI へ相談する（v1.2.4）。

- 会話全体ではなく「目的 / エラー / 試したこと / 関連コードの抜粋 / 質問」だけを送る
- 発動条件（cloud.require_failures）: 自動検証の差し戻し・テスト失敗・行き詰まり検知の合計がこの回数以上のときだけ使える
- 1 ターンの回数上限（cloud.max_per_turn）
- 送信前に秘密情報らしき文字列をマスク（cloud.mask_secrets）
- 承認は permissions.ask_cloud（既定 ask）
"""
from __future__ import annotations

import platform
import re
from pathlib import Path

from . import Tool, ToolContext, ToolError, register
from ..cloud import CloudClient, CloudSettings, ASK_SYSTEM, build_prompt, mask_secrets


def _excerpt(ctx: ToolContext, spec: str, max_lines: int) -> str:
    """'path' または 'path:10-80' 形式でファイルの抜粋を返す。"""
    spec = spec.strip()
    rng = None
    if ":" in spec and "-" in spec.rsplit(":", 1)[-1]:
        p, r = spec.rsplit(":", 1)
        try:
            a, b = r.split("-", 1)
            rng = (max(1, int(a)), int(b))
            spec = p
        except ValueError:
            rng = None
    path = ctx.resolve(spec)
    if not path.is_file():
        return f"### {spec}\n(ファイルがありません)"
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if rng:
        sel = lines[rng[0] - 1:rng[1]]
        start = rng[0]
    else:
        sel, start = lines[:max_lines], 1
    body = "\n".join(f"{i:4d}| {l}" for i, l in enumerate(sel, start))
    note = f"\n... (省略: 全 {len(lines)} 行。範囲は path:開始-終了 で指定可)" if len(lines) > len(sel) + (start - 1) else ""
    try:
        rel = path.relative_to(ctx.project_dir)
    except ValueError:
        rel = path
    return f"### {rel}\n```\n{body}{note}\n```"


async def ask_cloud(ctx: ToolContext, a: dict) -> str:
    cfg = ctx.cfg
    if not cfg.get("cloud.enabled", False):
        raise ToolError("クラウド相談は無効です（「設定」→「☁ クラウド AI の設定」で API キーを設定し、左のパネルの「☁ クラウド AI」をオンにしてください）")
    s = CloudSettings.from_cfg(cfg, "consult")
    vs = ctx.verify
    # ---- 発動条件: まずローカルで粘った後だけ
    need = int(cfg.get("cloud.require_failures", 1))
    failures = 0
    if vs is not None:
        failures = vs.stuck_count + vs.test_rounds + sum(vs.check_failures.values()) + vs.cloud_denied
    # v2.11.6: ユーザーが相談を求めたとき、Web で一定回数調べたとき（十分な情報が無い・アイデアが尽きた）も使える
    user_asked = bool(getattr(vs, "user_cloud", False))
    searched = int(getattr(vs, "web_calls", 0) or 0)
    search_need = int(cfg.get("cloud.search_before", 3))
    if failures < need and not user_asked and not (search_need > 0 and searched >= search_need):
        raise ToolError(f"まだクラウド相談は使えません（失敗・行き詰まり {failures} 回 / 必要 {need} 回、Web の調査 {searched} 回 / 必要 {search_need} 回）。"
                        "先にエラー文を読み直し、search_memory と web_search で解決策や情報を探して試してください")
    max_per_turn = int(cfg.get("cloud.max_per_turn", 2))
    if vs is not None and vs.cloud_calls >= max_per_turn:
        raise ToolError(f"このターンのクラウド相談は上限（{max_per_turn} 回）に達しました。得られたヒントを基に自分で進めるか、"
                        "試したこと・分かったことを整理してユーザーに報告してください")
    goal = str(a.get("goal") or "").strip()
    error = str(a.get("error") or "").strip()
    tried = str(a.get("tried") or "").strip()
    if not goal or not tried:
        raise ToolError("goal（目的）と tried（試したことと結果）は必須です。丸投げではなく相談になるように書いてください")
    files = a.get("files") or []
    if isinstance(files, str):
        files = [f for f in files.split(",") if f.strip()]
    max_lines = int(cfg.get("cloud.max_file_lines", 200))
    code = "\n\n".join(_excerpt(ctx, f, max_lines) for f in files[:6])
    env = f"OS: {platform.platform()}; project: {ctx.project_dir.name}"
    prompt = build_prompt(goal, error, tried, code, str(a.get("question") or ""), env)
    masked = 0
    if cfg.get("cloud.mask_secrets", True):
        prompt, masked = mask_secrets(prompt)
    if vs is not None:
        vs.cloud_calls += 1
    # v2.11.53: 「☁ レビューも外部 AI」がオフで、相談の中身がレビュー（文章の添削・最終チェック・コードレビューなど）なら、
    #   外部 AI には送らず、相談が失敗したときと同じ代わりの順（Web 検索 → メイン LLM）で行う
    if not cfg.get("cloud.review", True) and is_review_request(a):
        return await _fallback(ctx, "レビュー（添削・チェック）に外部 AI を使わない設定です（左のパネルの「☁ レビューも外部 AI」がオフ）",
                               goal, error, prompt)
    # v2.11.45: クラウド相談が失敗したら（設定の不備・API のエラー・通信の失敗など）、Web 検索 → メイン LLM の順に代わりを試す
    if not s.ready:
        return await _fallback(ctx, "クラウド相談の設定が不完全です（プロバイダ・モデル・API キーを確認してください）",
                               goal, error, prompt)
    try:
        answer = await CloudClient(s).ask(ASK_SYSTEM, prompt, max_tokens=int(cfg.get("cloud.max_tokens", 16000)))
    except Exception as e:  # noqa: BLE001
        return await _fallback(ctx, f"クラウド相談に失敗: {e}", goal, error, prompt)
    head = f"[クラウド相談: {s.describe()} / 送信 {len(prompt):,} 文字" + (f", 秘密情報 {masked} 件をマスク" if masked else "") + "]\n"
    tail = ("\n\n（上記はヒントです。そのまま信用せず、確認方法を実行して裏を取り、修正後は必ずテストで検証してください。"
            "解決したら原因と対処を save_memory に「（参考: クラウド相談）」を付けて保存してください）")
    return head + answer + tail


# v2.11.53: 相談の中身がレビューか（スキルの「クラウド添削」「送信前の最終チェック」など）。purpose: "review" でも明示できる
REVIEW_RE = re.compile(r"添削|校正|推敲|レビュー|最終チェック|最終確認|誤字|文法(を|の)?(確認|チェック)|直して|チェックして|"
                       r"\b(review|proofread|critique|feedback on (my|the) (draft|text|code))\b", re.I)


def is_review_request(a: dict) -> bool:
    if str(a.get("purpose") or "").lower() == "review":
        return True
    if str(a.get("purpose") or "").lower() == "consult":
        return False
    return bool(REVIEW_RE.search(" ".join(str(a.get(k) or "") for k in ("goal", "question"))))


# v2.11.45: クラウド相談の代わり（Web 検索 → メイン LLM）
_ERR_LINE = re.compile(r"(Traceback|Error|Exception|error:|ERROR|FAILED|No such file|not found|denied|undefined|cannot|failed)", re.I)


def _search_query(goal: str, error: str) -> str:
    """Web 検索の語: エラー文らしい行があればその最後の行（パスは除く）、無ければ目的の先頭。"""
    lines = [ln.strip() for ln in (error or "").splitlines() if _ERR_LINE.search(ln) and len(ln.strip()) > 8]
    q = lines[-1] if lines else (goal or "").strip().splitlines()[0] if (goal or "").strip() else ""
    return re.sub(r"\s+", " ", re.sub(r"(/[\w.\-]+)+", " ", q)).strip()[:150]


async def _fallback(ctx: ToolContext, reason: str, goal: str, error: str, prompt: str) -> str:
    """クラウド相談が使えなかったとき: ① Web 検索（cloud.fallback_web）② メイン LLM に同じ相談（cloud.fallback_local）。
    どちらも使えなければ、元の失敗をエラーとして返す。"""
    cfg = ctx.cfg
    notes = [reason]
    if cfg.get("cloud.fallback_web", True) and cfg.get("web.enabled", True):
        from . import get as _get
        tool = _get("web_search")
        q = _search_query(goal, error)
        if tool is not None and q:
            try:
                res = await tool.handler(ctx, {"query": q})
            except Exception as e:  # noqa: BLE001
                res = ""
                notes.append(f"Web 検索に失敗: {str(e).splitlines()[0][:200]}")
            if res and "\n1. " in res:
                vs = ctx.verify
                if vs is not None:
                    vs.web_calls = int(getattr(vs, "web_calls", 0) or 0) + 1
                return (f"[{reason[:300]} → 代わりに Web で検索しました]\n" + res[:4000]
                        + "\n\n（クラウド AI の助言ではなく検索結果です。関係のありそうな結果は fetch_url で読み、"
                          "書かれていることを確かめてから試してください）")
            if res and "\n1. " not in res:
                notes.append("Web 検索: 結果なし")
    if cfg.get("cloud.fallback_local", True) and ctx.complete is not None:
        try:
            answer = (await ctx.complete(ASK_SYSTEM, prompt) or "").strip()
        except Exception as e:  # noqa: BLE001
            answer = ""
            notes.append(f"メイン LLM での検討に失敗: {str(e).splitlines()[0][:200]}")
        if answer:
            return (f"[{' / '.join(n[:200] for n in notes)} → 代わりにメイン LLM が相談内容を検討しました]\n" + answer
                    + "\n\n（クラウド AI ではなくメイン LLM（自分自身）の考えです。新しい情報は含まれないので、"
                      "仮説を 1 つずつ確認方法で確かめ、修正後は必ずテストで検証してください）")
    raise ToolError(" / ".join(notes))


async def cloud_review(ctx: ToolContext, a: dict) -> str:
    """v2.11.14: クラウド AI に、指定したファイルのコードレビューを頼む（最終レビュー用のモデル）。"""
    from ..cloud import (REVIEW_DELTA, REVIEW_FOLLOWUP, REVIEW_SYSTEM, apply_followup, build_delta_section, build_followup_section,
                         build_review_prompt, delta_enabled, format_issue, open_review_issues, parse_review_json, use_delta)
    from ..prompts import prompt_language
    cfg = ctx.cfg
    if not cfg.get("cloud.enabled", False):
        raise ToolError("クラウド AI は無効です（「設定」→「☁ クラウド AI の設定」で API キーを設定し、左のパネルの「☁ クラウド AI」をオンにしてください）")
    local = not cfg.get("cloud.review", True)   # v2.11.53: 「☁ レビューも外部 AI」がオフ → 外部に送らず、ローカルの LLM がレビューする
    s = CloudSettings.from_cfg(cfg, "review")
    if not local and not s.ready:
        raise ToolError("クラウド AI の設定が不完全です（プロバイダ・モデル・API キーを確認してください）")
    if local and ctx.complete is None:
        raise ToolError("レビューに外部 AI を使わない設定です（左のパネルの「☁ レビューも外部 AI」がオフ）。"
                        "完了前の最終レビューは AperCode がローカルの LLM で行います")
    vs = ctx.verify
    limit = int(cfg.get("cloud.review_max_per_turn", 3))
    used = int(getattr(vs, "cloud_review_calls", 0) or 0) if vs is not None else 0
    if not local and used >= limit:
        raise ToolError(f"このターンのクラウド AI のレビューは上限（{limit} 回）に達しました。指摘を直した結果は、完了前の最終レビューで確かめられます")
    files = a.get("files") or []
    if isinstance(files, str):
        files = [f for f in files.split(",") if f.strip()]
    if not files:
        raise ToolError("files（レビューするファイル）を 1 つ以上指定してください")
    contents: dict[str, str] = {}
    for f in files[:8]:
        import re as _re
        p = ctx.resolve(_re.sub(r":\d+-\d+$", "", str(f)))
        if not p.is_file():
            raise ToolError(f"ファイルがありません: {f}")
        try:                                     # v2.11.16: 確認なしで送るので、作業ディレクトリの中のファイルだけにする
            p.resolve().relative_to(Path(ctx.project_dir).resolve())
        except ValueError:
            raise ToolError(f"作業ディレクトリの外のファイルはレビューに送れません: {f}")
        raw = p.read_bytes()
        txt = raw.decode("utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else raw.decode("utf-8", errors="replace")
        try:
            rel = str(p.relative_to(ctx.project_dir))
        except ValueError:
            rel = str(p)
        contents[rel] = txt
    task = str(a.get("task") or "").strip() or "(未記入)"
    if a.get("focus"):
        task += "\n\n## 特に見てほしい点\n" + str(a["focus"]).strip()
    maxc = int(cfg.get("verify.review.cloud_max_chars", 60000) or 60000)
    if local:
        return await _local_review(ctx, task, contents, min(maxc, 40000))
    prompt = build_review_prompt(task, "(差分ではなく、下のファイル全体をレビューする)", contents, maxc)
    # v2.11.20: このターンで 2 回目以降のクラウド AI のレビューなら、前回の指摘が直ったかの確認と、新しい high・medium だけを求める
    followup = followup_mode(cfg, vs)
    prev_all = list(getattr(vs, "review_open", None) or []) if followup else []
    prev = [i for i in prev_all if str(i.get("file") or "") in contents]      # 今回送るファイルの指摘だけを確かめる
    keep = [i for i in prev_all if i not in prev]
    # v2.11.55: 2 回目以降は、前回のレビュー以降に変わった部分（＋前回の指摘の周辺）だけを送る
    snap = dict(getattr(vs, "review_snapshot", None) or {}) if vs is not None else {}
    delta = False
    if followup and snap and delta_enabled(cfg):
        dprompt = f"## Task\n{task[:3000]}\n\n" + build_delta_section(snap, contents, prev, max_chars=maxc)
        if use_delta(prompt, dprompt):
            prompt, delta = dprompt, True
    if followup:
        prompt += "\n\n" + build_followup_section(prev) if prev else "\n\n## Previous findings\n(none for these files)"
    masked = 0
    if cfg.get("cloud.mask_secrets", True):
        prompt, masked = mask_secrets(prompt)
    if vs is not None:
        vs.cloud_review_calls = used + 1
    system = REVIEW_SYSTEM.replace("{lang}", "English" if prompt_language() == "en" else "Japanese")
    if followup:
        system += REVIEW_FOLLOWUP + (REVIEW_DELTA if delta else "")
    try:
        text = await CloudClient(s).ask(system, prompt, max_tokens=int(cfg.get("cloud.max_tokens", 16000)))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"クラウド AI のレビューに失敗: {e}")
    data = parse_review_json(text)
    head = (f"[クラウド AI のレビュー" + ("（2 回目以降: 前回の指摘の確認＋新しい high・medium）" if followup else "")
            + f": {s.describe()} / 送信 {len(prompt):,} 文字" + ("（前回のレビュー以降の変更だけ）" if delta else "") + (f", 秘密情報 {masked} 件をマスク" if masked else "") + "]\n")
    if data is None:
        return head + text[-6000:] + "\n\n（決まった形の結果を読み取れませんでした。上の文章から指摘を読み取ってください）"
    fixed_note = ""
    if followup:
        data = apply_followup(data, prev)
        new = data["new_issues"]
        fixed_note = f"前回の指摘 {len(prev)} 件のうち {len(data['fixed'])} 件は修正済み。"
    else:
        new = data["issues"]
    issues = data["issues"]
    if vs is not None:
        vs.cloud_reviews_done = int(getattr(vs, "cloud_reviews_done", 0) or 0) + 1
        vs.review_open = keep + open_review_issues(issues)
        vs.review_snapshot = {**snap, **contents}
    if not issues:
        return head + fixed_note + "指摘なし（ok: " + str(data.get("ok")) + "）"
    body = "\n".join(format_issue(i) for i in issues)
    # v2.11.17: 指摘を確認済みの教訓として経験メモリに保存する（次の作業から参照される。前回の指摘は保存済みなので新しいものだけ）
    from ..review_memory import save_review_lessons
    saved = await save_review_lessons(getattr(ctx, "memory", None), cfg, new, ctx.project_dir, s.model, task) if new else []
    note = f"\n（指摘 {len(saved)} 件を確認済みの教訓として経験メモリに保存しました）" if saved else ""
    return (head + fixed_note + f"指摘 {len(issues)} 件（ok: {data.get('ok')}）\n{body}\n\n"
            "（妥当な指摘は直し、コンパイル・テストで確かめる。妥当でない指摘は理由を完了報告に書く）" + note)


async def _local_review(ctx: ToolContext, task: str, contents: dict[str, str], maxc: int) -> str:
    """v2.11.53: 「☁ レビューも外部 AI」がオフのときの cloud_review。同じレビューの指示で、ローカルの LLM（メイン LLM）がレビューする。
    外部には何も送らない。指摘は確認済みの教訓としては保存しない（ローカルの LLM の判断のため）。"""
    from ..cloud import REVIEW_SYSTEM, build_review_prompt, format_issue, parse_review_json
    from ..prompts import prompt_language
    prompt = build_review_prompt(task, "(差分ではなく、下のファイル全体をレビューする)", contents, maxc)
    system = REVIEW_SYSTEM.replace("{lang}", "English" if prompt_language() == "en" else "Japanese")
    try:
        text = (await ctx.complete(system, prompt) or "").strip()
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"ローカルの LLM のレビューに失敗: {str(e).splitlines()[0][:200]}")
    head = "[ローカルの LLM のレビュー（「☁ レビューも外部 AI」がオフのため、外部 AI には送っていません）]\n"
    data = parse_review_json(text)
    if data is None:
        return head + text[-6000:] + "\n\n（決まった形の結果を読み取れませんでした。上の文章から指摘を読み取ってください）"
    issues = data.get("issues") or []
    if not issues:
        return head + "指摘なし（ok: " + str(data.get("ok")) + "）"
    body = "\n".join(format_issue(i) for i in issues)
    return (head + f"指摘 {len(issues)} 件（ok: {data.get('ok')}）\n{body}\n\n"
            "（ローカルの LLM の指摘です。妥当なものは直して確かめ、妥当でないものは理由を完了報告に書く）")


def followup_mode(cfg, vs) -> bool:
    """v2.11.20: このターンで既にクラウド AI のレビューを受けていて、2 回目以降の絞り込みが有効か。"""
    if vs is None or not int(getattr(vs, "cloud_reviews_done", 0) or 0):
        return False
    return str((cfg.get("verify.review", {}) or {}).get("followup", True)).lower() not in ("off", "false", "0")


register(Tool(
    "cloud_review",
    "クラウド AI（最終レビュー用のモデル）に、指定したファイルのコードレビューを頼む。バグ・ロジックの誤り・要件の取りこぼし・"
    "セキュリティ・リソースの扱い（EA なら注文・SL/TP・ポジション管理・確定足・ハンドル）を見て、指摘を返す。"
    "ユーザーが「クラウド AI でレビュー」を求めたとき、作ったコードを完成前に確かめたいときに使う（行き詰まりの相談は ask_cloud）。",
    {"type": "object", "properties": {
        "files": {"type": "array", "items": {"type": "string"}, "description": "レビューするファイル（最大 8。ファイル全体を送る）"},
        "task": {"type": "string", "description": "何を作ったか・満たすべき要件（ユーザーの依頼の要点）"},
        "focus": {"type": "string", "description": "特に見てほしい点（任意）"}},
     "required": ["files", "task"]},
    cloud_review,
    lambda a: f"{', '.join(str(x) for x in (a.get('files') or [])[:4])} / {str(a.get('task', ''))[:50]}"))


register(Tool(
    "ask_cloud",
    "クラウドの強い AI に相談してヒントをもらう。行き詰まったとき、アイデアが尽きたとき、Web 検索で十分な情報が得られないとき、"
    "ユーザーがクラウド AI との相談を求めたときに使う（失敗や Web の調査が一定回数に達するまでは使えない。ユーザーが求めたときはすぐ使える）。"
    "会話全体ではなく、目的・エラー（または調べたこと）・試したこと・関連コードの抜粋だけを送る。返ってくるのは仮説と案であり、実装と検証は自分で行う。"
    "コードのレビューを頼むときは cloud_review を使う（レビュー用のモデルが使われる）。",
    {"type": "object", "properties": {
        "goal": {"type": "string", "description": "何を実現しようとしているか（1〜3 文）"},
        "error": {"type": "string", "description": "エラー全文・スタックトレース・症状（情報やアイデアの相談なら、調べて分かったこと・足りないこと）"},
        "tried": {"type": "string", "description": "試したことと、それぞれの結果（必須）"},
        "files": {"type": "array", "items": {"type": "string"},
                  "description": "関連ファイル（最大 6。'path' または 'path:開始行-終了行'。先頭 200 行までが送られる）"},
        "question": {"type": "string", "description": "特に聞きたいこと（任意）"},
        "purpose": {"type": "string", "enum": ["consult", "review"],
                    "description": "consult = 行き詰まり・情報の相談（既定）/ review = 文章の添削・最終チェック・コードのレビュー"}},
     "required": ["goal", "tried"]},
    ask_cloud,
    lambda a: f"{str(a.get('goal',''))[:60]} / files={len(a.get('files') or [])}"))
