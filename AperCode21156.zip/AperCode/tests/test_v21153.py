"""v2.11.53 の回帰テスト: 「☁ レビューも外部 AI」がオフなら、スキルの「クラウド添削」「最終チェック」も外部 AI に送らない。"""
from __future__ import annotations

import uuid

from codeagent import cloud as C
from codeagent import tools as T
from codeagent.tools import cloud_tools as CT

CLOUD = {"cloud.enabled": True, "cloud.provider": "anthropic", "cloud.model": "claude-test", "cloud.api_key": "sk-test",
         "phases.enabled": False, "permissions.ask_cloud": "allow", "security.taint_guard": False, "security.ask_on_injection": False}


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def test_review_request_detection():
    assert CT.is_review_request({"goal": "X の返信の下書きを添削してほしい"})
    assert CT.is_review_request({"goal": "投稿文", "question": "送信前の最終チェックをお願いします"})
    assert CT.is_review_request({"goal": "x", "purpose": "review"})
    assert not CT.is_review_request({"goal": "pytest が ImportError で落ちる原因を知りたい"})
    assert not CT.is_review_request({"goal": "下書きを添削", "purpose": "consult"})       # 明示が優先


def _setup(h, monkeypatch, review: bool):
    sent, queries = [], []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        sent.append(prompt)
        return "クラウドの回答"
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)

    async def web(ctx, a):
        queries.append(a["query"])
        return f"検索: {a['query']}\n1. 結果\n   https://example.com/x\n   説明"
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", web)
    return sent, queries, {**CLOUD, "cloud.review": review}


def test_proofreading_does_not_go_to_cloud_when_off(h, monkeypatch):
    sent, queries, over = _setup(h, monkeypatch, review=False)
    proj = h.project(with_test=False)
    ask = call("ask_cloud", goal="X の返信の下書きを添削してほしい", tried="下書きを書いた", question="文法と自然さをチェックして")
    agent, llm, store, s = h.make([("tools", [ask]), ("text", "完了")], proj, over)
    h.run(agent, s, "返信文をクラウドAIと相談して作って")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "ask_cloud"][0]
    assert not sent and queries                                               # 外部 AI には送らず Web 検索（→ 駄目ならメイン LLM）
    assert "レビュー（添削・チェック）に外部 AI を使わない設定" in out and "代わりに Web で検索しました" in out


def test_consultation_still_goes_to_cloud_when_off(h, monkeypatch):
    sent, queries, over = _setup(h, monkeypatch, review=False)
    proj = h.project(with_test=False)
    ask = call("ask_cloud", goal="pytest が ImportError で落ちる原因を知りたい", tried="パスを確認した")
    agent, llm, store, s = h.make([("tools", [ask]), ("text", "完了")], proj, over)
    h.run(agent, s, "クラウドAIと相談して直して")
    assert len(sent) == 1 and not queries                                     # 相談は「☁ クラウド AI」のとおり外部 AI へ


def test_proofreading_goes_to_cloud_when_on(h, monkeypatch):
    sent, queries, over = _setup(h, monkeypatch, review=True)
    proj = h.project(with_test=False)
    ask = call("ask_cloud", goal="X の返信の下書きを添削してほしい", tried="下書きを書いた")
    agent, llm, store, s = h.make([("tools", [ask]), ("text", "完了")], proj, over)
    h.run(agent, s, "返信文をクラウドAIと相談して作って")
    assert len(sent) == 1                                                     # オンならこれまでどおり
