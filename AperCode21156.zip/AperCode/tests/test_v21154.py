"""v2.11.54 の回帰テスト: Anthropic のプロンプトキャッシュが途中で切れないようにする。
- 古いツール結果の短縮を 8 件ごとにまとめ、呼ぶたびに履歴の途中を変えない
- システムプロンプトを固定部分（キャッシュする）と変化部分（作業の指示書・作業フェーズ）に分ける"""
from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

import httpx

from codeagent.agent import Agent
from codeagent.llm import LLMClient, SplitSystem

KEY = "sk-test-secret-987654"


class _Cfg(dict):
    def get(self, k, d=None):
        return super().get(k, d)


def _agent(provider: str, extra: dict | None = None):
    a = Agent.__new__(Agent)
    a.cfg = _Cfg(extra or {})
    a.llm = SimpleNamespace(provider=provider)
    return a


def _msgs(n_tools: int) -> list[dict]:
    out: list[dict] = [{"role": "user", "content": "依頼"}]
    for k in range(n_tools):
        out.append({"role": "assistant", "content": "", "tool_calls": [{"id": f"t{k}", "name": "read_file", "args": {}}]})
        out.append({"role": "tool", "tool_call_id": f"t{k}", "content": f"{k}:" + "x" * 3000})
    return out


def _short(hist: list[dict]) -> list[bool]:
    return [m["content"].endswith("...(省略)") for m in hist if m["role"] == "tool"]


def test_trim_is_stable_for_anthropic():
    a = _agent("anthropic")
    # 履歴が 1 往復ずつ伸びても、前回送った部分（先頭からの並び）は変わらない
    for n in range(7, 30):
        prev = a._history(_msgs(n))
        cur = a._history(_msgs(n + 1))
        same = sum(1 for x, y in zip(prev, cur) if x == y)
        changed = len(prev) - same
        if changed:
            # 変わるのは 8 件ごとの区切りのときだけ
            assert (n + 1 - 6) % 8 == 0, (n, changed)
    s = _short(a._history(_msgs(20)))          # 20 件 → 短縮は先頭 8 件（20-6=14 → 8）
    assert s == [True] * 8 + [False] * 12
    assert a._trim_cut(20) == 8 and a._trim_cut(22) == 16 and a._trim_cut(6) == 0


def test_trim_unchanged_for_local_llm():
    a = _agent("openai")                        # Strata・Ollama はこれまでどおり（直近 6 件以外を短縮）
    assert _short(a._history(_msgs(20))) == [True] * 14 + [False] * 6
    a = _agent("anthropic", {"llm.history_trim_step": 1})
    assert _short(a._history(_msgs(20))) == [True] * 14 + [False] * 6


def test_estimate_matches_trim():
    a = _agent("anthropic", {"compaction.chars_per_token": 1.0})
    m = _msgs(20)
    est = a._estimate_tokens(m)
    sent = sum(min(len(x["content"]), 1510) if s else len(x["content"])
               for x, s in zip([x for x in m if x["role"] == "tool"], _short(a._history(m))))
    assert est >= sent


def _llm():
    llm = LLMClient.__new__(LLMClient)
    cfg = _Cfg({})
    llm.cfg = cfg
    llm.endpoint = {"id": "c"}
    llm.base_url = "https://api.anthropic.com"
    llm.provider = "anthropic"
    llm._ep_headers = {"x-api-key": KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    llm.num_predict = 0
    llm.temperature = 0.2
    llm.model = "claude-x"
    llm.retries = 0
    return llm


def test_split_system_caches_only_stable_part():
    llm = _llm()
    seen = {}

    def handler(req: httpx.Request):
        seen["body"] = json.loads(req.content)
        return httpx.Response(200, json={"content": [{"type": "text", "text": "OK"}],
                                         "usage": {"input_tokens": 5, "output_tokens": 1}})
    llm._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    msgs = [{"role": "user", "content": "一つ目"}]

    def run(system):
        async def go():
            return [ev async for ev in llm._chat_anthropic(system, msgs, [], "claude-x")]
        return asyncio.run(go())

    sp = SplitSystem("固定指示書フェーズ", "固定", "指示書フェーズ")
    assert sp == "固定指示書フェーズ" and isinstance(sp, str)          # ローカル LLM にはこれまでどおりの文字列
    run(sp)
    assert seen["body"]["system"] == [{"type": "text", "text": "固定", "cache_control": {"type": "ephemeral"}},
                                      {"type": "text", "text": "指示書フェーズ"}]
    assert json.dumps(seen["body"]).count("cache_control") <= 4
    run(SplitSystem("固定", "固定", ""))                                  # 変化部分が無ければ 1 ブロック
    assert seen["body"]["system"] == [{"type": "text", "text": "固定", "cache_control": {"type": "ephemeral"}}]
    llm.base_url = "http://10.0.0.3:8080"                                   # 互換サーバーには付けない
    run(sp)
    assert seen["body"]["system"] == "固定指示書フェーズ"


def test_system_with_brief_keeps_text_and_splits():
    a = _agent("anthropic")
    st = SimpleNamespace(system="SYS")
    a._system_brief_only = lambda st: st.system + "[指示書]"
    a._time_block = lambda: "[日付]"
    a._skills_block = lambda st: "[スキル]"
    a._mt5_block = lambda st: "[MT5]"
    a._cloud_block = lambda st: "[クラウド]"
    a._phase_block = lambda st: "[フェーズ]"
    a._chat_block = lambda st: "[会話]"
    s = Agent._system_with_brief(a, st)
    assert s == "SYS[指示書][日付][スキル][MT5][クラウド][フェーズ][会話]"      # これまでと同じ文字列
    assert s.stable == "SYS[日付][スキル][MT5][クラウド][会話]" and s.dynamic == "[指示書][フェーズ]"
