"""v2.11.56 の回帰テスト: OpenAI 互換 API（Strata など）にも、Ollama と同じ作業ごとの設定（思考・温度・top_p・top_k）を送る。"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import httpx

from codeagent import sampling as SM

ROOT = Path(__file__).resolve().parents[1]


class _Cfg:
    def __init__(self, d):
        self.d = d

    def get(self, k, default=None):
        return self.d.get(k, default)


def _llm():
    from codeagent.config import Config
    from codeagent.llm import LLMClient
    cfg = Config.load(ROOT / "config.yaml" if (ROOT / "config.yaml").exists() else ROOT / "config.example.yaml")
    cfg.data.setdefault("llm", {})["base_url"] = "http://127.0.0.1:9"
    llm = LLMClient(cfg)
    llm.use_endpoint({"id": "s", "name": "Strata", "type": "openai", "url": "http://10.0.0.3:8080/v1", "api_key": "x"}, "q")
    return llm


def _sse(text="OK"):
    body = f"data: {json.dumps({'choices': [{'delta': {'content': text}}]})}\n\ndata: [DONE]\n\n"
    return httpx.Response(200, text=body, headers={"content-type": "text/event-stream"})


def _run(llm, options=None, think=None):
    async def go():
        return [ev async for ev in llm.chat("SYS", [{"role": "user", "content": "hi"}], [], None, options, think)]
    return asyncio.run(go())


def test_call_args_for_openai():
    opts, think = SM.call_args(_Cfg({}), "execute", "openai")
    assert think == "off" and opts["temperature"] == 0.2 and opts["top_k"] == 20
    opts, think = SM.call_args(_Cfg({}), "code", "openai")
    assert think == "on" and opts["temperature"] == 0.6
    assert SM.call_args(_Cfg({}), "code", "anthropic") == (None, None)


def test_openai_sends_profile_and_thinking():
    llm = _llm()
    bodies = []

    def handler(req):
        bodies.append(json.loads(req.content))
        return _sse()
    llm._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    evs = _run(llm, {"temperature": 0.2, "top_p": 0.8, "top_k": 20, "repeat_penalty": 1.05}, "off")
    b = bodies[-1]
    assert b["temperature"] == 0.2 and b["top_p"] == 0.8 and b["top_k"] == 20 and b["repetition_penalty"] == 1.05
    assert b["chat_template_kwargs"] == {"enable_thinking": False}
    assert ("text", "OK") in evs
    _run(llm, {"temperature": 0.6}, "on")
    assert bodies[-1]["chat_template_kwargs"] == {"enable_thinking": True} and "top_k" not in bodies[-1]
    _run(llm, None, None)                                              # 指定なし → 思考はサーバーの既定
    assert "chat_template_kwargs" not in bodies[-1]


def test_openai_drops_extras_when_rejected():
    llm = _llm()
    bodies = []

    def handler(req):
        b = json.loads(req.content)
        bodies.append(b)
        if "top_k" in b or "chat_template_kwargs" in b:
            return httpx.Response(400, json={"error": {"message": "Unrecognized request argument: top_k"}})
        return _sse()
    llm._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    evs = _run(llm, {"temperature": 0.6, "top_p": 0.95, "top_k": 20}, "on")
    assert ("text", "OK") in evs and len(bodies) == 2
    assert "top_k" not in bodies[1] and "chat_template_kwargs" not in bodies[1] and bodies[1]["top_p"] == 0.95
    _run(llm, {"temperature": 0.6, "top_k": 20}, "on")                  # 以後は最初から送らない
    assert len(bodies) == 3 and "top_k" not in bodies[2]


def test_openai_extras_can_be_disabled():
    llm = _llm()
    llm.cfg.data["llm"]["openai_extras"] = False
    bodies = []

    def handler(req):
        bodies.append(json.loads(req.content))
        return _sse()
    llm._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    _run(llm, {"temperature": 0.6, "top_k": 20}, "off")
    assert "top_k" not in bodies[0] and "chat_template_kwargs" not in bodies[0] and bodies[0]["temperature"] == 0.6
