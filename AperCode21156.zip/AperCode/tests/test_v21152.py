"""v2.11.52 の回帰テスト: 左のパネルの「☁ レビューも外部 AI」スイッチ。オフならレビューに外部 AI を使わない（相談は使える）。"""
from __future__ import annotations

import asyncio
import json
import uuid
from pathlib import Path

from codeagent import cloud as C
from codeagent import skill_review as SR
from codeagent import skills as SK

ROOT = Path(__file__).resolve().parents[1]
CLOUD = {"cloud.enabled": True, "cloud.provider": "anthropic", "cloud.model": "claude-test", "cloud.api_key": "sk-test"}


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def test_review_switch_off_uses_local_review_and_hides_cloud_review(h, monkeypatch):
    sent = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        sent.append(system)
        return '{"ok": true, "issues": []}'
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False)
    py = "".join(f"V{i} = {i}\n" for i in range(80))
    over = {**CLOUD, "phases.enabled": False, "verify.create_missing_tests": False, "verify.review.enabled": True, "cloud.review": False}
    script = [("tools", [call("write_file", path="big.py", content=py)]), ("text", "完了"), ("text", "完了"), ("text", "完了")]
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "big.py を作って")
    assert not sent                                                         # 外部 AI には送らない
    assert [e for e in h.of("subagent_start") if e.get("mode") == "review"]  # 最終レビューはローカル（サブ LLM）
    assert "ask_cloud" in llm.toolsets[0]                                    # 相談は使える
    assert "レビューにはクラウド AI を使わない設定" in llm.systems[0]          # v2.11.53: cloud_review はローカルの LLM が代わりに行う


def test_review_switch_on_keeps_cloud_review(h, monkeypatch):
    sent = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        sent.append(system)
        return '{"ok": true, "issues": []}'
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False)
    over = {**CLOUD, "phases.enabled": False, "verify.create_missing_tests": False, "verify.review.enabled": True}
    script = [("tools", [call("write_file", path="a.py", content="x = 1\n")]), ("text", "完了"), ("text", "完了")]
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "a.py を作って")
    assert len(sent) == 1 and "cloud_review" in llm.toolsets[0]


def test_cloud_review_tool_is_local_when_off(h, monkeypatch):
    sent = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        sent.append(system)
        return '{"ok": true, "issues": []}'
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False, files={"a.py": "x = 1\n"})
    over = {**CLOUD, "phases.enabled": False, "cloud.review": False}
    agent, llm, store, s = h.make([("tools", [call("cloud_review", files=["a.py"], task="t")]), ("text", "完了")], proj, over)
    h.run(agent, s, "クラウドAIでレビューして")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "cloud_review"]
    assert out and "ローカルの LLM のレビュー" in out[0] and not sent        # v2.11.53: 外部には送らずローカルでレビュー


class _Cfg:
    def __init__(self, d, **extra):
        self.data = {"skills": {"dir": str(d), "review": {"enabled": True, "llm": True}}, "cloud": {"enabled": True}}
        for k, v in extra.items():
            cur = self.data
            ks = k.split(".")
            for x in ks[:-1]:
                cur = cur.setdefault(x, {})
            cur[ks[-1]] = v

    def get(self, k, default=None):
        cur = self.data
        for x in k.split("."):
            if not isinstance(cur, dict) or x not in cur:
                return default
            cur = cur[x]
        return cur


def test_skill_review_skips_cloud_when_off(tmp_path, monkeypatch):
    cfg = _Cfg(tmp_path / "skills", **{"cloud.review": False})
    SK.save(cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", "# 投稿\n\n## 手順\n1. 本文を作る\n2. 確認する\n3. 投稿する\n")
    asked = []

    class FakeS:
        ready = True

        def describe(self):
            return "クラウド（テスト）"

    class FakeClient:
        def __init__(self, s):
            pass

        async def ask(self, system, prompt, max_tokens=0):
            asked.append(system)
            return "{}"
    monkeypatch.setattr(C.CloudSettings, "from_cfg", classmethod(lambda cls, cfg, role="": FakeS()))
    monkeypatch.setattr(C, "CloudClient", FakeClient)
    ok = json.dumps({"verdict": "ok", "summary": "まとめ", "issues": [], "questions": []}, ensure_ascii=False)

    async def complete(system, text):
        return '["X 投稿 上限"]' if "検索語" in system else ok

    async def search(q):
        return "1. X の投稿の決まり"
    r = asyncio.run(SR.review(cfg, "x-post", complete=complete, search=search, stage="confirm"))
    assert not asked and r["confirm"]["via"] == "web"                       # Web 検索＋メイン LLM（これまでの代わりの順）


def test_switch_api_without_password(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from codeagent.config import Config
    from codeagent.server import app as APP
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    cfg = Config.load(ROOT / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    c = TestClient(APP.create_app(cfg))
    assert c.get("/api/cloud").json()["review"] is True                      # 既定はオン（これまでどおり）
    v = c.post("/api/cloud", json={"review": False}).json()                  # 左のパネルのスイッチ: パスワード不要
    assert v["review"] is False and cfg.get("cloud.review") is False
    assert "review: false" in (tmp_path / "user.yaml").read_text()
    html = (ROOT / "codeagent" / "server" / "static" / "index.html").read_text(encoding="utf-8")
    assert 'id="review-on"' in html and "JSON.stringify({review:on})" in html
