"""v2.11.55 の回帰テスト: 同じタスクでクラウド AI のレビューを繰り返すとき、2 回目以降は前回のレビュー以降に
変わった部分（＋前回の指摘の周辺）だけを送る。"""
from __future__ import annotations

import asyncio
import uuid

from codeagent import cloud as C
from codeagent import skill_review as SR

CLOUD = {"cloud.enabled": True, "cloud.provider": "anthropic", "cloud.model": "claude-test", "cloud.api_key": "sk-test",
         "phases.enabled": False, "memory.review_lessons": "off"}
BIG = "".join(f"def f{i}():\n    return {i}\n\n" for i in range(300))          # 約 900 行
REPLY1 = '{"ok": false, "issues": [{"file": "a.py", "line": 5, "severity": "high", "problem": "P1", "fix": "F1"}]}'
REPLY2 = '{"ok": true, "previous": [{"id": 1, "status": "fixed"}], "issues": []}'


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def test_delta_section():
    old = BIG
    new = BIG.replace("return 150\n", "return 151\n")
    body = C.build_delta_section({"a.py": old, "b.py": "x = 1\n"}, {"a.py": new, "b.py": "x = 1\n", "c.py": "y = 2\n"},
                                 [{"file": "a.py", "line": 600, "severity": "high", "problem": "P"}])
    assert "-    return 150" in body and "+    return 151" in body
    assert "return 3\n" not in body                                  # 変わっていない遠い部分は送らない
    assert "b.py" not in body                                        # 変わっていないファイルは送らない
    assert "New file since the previous review: c.py" in body and "y = 2" in body
    assert "a.py (lines 585-615, current)" in body                    # 前回の指摘の周辺
    assert len(body) < len(new) / 5
    assert "(none: no file changed)" in C.build_delta_section({"a.py": "x"}, {"a.py": "x"}, [])
    assert C.use_delta("x" * 100, "x" * 50) and not C.use_delta("x" * 100, "x" * 90)


def _ask_recorder(monkeypatch):
    sent = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        sent.append((system, prompt))
        return REPLY1 if len(sent) == 1 else REPLY2
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    return sent


def test_cloud_review_second_call_sends_only_changes(h, monkeypatch):
    sent = _ask_recorder(monkeypatch)
    proj = h.project(with_test=False, files={"a.py": BIG})
    fixed = BIG.replace("return 1\n", "return 100\n", 1)
    script = [("tools", [call("cloud_review", files=["a.py"], task="T")]),
              ("tools", [call("write_file", path="a.py", content=fixed)]),
              ("tools", [call("cloud_review", files=["a.py"], task="T")]), ("text", "done")]
    agent, _llm, _store, s = h.make(script, proj, {**CLOUD, "permissions.cloud_review": "allow", "security.taint_guard": False,
                                                 "verify.enabled": False})
    h.run(agent, s, "レビューして")
    assert len(sent) == 2
    assert "return 299" in sent[0][1]                                 # 1 回目は全体
    assert "Changes since the previous review" in sent[1][1] and "+    return 100" in sent[1][1]
    assert "return 299" not in sent[1][1]                             # 2 回目は変わった部分だけ
    assert "1. [high] a.py:5 P1" in sent[1][1]                         # 前回の指摘は確かめる
    assert "FOLLOW-UP" in sent[1][0] and "Only the changes since the previous review" in sent[1][0]
    assert len(sent[1][1]) < len(sent[0][1]) / 5
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "cloud_review"][1]
    assert "前回のレビュー以降の変更だけ" in out


def test_cloud_delta_off_sends_everything(h, monkeypatch):
    sent = _ask_recorder(monkeypatch)
    proj = h.project(with_test=False, files={"a.py": BIG})
    script = [("tools", [call("cloud_review", files=["a.py"], task="T")]),
              ("tools", [call("cloud_review", files=["a.py"], task="T")]), ("text", "done")]
    agent, _llm, _store, s = h.make(script, proj, {**CLOUD, "permissions.cloud_review": "allow", "security.taint_guard": False,
                                                 "verify.enabled": False, "verify.review": {"cloud_delta": False}})
    h.run(agent, s, "レビューして")
    assert len(sent) == 2 and "return 299" in sent[1][1] and "Only the changes" not in sent[1][0]


def test_final_review_after_cloud_review_sends_only_changes(h, monkeypatch):
    sent = _ask_recorder(monkeypatch)
    proj = h.project(with_test=False)
    fixed = BIG.replace("return 1\n", "return 100\n", 1)
    script = [("tools", [call("write_file", path="a.py", content=BIG)]),
              ("tools", [call("cloud_review", files=["a.py"], task="T")]),
              ("tools", [call("write_file", path="a.py", content=fixed)]),
              ("text", "完了しました"), ("text", "報告します")]
    agent, _llm, _store, s = h.make(script, proj, {**CLOUD, "permissions.cloud_review": "allow", "security.taint_guard": False,
                                                 "verify.create_missing_tests": False, "verify.review.enabled": True})
    h.run(agent, s, "コードを書いて")
    assert len(sent) >= 2
    assert "Changes since the previous review" in sent[1][1] and "+    return 100" in sent[1][1]
    assert "return 299" not in sent[1][1]
    assert [e for e in h.of("info") if "前回のレビュー以降の変更だけ" in e.get("text", "")]


class _Cfg(dict):
    def get(self, k, d=None):
        return super().get(k, d)


def test_skill_confirm_review_sends_only_changes(tmp_path, monkeypatch):
    folder = tmp_path / "x-post"
    folder.mkdir()
    md = "---\nname: x-post\ndescription: d\n---\n" + "".join(f"## 節 {i}\n手順 {i} を行う。\n\n" for i in range(400))
    (folder / "SKILL.md").write_text(md, encoding="utf-8")
    (folder / "helper.py").write_text("print('hi')\n", encoding="utf-8")
    sent = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        sent.append((system, prompt))
        return '{"verdict": "ok", "summary": "ok", "previous": [{"n": 1, "fixed": true}], "issues": []}'
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    SR._CLOUD_SNAP.clear()
    cfg = _Cfg({"cloud.enabled": True, "cloud.model": "claude-test", "cloud.api_key": "sk-test",
                "skills.review.confirm_order": ["cloud"]})
    prev = [{"severity": "high", "where": "節 3", "problem": "手順が曖昧", "fix": "", "by": "llm"}]
    asyncio.run(SR.confirm_review(cfg, folder, previous=None))
    (folder / "SKILL.md").write_text(md.replace("手順 3 を行う。", "手順 3 を、確認してから行う。"), encoding="utf-8")
    r = asyncio.run(SR.confirm_review(cfg, folder, previous=prev))
    assert len(sent) == 2 and "手順 399" in sent[0][1]
    assert "+手順 3 を、確認してから行う。" in sent[1][1] and "手順 399" not in sent[1][1]
    assert "helper.py" not in sent[1][1]                              # 変わっていないファイルは送らない
    assert "手順が曖昧" in sent[1][1] and "Only the changes since the previous review" in sent[1][0]
    assert r.get("delta") and r.get("via") == "cloud"
    # 前回の指摘が無い（一からのレビュー）なら全体を送る
    asyncio.run(SR.confirm_review(cfg, folder, previous=None))
    assert "手順 399" in sent[2][1]
