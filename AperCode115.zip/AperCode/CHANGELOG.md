# Changelog

## 1.1.5 (2026-09-20)

- 「このセッションでは編集・実行を常に許可」: 一度押せばコード生成・編集・テスト実行（write_file / edit_file / run_command / mt5_* / make_icon）を確認なしで継続。セッションに保存され再起動後も有効
- 取り返しのつかない操作（rm, git reset --hard, sudo, dd, kill, drop table, pip uninstall, curl|sh, restore_backup など）は常時許可の対象外で毎回確認。`permissions.dangerous_commands` で調整可能

## 1.1.4 (2026-09-20)

- 作業ディレクトリの外に触れるツール呼び出し（絶対パス・`~/`・`../`・run_command 内の `cd` や絶対パス）は、読み取り専用ツールでもユーザーの承認を求めるように。`permissions.outside_project`（ask / allow / deny）を追加
- 承認ダイアログに理由（⚠ 作業ディレクトリの外へのアクセス: パス）を表示

## 1.1.3 (2026-09-20)

- 作業ディレクトリの取り違え対策: システムプロンプト先頭で現在の作業ディレクトリを明示し、経験メモリ由来の別プロジェクトのパスに従わないよう指示
- app.py: 起動時に既存サーバーのバージョンを確認し、古いサーバーが残っていれば停止して起動し直す（/api/shutdown を追加）
- 作業ディレクトリ欄を変更して送信すると自動で新しいセッションを開始。セッション未選択時の送信でも自動作成
- 経験メモリの自動注入を厳格化（類似度の正規化、閾値 0.40、上位 3 件、短い入力は対象外）。「参照した経験」を折りたたみ表示

## 1.1.2 (2026-09-20)

- 変更前ファイルの自動バックアップ: write_file / edit_file の直前に `backup/<日時>/` へ退避。list_backups / restore_backup ツール、保持日数による自動整理
- make_icon ツール / CLI（Pillow）: PNG 一式・.ico・.svg のアプリアイコン生成
- GTK 専用ウィンドウでモデル選択プルダウンが白く塗りつぶされる問題を修正（select を独自描画）
- 依存に pillow を追加

## 1.1.0 (2026-09-20)

- web_search / fetch_url ツール（DuckDuckGo / SearXNG）と「行き詰まったときの手順」をシステムプロンプトに追加
- save_memory に出典 URL を付けられるように。振り返りでも Web 由来の解決策に URL を含める
- 専用ウィンドウを GTK バックエンド優先に変更（OS の日本語入力が使える）。setup_linux_window.sh を追加
- IME 変換確定の Enter で送信されてしまう問題を修正
- ディレクトリ選択ダイアログ、存在しないディレクトリの作成確認

## 1.0.0 (2026-09-20)

初回リリース。

- Ollama（ローカル LLM）/ Anthropic API 対応のコーディングエージェント
- ツール: read_file / write_file / edit_file / list_dir / glob / grep / run_command
- MT5 (wine) 向けツール: mt5_compile / mt5_backtest
- Web UI（承認ダイアログ、ツール実行の可視化、状態表示、画像・テキスト添付、右クリックメニュー）
- コンテキスト自動圧縮（要約による置き換え）
- サブエージェント（explore / code モード）
- 経験メモリ（SQLite FTS5 + 埋め込みベクトルのハイブリッド検索、自動抽出、管理画面）
- デスクトップ起動（app.py / install_desktop.sh）
- 作業ディレクトリ選択ダイアログ、存在しない場合の作成確認
