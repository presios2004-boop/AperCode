"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "1.1.5"
__app_name__ = "AperCode"
