"""AperCode デスクトップ起動: サーバーをバックグラウンドで起動してから専用ウィンドウを開く。

    python3 app.py            # 専用ウィンドウ（pywebview）→ 無ければ Chromium 系の --app モード → 無ければ既定ブラウザ
    python3 app.py --browser  # 常に既定ブラウザで開く

ウィンドウを閉じるとサーバーも終了する。ログは ~/.apercode/app.log に出力。
"""
from __future__ import annotations

import argparse
import logging
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from codeagent import __version__  # noqa: E402
from codeagent.config import Config, ensure_data_dir  # noqa: E402

LOG_DIR = ensure_data_dir()
logging.basicConfig(filename=LOG_DIR / "app.log", level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("codeagent.app")
logging.getLogger("httpx").setLevel(logging.WARNING)

APP_TITLE = "AperCode"


def port_open(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        return s.connect_ex((host, port)) == 0


def start_server(cfg: Config, host: str, port: int):
    """uvicorn を別スレッドで起動し、停止用の Server オブジェクトを返す。"""
    import uvicorn
    from codeagent.server.app import create_app

    config = uvicorn.Config(create_app(cfg), host=host, port=port, log_level="warning")
    server = uvicorn.Server(config)
    th = threading.Thread(target=server.run, daemon=True, name="uvicorn")
    th.start()
    for _ in range(100):  # 最大 10 秒待つ
        if port_open(host, port):
            return server
        time.sleep(0.1)
    raise RuntimeError("サーバーが起動しませんでした（~/.apercode/app.log を確認）")


def ollama_running(base_url: str) -> bool:
    try:
        import httpx
        return httpx.get(f"{base_url}/api/tags", timeout=2).status_code == 200
    except Exception:
        return False


def try_start_ollama(base_url: str) -> bool:
    """Ollama が起動していなければ `ollama serve` をバックグラウンドで試みる。"""
    if ollama_running(base_url):
        return True
    exe = shutil.which("ollama")
    if not exe:
        return False
    log.info("ollama serve を起動します")
    subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    for _ in range(30):
        if ollama_running(base_url):
            return True
        time.sleep(0.5)
    return False


# ------------------------------------------------------------------ ウィンドウ
def _run_webview(url: str) -> None:
    """（子プロセスで実行）pywebview のウィンドウを開き、閉じるまでブロックする。"""
    import webview  # type: ignore
    webview.create_window(APP_TITLE, url, width=1360, height=880, min_size=(900, 600))
    webview.start()


def open_webview(url: str) -> bool:
    """pywebview で専用ウィンドウを開く。

    Qt/GTK の初期化失敗は Python の例外にならず即座にプロセスが落ちることがあるため、
    別プロセスで開き、すぐに異常終了した場合は False を返してフォールバックさせる。
    """
    try:
        import webview  # type: ignore  # noqa: F401
    except ImportError:
        return False
    env = {**os.environ, "PYWEBVIEW_LOG": "critical"}
    t0 = time.time()
    proc = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--_webview", url],
                          stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=env)
    if proc.returncode != 0 and time.time() - t0 < 15:
        err = proc.stderr.decode(errors="replace").strip().splitlines()
        log.warning("pywebview の起動に失敗 (code %s): %s", proc.returncode, " | ".join(err[-4:]))
        hint = ""
        if any("xcb" in l for l in err):
            hint = "  → sudo apt install -y libxcb-cursor0"
        print(f"専用ウィンドウ (pywebview) を開けませんでした。{hint}")
        return False
    return True


CHROMIUM_CANDIDATES = ["chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "brave-browser",
                       "microsoft-edge", "vivaldi"]


def open_chromium_app(url: str) -> bool:
    """Chromium 系ブラウザの --app モード（アドレスバー無しの専用ウィンドウ）。閉じるまでブロック。"""
    for name in CHROMIUM_CANDIDATES:
        exe = shutil.which(name)
        if exe:
            profile = LOG_DIR / "browser-profile"
            log.info("%s --app で開きます", exe)
            subprocess.run([exe, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run",
                            f"--window-size=1360,880", f"--class={APP_TITLE}"])
            return True
    # flatpak 版 Chromium/Chrome
    if shutil.which("flatpak"):
        for app_id in ("org.chromium.Chromium", "com.google.Chrome", "com.brave.Browser"):
            r = subprocess.run(["flatpak", "info", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if r.returncode == 0:
                subprocess.run(["flatpak", "run", app_id, f"--app={url}", "--no-first-run"])
                return True
    return False


def open_default_browser(url: str):
    """既定ブラウザで開く。ブロックしないので、Ctrl+C まで待つ。"""
    webbrowser.open(url)
    print(f"{APP_TITLE}: {url} をブラウザで開きました。終了するには Ctrl+C")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=None)
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--browser", action="store_true", help="専用ウィンドウではなく既定ブラウザで開く")
    ap.add_argument("--_webview", default=None, help=argparse.SUPPRESS)  # 内部用: ウィンドウ子プロセス
    args = ap.parse_args()
    if args._webview:
        _run_webview(args._webview)
        return

    cfg = Config.load(args.config)
    host = cfg.get("server.host", "127.0.0.1")
    port = args.port or int(cfg.get("server.port", 8765))
    url = f"http://{host}:{port}"

    server = None
    if port_open(host, port):
        log.info("ポート %d は使用中。既存のサーバーに接続します", port)
        print(f"{APP_TITLE} v{__version__}: 既に起動中のサーバー ({url}) に接続します")
    else:
        try_start_ollama(cfg.get("llm.base_url", "http://localhost:11434"))
        server = start_server(cfg, host, port)
        log.info("サーバー起動 %s", url)
        print(f"{APP_TITLE} v{__version__}: {url}")

    try:
        if args.browser:
            open_default_browser(url)
        elif not (open_webview(url) or open_chromium_app(url)):
            print("専用ウィンドウを開けなかったため既定ブラウザで開きます"
                  "（専用ウィンドウにするには: pip install \"pywebview[qt]\"）")
            open_default_browser(url)
    finally:
        if server is not None:
            log.info("終了します")
            server.should_exit = True
            time.sleep(0.5)


if __name__ == "__main__":
    main()
