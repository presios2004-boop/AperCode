"""search_memory / save_memory: 経験メモリをエージェント自身が能動的に使うためのツール。

MemoryStore の実体は ToolContext.memory として agent から注入される。
"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register


async def search_memory(ctx: ToolContext, a: dict) -> str:
    store = getattr(ctx, "memory", None)
    if store is None:
        raise ToolError("経験メモリは無効です")
    hits = await store.search(a["query"], limit=int(a.get("limit", 5)), tags=a.get("tags") or [],
                              project=str(ctx.project_dir))
    if not hits:
        return "該当する経験はありません"
    store.touch([m.id for m in hits])
    lines = []
    for m in hits:
        lines.append(f"#{m.id} (score {m.score}, {m.outcome}{', 確認済' if m.verified else ''}) {m.to_prompt()}")
        if m.action:
            lines.append(f"    行動: {m.action}")
    return "\n".join(lines)


async def save_memory(ctx: ToolContext, a: dict) -> str:
    store = getattr(ctx, "memory", None)
    if store is None:
        raise ToolError("経験メモリは無効です")
    lesson = (a.get("lesson") or "").strip()
    if not lesson:
        raise ToolError("lesson は必須です")
    outcome = a.get("outcome", "info")
    if outcome not in ("success", "failure", "info"):
        outcome = "info"
    m, dup = await store.add(lesson=lesson, situation=a.get("situation", ""), action=a.get("action", ""),
                             outcome=outcome, tags=a.get("tags") or [], project=str(ctx.project_dir),
                             source="tool", dedup_threshold=float(ctx.cfg.get("memory.dedup_threshold", 0.92)))
    if dup:
        return f"類似の経験が既に存在します (#{dup.id}): {dup.lesson}"
    return f"保存しました (#{m.id}): {m.to_prompt()}"


register(Tool(
    "search_memory",
    "過去の経験（成功・失敗の教訓、確認済みの事実）を検索する。似た作業を始める前、エラーに遭遇したとき、"
    "設定値や手順に迷ったときに使う。",
    {"type": "object", "properties": {
        "query": {"type": "string", "description": "状況やエラー内容を自然文で"},
        "tags": {"type": "array", "items": {"type": "string"}, "description": "言語・ツール名などで絞り込み（任意）"},
        "limit": {"type": "integer"}},
     "required": ["query"]},
    search_memory, lambda a: a.get("query", "")[:80]))

register(Tool(
    "save_memory",
    "今後も役立つ教訓・事実を経験メモリに保存する。エラーの原因と解決法、環境固有の設定、うまくいった手順など。"
    "一時的な情報（ファイルの一時的な状態など）は保存しない。",
    {"type": "object", "properties": {
        "lesson": {"type": "string", "description": "教訓・事実（1〜2文、具体的に）"},
        "situation": {"type": "string", "description": "どんな状況で（任意）"},
        "action": {"type": "string", "description": "何をしたか（任意）"},
        "outcome": {"type": "string", "enum": ["success", "failure", "info"]},
        "tags": {"type": "array", "items": {"type": "string"}, "description": "言語・フレームワーク・ツール名など"}},
     "required": ["lesson"]},
    save_memory, lambda a: a.get("lesson", "")[:80]))
