"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "1.1.2"
__app_name__ = "AperCode"
