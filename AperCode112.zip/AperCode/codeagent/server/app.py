"""FastAPI サーバー: REST（セッション管理）+ WebSocket（チャット）"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from .. import __version__
from ..agent import Agent
from ..config import Config, expand
from ..llm import LLMClient
from ..session import Session, SessionStore

STATIC = Path(__file__).parent / "static"


class NewSession(BaseModel):
    project_dir: str | None = None
    create: bool = False          # True なら存在しないディレクトリを作成する


class PathIn(BaseModel):
    path: str


class SetModel(BaseModel):
    model: str


class MemoryIn(BaseModel):
    lesson: str
    situation: str = ""
    action: str = ""
    outcome: str = "info"
    tags: list[str] = []
    project: str = ""
    verified: int = 0


class MemoryPatch(BaseModel):
    lesson: str | None = None
    situation: str | None = None
    action: str | None = None
    outcome: str | None = None
    tags: list[str] | None = None
    project: str | None = None
    verified: int | None = None


def create_app(cfg: Config) -> FastAPI:
    app = FastAPI(title="AperCode", version=__version__)
    llm = LLMClient(cfg)
    store = SessionStore(cfg.sessions_dir)
    agent = Agent(cfg, llm, store)
    running: dict[str, asyncio.Task] = {}

    @app.get("/")
    async def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/config")
    async def get_config():
        return {"version": __version__, "model": llm.model, "provider": llm.provider, "tool_mode": llm.tool_mode,
                "workspace": str(cfg.workspace_root), "default_project": str(cfg.default_project),
                "recent_projects": [r for r in cfg.state().get("recent_projects", []) if Path(r).is_dir()],
                "permissions": cfg.get("permissions", {})}

    @app.get("/api/models")
    async def models():
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.get(f"{llm.base_url}/api/tags")
                return {"models": [m["name"] for m in r.json().get("models", [])]}
        except Exception as e:
            return {"models": [], "error": str(e)}

    @app.post("/api/model")
    async def set_model(body: SetModel):
        llm.model = body.model
        return {"model": llm.model}

    @app.get("/api/sessions")
    async def list_sessions():
        return store.list()

    @app.post("/api/sessions")
    async def new_session(body: NewSession):
        pdir = expand(body.project_dir) if body.project_dir else cfg.default_project
        if not cfg.in_workspace(pdir):
            raise HTTPException(400, f"ワークスペース外です: {pdir}\n（許可範囲: {cfg.workspace_root}。config.yaml の workspace.root で変更できます）")
        if pdir.exists() and not pdir.is_dir():
            raise HTTPException(400, f"ディレクトリではありません: {pdir}")
        if not pdir.exists():
            if not body.create:
                # UI 側で「作成しますか？」を出すための応答
                return JSONResponse(status_code=404, content={"code": "not_found", "path": str(pdir),
                                                              "detail": f"ディレクトリがありません: {pdir}"})
            try:
                pdir.mkdir(parents=True)
            except OSError as e:
                raise HTTPException(400, f"作成できません: {e}")
        cfg.remember_project(pdir)
        s = Session.new(str(pdir))
        store.save(s)
        return s.summary()

    # ---------------------------------------------------------------- ディレクトリ選択
    @app.get("/api/fs/list")
    async def fs_list(path: str = ""):
        """ワークスペース内のディレクトリ一覧（ディレクトリ選択ダイアログ用）。"""
        p = expand(path) if path else cfg.default_project
        if not cfg.in_workspace(p):
            p = cfg.workspace_root
        while not p.is_dir() and p != p.parent:
            p = p.parent
        dirs = []
        try:
            for c in sorted(p.iterdir(), key=lambda c: c.name.lower()):
                if c.is_dir() and not c.name.startswith(".") and c.name not in ("node_modules", "__pycache__"):
                    dirs.append(c.name)
        except PermissionError:
            pass
        root = cfg.workspace_root
        parent = str(p.parent) if p != root and root in p.parents else None
        return {"path": str(p), "parent": parent, "dirs": dirs, "root": str(root), "home": str(Path.home()),
                "recent": [r for r in cfg.state().get("recent_projects", []) if Path(r).is_dir()]}

    @app.post("/api/fs/mkdir")
    async def fs_mkdir(body: PathIn):
        p = expand(body.path)
        if not cfg.in_workspace(p):
            raise HTTPException(400, f"ワークスペース外です: {p}")
        try:
            p.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise HTTPException(400, f"作成できません: {e}")
        return {"path": str(p)}

    @app.get("/api/sessions/{sid}")
    async def get_session(sid: str):
        s = store.load(sid)
        if not s:
            raise HTTPException(404)
        return {"summary": s.summary(), "messages": s.messages, "usage": s.usage,
                "context": {"estimated_tokens": max(agent._estimate_tokens(s.messages), s.last_prompt_tokens),
                            "num_ctx": llm.num_ctx, "messages": len(s.messages)}}

    @app.get("/api/sessions/{sid}/files/{name}")
    async def session_file(sid: str, name: str):
        p = (store.root / f"{sid}_files" / Path(name).name)
        if not p.is_file():
            raise HTTPException(404)
        return FileResponse(p)

    @app.delete("/api/sessions/{sid}")
    async def delete_session(sid: str):
        store.delete(sid)
        return {"ok": True}

    # ---------------------------------------------------------------- 経験メモリ
    def _mem():
        if agent.memory is None:
            raise HTTPException(400, "経験メモリは無効です (config.yaml memory.enabled)")
        return agent.memory

    @app.get("/api/memory")
    async def memory_list(q: str = "", limit: int = 100, outcome: str | None = None, verified: int | None = None):
        mem = _mem()
        if q.strip():
            items = await mem.search(q, limit=limit, min_score=0.0)
        else:
            items = mem.list(limit=limit, outcome=outcome or None, verified=verified)
        return {"items": [m.to_dict() for m in items], "count": mem.count(), "tags": mem.all_tags()[:40],
                "embed_model": mem.embedder.model, "embed_available": mem.embedder.available}

    @app.post("/api/memory")
    async def memory_add(body: MemoryIn):
        mem = _mem()
        m, dup = await mem.add(lesson=body.lesson, situation=body.situation, action=body.action,
                               outcome=body.outcome, tags=body.tags, project=body.project, source="manual",
                               verified=body.verified, dedup_threshold=float(cfg.get("memory.dedup_threshold", 0.92)))
        if dup:
            raise HTTPException(409, f"類似のメモリが既にあります (#{dup.id}): {dup.lesson}")
        return m.to_dict()

    @app.patch("/api/memory/{mid}")
    async def memory_update(mid: int, body: MemoryPatch):
        m = await _mem().update(mid, **body.model_dump())
        if not m:
            raise HTTPException(404)
        return m.to_dict()

    @app.delete("/api/memory/{mid}")
    async def memory_delete(mid: int):
        return {"ok": _mem().delete(mid)}

    @app.post("/api/memory/reindex")
    async def memory_reindex():
        n = await _mem().reindex()
        return {"reindexed": n, "embed_available": _mem().embedder.available}

    @app.websocket("/ws/{sid}")
    async def ws(websocket: WebSocket, sid: str):
        await websocket.accept()
        session = store.load(sid)
        if not session:
            await websocket.send_json({"type": "error", "text": "セッションがありません"})
            await websocket.close()
            return
        pending: dict[str, asyncio.Future] = {}
        send_lock = asyncio.Lock()

        async def emit(ev: dict):
            try:
                async with send_lock:
                    await websocket.send_json(ev)
            except Exception:
                # クライアント切断後の送信。処理を止めて静かに無視する（次の接続で履歴から復元される）
                agent.cancel(sid)

        async def ask_approval(req: dict) -> str:
            fut: asyncio.Future = asyncio.get_event_loop().create_future()
            pending[req["id"]] = fut
            await emit({"type": "approval_request", **req})
            try:
                return await fut
            finally:
                pending.pop(req["id"], None)

        try:
            while True:
                raw = await websocket.receive_text()
                msg = json.loads(raw)
                t = msg.get("type")
                if t == "user":
                    if sid in running and not running[sid].done():
                        await emit({"type": "error", "text": "前の処理が実行中です"})
                        continue
                    session = store.load(sid) or session
                    running[sid] = asyncio.create_task(agent.run(session, msg["text"], emit, ask_approval,
                                                                 attachments=msg.get("attachments") or []))
                elif t == "approval":
                    fut = pending.get(msg["id"])
                    if fut and not fut.done():
                        fut.set_result(msg.get("decision", "deny"))
                elif t == "compact":
                    if sid in running and not running[sid].done():
                        await emit({"type": "error", "text": "処理中は要約できません"})
                        continue
                    session = store.load(sid) or session
                    running[sid] = asyncio.create_task(agent.compact_now(session, emit))
                elif t == "cancel":
                    agent.cancel(sid)
                    for fut in pending.values():
                        if not fut.done():
                            fut.set_result("deny")
        except WebSocketDisconnect:
            for fut in pending.values():
                if not fut.done():
                    fut.set_result("deny")

    @app.on_event("shutdown")
    async def shutdown():
        await llm.close()

    return app
