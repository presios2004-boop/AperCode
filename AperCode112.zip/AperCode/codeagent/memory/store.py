"""経験メモリのストア: SQLite(FTS5) + 埋め込みベクトル（numpy）によるハイブリッド検索。

- 全文検索 (FTS5) と ベクトル検索 (cosine) の結果を RRF (Reciprocal Rank Fusion) で統合する
- 埋め込みは Ollama /api/embed を使う。取得できない場合は全文検索のみで動作する
- 分野に依存しない構造: 状況 / 行動 / 結果 / 教訓 / タグ
"""
from __future__ import annotations

import json
import sqlite3
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import httpx
import numpy as np

SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL DEFAULT 'lesson',        -- lesson | fact | preference
  situation TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL DEFAULT '',
  outcome TEXT NOT NULL DEFAULT 'info',       -- success | failure | info
  lesson TEXT NOT NULL,
  tags TEXT NOT NULL DEFAULT '[]',            -- JSON array
  project TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT 'manual',      -- auto | manual | tool
  verified INTEGER NOT NULL DEFAULT 0,
  use_count INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  embedding BLOB,
  embed_model TEXT
);
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
  situation, action, lesson, tags, content='memories', content_rowid='id',
  tokenize='trigram'
);
CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
  INSERT INTO memories_fts(rowid, situation, action, lesson, tags)
  VALUES (new.id, new.situation, new.action, new.lesson, new.tags);
END;
CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
  INSERT INTO memories_fts(memories_fts, rowid, situation, action, lesson, tags)
  VALUES ('delete', old.id, old.situation, old.action, old.lesson, old.tags);
END;
CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
  INSERT INTO memories_fts(memories_fts, rowid, situation, action, lesson, tags)
  VALUES ('delete', old.id, old.situation, old.action, old.lesson, old.tags);
  INSERT INTO memories_fts(rowid, situation, action, lesson, tags)
  VALUES (new.id, new.situation, new.action, new.lesson, new.tags);
END;
"""


@dataclass
class Memory:
    id: int
    kind: str
    situation: str
    action: str
    outcome: str
    lesson: str
    tags: list[str]
    project: str
    source: str
    verified: int
    use_count: int
    created_at: float
    updated_at: float
    score: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)

    def to_prompt(self) -> str:
        mark = {"success": "✓", "failure": "✗", "info": "・"}.get(self.outcome, "・")
        head = f"{mark} [{', '.join(self.tags)}] " if self.tags else f"{mark} "
        body = self.lesson
        if self.situation:
            body = f"{self.situation} → {body}"
        return head + body


class Embedder:
    """Ollama の埋め込み API。失敗時は None を返す（呼び出し側で全文検索にフォールバック）。"""

    def __init__(self, base_url: str, model: str | None):
        self.base_url = base_url.rstrip("/")
        self.model = model or ""
        self.available: bool | None = None  # None = 未確認
        self._client = httpx.AsyncClient(timeout=60.0)

    async def embed(self, texts: list[str]) -> list[np.ndarray] | None:
        if not self.model or not texts:
            return None
        try:
            r = await self._client.post(f"{self.base_url}/api/embed", json={"model": self.model, "input": texts})
            if r.status_code != 200:
                self.available = False
                return None
            vecs = r.json().get("embeddings") or []
            self.available = True
            out = []
            for v in vecs:
                a = np.asarray(v, dtype=np.float32)
                n = np.linalg.norm(a)
                out.append(a / n if n > 0 else a)
            return out
        except Exception:
            self.available = False
            return None

    async def close(self):
        await self._client.aclose()


class MemoryStore:
    def __init__(self, db_path: Path, embedder: Embedder):
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(db_path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self.embedder = embedder

    # ----------------------------------------------------------------- 基本操作
    @staticmethod
    def _embed_text(situation: str, action: str, lesson: str, tags: list[str]) -> str:
        return "\n".join(x for x in [situation, action, lesson, " ".join(tags)] if x)

    def _row(self, r: sqlite3.Row, score: float = 0.0) -> Memory:
        return Memory(id=r["id"], kind=r["kind"], situation=r["situation"], action=r["action"],
                      outcome=r["outcome"], lesson=r["lesson"], tags=json.loads(r["tags"] or "[]"),
                      project=r["project"], source=r["source"], verified=r["verified"],
                      use_count=r["use_count"], created_at=r["created_at"], updated_at=r["updated_at"], score=score)

    async def add(self, lesson: str, situation: str = "", action: str = "", outcome: str = "info",
                  tags: list[str] | None = None, project: str = "", source: str = "manual",
                  kind: str = "lesson", verified: int = 0, dedup_threshold: float | None = None) -> tuple[Memory | None, Memory | None]:
        """追加する。dedup_threshold を指定し類似メモリがあれば (None, 既存) を返す。"""
        tags = sorted({t.strip().lower() for t in (tags or []) if t.strip()})
        text = self._embed_text(situation, action, lesson, tags)
        vecs = await self.embedder.embed([text])
        vec = vecs[0] if vecs else None
        if dedup_threshold is not None:
            dup = self._find_duplicate(lesson, vec, dedup_threshold)
            if dup:
                return None, dup
        now = time.time()
        cur = self.db.execute(
            "INSERT INTO memories(kind,situation,action,outcome,lesson,tags,project,source,verified,use_count,"
            "created_at,updated_at,embedding,embed_model) VALUES (?,?,?,?,?,?,?,?,?,0,?,?,?,?)",
            (kind, situation, action, outcome, lesson, json.dumps(tags, ensure_ascii=False), project, source,
             verified, now, now, vec.tobytes() if vec is not None else None, self.embedder.model if vec is not None else None))
        self.db.commit()
        return self.get(cur.lastrowid), None

    def _find_duplicate(self, lesson: str, vec: np.ndarray | None, threshold: float) -> Memory | None:
        if vec is not None:
            for m, sim in self._vector_scores(vec, limit=1):
                if sim >= threshold:
                    return m
        # 埋め込みが無い場合（または類似度が低い場合）は lesson の完全一致で判定
        r = self.db.execute("SELECT * FROM memories WHERE lesson = ? LIMIT 1", (lesson,)).fetchone()
        return self._row(r) if r else None

    def get(self, mid: int) -> Memory | None:
        r = self.db.execute("SELECT * FROM memories WHERE id=?", (mid,)).fetchone()
        return self._row(r) if r else None

    async def update(self, mid: int, **fields) -> Memory | None:
        m = self.get(mid)
        if not m:
            return None
        allowed = {"kind", "situation", "action", "outcome", "lesson", "tags", "project", "verified"}
        fields = {k: v for k, v in fields.items() if k in allowed and v is not None}
        if "tags" in fields:
            fields["tags"] = json.dumps(sorted({t.strip().lower() for t in fields["tags"] if t.strip()}), ensure_ascii=False)
        sets = ", ".join(f"{k}=?" for k in fields) + ", updated_at=?"
        self.db.execute(f"UPDATE memories SET {sets} WHERE id=?", (*fields.values(), time.time(), mid))
        # テキストが変わったら埋め込みを更新
        if any(k in fields for k in ("situation", "action", "lesson", "tags")):
            m2 = self.get(mid)
            vecs = await self.embedder.embed([self._embed_text(m2.situation, m2.action, m2.lesson, m2.tags)])
            if vecs:
                self.db.execute("UPDATE memories SET embedding=?, embed_model=? WHERE id=?",
                                (vecs[0].tobytes(), self.embedder.model, mid))
        self.db.commit()
        return self.get(mid)

    def delete(self, mid: int) -> bool:
        cur = self.db.execute("DELETE FROM memories WHERE id=?", (mid,))
        self.db.commit()
        return cur.rowcount > 0

    def touch(self, ids: list[int]):
        if ids:
            self.db.execute(f"UPDATE memories SET use_count=use_count+1 WHERE id IN ({','.join('?'*len(ids))})", ids)
            self.db.commit()

    def list(self, limit: int = 200, offset: int = 0, outcome: str | None = None, verified: int | None = None) -> list[Memory]:
        where, args = [], []
        if outcome:
            where.append("outcome=?"); args.append(outcome)
        if verified is not None:
            where.append("verified=?"); args.append(verified)
        sql = "SELECT * FROM memories" + (" WHERE " + " AND ".join(where) if where else "") + \
              " ORDER BY updated_at DESC LIMIT ? OFFSET ?"
        return [self._row(r) for r in self.db.execute(sql, (*args, limit, offset)).fetchall()]

    def count(self) -> int:
        return self.db.execute("SELECT COUNT(*) FROM memories").fetchone()[0]

    def all_tags(self) -> list[tuple[str, int]]:
        counts: dict[str, int] = {}
        for r in self.db.execute("SELECT tags FROM memories"):
            for t in json.loads(r["tags"] or "[]"):
                counts[t] = counts.get(t, 0) + 1
        return sorted(counts.items(), key=lambda x: -x[1])

    async def reindex(self) -> int:
        """埋め込みを全件再計算する（モデル変更時など）。"""
        rows = self.db.execute("SELECT * FROM memories").fetchall()
        n = 0
        for i in range(0, len(rows), 32):
            batch = rows[i:i + 32]
            texts = [self._embed_text(r["situation"], r["action"], r["lesson"], json.loads(r["tags"] or "[]")) for r in batch]
            vecs = await self.embedder.embed(texts)
            if not vecs:
                break
            for r, v in zip(batch, vecs):
                self.db.execute("UPDATE memories SET embedding=?, embed_model=? WHERE id=?",
                                (v.tobytes(), self.embedder.model, r["id"]))
                n += 1
        self.db.commit()
        return n

    # ----------------------------------------------------------------- 検索
    def _vector_scores(self, q: np.ndarray, limit: int = 50) -> list[tuple[Memory, float]]:
        rows = self.db.execute("SELECT * FROM memories WHERE embedding IS NOT NULL").fetchall()
        if not rows:
            return []
        mat = np.stack([np.frombuffer(r["embedding"], dtype=np.float32) for r in rows])
        if mat.shape[1] != q.shape[0]:
            return []  # モデルが変わっている → reindex が必要
        sims = mat @ q
        order = np.argsort(-sims)[:limit]
        return [(self._row(rows[i]), float(sims[i])) for i in order]

    def _fts_scores(self, query: str, limit: int = 50) -> list[tuple[Memory, float]]:
        # FTS5 クエリ構文エラーを避けるため、各語をダブルクォートで囲む
        terms = [t.replace('"', '') for t in query.split() if len(t.replace('"', '')) >= 2]
        if not terms:
            return []
        q = " OR ".join(f'"{t}"' for t in terms)
        try:
            rows = self.db.execute(
                "SELECT m.*, bm25(memories_fts) AS rank FROM memories_fts f JOIN memories m ON m.id=f.rowid "
                "WHERE memories_fts MATCH ? ORDER BY rank LIMIT ?", (q, limit)).fetchall()
        except sqlite3.OperationalError:
            return []
        return [(self._row(r), -float(r["rank"])) for r in rows]

    async def search(self, query: str, limit: int = 5, tags: list[str] | None = None,
                     project: str = "", min_score: float = 0.0) -> list[Memory]:
        """ハイブリッド検索（ベクトル + 全文）。スコアは 0〜1。"""
        vec_hits: list[tuple[Memory, float]] = []
        vecs = await self.embedder.embed([query])
        if vecs:
            vec_hits = self._vector_scores(vecs[0], limit=50)
        fts_hits = self._fts_scores(query, limit=50)
        if not vec_hits and not fts_hits:
            return []
        # スコア = 0.7 × ベクトル類似度（0.45〜0.85 を 0〜1 に正規化） + 全文検索順位項（1位 0.15, 2位 0.10, ...） + ボーナス（最大 0.15）
        # 例: 本当に似た経験 (sim 0.75) → 0.53 + α、無関係だが単語が一部一致 → 0.15 程度
        scores: dict[int, float] = {}
        items: dict[int, Memory] = {}
        for m, sim in vec_hits:
            # 多言語埋め込み（bge-m3 等）は無関係な文同士でも 0.3〜0.5 程度になるため、0.45 未満は無視し
            # 0.45〜0.85 を 0〜1 に正規化する（本当に似ているものだけが高得点になる）
            if sim < 0.45:
                continue
            scores[m.id] = 0.7 * min((sim - 0.45) / 0.4, 1.0)
            items[m.id] = m
        for rank, (m, _) in enumerate(fts_hits):
            # 全文検索（trigram）は部分一致でも拾うため寄与は小さめにする
            scores[m.id] = scores.get(m.id, 0) + 0.15 / (1 + 0.5 * rank)
            items[m.id] = m
        # ボーナス: タグ一致 / 同一プロジェクト / 確認済み
        tagset = {t.lower() for t in (tags or [])}
        for mid, m in items.items():
            bonus = 0.0
            if tagset and tagset & set(m.tags):
                bonus += 0.05
            if project and m.project == project:
                bonus += 0.05
            if m.verified:
                bonus += 0.05
            scores[mid] += bonus
        out = []
        for mid, sc in sorted(scores.items(), key=lambda x: -x[1]):
            m = items[mid]
            m.score = round(min(sc, 1.0), 3)
            if m.score >= min_score:
                out.append(m)
            if len(out) >= limit:
                break
        return out

    def close(self):
        self.db.close()
