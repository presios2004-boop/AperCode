# AperCode

[English](README.en.md)

ローカル LLM（Ollama）で動く汎用コーディングエージェント。Web ブラウザ UI 付き。
MT5 (wine) の EA コンパイル・バックテストをツールとして組み込み済み。
コンテキスト自動圧縮とサブエージェント（子エージェント）に対応し、中規模プロジェクトの構築を想定。

## 構成

```
codeagent/
├── app.py                  # デスクトップ起動（サーバー自動起動 + 専用ウィンドウ）
├── install_desktop.sh      # アプリメニュー / デスクトップへの登録
├── main.py                 # サーバーのみ起動
├── config.example.yaml     # 設定テンプレート（config.yaml にコピーして編集）
├── LICENSE                 # MIT
├── config.yaml             # 設定（モデル・権限・MT5 パス）
├── codeagent/
│   ├── agent.py            # エージェントループ（LLM ⇄ ツール）
│   ├── llm.py              # Ollama / Anthropic クライアント
│   ├── prompts.py          # システムプロンプト
│   ├── session.py          # 会話履歴の保存（JSON）
│   ├── memory/store.py     # 経験メモリ（SQLite FTS5 + 埋め込みベクトル）
│   ├── tools/
│   │   ├── fs.py           # read_file / write_file / edit_file / list_dir / glob / grep
│   │   ├── shell.py        # run_command
│   │   ├── mt5.py          # mt5_compile / mt5_backtest
│   │   ├── subagent.py     # spawn_agent（子エージェント）
│   │   ├── web.py          # web_search / fetch_url
│   │   ├── backup_tools.py # list_backups / restore_backup
│   │   └── icon.py         # make_icon（アイコン生成、CLI 兼用）
│   ├── backup.py           # 変更前ファイルの自動バックアップ
│   │   └── memory_tools.py # search_memory / save_memory
│   └── server/
│       ├── app.py          # FastAPI + WebSocket
│       └── static/index.html
```

## セットアップ

```bash
cd codeagent
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp config.example.yaml config.yaml     # 任意。無ければ config.example.yaml がそのまま使われる
ollama pull qwen3:8b bge-m3            # 使うモデルと埋め込みモデル
```

設定は 3 段階で読み込まれる（後のものが優先）:
1. `config.example.yaml`（リポジトリ同梱の既定値）
2. `config.yaml`（プロジェクト直下。`.gitignore` 済み）
3. `~/.apercode/config.yaml`（ユーザー固有の上書き。差分だけ書けばよい）

`config.yaml` の主な項目:

| 項目 | 内容 |
|---|---|
| `llm.model` | 使うモデル（例: `gemma4:26b`） |
| `llm.tool_mode` | `native`（Ollama tool calling）/ `json`（非対応モデル用フォールバック） |
| `llm.num_ctx` / `llm.auto_ctx.*` | コンテキストサイズの上限と、VRAM の空きからの自動調整（下記） |
| `workspace.root` | エージェントが触れる範囲。この外は拒否される |
| `workspace.default_project` | 新規セッションの既定プロジェクト。空なら最近使ったものを使う |
| `permissions.*` | ツールごとに `allow` / `ask` / `deny` |
| `mt5.*` | WINEPREFIX と MT5 のインストール先 |
| `compaction.*` | コンテキスト圧縮の閾値（num_ctx に対する割合）と、残す直近メッセージ数 |
| `subagents.*` | 子エージェントの上限回数・深さ・モード別モデル |
| `memory.*` | 経験メモリ: 埋め込みモデル、自動注入件数、自動抽出の条件 |
| `web.*` | Web 検索: provider（duckduckgo / searxng）、結果数、取得文字数 |
| `backup.*` | 変更前ファイルの自動バックアップ: フォルダ名、保持日数、対象サイズ上限 |
| `verify.*` | 生成コードの検証レイヤー: 自動チェック・テスト自動実行・レビュー子エージェント（下記） |

## 起動

### デスクトップアプリとして（推奨）

```bash
bash install_desktop.sh
```

アプリメニュー（開発）とデスクトップに「AperCode」が追加される。クリックすると
サーバーを自動起動し（Ollama が止まっていれば `ollama serve` も試みる）、専用ウィンドウを開く。
ウィンドウを閉じるとサーバーも終了する。ログは `~/.apercode/app.log`。

専用ウィンドウの優先順位:
1. pywebview GTK バックエンド（OS の WebKit2GTK。日本語入力がそのまま使える。`bash setup_linux_window.sh` で準備）
2. Chromium / Chrome / Brave の `--app` モード（アドレスバー無しのウィンドウ）
3. pywebview Qt バックエンド（`pip install "pywebview[qt]"`。pip 版 Qt は fcitx 未対応のため日本語入力に難あり）
4. 既定のブラウザ

Linux で日本語入力（Mozc 等）を専用ウィンドウで使うには、1 を推奨:

```bash
bash setup_linux_window.sh   # python3-gi / WebKit2GTK を入れ、.venv を --system-site-packages で作り直す
```

ターミナルから同じ動作をさせるには `python3 app.py`（`--browser` で常に既定ブラウザ）。

#### トラブルシューティング

**専用ウィンドウで日本語入力（Mozc など）が起動しない**

pip でインストールした Qt（`pywebview[qt]`）には fcitx 用の入力メソッドプラグインが含まれていないため、
Qt バックエンドの専用ウィンドウ内では IME が動かない。ブラウザ（Firefox 等）では問題なく入力できるのが特徴。

対策: OS 標準の GTK + WebKit2GTK を使う GTK バックエンドに切り替える。

```bash
bash setup_linux_window.sh
```

このスクリプトは `python3-gi` と WebKit2GTK のバインディングを apt で入れ、仮想環境を
`--system-site-packages` 付きで作り直し（依存パッケージも再インストール）、Qt を外す。
以後 `app.py` は GTK バックエンドを最優先で使うので、OS の日本語入力がそのまま効く。

**専用ウィンドウが開かず、ブラウザで開いてしまう**

`~/.apercode/app.log` に理由が記録される。Qt バックエンドで
`Could not load the Qt platform plugin "xcb"` と出る場合は `sudo apt install -y libxcb-cursor0`。

**「経験メモリに保存」の直後に LLM が応答しなくなる（落ちる）**

v1.1.7 で対策。ターン終了後の教訓抽出（振り返り）はチャットモデルへの追加呼び出しと埋め込みモデル（bge-m3）の
ロードを伴うため、VRAM が足りない環境ではチャットモデルが追い出され、次の応答まで再ロード待ちになったり、
Ollama 自体が落ちたりすることがあった。対策:

- 振り返りを応答完了後の**バックグラウンド**処理にした（会話はすぐ続けられる。失敗しても会話に影響しない、180 秒でタイムアウト）
- 振り返りに渡す記録を 24k 文字に制限、埋め込みモデルは `keep_alive: 2m` で使用後すぐ解放、チャットモデルは
  `llm.keep_alive`（既定 30m）で保持
- Ollama が一時的に応答しない場合は自動で再試行（`llm.connect_retries`、既定 3 回）。途中で切れた場合は
  「LLM との接続が途中で切れました（Ollama が落ちた可能性…）」と表示

それでも落ちる場合は VRAM 不足の可能性が高い。`llm.num_ctx` を 32768 に下げる、`memory.embed_model` を空にして
全文検索のみにする（埋め込みモデルを使わない）、`memory.reflect: off` にする、のいずれかで軽くなる。
Ollama 側のログは `journalctl -u ollama -n 50` で確認できる。

**ツール呼び出し上限（60）に達すると何も言わずに止まる**

v1.1.6 で修正。上限到達時は状況報告を生成し、「続けて」で再開できる。同じ操作の繰り返しや連続失敗も検知して
Web 検索など別アプローチを促す。長い作業で上限に当たりやすい場合は `config.yaml` の `llm.max_iterations` を増やす。

**LLM が別のディレクトリに移動しないようにしたい**

v1.1.4 から、作業ディレクトリの外を指すパス（絶対パス、`~/…`、`../` で親へ出る相対パス、`run_command` 内の `cd` や
絶対パス）を含むツール呼び出しは、ツールの権限設定に関わらず承認ダイアログが出る。読み取り（`read_file` / `list_dir` /
`grep`）も対象。許可すればその 1 回だけ、「このセッションでは常に許可」を選べばそのセッション中は確認しない。
`config.yaml` の `permissions.outside_project` を `deny` にすると常に拒否、`allow` にすると確認なし。
なお `workspace.root` の外は設定に関わらず常に拒否される。

**新しい作業ディレクトリでセッションを始めたのに、LLM が以前のディレクトリで作業する**

v1.1.3 で対策済み。原因は主に次の 2 つ。

1. 以前に `python3 main.py` で起動したサーバーが残っていて、デスクトップ起動（`app.py`）がその古いサーバーに
   接続していた。v1.1.3 からは起動時にサーバーのバージョンを確認し、コードと違えば古いサーバーを停止して
   起動し直す（ターミナルに「古いサーバー (vX) が動いていたため停止して起動し直します」と出る）。
2. 経験メモリに別プロジェクトのパスが含まれていて、LLM がそれに引きずられた。システムプロンプトの先頭で
   現在の作業ディレクトリを最重要として明示し、経験メモリの注入部分にも「別プロジェクトのパスが含まれていても
   作業ディレクトリで行う」と付記した。

それでも迷う場合は「list_dir で現在地を確認して」と一言添えると確実。ヘッダーの「プロジェクト:」が
現在のセッションの作業ディレクトリなので、意図と違えば 📁 で選び直してから送信する（自動的に新しいセッションになる）。

**モデル選択のプルダウンが白く塗りつぶされて文字が読めない（GTK 専用ウィンドウ）**

WebKitGTK が OS のテーマでネイティブ描画するため。v1.1.2 で `select` を独自描画（`appearance: none` + ダーク配色）に
変更して解消済み。古い `index.html` の場合は最新版に更新すること。

**web_search が「HTTP 403」で失敗する**

検索サイトのボット判定です。`ddgs` パッケージを入れると、ブラウザ相当の TLS で接続するため回避できます
（v1.2.1.1 の requirements.txt に含まれています。既存の venv では `.venv/bin/pip install ddgs`）。
入っていれば最初に使われ、失敗しても Bing → Brave → Mojeek → Stack Exchange / GitHub / Wikipedia の
API へ順に切り替わります。結果の 1 行目「検索: …（エンジン名）」でどれが使われたか分かります。
すべて失敗するときはエラー文にエンジンごとの結果が並ぶので、回線側（プロキシ・セキュリティソフト）の
ブロックか判断できます。自前の SearXNG がある場合は `web.searxng_url` を設定してください。

**変換確定の Enter で送信されてしまう**

修正済み（IME 変換中の Enter は無視する）。古い `index.html` を使っている場合は最新版に更新すること。

## サーバーだけ起動する（開発用）

```bash
python3 main.py
# → http://127.0.0.1:8765 をブラウザで開く
```

## 使い方

1. 左上でモデルを選び、作業ディレクトリを指定して「新しいセッション」
   - 📁 ボタンでディレクトリ選択ダイアログ（最近使ったもの・新しいフォルダの作成も可）
   - 存在しないパスを入力すると「新規に作成しますか？」と確認される
   - 選べるのは `workspace.root` 配下のみ
2. 指示を入力（例: 「USDJPY H1 の移動平均クロス EA を作ってコンパイルして」）
3. `write_file` / `edit_file` / `run_command` は承認ダイアログが出る。「このセッションでは編集・実行を常に許可」を押すと、
   そのセッションでは以後のコード生成・編集・テスト実行（`write_file` / `edit_file` / `run_command` / `mt5_*` / `make_icon`）を
   確認なしで続ける（設定はセッションに保存され、再起動後も有効）
   - ただし**取り返しのつかない操作**は常時許可の対象外で毎回確認する: `rm` / `rmdir`、`git reset --hard` / `git clean` /
     `git push --force`、`sudo`、`dd` / `mkfs`、`chmod -R` / `chown`、`kill`、`drop table`、`pip uninstall`、`apt remove`、
     `curl … | sh`、絶対パスへの `mv`、`restore_backup` など（ダイアログに「危険なコマンド」と表示。
     `permissions.dangerous_commands` で正規表現リストを差し替え可能）
   - 作業ディレクトリの**外**（`workspace.root` 内の別ディレクトリ）に触れる操作は、読み取り専用ツールでも必ず承認を求める
     （ダイアログ上部に「⚠ 作業ディレクトリの外へのアクセス: パス」と表示）。`permissions.outside_project` で ask / allow / deny を選べる
4. ツールカードをクリックすると引数と結果が展開される
5. 「停止」で処理を中断

画像やテキストの添付:
- 画像は入力欄に Ctrl+V で貼り付け、またはファイルをドラッグ&ドロップ、📎 ボタンから選択
- 3,000 文字を超えるテキストを貼り付けると、本文ではなく添付（📄）として扱われる
- 画像はセッションごとに `~/.apercode/sessions/<id>_files/` に保存され、直近 2 回分のみ LLM に渡す
- 画像を理解できるのは vision 対応モデル（例: `qwen3-vl`, `gemma3`, `llava`）のみ。非対応モデルでは画像を除いて送信し、その旨を表示する

プロジェクト直下に `AGENT.md`（または `CLAUDE.md`）を置くと、その内容がシステムプロンプトに読み込まれる。EA の命名規則や共通ライブラリの説明などを書いておくと精度が上がる。

## コンテキスト圧縮

履歴の推定トークン数（または直近の実測値）が `num_ctx × compaction.threshold` を超えると、
直近 `keep_recent` 件を残して古い履歴を LLM で要約し、1 メッセージに置き換える。
元のメッセージはセッション JSON の `archive` に保存される。
ヘッダー右上のメーターで現在の使用量を確認でき、「要約」ボタンで手動実行もできる。

## サブエージェント

親エージェントは `spawn_agent` ツールで子エージェントにサブタスクを委譲できる。
子は独立した会話履歴で動き、完了時に「結果報告」だけを親に返すので、親のコンテキストを消費しない。

- `mode=explore`: 読み取り専用（read_file / list_dir / glob / grep）。既存コードの調査向け
- `mode=code`: 編集・コマンド実行可。独立したモジュールの実装向け

承認が必要な操作は子でも同じように UI に承認ダイアログが出る。

### メインとサブのモデルを画面で選ぶ（v1.2.2）

左上に 2 つのプルダウンがある。上が **メインモデル**（会話・実装）、下が **サブモデル**（サブエージェントの調査・実装、
コードレビュー用）。サブに 8B クラスの軽いモデル（例: `llama3.1:8b`）を指定すると、調査やレビューが速くなり、
27B と 8B が同時に VRAM に載っていれば切り替えのロード待ちも無い。「サブ: メインLLMを使う」（既定）にすると 1 モデル運用になり、サブ LLM は不要。
選択は `~/.apercode/state.json` に記憶され、次回起動時も引き継がれる（`config.yaml` の `llm.model` /
`subagents.*_model` より優先。config の値に戻すには state.json の `model` / `sub_model` を削除する）。
ヘッダーに「モデル: qwen3.8:27b ／ サブ: llama3.1:8b」のように現在の組み合わせが出る。
画面で選ばない場合は `subagents.explore_model` / `code_model` / `verify.review.model` の設定が使われる。

## 経験メモリ

成功・失敗の教訓や環境固有の事実を蓄積し、次のタスクで自動的に参照する。分野（言語・ツール）に依存しない。

- 保存単位: `状況 / 行動 / 結果(成功・失敗・事実) / 教訓 / タグ / プロジェクト / 確認済みフラグ`
- 蓄積の経路
  - 自動: ツールを `reflect_min_tools` 回以上使ったターンの終了後、LLM が作業記録から教訓を抽出して保存（`memory.reflect: auto`）
  - エージェント自身: `save_memory` ツール
  - 手動: 左メニュー「経験メモリ」から追加・編集・削除・確認済み設定
- 参照の経路
  - 自動: ユーザー入力ごとに関連する経験を検索し、上位 `inject_top_k` 件をシステムプロンプトに注入（画面に「参照した経験」と表示）
  - エージェント自身: `search_memory` ツール
- 検索: 埋め込みベクトル（Ollama `bge-m3`）と全文検索（FTS5 trigram）のハイブリッド。プロジェクトの言語タグ一致・確認済みにボーナス
- 類似度 `dedup_threshold` 以上の既存メモリがあれば重複として保存しない

埋め込みモデルの準備:

```bash
ollama pull bge-m3
```

モデルが無い場合は全文検索のみで動作する（「経験メモリ」画面に「利用不可」と表示される）。
`embed_model` を変えたら「再索引」ボタンで埋め込みを再計算する。

自動抽出された教訓は `verified=0`（未確認）で保存される。管理画面で「確認済にする」を押すと検索時に優先される。
誤った教訓は削除すること。DB は `~/.apercode/memory.sqlite`（1 ファイル、バックアップはコピーするだけ）。

## コンテキストサイズの自動調整（v1.1.8）

起動時とモデル切替時に、空き VRAM（GPU が無ければ空き RAM）とモデルの構造（層数・KV ヘッド数・ヘッド次元）から
KV キャッシュに使えるトークン数を見積もり、`llm.num_ctx` を上限としてコンテキストサイズを自動で決める。
画面に「コンテキストサイズを自動設定: N tokens（GPU 空き … − モデル … → 約 … tokens）」と表示され、
ヘッダーのモデル名にマウスを乗せると計算根拠が見える。
GPU が複数ある場合は全 GPU の空き容量を合算する（Ollama は層を複数 GPU に分散して載せる）。予備は GPU ごとに確保する。

```
KV キャッシュ/トークン = 2 × 層数 × KV ヘッド数 × ヘッド次元 × 2 byte (f16)
使えるメモリ = 空き VRAM − モデル本体 − 予備 (reserve_mb)
num_ctx = 使えるメモリ × 0.8 ÷ KV/トークン → 4096 の倍数に切り下げ、min〜上限で丸める
```

`config.yaml` の `llm.auto_ctx`:

| 項目 | 内容 |
|---|---|
| `enabled` | 自動調整のオン/オフ（オフなら `num_ctx` をそのまま使う） |
| `min` / `max` | 下限 / 上限（`max: 0` なら `num_ctx` が上限） |
| `reserve_mb` | 計算用に空けておく予備メモリ（既定 1024） |
| `kv_cache_type` | Ollama の `OLLAMA_KV_CACHE_TYPE` に合わせる。`q8_0` なら約 2 倍のコンテキストが載る |
| `ram_offload_ratio` | 0 より大きいと空き RAM のこの割合も KV 用に数える（GPU に載りきらない分を RAM に逃がす前提。遅くなる） |

目安: 27B Q4（約 17 GB）を 24 GB の GPU で使う場合、f16 KV では 12k 前後、`q8_0` なら 24k 前後になる。
設定の 64k をそのまま使うと GPU に載りきらず RAM に退避されて極端に遅くなったり、Ollama が落ちたりするので、
自動調整の値を基準にし、必要なら `kv_cache_type: q8_0`（Ollama 側で `OLLAMA_KV_CACHE_TYPE=q8_0` と
`OLLAMA_FLASH_ATTENTION=1` を設定）で増やすのが安全。

## 生成コードの検証レイヤー（v1.2.0）

「書く → 検証 → 直す → レビュー」のループをシステム側で回し、人が承認しなくても壊れたコードが残りにくくする。
EA（MQL5）はコンパイラとバックテストで検証できるが、Python や他の言語のアプリにも同じ仕組みを用意したもの。

```
ユーザー指示 → 実装 → [自動チェック] NG なら差し戻し（最大 max_fix_rounds 回）
           → 完了報告の直前に [テスト自動実行] 失敗なら差し戻し
           → 変更が大きければ [レビュー子エージェント] 指摘があれば差し戻し
           → 完了報告 + 画面に「検証結果」サマリ
```

1. **自動チェック**: `write_file` / `edit_file` の直後に、拡張子に応じて構文・lint・型チェックを実行し、
   結果をツール結果の末尾（`## 自動検証`）として LLM に返す。NG なら「修正してから進む」よう指示する。
   外部ツールは「入っていれば使う」方式（無ければ構文チェックのみ）。

   | 言語 | 構文 | lint / 型（入っていれば） |
   |---|---|---|
   | Python | `py_compile` | `ruff`（未定義名・未使用 import 等の F/E9 ルールのみ）/ `pyflakes`、`verify.types: true` で `mypy` |
   | JS / TS | `node --check` / `tsc --noEmit` | `eslint`（設定ファイルがあるとき） |
   | Go | `go vet` | |
   | Rust | `cargo check` | |
   | シェル | `bash -n` | `shellcheck` |
   | C / C++ | `gcc/g++ -fsyntax-only` | |
   | JSON / YAML | パース | |

2. **テストの自動実行**（`run_tests` ツール）: LLM が完了報告をしようとした時点で、まだテストを実行していなければ
   システムがテストを走らせる。コマンドはプロジェクト構成から自動判定（`pytest` / `unittest` / `npm test` /
   `go test` / `cargo test` / `make test`。`backup/` は収集対象外）。失敗すれば失敗内容を LLM に戻して修正させる。
   テストが無いプロジェクトでは、変更した機能に対する最小限のテストの作成を 1 回促す
   （`verify.create_missing_tests: false` で無効）。LLM が `run_command` で自分でテストを走らせた場合も「テスト済み」と扱う。

3. **レビュー子エージェント**: 変更行数が `verify.review.min_changed_lines`（既定 50）以上のとき、読み取り専用の
   子エージェントが今回の差分（unified diff）をレビューし、バグ・未処理例外・呼び出し元との不整合・要件漏れ・
   セキュリティを high / medium / low で指摘する。high / medium があれば親に【レビュー指摘】として戻して修正させ、
   もう一度レビューする（`max_rounds`、既定 2）。小さな修正では走らないので LLM 呼び出しの増加は限定的。
   `verify.review.model` で軽いモデルをレビュー専用に指定できる。

4. **テストの保護（v1.2.1）**: 「失敗 → 修正」ループの罠は、実装ではなくテストの方をパッチに合わせて書き換えて
   通してしまうこと（assertion weakening）。これを防ぐため、そのターンでテストが一度失敗した後は、既存テストファイル
   （`tests/`, `test_*.py`, `*_test.py`, `*.spec.ts`, `conftest.py` など。`verify.test_patterns` で変更可）への
   `write_file` / `edit_file` と、テストパスを書き換えるシェルコマンド（`sed -i`, `>`, `rm`, `mv` …）を
   「常時許可」の対象外にし、毎回承認を求める（`verify.lock_tests: ask`）。`deny` にすると拒否して実装側の修正を
   指示する。新しいテストの追加は制限しない。さらに、テストが通った時点でターン開始時からの既存テストの変更・削除を
   検出し、「⚠ 既存テスト変更 N 件」として検証結果に表示する。
   また、テストが失敗したまま何も変更せずに完了報告しようとした場合は、再実行せずにそのまま差し戻す。

完了時に画面へ「検証結果 変更 N ファイル / M 行 ｜ 自動チェック x 回（NG y） ｜ テスト: PASS … ｜ レビュー: 指摘なし」
のサマリが出る。各行をクリックすると詳細（エラー出力・指摘内容）が開く。

`config.yaml` の `verify`:

| 項目 | 内容 |
|---|---|
| `enabled` | 検証レイヤー全体のオン/オフ |
| `lint` | `auto`（入っているツールを使う）/ `off`（write/edit 後のチェックをしない） |
| `types` | `true` なら Python で `mypy` も実行 |
| `tests` | `auto`（完了前に自動実行）/ `off` |
| `create_missing_tests` | テストが無いときに作成を促す |
| `max_fix_rounds` | 自動チェック NG / テスト失敗の差し戻し回数上限（既定 3） |
| `review.enabled` / `min_changed_lines` / `max_rounds` / `model` | レビューの有効化、対象となる変更行数、回数、使用モデル |
| `lock_tests` / `test_patterns` | テスト失敗後の既存テスト変更: `ask`（要承認）/ `deny` / `off`。テストと見なすパスの正規表現 |

`requirements.txt` に `ruff` と `pytest` を追加した。既存の venv では `pip install ruff pytest` を実行する。

## 変更前ファイルの自動バックアップ

エージェントが `write_file`（上書き）/ `edit_file` で既存ファイルを変更する直前に、元の内容を

```
<プロジェクト>/backup/<YYYYMMDD-HHMMSS>/<プロジェクト相対パス>
```

へ退避する。日時フォルダは「ユーザーの指示 1 回」につき 1 つで、その指示で変更された全ファイルの
変更前の状態がまとまる。ターン終了時に「変更前のファイル n 件を backup/... に退避しました」と表示される。

復元方法:
- チャットで「さっきの変更を元に戻して」と頼む → エージェントが `list_backups` で世代を確認し `restore_backup` で書き戻す
  （復元前の状態も新しい世代に退避されるので、やり直しも安全）
- 手動: `cp -r backup/20260920-153000/. .`（プロジェクト直下で実行）

`backup.keep_days`（既定 30 日）より古い世代は自動削除。`backup/` は list_dir / grep / glob の対象外。
`run_command` 経由の変更（`sed -i` など）は対象外なので、大きな変更の前は git commit も併用すること。

## アプリアイコンの生成

`make_icon` ツール（または CLI）で PNG 一式（16〜512px）、`.ico`、`.svg` を生成できる。Pillow を使用。

```bash
python3 -m codeagent.tools.icon --text AC --shape chevron --bg "#171a21" --fg "#5b8cff" --out assets/icon
python3 -m codeagent.tools.icon --image logo.png --out assets/icon          # 既存画像を角丸背景に埋め込む
```

チャットから「アプリのアイコンを作って。文字は MT、青系で」のように頼んでもよい（実行前に承認あり）。

## Web 検索と知見の蓄積（行き詰まり対策）

エージェントは分からない問題に当たっても作業を止めず、次の順で解決を試みる（システムプロンプトに組み込み済み）:

1. エラー全文を読み、原因の仮説を立てる
2. `search_memory` で過去の経験を確認
3. `web_search`（DuckDuckGo → Bing → Brave → Mojeek の順に自動フォールバック、API キー不要。v1.2.1.1）で検索し、`fetch_url` で公式ドキュメント・GitHub Issue・Q&A を読む
4. 見つけた解決策を試す。効かなければ別のキーワードで 2〜3 回繰り返す
5. 効いた解決策は `save_memory` に出典 URL 付きで保存（次回は検索せずに済む）
6. それでも解決しない場合のみ、試したことを整理してユーザーに相談

ターン終了時の自動抽出（振り返り）でも、Web 由来の解決策は「（参考: URL）」付きで経験メモリに入る。

### 行き詰まりの自動検知（v1.1.6）

エージェント本体が次の状態を監視し、放置せずに介入する。

- 同じツール呼び出し（同じ引数）を 3 回以上繰り返した、またはツールの失敗が 3 回連続した（その間に検索していない）
  → 「同じ操作を繰り返さず、search_memory → web_search / fetch_url で解決策を調べてから別の方法を試すこと」という
  指示を履歴に差し込む（画面に「行き詰まりを検知…」と表示）。1 ターンに最大 3 回
- ツール呼び出し上限（`llm.max_iterations`、既定 60）に達した
  → 黙って止まらず、ツールを使わずに「完了したこと・未完了・問題と原因の推測・次の手順」の状況報告を生成する。
  「続けて」と送れば同じセッションで作業を再開できる

検索中は画面の状態表示が「Web 検索中」になる。DuckDuckGo がブロック（403）・結果なしの場合は Bing、Brave、Mojeek、さらに API キー不要の JSON API
（Stack Exchange、GitHub Issues、Wikipedia）を順に試し、
すべて失敗したときだけエラーになる（`web.engines` で順序を変更可）。それでも
検索がブロックされる環境では `config.yaml` の `web.provider: searxng` と `web.searxng_url` で
自前の SearXNG を使う。検索サイトの 403 は `ddgs` パッケージ（requirements.txt に含まれる。既存の venv では
`.venv/bin/pip install ddgs`）で回避できることが多い。入っていれば最初に使われる。`web.enabled: false` で完全に無効化。

## 中規模プロジェクトを作るときのコツ

1. 最初に要件と設計を相談し、エージェントに `AGENT.md`（設計方針・構成・進捗）を書かせる
2. 機能単位で指示を出す。「全部作って」より「まず○○モジュールを作ってテストして」
3. 大きな調査や独立モジュールは子エージェントに任せるよう促す
4. セッションが長くなったら新しいセッションを作る。`AGENT.md` があれば引き継げる

## tool calling が使えないモデルの場合

`llm.tool_mode: json` にすると、モデルに次の形式でツール呼び出しを書かせて解析する:

````
```tool_call
{"name": "read_file", "arguments": {"path": "a.py"}}
```
````

## MT5 ツール

- `mt5_compile`: `.mq5` を `MetaEditor64.exe /compile` でコンパイル。MQL5 フォルダ外のファイルは `MQL5/Experts/AperCode/` にコピーしてからコンパイルし、`.ex5` を元の場所にも戻す
- `mt5_backtest`: `terminal64.exe /config:tester.ini` でストラテジーテスターを実行し、HTML レポートから純利益・PF・DD などを抽出

いずれも `WINEPREFIX=~/.wine_mt5` を使う（config.yaml で変更可）。

## Claude API を使う場合

```yaml
llm:
  provider: anthropic
anthropic:
  model: claude-sonnet-4-5
```

環境変数 `ANTHROPIC_API_KEY` を設定して起動。

## ツールの追加

`codeagent/tools/` に新しいモジュールを作り、`register(Tool(...))` で登録して `tools/__init__.py` の `load_builtin()` に import を足す。
