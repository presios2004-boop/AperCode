"""run_tests: プロジェクトのテストを実行して結果を要約する（v1.2.0）。

テストコマンドはプロジェクト構成から自動判定（pytest / unittest / npm test / go test / cargo test / make test）。
command を指定すればそれを使う。結果は ToolContext.verify（ターンの検証状態）にも記録され、
完了時の自動テストゲートで「テスト済み」と扱われる。
"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register
from .. import verify as V


async def run_tests(ctx: ToolContext, a: dict) -> str:
    cmd = (a.get("command") or "").strip() or None
    timeout = int(a.get("timeout", 600))
    res = await V.run_tests(ctx.project_dir, cmd, timeout=timeout,
                            ignore_dirs=(str(ctx.cfg.get("backup.dir", "backup")),))
    if ctx.verify is not None:
        ctx.verify.record_tests(res)
    if not res.detected:
        raise ToolError("テストコマンドを自動判定できませんでした。tests/ に test_*.py を作成するか、"
                        "package.json の scripts.test を定義するか、command を指定してください")
    head = f"$ {res.command}\n{res.summary()}\n"
    return head + (res.output if not res.ok else res.output[-1500:])


register(Tool(
    "run_tests",
    "プロジェクトのテストを実行して結果を要約する。コマンドは構成から自動判定（pytest / unittest / npm test / "
    "go test / cargo test / make test）。コードを変更したら完了報告の前に必ず実行し、失敗があれば修正して再実行する。"
    "テストが無いプロジェクトでは、まず主要な機能のテストを作成してから実行する。",
    {"type": "object", "properties": {
        "command": {"type": "string", "description": "テストコマンド（省略時は自動判定）"},
        "timeout": {"type": "integer", "description": "秒（既定 600）"}},
     "required": []},
    run_tests,
    lambda a: a.get("command") or "(自動判定)"))
