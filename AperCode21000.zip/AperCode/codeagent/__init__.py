"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "2.10.0"
__app_name__ = "AperCode"
