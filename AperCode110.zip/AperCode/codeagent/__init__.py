"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "1.1.0"
__app_name__ = "AperCode"
