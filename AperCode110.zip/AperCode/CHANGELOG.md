# Changelog

## 1.1.0 (2026-09-20)

- web_search / fetch_url ツール（DuckDuckGo / SearXNG）と「行き詰まったときの手順」をシステムプロンプトに追加
- save_memory に出典 URL を付けられるように。振り返りでも Web 由来の解決策に URL を含める
- 専用ウィンドウを GTK バックエンド優先に変更（OS の日本語入力が使える）。setup_linux_window.sh を追加
- IME 変換確定の Enter で送信されてしまう問題を修正
- ディレクトリ選択ダイアログ、存在しないディレクトリの作成確認

## 1.0.0 (2026-09-20)

初回リリース。

- Ollama（ローカル LLM）/ Anthropic API 対応のコーディングエージェント
- ツール: read_file / write_file / edit_file / list_dir / glob / grep / run_command
- MT5 (wine) 向けツール: mt5_compile / mt5_backtest
- Web UI（承認ダイアログ、ツール実行の可視化、状態表示、画像・テキスト添付、右クリックメニュー）
- コンテキスト自動圧縮（要約による置き換え）
- サブエージェント（explore / code モード）
- 経験メモリ（SQLite FTS5 + 埋め込みベクトルのハイブリッド検索、自動抽出、管理画面）
- デスクトップ起動（app.py / install_desktop.sh）
- 作業ディレクトリ選択ダイアログ、存在しない場合の作成確認
