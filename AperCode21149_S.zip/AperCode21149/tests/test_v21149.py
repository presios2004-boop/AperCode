"""v2.11.49 の回帰テスト: LLM サーバー（Strata など）のエンジンが落ちたら、待ってから送り直す。"""
from __future__ import annotations

from codeagent import agent as A

ERR = "{'type': 'server_error', 'message': 'the engine stopped unexpectedly (exit code -6); the next request restarts it'}"


def _fast_sleep(monkeypatch):
    waits = []
    real = A.asyncio.sleep

    async def fake(sec, *a, **k):
        waits.append(sec)
        await real(0)
    monkeypatch.setattr(A.asyncio, "sleep", fake)
    return waits


def test_engine_restart_is_retried(h, monkeypatch):
    waits = _fast_sleep(monkeypatch)
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("raise", ERR), ("text", "完了しました")], proj, {"phases.enabled": False})
    h.run(agent, s, "こんにちは。調子はどう？")
    assert not h.of("error")
    assert any("エンジンが停止しました" in (e.get("text") or "") for e in h.of("info"))
    assert 10 in waits and not llm.script


def test_engine_down_gives_up_after_two_retries(h, monkeypatch):
    _fast_sleep(monkeypatch)
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("raise", ERR)] * 3 + [("text", "完了しました")], proj, {"phases.enabled": False})
    h.run(agent, s, "こんにちは。調子はどう？")
    assert [e for e in h.of("error") if "LLM エラー" in e.get("text", "")]
    assert llm.script == [("text", "完了しました")]
