"""承認ダイアログの「この操作の内容」（v2.7.0）。

LLM が実行しようとしている操作（コマンド・ファイルの変更・送信など）を、ハーネスが決まった規則で日本語（英語）の説明にする。
LLM に説明させないのは、プロンプトインジェクションで誘導された LLM は説明でもうそをつけるため。
説明は「何を・どうするか」の行と、注意が必要な点（⚠ 行）からなる。知らないコマンドは知らないと書く。
"""
from __future__ import annotations

import re
import shlex
from pathlib import Path

from . import i18n

MAX_LINES = 14


def _(ja: str, en: str) -> str:
    return en if i18n.get_language() == "en" else ja


def _q(s: str, n: int = 60) -> str:
    """表示用に短くして「」で囲む。"""
    s = " ".join(str(s).split())
    if len(s) > n:
        s = s[:n] + "…"
    return _(f"「{s}」", f'"{s}"')


def _lines(text: str) -> int:
    return 0 if not text else text.count("\n") + (0 if text.endswith("\n") else 1)


# ------------------------------------------------------------------ 注意点
_SECRET = re.compile(r"(\.env\b|\.ssh\b|id_rsa|id_ed25519|\.netrc|\.pgpass|\.aws\b|credentials|api[_-]?key|secret|token|password|\.apercode\b|\.gnupg)", re.I)


class _Notes:
    def __init__(self, project: Path | None):
        self.project = project.resolve() if project else None
        self.warn: list[str] = []

    def add(self, w: str) -> None:
        if w not in self.warn:
            self.warn.append(w)

    def path(self, p: str) -> None:
        """作業ディレクトリの外・秘密情報らしいパスに注意を付ける。"""
        if not p or p.startswith("-"):
            return
        if _SECRET.search(p):
            self.add(_(f"秘密情報（鍵・パスワード・設定）を含みそうな場所に触れます: {p}",
                       f"Touches a place that may hold secrets (keys, passwords, config): {p}"))
        if self.project is None or not (p.startswith("/") or p.startswith("~")):
            if ".." in Path(p).parts and self.project is not None:
                self.add(_(f"作業ディレクトリの外（{p}）に触れます", f"Touches a path outside the working directory ({p})"))
            return
        try:
            q = Path(p).expanduser().resolve()
        except (OSError, RuntimeError):
            return
        if str(q).startswith(("/tmp", "/dev/null", "/usr/", "/bin/", "/proc/")):
            return
        if q != self.project and self.project not in q.parents:
            self.add(_(f"作業ディレクトリの外（{p}）に触れます", f"Touches a path outside the working directory ({p})"))


# ------------------------------------------------------------------ シェルコマンド
_SEPS = {"&&": ("（成功したら）次へ", "then, if it succeeded"), "||": ("（失敗したら）次へ", "then, if it failed"),
         ";": ("続けて", "then"), "|": ("その出力を次のコマンドに渡す", "pipe the output to"), "&": ("裏で動かしたまま次へ", "in the background, then")}


def _split(cmd: str) -> list[tuple[str, list[str]]]:
    """コマンド列を (区切り, トークン) に分ける。"""
    lex = shlex.shlex(cmd.replace("\n", " ; "), posix=True, punctuation_chars=";&|<>")
    lex.whitespace_split = True
    try:
        toks = list(lex)
    except ValueError:                       # 引用符の閉じ忘れ
        toks = cmd.split()
    out: list[tuple[str, list[str]]] = []
    cur: list[str] = []
    sep = ""
    for tk in toks:
        if tk in _SEPS:
            if cur:
                out.append((sep, cur))
            cur, sep = [], tk
        else:
            cur.append(tk)
    if cur:
        out.append((sep, cur))
    return out


def _args(a: list[str]) -> list[str]:
    return [x for x in a if not x.startswith("-")]


def _flags(a: list[str]) -> str:
    return " ".join(x for x in a if x.startswith("-"))


def _join(xs: list[str], n: int = 4) -> str:
    xs = [str(x) for x in xs]
    s = "、".join(xs[:n]) if i18n.get_language() != "en" else ", ".join(xs[:n])
    return s + (_(f" ほか {len(xs) - n} 件", f" and {len(xs) - n} more") if len(xs) > n else "")


def _segment(tokens: list[str], notes: _Notes, depth: int = 0) -> str:
    """1 つのコマンドを説明する。"""
    t = list(tokens)
    redirect = []
    # リダイレクト（> file / >> file / < file / 2>&1）
    i = 0
    while i < len(t):
        if t[i] in (">", ">>", "<", ">&", "&>", "<<<"):
            op = t[i]
            tgt = t[i + 1] if i + 1 < len(t) else ""
            fd = ""
            if i > 0 and re.fullmatch(r"\d", t[i - 1]):     # 2>file / 2>&1 の 2
                fd = t[i - 1]
                del t[i - 1]
                i -= 1
            del t[i:i + 2]
            if op in (">&", "&>") and re.fullmatch(r"\d", tgt):   # 2>&1
                continue
            if op == "<<<":
                continue
            if tgt in ("/dev/null",):
                redirect.append(_("エラー表示は捨てる", "errors discarded") if fd == "2" else _("出力は捨てる", "output discarded"))
            elif op.endswith(">>"):
                redirect.append(_(f"出力をファイル {tgt} の末尾に追記", f"append the output to {tgt}"))
                notes.path(tgt)
            elif op.endswith(">"):
                redirect.append(_(f"出力でファイル {tgt} を上書き", f"overwrite {tgt} with the output"))
                notes.path(tgt)
            else:
                redirect.append(_(f"ファイル {tgt} を入力にする", f"read input from {tgt}"))
            continue
        i += 1
    # 前置き（環境変数・sudo・timeout など）
    pre = []
    while t:
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", t[0]):
            pre.append(_(f"環境変数 {t[0].split('=')[0]} を設定して", f"with env {t[0].split('=')[0]} set,"))
            t.pop(0)
        elif t[0] == "sudo":
            notes.add(_("管理者権限（sudo）で実行します。システム全体を変更できます", "Runs with administrator rights (sudo); can change the whole system"))
            pre.append(_("管理者権限で", "as root,"))
            t = [x for x in t[1:]]
            while t and t[0].startswith("-"):
                t.pop(0)
        elif t[0] in ("timeout",) and len(t) > 1:
            pre.append(_(f"最大 {t[1]} 秒で", f"for at most {t[1]} s,"))
            t = t[2:]
        elif t[0] in ("nohup", "env", "exec", "command", "time", "nice"):
            t.pop(0)
        else:
            break
    if not t:
        return "、".join(redirect) or _("（何もしない）", "(nothing)")
    exe = t[0].rsplit("/", 1)[-1]
    a = t[1:]
    pos = _args(a)
    fl = _flags(a)
    d = _describe(exe, t[0], a, pos, fl, notes, depth)
    s = (" ".join(pre) + " " if pre else "") + d
    if redirect:
        s += _("（", " (") + _("、", ", ").join(redirect) + _("）", ")")
    return s


def _describe(exe: str, raw: str, a: list[str], pos: list[str], fl: str, notes: _Notes, depth: int) -> str:
    if not (exe in ("bash", "sh", "zsh") and "-c" in a):
        for p in pos:
            if "/" in p or p.startswith((".", "~")) or _SECRET.search(p):
                notes.path(p.lstrip("@"))
    if exe in ("ls", "ll", "tree"):
        return _(f"フォルダ {_join(pos) or '（今の場所）'} の中身を一覧表示する", f"list the contents of {_join(pos) or 'the current folder'}")
    if exe in ("cat", "head", "tail", "less", "more", "bat"):
        m = re.search(r"-n?\s*(\d+)", " ".join(x for x in a if x.startswith("-") or x.isdigit()))
        files = [x for x in pos if not x.isdigit()]
        src = _(f"ファイル {_join(files)}", f"the file {_join(files)}") if files else _("前のコマンドの出力", "the previous output")
        if exe in ("head", "tail") and m:
            part = _(f"{'先頭' if exe == 'head' else '最後'}の {m.group(1)} 行", f"the {'first' if exe == 'head' else 'last'} {m.group(1)} lines")
            return _(f"{src} の{part}を表示する", f"show {part} of {src}")
        return _(f"{src} の内容を表示する", f"show {src}")
    if exe in ("grep", "rg", "egrep", "ag"):
        pat = pos[0] if pos else ""
        return _(f"{_join(pos[1:]) or '入力'} の中から {_q(pat, 40)} を検索する", f"search {_join(pos[1:]) or 'the input'} for {_q(pat, 40)}")
    if exe == "find":
        s = _(f"{pos[0] if pos else '今の場所'} 以下のファイルを探す", f"find files under {pos[0] if pos else 'the current folder'}")
        if "-delete" in a:
            notes.add(_("見つかったファイルを削除します（元に戻せません）", "Deletes the files it finds (cannot be undone)"))
            s += _("（見つかったものを削除）", " (and delete them)")
        if "-exec" in a:
            s += _("（見つかったそれぞれに別のコマンドを実行）", " (and run a command on each)")
        return s
    if exe == "rm" or exe == "rmdir" or exe == "unlink":
        rec = bool(re.search(r"-\w*r|--recursive", fl)) or exe == "rmdir"
        notes.add(_("ファイルを削除します（ゴミ箱を通らず、元に戻せません）", "Deletes files permanently (no trash, cannot be undone)"))
        return _(f"{'フォルダごと' if rec else 'ファイル'} {_join(pos)} を削除する", f"delete {'the folders' if rec else 'the files'} {_join(pos)}")
    if exe == "mv":
        return _(f"{_join(pos[:-1])} を {pos[-1] if pos else '?'} へ移動（または名前を変更）する", f"move (or rename) {_join(pos[:-1])} to {pos[-1] if pos else '?'}")
    if exe == "cp":
        return _(f"{_join(pos[:-1])} を {pos[-1] if pos else '?'} にコピーする", f"copy {_join(pos[:-1])} to {pos[-1] if pos else '?'}")
    if exe == "mkdir":
        return _(f"フォルダ {_join(pos)} を作る", f"create the folder {_join(pos)}")
    if exe == "touch":
        return _(f"空のファイル {_join(pos)} を作る（あれば更新日時だけ変える）", f"create the empty file {_join(pos)} (or update its time)")
    if exe in ("chmod", "chown"):
        return _(f"{_join(pos[1:])} の{'権限' if exe == 'chmod' else '所有者'}を {pos[0] if pos else '?'} に変える", f"change the {'permissions' if exe == 'chmod' else 'owner'} of {_join(pos[1:])} to {pos[0] if pos else '?'}")
    if exe == "ln":
        return _(f"{pos[-1] if pos else '?'} に {pos[0] if pos else '?'} へのリンクを作る", f"create a link {pos[-1] if pos else '?'} → {pos[0] if pos else '?'}")
    if exe == "cd":
        return _(f"作業する場所を {pos[0] if pos else 'ホーム'} に移す", f"change directory to {pos[0] if pos else 'home'}")
    if exe in ("echo", "printf"):
        return _(f"文字列 {_q(' '.join(a), 50)} を出力する", f"print {_q(' '.join(a), 50)}")
    if exe in ("pwd", "whoami", "date", "uname", "hostname", "which", "type", "id", "nproc", "free", "df", "du", "ps", "top",
               "wc", "sort", "uniq", "cut", "tr", "jq", "file", "stat", "diff", "env", "printenv", "nvidia-smi", "lsof", "ss", "netstat"):
        return _(f"情報を表示する（{exe}{' ' + _join(pos) if pos else ''}）。ファイルは変えない", f"show information ({exe}{' ' + _join(pos) if pos else ''}); changes nothing")
    if exe == "sleep":
        return _(f"{pos[0] if pos else '?'} 秒待つ", f"wait {pos[0] if pos else '?'} seconds")
    if exe == "sed":
        if re.search(r"-\w*i", fl):
            return _(f"ファイル {_join(pos[1:])} の中身をその場で書き換える（{_q(pos[0] if pos else '', 30)}）", f"edit {_join(pos[1:])} in place ({_q(pos[0] if pos else '', 30)})")
        return _("文字列を置換して表示する（ファイルは変えない）", "transform text and print it (files unchanged)")
    if exe in ("awk", "gawk"):
        return _("テキストを加工して表示する", "process text and print it")
    if exe in ("python", "python3") or re.fullmatch(r"python3(\.\d+)?", exe):
        return _python(a, pos, notes)
    if exe in ("pip", "pip3"):
        return _pip(pos, notes, raw)
    if exe in ("pytest", "py.test"):
        return _(f"テストを実行する（{_join(pos) or 'すべて'}）", f"run the tests ({_join(pos) or 'all'})")
    if exe == "node":
        if "-e" in a or "--eval" in a:
            return _("短い JavaScript コードを実行する", "run a short JavaScript snippet")
        return _(f"Node.js で {pos[0] if pos else '?'} を実行する", f"run {pos[0] if pos else '?'} with Node.js")
    if exe in ("npm", "pnpm", "yarn", "npx"):
        sub = pos[0] if pos else ""
        if exe == "npx":
            notes.add(_("npx はパッケージをダウンロードして実行することがあります", "npx may download and run a package"))
            return _(f"パッケージ {sub} を（必要ならダウンロードして）実行する", f"run the package {sub} (downloading it if needed)")
        if sub in ("install", "i", "add", "ci"):
            return _(f"JavaScript のパッケージ {_join(pos[1:]) or '（package.json の依存）'} をインストールする", f"install JavaScript packages {_join(pos[1:]) or '(from package.json)'}")
        if sub in ("test", "t"):
            return _("テストを実行する（npm test）", "run the tests (npm test)")
        if sub == "run":
            return _(f"package.json のスクリプト {pos[1] if len(pos) > 1 else '?'} を実行する", f"run the package.json script {pos[1] if len(pos) > 1 else '?'}")
        return _(f"{exe} {sub} を実行する", f"run {exe} {sub}")
    if exe == "git":
        return _git(pos, a, notes)
    if exe in ("curl", "wget"):
        return _curl(exe, a, pos, notes)
    if exe in ("apt", "apt-get", "dnf", "yum", "pacman", "snap", "brew"):
        sub = pos[0] if pos else ""
        if sub in ("install", "remove", "purge", "upgrade", "-S"):
            notes.add(_("システムのパッケージを変更します", "Changes system packages"))
        return _(f"システムのパッケージを{'インストール' if sub == 'install' else '削除' if sub in ('remove', 'purge') else '操作'}する: {_join(pos[1:])}", f"{sub} system packages: {_join(pos[1:])}")
    if exe in ("kill", "pkill", "killall"):
        return _(f"実行中のプログラム {_join(pos)} を止める", f"stop the running program(s) {_join(pos)}")
    if exe in ("tar", "zip", "unzip", "gzip", "gunzip", "7z"):
        unpack = exe in ("unzip", "gunzip") or re.search(r"-\w*x", fl)
        return _(f"{_join(pos)} を{'展開' if unpack else '圧縮'}する", f"{'extract' if unpack else 'compress'} {_join(pos)}")
    if exe == "make":
        return _(f"make で {_join(pos) or '既定のターゲット'} を実行する（Makefile の中身による）", f"run make {_join(pos) or '(default target)'} (depends on the Makefile)")
    if exe in ("bash", "sh", "zsh", "source", "."):
        if "-c" in a:
            inner = a[a.index("-c") + 1] if a.index("-c") + 1 < len(a) else ""
            if depth < 2:
                sub = explain_command(inner, notes.project, depth + 1)
                for x in sub:
                    if x.startswith("⚠ "):
                        notes.add(x[2:])
                return _("次のシェルコマンドを実行する: ", "run this shell command: ") + " / ".join(x for x in sub if not x.startswith("⚠"))
        return _(f"シェルスクリプト {pos[0] if pos else '（入力）'} を実行する（中身はこの画面では分からない）", f"run the shell script {pos[0] if pos else '(stdin)'} (its contents are not shown here)")
    if exe in ("ssh", "scp", "rsync", "sftp", "nc", "ncat", "telnet", "ftp"):
        notes.add(_("ほかのマシンに接続・転送します", "Connects to / transfers to another machine"))
        return _(f"ほかのマシンと接続・転送する（{_join(pos)}）", f"connect or transfer to another machine ({_join(pos)})")
    if exe in ("base64",) and ("-d" in a or "--decode" in a):
        notes.add(_("隠された（エンコードされた）内容を元に戻しています。中身を確認してください", "Decodes hidden (encoded) content; check what it is"))
        return _("base64 でエンコードされた内容を元に戻す", "decode base64 content")
    if exe == "eval":
        notes.add(_("文字列をコマンドとして実行します（中身が見えにくい）", "Runs a string as a command (hard to see what it does)"))
        return _("文字列をコマンドとして実行する", "evaluate a string as a command")
    if exe in ("xdg-open", "open"):
        return _(f"{_join(pos)} を既定のアプリで開く", f"open {_join(pos)} with the default app")
    if exe in ("docker", "podman"):
        return _(f"コンテナを操作する（{_join(pos[:3])}）", f"manage containers ({_join(pos[:3])})")
    if exe in ("cargo", "go", "javac", "gcc", "g++", "clang", "rustc", "tsc", "dotnet"):
        sub = pos[0] if pos else ""
        if sub == "test":
            return _(f"テストを実行する（{exe} test）", f"run the tests ({exe} test)")
        return _(f"{exe} でビルド・実行する（{_join(pos[:3])}）", f"build / run with {exe} ({_join(pos[:3])})")
    return _(f"コマンド {exe} を実行する（引数: {_join(a, 5) or 'なし'}）。AperCode が説明を知らないコマンドです",
             f"run the command {exe} (args: {_join(a, 5) or 'none'}); AperCode has no description for it")


def _python(a: list[str], pos: list[str], notes: _Notes) -> str:
    if "-m" in a:
        mod = a[a.index("-m") + 1] if a.index("-m") + 1 < len(a) else "?"
        rest = a[a.index("-m") + 2:]
        if mod == "pip":
            return _pip(_args(rest), notes, "python -m pip")
        if mod in ("pytest", "unittest"):
            return _(f"テストを実行する（{mod}{' ' + _join(_args(rest)) if _args(rest) else ''}）", f"run the tests ({mod}{' ' + _join(_args(rest)) if _args(rest) else ''})")
        if mod == "venv":
            return _(f"Python の仮想環境を {_join(_args(rest))} に作る", f"create a Python virtual environment in {_join(_args(rest))}")
        if mod == "http.server":
            return _("このフォルダを Web サーバーとして公開する（ブラウザから見られる）", "serve this folder over HTTP")
        if mod == "py_compile":
            return _(f"{_join(_args(rest))} の文法チェックをする", f"syntax-check {_join(_args(rest))}")
        return _(f"Python のモジュール {mod} を実行する", f"run the Python module {mod}")
    if "-c" in a:
        code = a[a.index("-c") + 1] if a.index("-c") + 1 < len(a) else ""
        for w in _code_risks(code):
            notes.add(w)
        return _(f"短い Python コード {_q(code, 50)} を実行する", f"run the Python snippet {_q(code, 50)}")
    if pos:
        rest = " ".join(a[a.index(pos[0]) + 1:])
        return _(f"Python でスクリプト {pos[0]} を実行する{'（引数: ' + rest + '）' if rest else ''}。何をするかはスクリプトの中身による",
                 f"run the Python script {pos[0]}{' (args: ' + rest + ')' if rest else ''}; what it does depends on the script")
    return _("Python を起動する", "start Python")


def _pip(pos: list[str], notes: _Notes, raw: str) -> str:
    sub = pos[0] if pos else ""
    pk = pos[1:]
    where = _("作業ディレクトリの .venv（無ければシステム）", "the working directory's .venv (or the system)")
    if sub == "install":
        if any(p.startswith(("http://", "https://", "git+")) for p in pk):
            notes.add(_("Web 上の場所から直接パッケージを入れます", "Installs a package directly from a URL"))
        return _(f"Python パッケージ {_join(pk) or '（指定ファイルの一覧）'} をインストールする（入れ先: {where}）", f"install the Python packages {_join(pk) or '(from a file)'} (into {where})")
    if sub == "uninstall":
        return _(f"Python パッケージ {_join(pk)} を削除する", f"uninstall the Python packages {_join(pk)}")
    return _(f"pip {sub} を実行する（パッケージの情報表示など）", f"run pip {sub} (show package info etc.)")


def _git(pos: list[str], a: list[str], notes: _Notes) -> str:
    sub = pos[0] if pos else ""
    rest = pos[1:]
    m = {"status": ("変更状況を表示する", "show the change status"), "diff": ("変更の差分を表示する", "show the diff"),
         "log": ("履歴を表示する", "show the history"), "show": ("コミットの内容を表示する", "show a commit"),
         "add": (f"{_join(rest) + ' を' if rest and rest != ['.'] else 'すべての変更を'}コミット対象に加える", f"stage {_join(rest) if rest and rest != ['.'] else 'all changes'}"),
         "commit": ("変更をコミット（記録）する", "commit the changes"), "init": ("Git リポジトリを作る", "create a Git repository"),
         "branch": ("ブランチを表示・作成する", "list / create branches"), "stash": ("変更を一時退避する", "stash the changes"),
         "fetch": ("リモートの変更を取得する（作業中のファイルは変えない）", "fetch from the remote (working files unchanged)"),
         "pull": ("リモートの変更を取り込む（ファイルが変わる）", "pull from the remote (files change)"),
         "clone": (f"{rest[0] if rest else '?'} を複製（ダウンロード）する", f"clone {rest[0] if rest else '?'}"),
         "checkout": (f"{_join(rest) or '?'} に切り替える（ファイルが変わる）", f"switch to {_join(rest) or '?'} (files change)"),
         "switch": (f"ブランチ {_join(rest) or '?'} に切り替える", f"switch to branch {_join(rest) or '?'}"),
         "merge": (f"{_join(rest)} を合流させる", f"merge {_join(rest)}"), "rebase": ("履歴を並べ替える", "rebase the history"),
         "restore": (f"{_join(rest)} を元の状態に戻す（変更が消える）", f"restore {_join(rest)} (changes are lost)")}
    if sub == "push":
        notes.add(_("リモート（GitHub など）に送信します。公開リポジトリなら誰でも見られます", "Sends to the remote (e.g. GitHub); public repos are visible to anyone"))
        return _("コミットをリモートに送信（push）する", "push the commits to the remote")
    if sub == "reset" and "--hard" in a:
        notes.add(_("コミットしていない変更がすべて消えます（元に戻せません）", "All uncommitted changes are lost (cannot be undone)"))
        return _("変更を捨てて指定の時点に戻す", "discard changes and reset")
    if sub == "clean":
        notes.add(_("Git が管理していないファイルを削除します", "Deletes files not tracked by Git"))
        return _("管理外のファイルを削除する", "delete untracked files")
    if sub in m:
        return _("Git: ", "Git: ") + _(m[sub][0], m[sub][1])
    return _(f"Git の {sub} を実行する", f"run git {sub}")


def _curl(exe: str, a: list[str], pos: list[str], notes: _Notes) -> str:
    urls = [p for p in pos if re.match(r"https?://", p)] or pos[:1]
    send = any(x in a for x in ("-d", "--data", "--data-raw", "--data-binary", "-F", "--form", "-T", "--upload-file", "--post-data", "--post-file")) or \
        any(x in ("POST", "PUT", "PATCH", "DELETE") for x in a)
    out = None
    for flag in ("-o", "--output", "-O", "-P"):
        if flag in a:
            j = a.index(flag)
            out = a[j + 1] if flag not in ("-O",) and j + 1 < len(a) else _("（URL と同じ名前）", "(same name as the URL)")
    if send:
        notes.add(_(f"データを外部（{_join(urls)}）へ送信します。何を送るか確認してください", f"Sends data to an outside server ({_join(urls)}); check what is sent"))
        return _(f"{_join(urls)} にデータを送信する", f"send data to {_join(urls)}")
    if out:
        return _(f"{_join(urls)} からダウンロードして {out} に保存する", f"download {_join(urls)} and save it as {out}")
    return _(f"{_join(urls)} の内容を取得して表示する", f"fetch {_join(urls)} and print it")


def _code_risks(code: str) -> list[str]:
    """Python / JS のコードから、注意が必要な操作を探す。"""
    w = []
    if re.search(r"\b(os\.remove|os\.unlink|shutil\.rmtree|\.unlink\(|rmdir|fs\.rm|fs\.unlink)", code):
        w.append(_("コードがファイルを削除します", "The code deletes files"))
    if re.search(r"open\([^)]*['\"][wa]\+?b?['\"]|write_text|write_bytes|fs\.writeFile", code):
        w.append(_("コードがファイルに書き込みます", "The code writes files"))
    if re.search(r"\b(subprocess|os\.system|os\.popen|child_process|exec\()", code):
        w.append(_("コードがほかのコマンドを実行します", "The code runs other commands"))
    if re.search(r"\b(requests\.(post|put)|urlopen|httpx|socket\.|fetch\(|http\.request)", code):
        w.append(_("コードがネットワークに接続します", "The code connects to the network"))
    if _SECRET.search(code):
        w.append(_("コードが秘密情報（鍵・パスワード・設定）らしきものに触れます", "The code touches something that looks like secrets"))
    return w


def explain_command(cmd: str, project: Path | None = None, depth: int = 0) -> list[str]:
    """シェルコマンドの説明（1 行 = 1 コマンド。注意点は ⚠ で始まる行）。"""
    notes = _Notes(project)
    out: list[str] = []
    for n, (sep, toks) in enumerate(_split(cmd or "")):
        line = _segment(toks, notes, depth)
        if n and sep:
            line = "→ " + _(_SEPS[sep][0], _SEPS[sep][1]) + _(": ", ": ") + line
        out.append(line)
    if re.search(r"(curl|wget)[^|]*\|\s*(sudo\s+)?(ba|z)?sh\b", cmd or ""):
        notes.add(_("ダウンロードしたものをそのまま実行します（中身を確認できません）", "Runs downloaded content directly (cannot be inspected)"))
    if len(out) > MAX_LINES:
        out = out[:MAX_LINES] + [_(f"…ほか {len(out) - MAX_LINES} 個のコマンド", f"… and {len(out) - MAX_LINES} more commands")]
    return out + ["⚠ " + w for w in notes.warn]


# ------------------------------------------------------------------ ツール全般
def explain(name: str, args: dict, project: Path | None = None) -> list[str]:
    """承認ダイアログに出す説明の行。"""
    a = args or {}
    try:
        return _explain(name, a, project)
    except Exception:  # noqa: BLE001 — 説明は補助。失敗しても承認は続ける
        return []


def _explain(name: str, a: dict, project: Path | None) -> list[str]:
    notes = _Notes(project)
    lines: list[str] = []
    if name == "run_command":
        lines = explain_command(str(a.get("command", "")), project)
        if a.get("cwd"):
            notes.path(str(a["cwd"]))
            lines.insert(0, _(f"場所: {a['cwd']}", f"In: {a['cwd']}"))
        return lines + ["⚠ " + w for w in notes.warn if "⚠ " + w not in lines]
    if name == "process_start":
        lines = [_("次のコマンドを、止めるまで裏で動かし続ける（サーバーなど）:", "Keep this command running in the background until stopped (e.g. a server):")]
        lines += ["  " + x if not x.startswith("⚠") else x for x in explain_command(str(a.get("command", "")), project)]
        if a.get("port"):
            lines.insert(1, _(f"ポート {a['port']} で待ち受けるのを待つ", f"wait until port {a['port']} is listening"))
        return lines
    if name == "process_stop":
        return [_("裏で動いているすべてのプロセスを止める", "Stop all background processes") if a.get("all")
                else _(f"裏で動いているプロセス {a.get('id', '?')} を止める", f"Stop the background process {a.get('id', '?')}")]
    if name == "write_file":
        p = str(a.get("path", ""))
        notes.path(p)
        n = _lines(str(a.get("content", "")))
        exists = None
        if project is not None and p:
            q = Path(p).expanduser()
            q = q if q.is_absolute() else project / q
            exists = q.is_file()
            old = _lines(q.read_text(encoding="utf-8", errors="replace")) if exists else 0
        if exists:
            lines.append(_(f"ファイル {p} を丸ごと書き換える（{old} 行 → {n} 行）。元の内容は backup/ に保存される",
                           f"Overwrite the whole file {p} ({old} → {n} lines); the old content is saved to backup/"))
        else:
            lines.append(_(f"新しいファイル {p} を作る（{n} 行）", f"Create the new file {p} ({n} lines)"))
        for w in _code_risks(str(a.get("content", ""))) if p.endswith((".py", ".js", ".ts", ".sh", ".mjs")) else []:
            lines.append(_("このファイルを実行すると: ", "When this file runs: ") + w)
    elif name == "edit_file":
        p = str(a.get("path", ""))
        notes.path(p)
        o, nw = str(a.get("old_string", "")), str(a.get("new_string", ""))
        allr = _("（一致する箇所すべて）", " (every match)") if a.get("replace_all") else ""
        if not nw.strip():
            lines.append(_(f"ファイル {p} から {_lines(o)} 行を削除する{allr}", f"Delete {_lines(o)} line(s) from {p}{allr}"))
        else:
            lines.append(_(f"ファイル {p} の一部（{_lines(o)} 行）を、新しい内容（{_lines(nw)} 行）に置き換える{allr}",
                           f"Replace part of {p} ({_lines(o)} lines) with new content ({_lines(nw)} lines){allr}"))
        for w in _code_risks(nw) if p.endswith((".py", ".js", ".ts", ".sh", ".mjs")) else []:
            lines.append(_("追加されるコードを実行すると: ", "When the added code runs: ") + w)
    elif name == "restore_backup":
        lines.append(_(f"バックアップ {a.get('stamp') or '（最新）'} から {_join(a.get('files') or []) or 'すべてのファイル'} を元に戻す（今の内容は上書きされる）",
                       f"Restore {_join(a.get('files') or []) or 'all files'} from backup {a.get('stamp') or '(latest)'} (current content is overwritten)"))
    elif name == "repl":
        lang = "Node.js" if str(a.get("language", "")).lower() == "node" else "Python"
        code = str(a.get("code", ""))
        lines.append(_(f"{lang} の対話環境でコード（{_lines(code)} 行）を実行する{'（環境をリセットしてから）' if a.get('reset') else ''}",
                       f"Run {_lines(code)} line(s) of code in the {lang} session{' (after a reset)' if a.get('reset') else ''}"))
        for w in _code_risks(code):
            notes.add(w)
    elif name == "gui_launch":
        lines.append(_(f"デスクトップアプリを起動する: {a.get('command', '')}", f"Launch the desktop app: {a.get('command', '')}"))
    elif name == "gui_activate":
        lines.append(_(f"ウィンドウ {_q(a.get('window', ''), 40)} を前面に出す", f"Bring the window {_q(a.get('window', ''), 40)} to the front"))
    elif name == "gui_input":
        w = _q(a.get("window", ""), 40)
        if a.get("click"):
            lines.append(_(f"ウィンドウ {w} の位置 {a['click']} をクリックする", f"Click at {a['click']} in the window {w}"))
        if a.get("text"):
            lines.append(_(f"ウィンドウ {w} に文章 {_q(a['text'], 80)} を貼り付ける", f"Paste the text {_q(a['text'], 80)} into the window {w}"))
        if a.get("keys"):
            k = list(a["keys"])
            send = any(str(x).lower().endswith("return") or str(x).lower() == "enter" for x in k)
            lines.append(_(f"キー {_join(k)} を押す{'（文章を送信する）' if send and a.get('text') else ''}", f"Press {_join(k)}{' (sends the text)' if send and a.get('text') else ''}"))
    elif name in ("ask_peer", "peer_reply"):
        lines.append(_(f"LAN 上の AperCode（{a.get('peer') or '既定'}）に {_q(a.get('task') or a.get('text') or '', 80)} を送る",
                       f"Send {_q(a.get('task') or a.get('text') or '', 80)} to the AperCode on the LAN ({a.get('peer') or 'default'})"))
        if a.get("files"):
            lines.append(_(f"ファイルも送る: {_join(a['files'])}", f"Also send files: {_join(a['files'])}"))
            for f in a["files"]:
                notes.path(str(f))
    elif name == "cloud_chat":
        lines.append(_(f"クラウド AI に {_q(a.get('message', ''), 80)} を送る（外部のサービスに送信される）",
                       f"Send {_q(a.get('message', ''), 80)} to the cloud AI (leaves this computer)"))
    elif name == "ask_cloud":
        lines.append(_("クラウド AI に、目的・エラー・試したことを送って助言を求める（外部のサービスに送信される）",
                       "Send the goal, error and what was tried to the cloud AI for advice (leaves this computer)"))
        if a.get("files"):
            lines.append(_(f"ファイルの一部も送る: {_join(a['files'])}", f"Also send excerpts of: {_join(a['files'])}"))
    elif name == "save_memory":
        lines.append(_(f"経験メモリに {_q(a.get('lesson', ''), 80)} を保存する（今後のプロンプトに入る）",
                       f"Save {_q(a.get('lesson', ''), 80)} to experience memory (used in future prompts)"))
    elif name in ("fetch_url", "browser_open"):
        lines.append(_(f"{a.get('url', '')} を{'ブラウザで開く' if name == 'browser_open' else '取得して読む'}",
                       f"{'Open' if name == 'browser_open' else 'Fetch and read'} {a.get('url', '')}"))
    elif name == "browser_click":
        lines.append(_(f"ブラウザで {_q(a.get('target', ''), 50)} をクリックする", f"Click {_q(a.get('target', ''), 50)} in the browser"))
    elif name == "browser_type":
        lines.append(_(f"ブラウザの {_q(a.get('target', ''), 40)} に {_q(a.get('text', ''), 50)} を入力する{'して送信する' if a.get('submit') else ''}",
                       f"Type {_q(a.get('text', ''), 50)} into {_q(a.get('target', ''), 40)}{' and submit' if a.get('submit') else ''}"))
    elif name == "browser_press":
        lines.append(_(f"ブラウザでキー {a.get('key', '')} を押す", f"Press {a.get('key', '')} in the browser"))
    elif name == "browser_eval":
        lines.append(_(f"ブラウザのページで JavaScript {_q(a.get('js', ''), 60)} を実行する", f"Run the JavaScript {_q(a.get('js', ''), 60)} on the page"))
        for w in _code_risks(str(a.get("js", ""))):
            notes.add(w)
    elif name == "mt5_compile":
        lines.append(_(f"MQL5 のファイル {a.get('path', '')} をコンパイルする", f"Compile the MQL5 file {a.get('path', '')}"))
    elif name == "mt5_backtest":
        lines.append(_(f"{a.get('path', '')} を {a.get('symbol', '')} {a.get('period', '')} でバックテストする",
                       f"Backtest {a.get('path', '')} on {a.get('symbol', '')} {a.get('period', '')}"))
    elif name == "mt5_event_backtest":
        ev = a.get("events") or []
        what = (f"{len(ev)} 件のイベント" if ev else f"{a.get('topic', '')} の {a.get('kind') or 'すべての'} イベント")
        what_en = (f"{len(ev)} events" if ev else f"{a.get('kind') or 'all'} events of {a.get('topic', '')}")
        lines.append(_(f"{a.get('path', '')} を、過去の{what}の前後（{a.get('days_before', 2)} 日前〜{a.get('days_after', 2)} 日後）だけで 1 回ずつバックテストして集計する",
                       f"Backtest {a.get('path', '')} on the windows around past {what_en} ({a.get('days_before', 2)} days before to {a.get('days_after', 2)} after), one by one, and summarise"))
    elif name == "event_calendar":
        lines.append(_(f"{a.get('topic', '')} のイベントの日程を{'記録' if str(a.get('action')) == 'add' else '一覧'}する（research/ の中）",
                       f"{'Record' if str(a.get('action')) == 'add' else 'List'} event dates for {a.get('topic', '')} (in research/)"))
    elif name == "make_icon":
        lines.append(_(f"アイコン画像を {a.get('out') or 'assets/icon'}（.png / .ico / .svg）に作る", f"Create icon images at {a.get('out') or 'assets/icon'} (.png / .ico / .svg)"))
    elif name == "save_skill":
        fs = list((a.get("files") or {}).keys())
        lines.append(_(f"スキル {a.get('name', '?')} を{'更新' if a.get('overwrite') else '作成'}する（SKILL.md{'、' + _join(fs) if fs else ''}）。置き場: 作業ディレクトリの skills/",
                       f"{'Update' if a.get('overwrite') else 'Create'} the skill {a.get('name', '?')} (SKILL.md{', ' + _join(fs) if fs else ''}) in the working directory's skills/"))
        lines.append(_(f"説明: {_q(a.get('description', ''), 100)}", f"Description: {_q(a.get('description', ''), 100)}"))
        for f, c in (a.get("files") or {}).items():
            if str(f).endswith((".py", ".sh", ".js", ".mjs")):
                for w in _code_risks(str(c)):
                    lines.append(_(f"{f} を実行すると: ", f"When {f} runs: ") + w)
    elif name == "edit_skill":
        f = a.get("file") or "SKILL.md"
        if a.get("delete"):
            lines.append(_(f"スキル {a.get('name', '?')} のファイル {f} を消す（前の版は履歴に残る）", f"Delete {f} from the skill {a.get('name', '?')} (kept in history)"))
        elif a.get("content") is not None:
            lines.append(_(f"スキル {a.get('name', '?')} のファイル {f} を丸ごと書く（{_lines(str(a.get('content')))} 行）",
                           f"Write the whole file {f} of the skill {a.get('name', '?')} ({_lines(str(a.get('content')))} lines)"))
        else:
            lines.append(_(f"スキル {a.get('name', '?')} のファイル {f} の一部（{_lines(str(a.get('old_string', '')))} 行）を新しい内容（{_lines(str(a.get('new_string', '')))} 行）に置き換える",
                           f"Replace part of {f} in the skill {a.get('name', '?')} ({_lines(str(a.get('old_string', '')))} → {_lines(str(a.get('new_string', '')))} lines)"))
        code = str(a.get("content") if a.get("content") is not None else a.get("new_string") or "")
        if str(f).endswith((".py", ".sh", ".js", ".mjs")):
            for w in _code_risks(code):
                lines.append(_(f"{f} を実行すると: ", f"When {f} runs: ") + w)
    elif name == "run_skill":
        lines.append(_(f"スキル {a.get('name', '?')} のスクリプト {a.get('script', '?')} をサンドボックスの中で実行する"
                       f"{'（引数: ' + ' '.join(str(x) for x in a.get('args') or []) + '）' if a.get('args') else ''}。何をするかはスクリプトの中身による",
                       f"Run the script {a.get('script', '?')} of the skill {a.get('name', '?')} in the sandbox"
                       f"{' (args: ' + ' '.join(str(x) for x in a.get('args') or []) + ')' if a.get('args') else ''}; what it does depends on the script"))
    elif name == "market_data":
        lines.append(_(f"MT5 を起動して、{a.get('symbol') or '既定の銘柄'} の {a.get('period') or 'H1'} の価格データを CSV に書き出し、作業ディレクトリの market_data/ に置く",
                       f"Start MT5, export {a.get('symbol') or 'the default symbol'} {a.get('period') or 'H1'} prices to CSV in market_data/"))
    elif name == "research_note":
        src = a.get("source") or {}
        lines.append(_(f"資料「{src.get('institution') or src.get('title') or '?'}」のノートを作業ディレクトリの research/ に保存する",
                       f"Save a note on {src.get('institution') or src.get('title') or '?'} to research/"))
    elif name == "research_scenarios":
        lines.append(_(f"シナリオ {len(a.get('scenarios') or [])} 件を research/ に保存する", f"Save {len(a.get('scenarios') or [])} scenarios to research/"))
    elif name == "spawn_agent":
        lines.append(_(f"子エージェント（{'読み取り専用' if a.get('mode') == 'explore' else '編集可'}）に {_q(a.get('task', ''), 80)} を任せる",
                       f"Delegate {_q(a.get('task', ''), 80)} to a sub-agent ({'read-only' if a.get('mode') == 'explore' else 'can edit'})"))
    else:
        return []
    return lines + ["⚠ " + w for w in notes.warn]
