"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "2.11.11"
__app_name__ = "AperCode"
