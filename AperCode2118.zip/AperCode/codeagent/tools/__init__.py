"""ツールレジストリ。各ツールは Tool を継承し、register() で登録する。"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Awaitable

from ..config import Config


class ToolError(Exception):
    pass


@dataclass
class ToolContext:
    cfg: Config
    project_dir: Path
    depth: int = 0                                     # 0 = メインエージェント, 1 = 子エージェント
    spawn: Callable[[dict[str, Any]], Awaitable[str]] | None = None  # spawn_agent の実体（agent が注入）
    memory: Any = None                                 # MemoryStore（agent が注入。None なら無効）
    backup: Any = None                                 # BackupManager（agent が注入。None なら無効）
    verify: Any = None                                 # VerifyState（agent が注入。ターンの検証状態）
    browser: Any = None                                # Browser（Playwright。agent が注入。None なら無効）
    files_dir: Path | None = None                      # セッションのファイル置き場（スクリーンショット等）
    session_id: str = ""                               # v1.5.0: repl / process の紐付け用
    repls: Any = None                                  # ReplManager（agent が注入）
    procs: Any = None                                  # ProcessManager（agent が注入）
    phase: Any = None                                  # v1.9.0: PhaseState（親エージェントのみ。set_plan / step_done が通知を書く）
    checkpoints: Any = None                            # v1.9.0: CheckpointStore（write/edit の変更前を記録。子にも渡す）
    request: str = ""                                  # v2.11.7: ユーザーの最新の依頼（「続けて」などの短い返事は除く）
    fetched: Any = None                                # v2.11.0: このセッションで読んだ本文 {URL/パス: 本文}（research_note の引用の確認用）
    taint: Any = None                                  # v2.2.0: セッションの汚染状態（外部の内容を読んだか。security.new_state() の dict）

    def resolve(self, path: str) -> Path:
        """ワークスペース外へのアクセスを拒否しつつパスを解決する。"""
        p = Path(path).expanduser()
        if not p.is_absolute():
            p = self.project_dir / p
        p = p.resolve()
        root = self.cfg.workspace_root
        if root != p and root not in p.parents:
            raise ToolError(f"ワークスペース外のパスです: {p}（許可: {root} 配下）")
        return p


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]
    handler: Callable[[ToolContext, dict[str, Any]], Awaitable[str]]
    # UI に表示する要約を作る（承認ダイアログ用）
    summarize: Callable[[dict[str, Any]], str] = field(default=lambda a: "")

    def schema(self) -> dict:
        return {"type": "function", "function": {
            "name": self.name, "description": self.description, "parameters": self.parameters}}


_REGISTRY: dict[str, Tool] = {}


def register(tool: Tool) -> Tool:
    _REGISTRY[tool.name] = tool
    return tool


def get(name: str) -> Tool | None:
    return _REGISTRY.get(name)


def all_tools() -> list[Tool]:
    return list(_REGISTRY.values())


def schemas(names: list[str] | None = None) -> list[dict]:
    from ..i18n import tool_schema
    if names is None:
        return [tool_schema(t.schema()) for t in _REGISTRY.values()]
    return [tool_schema(_REGISTRY[n].schema()) for n in names if n in _REGISTRY]


# サブエージェントのモード別に使えるツール
READ_ONLY_TOOLS = ["read_file", "list_dir", "glob", "grep", "search_memory", "web_search", "fetch_url",
                   "browser_open", "browser_read", "browser_eval", "browser_screenshot", "browser_console",
                   "read_document", "check_js", "process_status", "process_logs", "gui_windows", "screenshot",
                   "digest", "peer_list", "peer_status", "peer_read_file", "list_skills", "use_skill",
                   "research_note", "research_summary", "market_stats", "research_scenarios", "event_calendar"]
CODE_TOOLS = READ_ONLY_TOOLS + ["write_file", "edit_file", "run_command", "mt5_compile", "mt5_backtest", "mt5_event_backtest", "save_memory",
                                "list_backups", "restore_backup", "make_icon", "run_tests", "ask_cloud",
                                "browser_open", "browser_read", "browser_click", "browser_type", "browser_press",
                                "browser_scroll", "browser_eval", "browser_screenshot", "browser_console", "browser_close",
                                "repl", "process_start", "process_stop", "gui_launch", "gui_activate", "gui_input",
                                "ask_peer", "peer_reply", "peer_verify", "cloud_chat", "save_skill", "edit_skill", "run_skill", "market_data"]


def load_builtin():
    from . import fs, shell, mt5, subagent, memory_tools, web, backup_tools, icon, verify_tools, cloud_tools, browser_tools, repl_tools, process_tools, doc_tools, jscheck_tools, brief_tools, phase_tools, gui_tools, peer_tools, skill_tools, research_tools  # noqa: F401  (import で登録される)
