"""セッション（会話履歴）の永続化。1セッション = 1 JSON ファイル。"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class Session:
    id: str
    project_dir: str
    title: str = "新しいセッション"
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    messages: list[dict] = field(default_factory=list)
    usage: dict = field(default_factory=lambda: {"prompt_tokens": 0, "completion_tokens": 0})
    archive: list[dict] = field(default_factory=list)   # 圧縮で要約に置き換えた元メッセージ
    last_prompt_tokens: int = 0                          # 直近の LLM 呼び出しの入力トークン数
    allow: list[str] = field(default_factory=list)       # このセッションで「常に許可」したもの（edit_run, outside_project, ツール名）
    stuck_carry: int = 0                                 # 前ターンから持ち越す失敗・行き詰まり回数（LLM 落ち・未解決のとき）
    mode: str = "auto"                                   # v2.1.0: auto（会話→作業へ自動で切り替え）/ chat（会話のみ）/ work（常に作業）
    working: bool = False                                # v2.1.0: auto のとき、いま作業中か（指示書・作業フェーズを使う）
    pause_pending: bool = False                          # v2.1.0: 承認で一時停止した。次の入力はユーザーの質問として答える
    taint: dict = field(default_factory=dict)            # v2.2.0: 外部の内容を読んだか（プロンプトインジェクション対策。security.new_state()）
    clarify_pending: bool = False                        # v2.0.0: 作業前の確認をユーザーに求めて止まっている（次の返事を指示書に追記して開始）
    skill_rec: dict = field(default_factory=dict)        # v2.11.23: 操作の記録（「⏺ スキルを作成」。skill_recorder）
    clarify_questions: list = field(default_factory=list)  # v2.11.22: そのときの質問（選択肢付き。「1-A」の返事を文章に戻す）
    phase: dict = field(default_factory=dict)            # v1.9.0: 作業フェーズ（PhaseState.to_dict()）。「続けて」で再開する

    @classmethod
    def new(cls, project_dir: str) -> "Session":
        return cls(id=time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6], project_dir=project_dir)

    def summary(self) -> dict:
        return {"id": self.id, "title": self.title, "project_dir": self.project_dir,
                "updated_at": self.updated_at, "n": len(self.messages), "mode": self.mode, "working": self.working,
                "taint": bool((self.taint or {}).get("active"))}


class SessionStore:
    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def path(self, sid: str) -> Path:
        return self.root / f"{sid}.json"

    def save(self, s: Session):
        s.updated_at = time.time()
        self.path(s.id).write_text(json.dumps(asdict(s), ensure_ascii=False, indent=1), encoding="utf-8")

    def load(self, sid: str) -> Session | None:
        p = self.path(sid)
        if not p.exists():
            return None
        data = json.loads(p.read_text(encoding="utf-8"))
        known = {f for f in Session.__dataclass_fields__}
        return Session(**{k: v for k, v in data.items() if k in known})

    def list(self) -> list[dict]:
        out = []
        for p in self.root.glob("*.json"):
            try:
                s = self.load(p.stem)
                if s:
                    out.append(s.summary())
            except Exception:
                continue
        return sorted(out, key=lambda x: x["updated_at"], reverse=True)

    def delete(self, sid: str):
        p = self.path(sid)
        if p.exists():
            p.unlink()
        d = self.root / f"{sid}_files"
        if d.is_dir():
            import shutil
            shutil.rmtree(d, ignore_errors=True)
