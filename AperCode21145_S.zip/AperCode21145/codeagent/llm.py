"""LLM クライアント。Ollama（ネイティブ tool calling / JSON フォールバック）と Anthropic に対応。

chat() は非同期ジェネレータで、以下のイベントを順に yield する:
  ("text", str)                      : 生成テキストの断片
  ("tool_call", {"id","name","args"}): ツール呼び出し
  ("done", {"prompt_tokens", "completion_tokens"})
"""
from __future__ import annotations

import json
import os
import re
import uuid
from typing import Any, AsyncIterator

import httpx

from .config import Config

Event = tuple[str, Any]

JSON_TOOL_INSTRUCTIONS = """
## ツールの呼び出し方法
ツールを使うときは、本文の末尾に次の形式のブロックを出力してください（複数可）。
ブロックを出力したら、そこで応答を終了してください。結果は次のメッセージで返されます。

```tool_call
{"name": "<ツール名>", "arguments": { ... }}
```

利用可能なツール:
"""


def _tool_schemas_text(tools: list[dict]) -> str:
    lines = []
    for t in tools:
        fn = t["function"]
        params = json.dumps(fn.get("parameters", {}), ensure_ascii=False)
        lines.append(f"- {fn['name']}: {fn.get('description','')}\n  parameters: {params}")
    return "\n".join(lines)


class LLMClient:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.provider = cfg.get("llm.provider", "ollama")
        self.tool_mode = cfg.get("llm.tool_mode", "native")
        self.model = cfg.get("llm.model", "gemma4:26b")
        self.base_url = cfg.get("llm.base_url", "http://localhost:11434").rstrip("/")
        self.temperature = float(cfg.get("llm.temperature", 0.2))
        self.num_ctx = int(cfg.get("llm.num_ctx", 32768))
        self.keep_alive = cfg.get("llm.keep_alive", "30m")     # チャットモデルを VRAM に保持する時間
        self.retries = int(cfg.get("llm.connect_retries", 3))  # 接続失敗時の再試行回数（Ollama 再起動待ち）
        self.num_predict = int(cfg.get("llm.num_predict", 0) or 0)   # 1 回の生成トークン上限（0 = 無制限）
        self.think = str(cfg.get("llm.think", "auto"))          # auto（モデル既定）| on | off（qwen3 などの思考モード）
        self.timeout = float(cfg.get("llm.timeout", 600))       # 応答待ちの秒数（ストリーミング中はチャンク間）
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(self.timeout, connect=10.0))
        # v2.11.43: 接続先（クラウド AI・LAN 上の LLM）。None = ローカルの Ollama（llm.base_url）
        self.local_base_url = self.base_url
        self.local_provider = self.provider
        self.local_num_ctx = self.num_ctx
        self.endpoint: dict | None = None
        self._ep_headers: dict = {}

    def use_endpoint(self, ep: dict | None, model: str) -> None:
        """v2.11.43: メインモデルの接続先を切り替える。ep = endpoints の 1 件（API キーを含む）/ None = ローカルの Ollama。"""
        from . import endpoints as EP
        self.model = model
        if not ep:
            self.endpoint = None
            self.provider = self.local_provider
            self.base_url = self.local_base_url
            self._ep_headers = {}
            self.num_ctx = self.local_num_ctx
            return
        t = str(ep.get("type") or "openai")
        self.endpoint = {k: v for k, v in ep.items() if k != "api_key"}
        self.provider = {"ollama": "ollama", "anthropic": "anthropic"}.get(t, "openai")
        self.base_url = str(ep.get("url") or "").rstrip("/") or (EP.ANTHROPIC_URL if t == "anthropic" else self.local_base_url)
        self._ep_headers = EP.headers(ep)
        self.num_ctx = int(ep.get("num_ctx") or EP.DEFAULT_CTX.get(t, 32768))

    def describe(self) -> str:
        """画面用の接続先の名前（API キーは含めない）。"""
        if not self.endpoint:
            return "ローカル（Ollama）"
        return str(self.endpoint.get("name") or self.endpoint.get("id"))

    def apply_settings(self) -> None:
        """設定画面で変えた値を反映する（モデル・num_ctx は別経路で管理）。"""
        cfg = self.cfg
        self.temperature = float(cfg.get("llm.temperature", 0.2))
        self.keep_alive = cfg.get("llm.keep_alive", "30m")
        self.tool_mode = cfg.get("llm.tool_mode", "native")
        self.num_predict = int(cfg.get("llm.num_predict", 0) or 0)
        self.think = str(cfg.get("llm.think", "auto"))
        t = float(cfg.get("llm.timeout", 600))
        if t != self.timeout:
            self.timeout = t
            self._client = httpx.AsyncClient(timeout=httpx.Timeout(t, connect=10.0))

    def _options(self, extra: dict | None = None) -> dict:
        o = {"temperature": self.temperature, "num_ctx": self.num_ctx}
        if self.num_predict > 0:
            o["num_predict"] = self.num_predict
        if extra:
            o.update(extra)
        return o

    def _payload_extra(self, think: str | None = None) -> dict:
        t = think if think is not None else self.think
        return {"think": True} if t == "on" else {"think": False} if t == "off" else {}

    async def close(self):
        await self._client.aclose()

    # ------------------------------------------------------------------ public
    async def chat(self, system: str, messages: list[dict], tools: list[dict],
                   model: str | None = None, options: dict | None = None,
                   think: str | None = None) -> AsyncIterator[Event]:
        fixed_model = model
        model = model or self.model
        import asyncio
        # v2.11.29: 思考モードに対応しないモデル（作業に合わせて think を指定したときに 400 になったもの）には think を送らない
        no_think: set = self.__dict__.setdefault("_no_think_models", set())
        if model in no_think:
            think = None
        for attempt in range(self.retries + 1):
            yielded = False
            try:
                try:
                    async for ev in self._chat(system, messages, tools, model, options, think):
                        yielded = True
                        yield ev
                    return
                except (httpx.HTTPStatusError, RuntimeError) as e:
                    msg = str(e).lower()
                    if isinstance(e, httpx.HTTPStatusError):
                        try:
                            msg += e.response.text.lower()
                        except Exception:  # noqa: BLE001  ストリームの本文を読めないことがある
                            pass
                    bad = (isinstance(e, httpx.HTTPStatusError) and e.response.status_code == 400) or "think" in msg
                    if think is None or yielded or not bad:
                        raise
                    no_think.add(model)
                    think = None
                    async for ev in self._chat(system, messages, tools, model, options, None):
                        yielded = True
                        yield ev
                    return
            except (httpx.ConnectError, httpx.RemoteProtocolError, httpx.ReadError) as e:
                # Ollama がモデル再ロード中／クラッシュ直後で一時的に応答しない場合に備えて再試行する
                # （出力を返し始めた後の切断は再試行しない: 重複出力を避ける）
                if attempt < self.retries and not yielded:
                    await asyncio.sleep(3 * (attempt + 1))
                    model = fixed_model or self.model          # v2.11.43: 待つ間に接続先を切り替えたら新しいモデルで
                    continue
                if isinstance(e, httpx.ConnectError):
                    if self.endpoint:
                        raise RuntimeError(f"LLM サーバーに接続できません（{self.describe()}: {self.base_url}）。相手の PC やネットワークを確認してください")
                    raise RuntimeError(f"LLM サーバーに接続できません ({self.base_url})。Ollama が起動しているか確認してください")
                raise RuntimeError(f"LLM との接続が途中で切れました（Ollama が落ちた可能性。メモリ不足なら num_ctx を減らす）: {e}")
            except httpx.ReadTimeout:
                raise RuntimeError("LLM からの応答がタイムアウトしました。モデルのロード中か、負荷が高い可能性があります")
            except httpx.HTTPStatusError as e:
                code = e.response.status_code
                hint = (f"モデル名が間違っている可能性: {model}" if code == 404 else
                        f"tool calling 非対応のモデルなど、リクエストを受け付けられない: {model}" if code == 400 else
                        f"Ollama の内部エラー。VRAM / メモリ不足やモデルの読み込み失敗の可能性: {model}" if code >= 500 else model)
                raise RuntimeError(f"LLM サーバーエラー {code}（{hint}）")

    async def _chat(self, system, messages, tools, model, options=None, think=None) -> AsyncIterator[Event]:
        if self.provider == "anthropic":
            async for ev in self._chat_anthropic(system, messages, tools, model):
                yield ev
        elif self.provider == "openai":
            async for ev in self._chat_openai(system, messages, tools, model, options):
                yield ev
        elif self.tool_mode == "json" or not tools:
            async for ev in self._chat_ollama_json(system, messages, tools, model, options, think):
                yield ev
        else:
            async for ev in self._chat_ollama_native(system, messages, tools, model, options, think):
                yield ev

    async def complete(self, system: str, prompt: str, model: str | None = None, options: dict | None = None,
                       think: str | None = None) -> str:
        """ツールなしの単発生成（要約などに使う）。options は Ollama の options を上書き（num_ctx / num_gpu など）。"""
        parts = []
        async for kind, data in self.chat(system, [{"role": "user", "content": prompt}], [], model, options, think):
            if kind == "text":
                parts.append(data)
        return "".join(parts)

    # ------------------------------------------------------------------ ollama
    def _ollama_messages(self, system: str, messages: list[dict]) -> list[dict]:
        out = [{"role": "system", "content": system}]
        for m in messages:
            if m["role"] == "tool":
                out.append({"role": "tool", "content": m["content"], "tool_name": m.get("name", "")})
            elif m["role"] == "assistant":
                msg: dict[str, Any] = {"role": "assistant", "content": m.get("content", "") or ""}
                if m.get("tool_calls"):
                    msg["tool_calls"] = [
                        {"function": {"name": tc["name"], "arguments": tc["args"]}} for tc in m["tool_calls"]
                    ]
                out.append(msg)
            else:
                msg = {"role": m["role"], "content": m["content"]}
                if m.get("images"):
                    msg["images"] = m["images"]  # base64 文字列のリスト（vision モデル用）
                out.append(msg)
        return out

    async def _chat_ollama_native(self, system, messages, tools, model, options=None, think=None) -> AsyncIterator[Event]:
        payload = {
            "model": model,
            "messages": self._ollama_messages(system, messages),
            "tools": tools,
            "stream": True,
            "options": self._options(options),
            "keep_alive": self.keep_alive,
            **self._payload_extra(think),
        }
        usage = {"prompt_tokens": 0, "completion_tokens": 0}
        async with self._client.stream("POST", f"{self.base_url}/api/chat", json=payload, headers=self._ep_headers) as r:
            r.raise_for_status()
            async for line in r.aiter_lines():
                if not line.strip():
                    continue
                chunk = json.loads(line)
                if "error" in chunk:
                    raise RuntimeError(chunk["error"])
                msg = chunk.get("message", {})
                if msg.get("thinking"):
                    yield ("thinking", msg["thinking"])
                if msg.get("content"):
                    yield ("text", msg["content"])
                for tc in msg.get("tool_calls", []) or []:
                    fn = tc.get("function", {})
                    args = fn.get("arguments", {})
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except json.JSONDecodeError:
                            args = {"_raw": args}
                    yield ("tool_call", {"id": uuid.uuid4().hex[:8], "name": fn.get("name"), "args": args})
                if chunk.get("done"):
                    usage["prompt_tokens"] = chunk.get("prompt_eval_count", 0)
                    usage["completion_tokens"] = chunk.get("eval_count", 0)
        yield ("done", usage)

    _JSON_BLOCK = re.compile(r"```tool_call\s*(\{.*?\})\s*```", re.S)

    # 本文に書かれたツール呼び出し（native モードで coder 系モデルが JSON をテキストとして出す場合の救済）
    _TEXT_CALL = re.compile(r"(?:```(?:tool_call|json)\s*(\{.*?\})\s*```|<tool_call>\s*(\{.*?\})\s*</tool_call>)", re.S)

    @classmethod
    def extract_text_tool_calls(cls, content: str, valid_names: set[str]) -> list[dict]:
        out = []
        for m in cls._TEXT_CALL.finditer(content or ""):
            raw = m.group(1) or m.group(2)
            try:
                d = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if not isinstance(d, dict):
                continue
            name = d.get("name") or (d.get("function") or {}).get("name")
            args = d.get("arguments") or d.get("parameters") or d.get("args") or (d.get("function") or {}).get("arguments") or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    continue
            if name in valid_names and isinstance(args, dict):
                out.append({"id": uuid.uuid4().hex[:8], "name": name, "args": args})
        return out

    async def _chat_ollama_json(self, system, messages, tools, model, options=None, think=None) -> AsyncIterator[Event]:
        """tool calling 非対応モデル向け: 本文中の ```tool_call``` ブロックを解析する。"""
        if tools:
            system = system + "\n" + JSON_TOOL_INSTRUCTIONS + _tool_schemas_text(tools)
        # tool の結果は user メッセージとして渡す
        conv = []
        for m in messages:
            if m["role"] == "tool":
                conv.append({"role": "user", "content": f"[tool result: {m.get('name')}]\n{m['content']}"})
            elif m["role"] == "assistant":
                content = m.get("content", "") or ""
                for tc in m.get("tool_calls", []) or []:
                    content += "\n```tool_call\n" + json.dumps(
                        {"name": tc["name"], "arguments": tc["args"]}, ensure_ascii=False) + "\n```"
                conv.append({"role": "assistant", "content": content})
            else:
                conv.append({k: v for k, v in m.items() if k in ("role", "content", "images")})
        payload = {
            "model": model,
            "messages": [{"role": "system", "content": system}] + conv,
            "stream": True,
            "options": self._options(options),
            "keep_alive": self.keep_alive,
            **self._payload_extra(think),
        }
        buf = ""
        usage = {"prompt_tokens": 0, "completion_tokens": 0}
        async with self._client.stream("POST", f"{self.base_url}/api/chat", json=payload, headers=self._ep_headers) as r:
            r.raise_for_status()
            async for line in r.aiter_lines():
                if not line.strip():
                    continue
                chunk = json.loads(line)
                if "error" in chunk:
                    raise RuntimeError(chunk["error"])
                piece = chunk.get("message", {}).get("content", "")
                if piece:
                    buf += piece
                    # tool_call ブロックが始まる前のテキストだけを流す
                    if "```tool_call" not in buf:
                        yield ("text", piece)
                if chunk.get("done"):
                    usage["prompt_tokens"] = chunk.get("prompt_eval_count", 0)
                    usage["completion_tokens"] = chunk.get("eval_count", 0)
        for m in self._JSON_BLOCK.finditer(buf):
            try:
                obj = json.loads(m.group(1))
                yield ("tool_call", {"id": uuid.uuid4().hex[:8], "name": obj.get("name"),
                                     "args": obj.get("arguments", {}) or {}})
            except json.JSONDecodeError:
                yield ("text", "\n[tool_call の JSON 解析に失敗しました]\n")
        yield ("done", usage)

    # --------------------------------------------------------------- anthropic
    async def _chat_anthropic(self, system, messages, tools, model=None) -> AsyncIterator[Event]:
        headers = dict(self._ep_headers) if self.endpoint else {}
        if not headers.get("x-api-key"):
            api_key = os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                raise RuntimeError("Anthropic の API キーが設定されていません（設定 → 接続先）")
            headers = {"x-api-key": api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
        if not self.endpoint:
            model = self.cfg.get("anthropic.model", "claude-sonnet-5-5")
        base = self.base_url if self.endpoint else "https://api.anthropic.com"
        a_tools = [{"name": t["function"]["name"], "description": t["function"].get("description", ""),
                    "input_schema": t["function"].get("parameters", {"type": "object", "properties": {}})}
                   for t in tools]
        a_msgs: list[dict] = []
        for m in messages:
            if m["role"] == "user":
                if m.get("images"):
                    def _mt(b: str) -> str:
                        return ("image/jpeg" if b.startswith("/9j/") else "image/webp" if b.startswith("UklGR")
                                else "image/gif" if b.startswith("R0lGOD") else "image/png")
                    blocks = [{"type": "image", "source": {"type": "base64", "media_type": _mt(b), "data": b}}
                              for b in m["images"]]
                    blocks.append({"type": "text", "text": m["content"] or "(画像を参照)"})
                    a_msgs.append({"role": "user", "content": blocks})
                else:
                    a_msgs.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                content: list[dict] = []
                if m.get("content"):
                    content.append({"type": "text", "text": m["content"]})
                for tc in m.get("tool_calls", []) or []:
                    content.append({"type": "tool_use", "id": tc["id"], "name": tc["name"], "input": tc["args"]})
                a_msgs.append({"role": "assistant", "content": content or [{"type": "text", "text": "(no content)"}]})
            elif m["role"] == "tool":
                block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
                if a_msgs and a_msgs[-1]["role"] == "user" and isinstance(a_msgs[-1]["content"], list):
                    a_msgs[-1]["content"].append(block)
                else:
                    a_msgs.append({"role": "user", "content": [block]})
        payload = {"model": model, "max_tokens": self.num_predict or 8192, "system": system, "messages": a_msgs,
                   "temperature": self.temperature}
        if a_tools:
            payload["tools"] = a_tools
        if self.cfg.get("llm.anthropic_cache", True) and "anthropic.com" in base:   # 互換サーバー（Strata など）には付けない
            self._anthropic_cache(payload)
        r = await self._client.post(f"{base}/v1/messages", json=payload, headers=headers)
        if r.status_code != 200:
            raise RuntimeError(f"Anthropic API error {r.status_code}: {r.text[:500]}")
        data = r.json()
        for block in data.get("content", []):
            if block["type"] == "text":
                yield ("text", block["text"])
            elif block["type"] == "tool_use":
                yield ("tool_call", {"id": block["id"], "name": block["name"], "args": block["input"]})
        u = data.get("usage", {})
        c_read, c_write = int(u.get("cache_read_input_tokens") or 0), int(u.get("cache_creation_input_tokens") or 0)
        # v2.11.44: キャッシュから読んだ分・書いた分も入力に含める（コンテキストの大きさの表示のため）
        yield ("done", {"prompt_tokens": int(u.get("input_tokens") or 0) + c_read + c_write,
                        "completion_tokens": u.get("output_tokens", 0), "cache_read_tokens": c_read, "cache_write_tokens": c_write})

    @staticmethod
    def _anthropic_cache(payload: dict) -> None:
        """v2.11.44: Anthropic のプロンプトキャッシュ。前回と同じ先頭部分（ツール定義・システムプロンプト・それまでの会話）を
        キャッシュから読ませ、入力の料金を下げる（キャッシュから読んだ分は通常の約 1 割）。区切りは 4 か所まで:
        ツール定義の最後・システムプロンプト・最後のメッセージ・その前のユーザーのメッセージ（前回の呼び出しで書いたキャッシュに確実に当てる）。"""
        eph = {"type": "ephemeral"}
        if payload.get("tools"):
            payload["tools"][-1] = {**payload["tools"][-1], "cache_control": eph}
        if isinstance(payload.get("system"), str) and payload["system"]:
            payload["system"] = [{"type": "text", "text": payload["system"], "cache_control": eph}]

        def mark(msg: dict) -> bool:
            c = msg.get("content")
            if isinstance(c, str):
                if not c:
                    return False
                msg["content"] = [{"type": "text", "text": c, "cache_control": eph}]
                return True
            if isinstance(c, list) and c:
                c[-1] = {**c[-1], "cache_control": eph}
                return True
            return False
        msgs = payload.get("messages") or []
        if msgs and mark(msgs[-1]):
            users = [i for i, m in enumerate(msgs[:-1]) if m.get("role") == "user"]
            if users:
                mark(msgs[users[-1]])                      # 前回の呼び出しの最後（ここまでは前回と同じ）

    # --------------------------------------------------------------- v2.11.43: OpenAI 互換 API
    @staticmethod
    def _openai_messages(system: str, messages: list[dict]) -> list[dict]:
        out: list[dict] = [{"role": "system", "content": system}]
        for m in messages:
            r = m["role"]
            if r == "tool":
                out.append({"role": "tool", "tool_call_id": str(m.get("tool_call_id") or ""), "content": m.get("content") or ""})
            elif r == "assistant":
                msg: dict[str, Any] = {"role": "assistant", "content": m.get("content") or ""}
                if m.get("tool_calls"):
                    msg["tool_calls"] = [{"id": str(tc["id"]), "type": "function",
                                          "function": {"name": tc["name"], "arguments": json.dumps(tc.get("args") or {}, ensure_ascii=False)}}
                                         for tc in m["tool_calls"]]
                out.append(msg)
            else:
                if m.get("images"):
                    def _mt(b: str) -> str:
                        return ("image/jpeg" if b.startswith("/9j/") else "image/webp" if b.startswith("UklGR")
                                else "image/gif" if b.startswith("R0lGOD") else "image/png")
                    parts: list[dict] = [{"type": "text", "text": m.get("content") or "(画像を参照)"}]
                    parts += [{"type": "image_url", "image_url": {"url": f"data:{_mt(b)};base64,{b}"}} for b in m["images"]]
                    out.append({"role": "user", "content": parts})
                else:
                    out.append({"role": "user", "content": m.get("content") or ""})
        return out

    async def _chat_openai(self, system, messages, tools, model, options=None) -> AsyncIterator[Event]:
        payload: dict[str, Any] = {"model": model, "messages": self._openai_messages(system, messages), "stream": True,
                                   "temperature": float((options or {}).get("temperature", self.temperature)),
                                   "stream_options": {"include_usage": True}}
        if tools:
            payload["tools"] = tools
        if self.num_predict > 0:
            payload["max_tokens"] = self.num_predict
        usage = {"prompt_tokens": 0, "completion_tokens": 0}
        calls: dict[int, dict] = {}
        async with self._client.stream("POST", f"{self.base_url}/chat/completions", json=payload,
                                       headers={**self._ep_headers, "Content-Type": "application/json"}) as r:
            if r.status_code >= 400:
                body = (await r.aread()).decode(errors="replace")[:500]
                raise RuntimeError(f"OpenAI 互換 API のエラー {r.status_code}: {body}")
            async for line in r.aiter_lines():
                line = line.strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue
                if chunk.get("error"):
                    raise RuntimeError(str(chunk["error"])[:500])
                if chunk.get("usage"):
                    usage["prompt_tokens"] = int(chunk["usage"].get("prompt_tokens") or 0)
                    usage["completion_tokens"] = int(chunk["usage"].get("completion_tokens") or 0)
                for ch in chunk.get("choices") or []:
                    d = ch.get("delta") or {}
                    th = d.get("reasoning_content") or d.get("reasoning")
                    if th:
                        yield ("thinking", str(th))
                    if d.get("content"):
                        yield ("text", d["content"])
                    for tc in d.get("tool_calls") or []:
                        i = int(tc.get("index", 0))
                        cur = calls.setdefault(i, {"id": "", "name": "", "args": ""})
                        if tc.get("id"):
                            cur["id"] = tc["id"]
                        fn = tc.get("function") or {}
                        if fn.get("name"):
                            cur["name"] += fn["name"]
                        if fn.get("arguments"):
                            cur["args"] += fn["arguments"]
        for i in sorted(calls):
            c = calls[i]
            try:
                args = json.loads(c["args"]) if c["args"].strip() else {}
            except json.JSONDecodeError:
                args = {"_raw": c["args"]}
            yield ("tool_call", {"id": re.sub(r"[^A-Za-z0-9_-]", "", c["id"])[:40] or uuid.uuid4().hex[:8],
                                 "name": c["name"], "args": args if isinstance(args, dict) else {"_raw": args}})
        yield ("done", usage)
