"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "2.11.45"
__app_name__ = "AperCode"
