"""AperCode デスクトップ起動: サーバーをバックグラウンドで起動してから専用ウィンドウを開く。

    python3 app.py            # 専用ウィンドウ（pywebview）→ 無ければ Chromium 系の --app モード → 無ければ既定ブラウザ
    python3 app.py --browser  # 常に既定ブラウザで開く

ウィンドウを閉じるとサーバーも終了する。ログは ~/.apercode/app.log に出力。
"""
from __future__ import annotations

import argparse
import logging
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from codeagent import __version__  # noqa: E402
from codeagent.config import Config, ensure_data_dir  # noqa: E402

LOG_DIR = ensure_data_dir()
logging.basicConfig(filename=LOG_DIR / "app.log", level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("codeagent.app")
logging.getLogger("httpx").setLevel(logging.WARNING)

APP_TITLE = "AperCode"


def port_open(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        return s.connect_ex((host, port)) == 0


def start_server(cfg: Config, host: str, port: int):
    """uvicorn を別スレッドで起動し、停止用の Server オブジェクトを返す。"""
    import uvicorn
    from codeagent.server.app import create_app

    config = uvicorn.Config(create_app(cfg), host=host, port=port, log_level="warning")
    server = uvicorn.Server(config)
    th = threading.Thread(target=server.run, daemon=True, name="uvicorn")
    th.start()
    for _ in range(100):  # 最大 10 秒待つ
        if port_open(host, port):
            return server
        time.sleep(0.1)
    raise RuntimeError("サーバーが起動しませんでした（~/.apercode/app.log を確認）")


def server_info(url: str) -> dict | None:
    """起動中の AperCode サーバーの情報（version, root）。AperCode でなければ None。"""
    try:
        import httpx
        r = httpx.get(f"{url}/api/config", timeout=2)
        if r.status_code != 200:
            return None
        d = r.json()
        return {"version": str(d.get("version") or ""), "root": d.get("root")} if "version" in d else None
    except Exception:
        return None


def server_version(url: str) -> str | None:
    info = server_info(url)
    return info["version"] if info else None


def free_port(host: str, start: int) -> int:
    for p in range(start, start + 50):
        if not port_open(host, p):
            return p
    raise RuntimeError("空いているポートが見つかりません")


def stop_server(url: str, host: str, port: int) -> bool:
    """起動中のサーバーに終了を要求し、ポートが空くまで待つ。"""
    try:
        import httpx
        httpx.post(f"{url}/api/shutdown", timeout=2)
    except Exception:
        pass
    for _ in range(50):
        if not port_open(host, port):
            return True
        time.sleep(0.1)
    return False


def ollama_running(base_url: str) -> bool:
    try:
        import httpx
        return httpx.get(f"{base_url}/api/tags", timeout=2).status_code == 200
    except Exception:
        return False


def try_start_ollama(base_url: str) -> bool:
    """Ollama が起動していなければ `ollama serve` をバックグラウンドで試みる。"""
    if ollama_running(base_url):
        return True
    exe = shutil.which("ollama")
    if not exe:
        return False
    log.info("ollama serve を起動します")
    subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    for _ in range(30):
        if ollama_running(base_url):
            return True
        time.sleep(0.5)
    return False


# ------------------------------------------------------------------ ウィンドウ
def _run_webview(url: str, gui: str | None = None) -> None:
    """（子プロセスで実行）pywebview のウィンドウを開き、閉じるまでブロックする。"""
    import webview  # type: ignore
    # text_select=True: pywebview の既定は選択不可なので、チャットのテキストをコピーできるようにする
    # v2.11.41: background_color = 画面と同じ暗い色（起動直後・終了時に白い枠が見えないように）
    # v2.11.41: サーバーの準備を待たずにウィンドウを出す（アイコンを押してから何も出ない時間をなくす。
    #           以前は数秒間なにも表示されず、もう一度アイコンを押してウィンドウが 2 つ開くことがあった）
    win = webview.create_window(APP_TITLE, html=LOADING_HTML, width=1360, height=880, min_size=(900, 600), text_select=True,
                                background_color="#0f1115")
    if gui == "gtk":
        win.events.closing += lambda: _hide_now(win)

    def go(w) -> None:
        for _ in range(600):                           # 最大 60 秒
            if server_info(url) is not None:
                w.load_url(url)
                return
            time.sleep(0.1)
        w.load_html(LOADING_HTML.replace("起動しています…", "サーバーが起動しませんでした（~/.apercode/app.log を確認）"))
    webview.start(go, win, gui=gui) if gui else webview.start(go, win)


LOADING_HTML = """<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;height:100%;background:#0f1115;color:#8b93a7;font-family:-apple-system,"Segoe UI","Noto Sans JP",sans-serif}
body{display:flex;align-items:center;justify-content:center;flex-direction:column;gap:14px}
b{font-size:30px;color:#e6e8ee;letter-spacing:.5px}</style></head>
<body><b>AperCode</b><div>起動しています…</div></body></html>"""


def _hide_now(win) -> None:
    """v2.11.41: 閉じるとき、ウィンドウの後片付け（WebKit の終了）を待たずに、先にウィンドウを消す。
    以前は後片付けの間、画面や白い枠が一瞬残っていた。closing は GTK のメインスレッドで同期して呼ばれる。"""
    try:
        from gi.repository import Gtk  # type: ignore
        from webview.platforms import gtk as G  # type: ignore
        inst = G.BrowserView.instances.get(win.uid)
        if inst is not None:
            inst.window.hide()
            for _ in range(50):                      # 隠す描画を先に済ませる
                if not Gtk.events_pending():
                    break
                Gtk.main_iteration_do(False)
    except Exception:  # noqa: BLE001
        pass


def gtk_webview_available() -> bool:
    """システムの GTK + WebKit2GTK（python3-gi）が使えるか。
    こちらは OS の入力メソッド（fcitx5 / ibus + Mozc）がそのまま効くので優先する。"""
    try:
        import gi  # type: ignore
        gi.require_version("Gtk", "3.0")
        for ver in ("4.1", "4.0"):
            try:
                gi.require_version("WebKit2", ver)
                from gi.repository import Gtk, WebKit2  # noqa: F401
                return True
            except (ValueError, ImportError):
                continue
    except Exception:
        pass
    return False


_GTK_CACHE: list[bool] = []


def GTK_OK() -> bool:
    """v2.11.41: gtk_webview_available() の結果を覚えておく（起動時に GTK と WebKit の読み込みを何度もしない）。"""
    if not _GTK_CACHE:
        _GTK_CACHE.append(gtk_webview_available())
    return _GTK_CACHE[0]


def open_webview(url: str, while_starting=None) -> bool:
    """pywebview で専用ウィンドウを開く。

    Qt/GTK の初期化失敗は Python の例外にならず即座にプロセスが落ちることがあるため、
    別プロセスで開き、すぐに異常終了した場合は False を返してフォールバックさせる。
    v2.11.41: ウィンドウを先に開き、while_starting（サーバーの起動）はその間に行う。
    """
    try:
        import webview  # type: ignore  # noqa: F401
    except ImportError:
        return False
    env = {**os.environ, "PYWEBVIEW_LOG": "critical"}
    gui = "gtk" if GTK_OK() else "qt"
    if gui == "qt":
        # pip 版 Qt には fcitx 用の入力プラグインが無い（ibus 用はある）。fcitx5 は ibus 互換
        # フロントエンドを持つので QT_IM_MODULE=ibus にすると IME が効く環境が多い。
        if env.get("QT_IM_MODULE", "").startswith("fcitx") or "QT_IM_MODULE" not in env:
            env["QT_IM_MODULE"] = "ibus"
    log.info("pywebview backend=%s", gui)
    t0 = time.time()
    proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "--_webview", url, "--_gui", gui],
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=env)
    try:
        if while_starting is not None:
            try:
                while_starting()
            except BaseException:
                proc.terminate()                       # サーバーを起動できなければ「起動中」のウィンドウも閉じる
                raise
        _, err_b = proc.communicate()
    finally:
        pass
    if proc.returncode != 0 and time.time() - t0 < 15:
        err = (err_b or b"").decode(errors="replace").strip().splitlines()
        log.warning("pywebview の起動に失敗 (code %s): %s", proc.returncode, " | ".join(err[-4:]))
        hint = ""
        if any("xcb" in l for l in err):
            hint = "  → sudo apt install -y libxcb-cursor0"
        print(f"専用ウィンドウ (pywebview) を開けませんでした。{hint}")
        return False
    return True


_LOCK: list = []


def take_window_lock() -> bool:
    """v2.11.41: 専用ウィンドウを開く AperCode は 1 つだけ（アイコンを続けて押しても 2 つ目は開かない）。
    ロックはこのプロセスが終わるまで持つ。取れなければ、既に別の AperCode がウィンドウを開いている（開いている途中も含む）。"""
    try:
        import fcntl
        f = open(LOG_DIR / f"window-{os.environ.get('USER', '')}.lock", "w")
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        _LOCK.append(f)
        return True
    except BlockingIOError:
        return False
    except Exception:  # noqa: BLE001
        return True                                # ロックを使えない環境では、これまでどおり開く


def window_running() -> bool:
    """AperCode の専用ウィンドウが既に開いているか（開いている途中も含む）。"""
    return not take_window_lock()


def activate_window() -> bool:
    """既に開いているウィンドウを前面に出す（wmctrl / xdotool があれば）。"""
    for cmd in (["wmctrl", "-a", APP_TITLE], ["xdotool", "search", "--name", f"^{APP_TITLE}$", "windowactivate"]):
        if shutil.which(cmd[0]):
            try:
                if subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3).returncode == 0:
                    return True
            except (OSError, subprocess.TimeoutExpired):
                pass
    return False


CHROMIUM_CANDIDATES = ["chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "brave-browser",
                       "microsoft-edge", "vivaldi"]


def open_chromium_app(url: str) -> bool:
    """Chromium 系ブラウザの --app モード（アドレスバー無しの専用ウィンドウ）。閉じるまでブロック。"""
    for name in CHROMIUM_CANDIDATES:
        exe = shutil.which(name)
        if exe:
            profile = LOG_DIR / "browser-profile"
            log.info("%s --app で開きます", exe)
            subprocess.run([exe, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run",
                            f"--window-size=1360,880", f"--class={APP_TITLE}"])
            return True
    # flatpak 版 Chromium/Chrome
    if shutil.which("flatpak"):
        for app_id in ("org.chromium.Chromium", "com.google.Chrome", "com.brave.Browser"):
            r = subprocess.run(["flatpak", "info", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if r.returncode == 0:
                subprocess.run(["flatpak", "run", app_id, f"--app={url}", "--no-first-run"])
                return True
    return False


def open_default_browser(url: str):
    """既定ブラウザで開く。ブロックしないので、Ctrl+C まで待つ。"""
    webbrowser.open(url)
    print(f"{APP_TITLE}: {url} をブラウザで開きました。終了するには Ctrl+C")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=None)
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--browser", action="store_true", help="専用ウィンドウではなく既定ブラウザで開く")
    ap.add_argument("--_webview", default=None, help=argparse.SUPPRESS)  # 内部用: ウィンドウ子プロセス
    ap.add_argument("--_gui", default=None, help=argparse.SUPPRESS)
    args = ap.parse_args()
    if args._webview:
        _run_webview(args._webview, args._gui)
        return

    cfg = Config.load(args.config)
    host = cfg.get("server.host", "127.0.0.1")
    port = args.port or int(cfg.get("server.port", 8765))
    url = f"http://{host}:{port}"

    if not args.browser and window_running():
        # v2.11.41: ウィンドウは既に開いている（開いている途中も含む）→ 2 つ目は開かずに前面に出す
        log.info("ウィンドウは既に開いています。前面に出します")
        activate_window()
        return
    server = None
    holder: dict = {}
    action = "start"
    if port_open(host, port):
        info = server_info(url)
        running_ver = info["version"] if info else None
        same_app = bool(info) and info.get("root") == str(HERE)
        if not same_app and (info is None or info.get("root") or running_ver == __version__):
            # v1.8.1: 別のフォルダの AperCode（AperCode_next など）や別のアプリがこのポートを使っている。
            # 同じバージョン番号でも中身・設定が違うので接続せず、空いているポートで自分のサーバーを起動する
            other = info.get("root") if info else None
            new_port = free_port(host, port + 1)
            log.info("ポート %d は別のアプリ（%s）が使用中。ポート %d で起動します", port, other or "不明", new_port)
            print(f"{APP_TITLE}: ポート {port} は別の" + (f"AperCode（{other}）" if other else "アプリ") +
                  f"が使っているため、ポート {new_port} で起動します")
            port = new_port
            url = f"http://{host}:{port}"
        elif running_ver == __version__:
            action = "connect"
            log.info("ポート %d は使用中（同一バージョン）。既存のサーバーに接続します", port)
            print(f"{APP_TITLE} v{__version__}: 既に起動中のサーバー ({url}) に接続します")
        else:
            action = "restart"
            # 古いコードのサーバー（ターミナルで起動したままの main.py など）が残っている → 止めて起動し直す
            log.info("ポート %d に別バージョン (%s) のサーバー。停止して起動し直します", port, running_ver)
            print(f"{APP_TITLE}: 古いサーバー (v{running_ver or '?'}) が動いていたため停止して起動し直します")

    def bring_up() -> None:
        """サーバーを用意する（ウィンドウを開いている間に行う）。"""
        if holder.get("done"):
            return
        holder["done"] = True
        if action == "connect":
            return
        if action == "restart" and not stop_server(url, host, port):
            print("古いサーバーを停止できませんでした。ターミナルの python3 main.py を Ctrl+C で終了してください")
            return
        try_start_ollama(cfg.get("llm.base_url", "http://localhost:11434"))
        holder["server"] = start_server(cfg, host, port)
        log.info("サーバー起動 %s", url)
        print(f"{APP_TITLE} v{__version__}: {url}")

    try:
        if args.browser:
            bring_up()
            open_default_browser(url)
        elif not ((GTK_OK() and open_webview(url, bring_up)) or (bring_up() or open_chromium_app(url))
                  or open_webview(url, bring_up)):
            print("専用ウィンドウを開けなかったため既定ブラウザで開きます"
                  "（専用ウィンドウにするには: pip install \"pywebview[qt]\"）")
            open_default_browser(url)
    finally:
        server = holder.get("server")
        if server is not None:
            log.info("終了します")
            server.should_exit = True
            time.sleep(0.5)


if __name__ == "__main__":
    main()
