"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "1.6.2"
__app_name__ = "AperCode"
