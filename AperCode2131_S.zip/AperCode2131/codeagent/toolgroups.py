"""ツール群の遅延公開（v2.12.0）。

AperCode は汎用エージェントなので 70 近いツールを持つが、1 回の LLM 呼び出しにすべてのスキーマ（約 35,000 文字）を
載せると、ローカル LLM はツールの選択を誤りやすく、プロンプトも重くなる。そこで、どの作業でも使う「中核ツール」だけを
常に見せ、分野ごとのツール（MT5・相場分析・ブラウザ・GUI 操作・ピア・スキルの作成など）は「群」にまとめて、
必要になったときだけスキーマを載せる。能力は減らさない（どの群もいつでも開ける）。

群が開くきっかけ（どれでも）:
  1. LLM が open_tools ツールで群を開く（システムプロンプトに閉じている群の一覧と一言の説明を載せる）
  2. 依頼・作業の指示書・プロジェクトの種類（.mq5 がある等）から AperCode が自動で開く（tools.auto_open）
  3. 閉じている群のツールを LLM が呼んだ（本文の XML など）→ 断らずに群を開いて実行する
  4. write_file / edit_file の対象（.mq5 → mt5、.html / .js → browser）、use_skill で読んだ手順に出てくるツール名
開いた群はセッションに保存され、以後そのセッションでは開いたまま（再起動しても引き継ぐ）。

設定（config.yaml の tools）:
  lazy: true / false       群の遅延公開を使う（false = これまでどおり全ツールを載せる）
  auto_open: true / false  依頼・指示書・プロジェクトから自動で開く
  always_open: [mt5, ...]  常に開いておく群
"""
from __future__ import annotations

import re
from typing import Iterable

# 群の定義。desc は LLM に見せる一言の説明（開くかどうかの判断材料）。keywords は依頼・指示書から自動で開くための語。
GROUPS: dict[str, dict] = {
    "mt5": {
        "tools": ["mt5_compile", "mt5_backtest", "mt5_event_backtest", "market_data"],
        "ja": "MetaTrader 5: EA（MQL5）のコンパイル・バックテスト・イベント前後のバックテスト・価格データの書き出し",
        "en": "MetaTrader 5: compile / back-test EAs (MQL5), event back-tests, export price data",
        "keywords": r"\bEA\b|MQL5|MQL4|MT5|MetaTrader|メタトレーダー|バックテスト|backtest|\.mq[45]\b|\.mqh\b|エキスパートアドバイザ|インジケータ",
        "exts": (".mq5", ".mqh", ".mq4"),
        "tags": ("mql5", "mql4"),
    },
    "research": {
        "tools": ["research_note", "research_summary", "market_stats", "research_scenarios", "event_calendar", "event_reaction"],
        "ja": "調査の記録: 資料のノート・集計・値動きの統計・シナリオ・イベントの日程と前後の値動き（相場分析や複数資料の調査）",
        "en": "Research records: source notes, aggregation, price statistics, scenarios, event calendar and reactions (market or multi-source research)",
        "keywords": r"相場|為替|シナリオ|見通し|フォーキャスト|forecast|FOMC|日銀|中央銀行|金融政策|会合|アナリスト|市場予想|"
                    r"market analysis|scenario|outlook|資料を(読|集|比|調)|文献|literature|出典",
        "exts": (),
        "tags": (),
    },
    "browser": {
        "tools": ["browser_open", "browser_read", "browser_click", "browser_type", "browser_press", "browser_scroll",
                  "browser_eval", "browser_screenshot", "browser_console", "browser_close", "check_js"],
        "ja": "内蔵ブラウザ: 作った Web アプリやページを開いて操作・確認する。check_js で JavaScript / HTML を検査する",
        "en": "Built-in browser: open and drive web apps / pages you built; check_js inspects JavaScript / HTML",
        "keywords": r"ブラウザ|browser|Web\s*アプリ|webapp|web app|HTML|JavaScript|\bJS\b|フロントエンド|frontend|localhost|"
                    r"ページを開|サイトを開|画面を見せ|Flask|FastAPI|Django|React|Vue|canvas|WebSocket",
        "exts": (".html", ".htm", ".js", ".mjs", ".ts", ".tsx", ".jsx", ".vue", ".css"),
        "tags": ("html", "react"),
    },
    "process": {
        "tools": ["process_start", "process_status", "process_logs", "process_stop"],
        "ja": "バックグラウンドのプロセス: サーバーなど長時間動くものの起動・状態・ログ・停止",
        "en": "Background processes: start / inspect / stop long-running programs such as servers",
        "keywords": r"サーバー|server|起動して|常駐|デーモン|daemon|ポート|port\b|uvicorn|gunicorn|npm (run|start)|node .*\.js|"
                    r"Web\s*アプリ|webapp|web app|Flask|FastAPI|Django|Express|localhost",
        "exts": (),
        "tags": (),
    },
    "gui": {
        "tools": ["gui_windows", "gui_launch", "gui_activate", "screenshot", "gui_input"],
        "ja": "デスクトップアプリの操作: ウィンドウ一覧・起動・前面化・スクリーンショット・クリックと入力（PC のブラウザやチャットアプリも）",
        "en": "Desktop app control: list / launch / focus windows, screenshots, clicks and typing (PC browsers and chat apps too)",
        "keywords": r"デスクトップ|ウィンドウ|window|アプリを(起動|開|操作)|スクリーンショット|screenshot|画面を(見|撮|確認)|"
                    r"Claude\s*(デスクトップ|desktop|アプリ)|Firefox|Chrome で|xdotool|\bGUI\b",
        "exts": (),
        "tags": (),
    },
    "collab": {
        "tools": ["peer_list", "ask_peer", "peer_reply", "peer_status", "peer_read_file", "peer_verify", "cloud_chat"],
        "ja": "ほかの AI との協調: LAN 上の別の AperCode（ピア）への依頼・返信・確認、クラウド AI との会話（cloud_chat）",
        "en": "Working with other AIs: ask / reply to / verify a peer AperCode on the LAN, chat with the cloud AI (cloud_chat)",
        "keywords": r"ピア|peer|分家|別の\s*AperCode|他の\s*PC|LAN|相談して|意見を聞|会話して|話し合|cloud_chat|クラウド\s*AI\s*と",
        "exts": (),
        "tags": (),
    },
    "skills": {
        "tools": ["save_skill", "edit_skill", "run_skill", "replay_skill", "skill_review"],
        "ja": "スキルの作成・変更・実行: 手順書とスクリプトを保存・修正し、スクリプトを実行・再生する。レビュー結果を読む（一覧と読むのは list_skills / use_skill）",
        "en": "Create / edit / run skills: save or fix procedures and scripts, run or replay them, read review findings (list_skills / use_skill are always available)",
        "keywords": r"スキル|skill|手順書|SKILL\.md|replay|再生",
        "exts": (),
        "tags": (),
    },
    "misc": {
        "tools": ["make_icon"],
        "ja": "その他: アプリのアイコン画像の生成（make_icon）",
        "en": "Other: generate an app icon image (make_icon)",
        "keywords": r"アイコン|icon\b|favicon",
        "exts": (".ico", ".icns"),
        "tags": (),
    },
}

OPEN_TOOL = "open_tools"

_TOOL_TO_GROUP: dict[str, str] = {n: g for g, d in GROUPS.items() for n in d["tools"]}
_KW_RE: dict[str, re.Pattern] = {g: re.compile(d["keywords"], re.I) for g, d in GROUPS.items() if d.get("keywords")}


def enabled(cfg) -> bool:
    try:
        return bool(cfg.get("tools.lazy", True))
    except Exception:  # noqa: BLE001
        return True


def auto_enabled(cfg) -> bool:
    try:
        return bool(cfg.get("tools.auto_open", True))
    except Exception:  # noqa: BLE001
        return True


def always_open(cfg) -> set[str]:
    try:
        v = cfg.get("tools.always_open", []) or []
    except Exception:  # noqa: BLE001
        v = []
    if isinstance(v, str):
        v = [x.strip() for x in v.split(",")]
    return {g for g in v if g in GROUPS}


def group_of(name: str) -> str | None:
    """ツール名が属する群（中核ツールなら None）。"""
    return _TOOL_TO_GROUP.get(name or "")


def normalize(groups: Iterable[str] | None) -> set[str]:
    return {g for g in (groups or []) if g in GROUPS}


def visible(cfg, names: list[str], open_groups: set[str] | None) -> list[str]:
    """LLM に見せるツール一覧に群のフィルタを掛ける。閉じている群のツールを除き、閉じている群が残っていれば open_tools を足す。
    遅延公開が無効なら names をそのまま返す（open_tools は除く）。"""
    if not enabled(cfg):
        return [n for n in names if n != OPEN_TOOL]
    opened = normalize(open_groups) | always_open(cfg)
    out = [n for n in names if n != OPEN_TOOL and (group_of(n) is None or group_of(n) in opened)]
    closed = closed_groups(cfg, names, opened)
    if closed:
        # open_tools は中核ツールの直後（読み取り系の後）に置く。位置はスキーマの並びだけで動作には関係ない
        out.append(OPEN_TOOL)
    return out


def closed_groups(cfg, names: list[str], open_groups: set[str] | None) -> list[str]:
    """names の中に属するツールがあり、まだ開いていない群（定義順）。names に 1 つも無い群（ピア未設定など）は出さない。"""
    opened = normalize(open_groups) | always_open(cfg)
    present = {group_of(n) for n in names} - {None}
    return [g for g in GROUPS if g in present and g not in opened]


def hidden_tools(cfg, names: list[str], open_groups: set[str] | None) -> list[str]:
    """names のうち、閉じている群に属していて今は見えていないツール。"""
    opened = normalize(open_groups) | always_open(cfg)
    return [n for n in names if group_of(n) is not None and group_of(n) not in opened]


def auto_open(cfg, text: str, tags: Iterable[str] = ()) -> set[str]:
    """依頼・指示書の文章とプロジェクトの種類（detect_project_tags）から、自動で開く群。"""
    if not enabled(cfg) or not auto_enabled(cfg):
        return set()
    out: set[str] = set()
    t = text or ""
    for g, rx in _KW_RE.items():
        if rx.search(t):
            out.add(g)
    tags_s = set(tags or ())
    for g, d in GROUPS.items():
        if tags_s & set(d.get("tags") or ()):
            out.add(g)
    return out


def auto_open_for_tool(cfg, name: str, args: dict | None) -> set[str]:
    """ツール呼び出しの内容から開く群: write_file / edit_file の対象ファイルの拡張子。"""
    if not enabled(cfg) or not auto_enabled(cfg):
        return set()
    if name not in ("write_file", "edit_file"):
        return set()
    path = str((args or {}).get("path") or "").lower()
    out: set[str] = set()
    for g, d in GROUPS.items():
        if any(path.endswith(e) for e in (d.get("exts") or ())):
            out.add(g)
    return out


_NAME_RE = re.compile(r"\b(" + "|".join(sorted(_TOOL_TO_GROUP, key=len, reverse=True)) + r")\b")


def groups_mentioned(cfg, text: str) -> set[str]:
    """文章（use_skill で読んだ SKILL.md など）に出てくる、閉じている群のツール名から開く群。"""
    if not enabled(cfg) or not auto_enabled(cfg):
        return set()
    return {_TOOL_TO_GROUP[m.group(1)] for m in _NAME_RE.finditer(text or "")}


def prompt_block(cfg, names: list[str], open_groups: set[str] | None, lang: str = "ja") -> str:
    """システムプロンプトに入れる、閉じている群の一覧。開いている群は出さない（スキーマが載っているので説明は不要）。"""
    if not enabled(cfg):
        return ""
    closed = closed_groups(cfg, names, open_groups)
    if not closed:
        return ""
    if lang == "en":
        head = ("\n\n## Tool groups not loaded yet\n"
                "To keep each request small, the tools below are grouped and their definitions are not loaded until needed. "
                "They are fully available: when the work needs one, call open_tools(groups=[...]) first; the tools of that group "
                "become callable from the next step and stay open for this session. Opening a group you end up not using is harmless.\n")
        rows = "".join(f"- {g}: {GROUPS[g]['en']}\n" for g in closed)
    else:
        head = ("\n\n## まだ読み込んでいないツール群\n"
                "1 回の呼び出しを軽くするため、次のツールは群にまとめ、必要になるまで定義を載せていない。使えなくなっているわけではない。"
                "作業に必要になったら、まず open_tools(groups=[...]) で群を開く。次の手番からその群のツールを呼べるようになり、"
                "このセッションの間は開いたまま。結局使わなかった群を開いても害はない。\n")
        rows = "".join(f"- {g}: {GROUPS[g]['ja']}\n" for g in closed)
    return head + rows


def describe_opened(groups: Iterable[str], lang: str = "ja") -> str:
    gs = [g for g in GROUPS if g in set(groups)]
    if not gs:
        return ""
    lines = []
    for g in gs:
        lines.append(f"- {g}: " + ", ".join(GROUPS[g]["tools"]))
    if lang == "en":
        return "Opened tool groups (callable from the next step):\n" + "\n".join(lines)
    return "次のツール群を開きました（次の手番から呼べます）:\n" + "\n".join(lines)
