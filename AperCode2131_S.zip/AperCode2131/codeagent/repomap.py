"""リポジトリマップ（v2.12.0）。

作業ディレクトリのファイル木と、主なファイルの関数・クラスを短い一覧にして、LLM を呼ぶたびに
システムプロンプトへ添える。行番号は示さない（v2.12.1: 地図はターンの開始時に作るので、作業中の編集で行がずれ、
古い行番号を信じた edit_file の失敗が増えた。ベンチで検証 NG 17 → 27）。ローカル LLM は「どこに何があるか」を list_dir / grep / read_file で何往復も調べてから
作業に入りやすく、その往復でコンテキストを使い切る。地図を先に渡しておけば、読むべきファイルへ直接向かえる。

- ファイル木: 隠しフォルダ・.venv・node_modules・backup・.apercode・ビルド生成物などは除く。大きなフォルダは先頭だけ
- 記号: Python は ast（クラスとメソッド・関数・引数）、JS / TS / Go / Rust / Java / C 系 / MQL5 / シェルは正規表現で宣言を拾う
- 大きさ: repomap.max_chars（既定 8000 文字 ≈ 3K トークン）に収める。木を先に入れ、残りで記号を優先度順（浅い・小さい・
  テスト以外）に入れる。入らなかったファイルは数だけ示す
- 速さ: 記号の解析結果は (パス, mtime, サイズ) でキャッシュし、変わったファイルだけ解析し直す

設定（config.yaml の repomap）: enabled / max_chars / max_files / exclude（追加で除くフォルダ名）
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_EXCLUDE = {".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv", "env", ".env", ".apercode", ".pytest_cache",
                   ".mypy_cache", ".ruff_cache", ".tox", "dist", "build", ".next", ".nuxt", "target", ".idea", ".vscode", "coverage",
                   "htmlcov", ".cache", "site-packages", "bt_reports", "snapshots", ".ipynb_checkpoints"}
CODE_EXTS = {".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java", ".kt", ".c", ".cpp", ".cc", ".h", ".hpp",
             ".cs", ".rb", ".php", ".sh", ".bash", ".mq5", ".mqh", ".mq4", ".lua", ".swift", ".dart", ".vue"}
MAX_FILE_BYTES = 1_000_000
MAX_TREE_PER_DIR = 40          # 1 フォルダに並べるファイル数の上限（超えた分は数だけ）
TEST_RE = re.compile(r"(^|/)(tests?|__tests__|spec)(/|$)|(^|/)test_[^/]*\.py$|_test\.(py|go|js|ts)$|\.(spec|test)\.(js|ts|tsx|jsx)$")

# 正規表現で宣言を拾う言語（Python は ast）
_RX: dict[str, list[tuple[re.Pattern, str]]] = {
    "js": [(re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)\s*\(([^)]*)\)", re.M), "function {0}({1})"),
           (re.compile(r"^\s*(?:export\s+)?(?:default\s+)?class\s+([A-Za-z_$][\w$]*)(?:\s+extends\s+([\w$.]+))?", re.M), "class {0}"),
           (re.compile(r"^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\(([^)]*)\)|([A-Za-z_$][\w$]*))\s*=>", re.M), "const {0} = ({1}) =>")],
    "go": [(re.compile(r"^func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)\s*\(([^)]*)\)", re.M), "func {0}({1})"),
           (re.compile(r"^type\s+([A-Za-z_]\w*)\s+(struct|interface)", re.M), "type {0} {1}")],
    "rs": [(re.compile(r"^\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+([A-Za-z_]\w*)\s*(?:<[^>]*>)?\s*\(([^)]*)\)", re.M), "fn {0}({1})"),
           (re.compile(r"^\s*(?:pub(?:\([^)]*\))?\s+)?(struct|enum|trait)\s+([A-Za-z_]\w*)", re.M), "{0} {1}"),
           (re.compile(r"^\s*impl(?:<[^>]*>)?\s+([\w:<>, ]+?)\s*(?:for\s+([\w:<>, ]+))?\s*\{", re.M), "impl {0}")],
    "java": [(re.compile(r"^\s*(?:public|private|protected)?\s*(?:static\s+)?(?:final\s+)?(?:abstract\s+)?(class|interface|enum|record)\s+([A-Za-z_]\w*)", re.M), "{0} {1}"),
             (re.compile(r"^\s*(?:public|private|protected)\s+(?:static\s+)?(?:final\s+)?(?:[\w<>\[\], ?]+)\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*(?:throws[^{]*)?\{", re.M), "{0}({1})")],
    "c": [(re.compile(r"^(?!\s*(?:if|for|while|switch|return|else)\b)[A-Za-z_][\w\s\*&<>:,]*?\b([A-Za-z_]\w*)\s*\(([^;)]*)\)\s*(?:const\s*)?\{", re.M), "{0}({1})"),
          (re.compile(r"^\s*(?:typedef\s+)?(struct|class|enum|union)\s+([A-Za-z_]\w*)\s*(?::[^{]*)?\{", re.M), "{0} {1}")],
    "mq5": [(re.compile(r"^(?!\s*(?:if|for|while|switch|return|else)\b)(?:[A-Za-z_]\w*\s+)+([A-Za-z_]\w*)\s*\(([^;)]*)\)\s*\{?\s*$", re.M), "{0}({1})"),
            (re.compile(r"^\s*(?:input|sinput)\s+([\w<>]+)\s+([A-Za-z_]\w*)\s*=\s*([^;]+);", re.M), "input {0} {1} = {2}"),
            (re.compile(r"^\s*(class|struct|enum)\s+([A-Za-z_]\w*)", re.M), "{0} {1}")],
    "sh": [(re.compile(r"^\s*(?:function\s+)?([A-Za-z_]\w*)\s*\(\)\s*\{", re.M), "{0}()")],
    "rb": [(re.compile(r"^\s*(?:def\s+(?:self\.)?([a-zA-Z_]\w*[?!=]?)(?:\(([^)]*)\))?)", re.M), "def {0}({1})"),
           (re.compile(r"^\s*(class|module)\s+([A-Z]\w*(?:::\w+)*)", re.M), "{0} {1}")],
    "php": [(re.compile(r"^\s*(?:public|private|protected)?\s*(?:static\s+)?function\s+([A-Za-z_]\w*)\s*\(([^)]*)\)", re.M), "function {0}({1})"),
            (re.compile(r"^\s*(?:abstract\s+|final\s+)?(class|interface|trait)\s+([A-Za-z_]\w*)", re.M), "{0} {1}")],
}
_LANG = {".js": "js", ".mjs": "js", ".cjs": "js", ".ts": "js", ".tsx": "js", ".jsx": "js", ".vue": "js", ".go": "go", ".rs": "rs",
         ".java": "java", ".kt": "java", ".cs": "java", ".c": "c", ".cpp": "c", ".cc": "c", ".h": "c", ".hpp": "c",
         ".mq5": "mq5", ".mqh": "mq5", ".mq4": "mq5", ".sh": "sh", ".bash": "sh", ".rb": "rb", ".php": "php", ".lua": "sh",
         ".swift": "java", ".dart": "java"}


@dataclass
class FileInfo:
    rel: str
    size: int
    mtime: float
    symbols: list[tuple[int, str]] = field(default_factory=list)      # (行番号, 表示)


def _args(a: ast.arguments) -> str:
    parts: list[str] = []
    pos = a.posonlyargs + a.args
    defaults = [None] * (len(pos) - len(a.defaults)) + list(a.defaults)
    for arg, d in zip(pos, defaults):
        parts.append(arg.arg + ("=…" if d is not None else ""))
    if a.vararg:
        parts.append("*" + a.vararg.arg)
    for arg in a.kwonlyargs:
        parts.append(arg.arg + "=…")
    if a.kwarg:
        parts.append("**" + a.kwarg.arg)
    s = ", ".join(parts)
    return s if len(s) <= 70 else s[:67] + "..."


def _py_symbols(src: str) -> list[tuple[int, str]]:
    try:
        tree = ast.parse(src)
    except (SyntaxError, ValueError):
        return []
    out: list[tuple[int, str]] = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            pre = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
            out.append((node.lineno, f"{pre} {node.name}({_args(node.args)})"))
        elif isinstance(node, ast.ClassDef):
            bases = ", ".join(ast.unparse(b) for b in node.bases[:3]) if node.bases else ""
            out.append((node.lineno, f"class {node.name}" + (f"({bases})" if bases else "")))
            for m in node.body:
                if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if m.name.startswith("__") and m.name.endswith("__") and m.name != "__init__":
                        continue
                    pre_m = "async def" if isinstance(m, ast.AsyncFunctionDef) else "def"
                    out.append((m.lineno, f"  {pre_m} {m.name}({_args(m.args)})"))
    return out


def _rx_symbols(src: str, lang: str) -> list[tuple[int, str]]:
    out: list[tuple[int, str]] = []
    seen: set[tuple[int, str]] = set()
    for rx, fmt in _RX.get(lang, []):
        for m in rx.finditer(src):
            groups = [(" ".join((g or "").split()))[:60] for g in m.groups()]
            while len(groups) < 3:
                groups.append("")
            try:
                text = fmt.format(*groups).strip()
            except (IndexError, KeyError):
                continue
            line = src.count("\n", 0, m.start()) + 1
            key = (line, text)
            if key in seen or not text:
                continue
            seen.add(key)
            out.append(key)
    out.sort()
    return out[:80]


def symbols_of(path: Path, suffix: str) -> list[tuple[int, str]]:
    try:
        src = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    if suffix == ".py":
        return _py_symbols(src)
    lang = _LANG.get(suffix)
    return _rx_symbols(src, lang) if lang else []


class RepoMap:
    """プロジェクトごとの記号キャッシュつきの地図作り。Agent が 1 つ持ち、ターンごとに build() を呼ぶ。"""

    def __init__(self):
        self._cache: dict[str, dict[str, FileInfo]] = {}        # project → rel → FileInfo

    @staticmethod
    def enabled(cfg) -> bool:
        try:
            return bool(cfg.get("repomap.enabled", True))
        except Exception:  # noqa: BLE001
            return True

    def _excluded(self, cfg) -> set[str]:
        ex = set(DEFAULT_EXCLUDE)
        try:
            ex.add(str(cfg.get("backup.dir", "backup") or "backup"))
            extra = cfg.get("repomap.exclude", []) or []
            if isinstance(extra, str):
                extra = [x.strip() for x in extra.split(",")]
            ex |= {str(x) for x in extra if x}
        except Exception:  # noqa: BLE001
            pass
        return ex

    def scan(self, project: Path, cfg) -> tuple[dict[str, list[str]], list[FileInfo], int]:
        """(フォルダ → ファイル名の一覧, コードファイルの情報, ファイル総数)。"""
        excluded = self._excluded(cfg)
        max_files = int(cfg.get("repomap.max_files", 1500) or 1500)
        tree: dict[str, list[str]] = {}
        infos: list[FileInfo] = []
        cache = self._cache.setdefault(str(project), {})
        seen: set[str] = set()
        total = 0
        stack = [project]
        while stack and total < max_files:
            d = stack.pop()
            try:
                entries = sorted(d.iterdir(), key=lambda p: (p.is_dir(), p.name.lower()))
            except OSError:
                continue
            rel_dir = str(d.relative_to(project)).replace("\\", "/")
            rel_dir = "" if rel_dir == "." else rel_dir
            names = tree.setdefault(rel_dir, [])
            for p in entries:
                if p.name.startswith(".") and p.name not in (".env.example", ".gitignore"):
                    continue
                if p.is_symlink():
                    continue
                if p.is_dir():
                    if p.name in excluded:
                        continue
                    stack.append(p)
                    names.append(p.name + "/")
                    continue
                total += 1
                if total > max_files:
                    break
                names.append(p.name)
                suf = p.suffix.lower()
                if suf not in CODE_EXTS:
                    continue
                try:
                    stt = p.stat()
                except OSError:
                    continue
                if stt.st_size > MAX_FILE_BYTES:
                    continue
                rel = (rel_dir + "/" if rel_dir else "") + p.name
                seen.add(rel)
                fi = cache.get(rel)
                if fi is None or fi.mtime != stt.st_mtime or fi.size != stt.st_size:
                    fi = FileInfo(rel, stt.st_size, stt.st_mtime, symbols_of(p, suf))
                    cache[rel] = fi
                infos.append(fi)
        for rel in [r for r in cache if r not in seen]:
            cache.pop(rel, None)
        return tree, infos, total

    def build(self, project: Path, cfg, lang: str = "ja") -> str:
        if not self.enabled(cfg) or not project.is_dir():
            return ""
        max_chars = int(cfg.get("repomap.max_chars", 8000) or 8000)
        tree, infos, total = self.scan(project, cfg)
        if total == 0:
            return ""
        tree_text = self._render_tree(tree, max(1200, max_chars // 3))
        sym_text, shown, skipped = self._render_symbols(infos, max_chars - len(tree_text) - 400)
        if lang == "en":
            head = (f"\n\n## Repository map (auto-generated: {total} files; functions / classes of {shown} files"
                    + (f", {skipped} more omitted" if skipped else "") + ")\n"
                    "Use it to decide which file to open; it was made when this turn started, so it shows no line numbers and does not "
                    "reflect your edits. Always read_file / grep before editing. Folders such as .venv, node_modules and backup are left out.\n")
        else:
            head = (f"\n\n## リポジトリマップ（自動生成: {total} ファイル。{shown} ファイルの関数・クラス"
                    + (f"。他 {skipped} ファイルは省略" if skipped else "") + "）\n"
                    "どのファイルを読むかを決めるための地図。このターンの開始時に作ったもので、行番号は示さず、作業中の編集も反映しない。"
                    "編集の前には必ず read_file / grep で現在の中身を確かめる。.venv・node_modules・backup などは除いてある。\n")
        return head + tree_text + ("\n" + sym_text if sym_text else "")

    @staticmethod
    def _render_tree(tree: dict[str, list[str]], budget: int) -> str:
        """フォルダを深さ優先で並べる（子フォルダは親の下に字下げして出す）。予算を超えたら残りは数だけ。"""
        lines: list[str] = []
        used = 0
        cut = False

        def emit(line: str) -> bool:
            nonlocal used, cut
            if cut:
                return False
            if used + len(line) + 1 > budget:
                cut = True
                return False
            lines.append(line)
            used += len(line) + 1
            return True

        def walk(rel_dir: str, depth: int) -> None:
            names = tree.get(rel_dir, [])
            files = [n for n in names if not n.endswith("/")]
            dirs = [n for n in names if n.endswith("/")]
            indent = "  " * depth
            if files:
                shown = files[:MAX_TREE_PER_DIR]
                emit(indent + "  ".join(shown) + (f"  …(+{len(files) - len(shown)} files)" if len(files) > len(shown) else ""))
            elif not dirs:
                emit(indent + "(empty)")
            for d in dirs:
                sub = (rel_dir + "/" if rel_dir else "") + d[:-1]
                if not emit(indent + d):
                    return
                walk(sub, depth + 1)
                if cut:
                    return

        walk("", 0)
        if cut:
            emitted_dirs = sum(1 for ln in lines if ln.endswith("/"))
            rest = max(1, len(tree) - 1 - emitted_dirs)
            lines.append(f"…(+{rest} folders omitted; use list_dir)")
        return "\n".join(lines)

    @staticmethod
    def _priority(fi: FileInfo) -> tuple:
        is_test = 1 if TEST_RE.search(fi.rel) else 0
        return (is_test, fi.rel.count("/"), -len(fi.symbols) if fi.symbols else 1, fi.rel)

    @classmethod
    def _render_symbols(cls, infos: list[FileInfo], budget: int, per_file: int = 30) -> tuple[str, int, int]:
        """優先度順にファイルの記号を入れる。入らないファイルは短くして試し、それでも入らなければ飛ばして次へ。"""
        files = [f for f in infos if f.symbols]
        files.sort(key=cls._priority)
        out: list[str] = []
        used = 0
        shown = 0

        def block(fi: FileInfo, n: int) -> str:
            b = [f"{fi.rel}:"] + [f"  {text}" for _ln, text in fi.symbols[:n]]
            if len(fi.symbols) > n:
                b.append(f"  … (+{len(fi.symbols) - n} more; grep for them)")
            return "\n".join(b) + "\n"

        for fi in files:
            text = block(fi, per_file)
            if used + len(text) > budget:
                text = block(fi, 8)
                if used + len(text) > budget:
                    if budget - used < 200:
                        break
                    continue
            out.append(text)
            used += len(text)
            shown += 1
        return "".join(out).rstrip(), shown, len(files) - shown
