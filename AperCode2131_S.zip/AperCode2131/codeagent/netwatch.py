"""v2.13.0: 通信の監視と遮断（netwatch）。

AperCode と、その周りで動くプロセスが外部のどこへ通信しているかを記録し、
Web 検索・クラウド AI・設定した接続先・作業で開いた URL のどれにも当てはまらない
「無関係の可能性がある通信」を見つけて、必要なら遮断する。

記録の取り方は 3 つ:
  1. AperCode のプロセス内（Python）: sys.addaudithook で socket.getaddrinfo / socket.connect を記録する。
     どのモジュールから呼ばれたかで用途（検索・クラウド AI・LLM など）を判定する。遮断も同じフックで行う。
  2. 内蔵ブラウザ（Playwright）: context の request イベントで、ページが読み込む先を記録する。遮断は route で行う。
  3. OS の接続一覧（/proc/net/tcp・udp）: AperCode の子プロセス（コマンド・常駐プロセス）、内蔵ブラウザの Edge 本体、
     LLM サーバーのコンテナ（docker）の接続を一定間隔で調べる。1・2 を通らない通信（Edge 本体の通信、Strata の通信など）を見つける。
     この経路の遮断は root 権限が要るため、pkexec（パスワードの画面）で iptables の規則を入れる。

送信先の分類（kind）:
  local   … 自分の PC・LAN（127.0.0.1、192.168.x.x など）
  config  … 設定にある接続先（LLM の接続先・SearXNG・Edge の CDP など）
  llm     … LLM の接続先へのアクセス（llm.py から）
  search  … Web 検索
  cloud   … クラウド AI（api.anthropic.com）
  task    … 作業で開いた URL（fetch_url・browser_open・コマンドの URL・ブラウザのアドレス欄）とそのページが読み込む先
  allowed … ユーザーが「問題なし」にした先
  unknown … 上のどれにも当てはまらない（無関係の可能性）
"""
from __future__ import annotations

import ipaddress
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
from collections import OrderedDict
from pathlib import Path
from urllib.parse import urlparse

STATE_PATH = Path.home() / ".apercode" / "netwatch.json"        # 許可・遮断の一覧
LOG_PATH = Path.home() / ".apercode" / "netwatch.jsonl"         # 初めて見た通信先の記録
RULE_TAG = "apercode-netwatch"

SEARCH_HOSTS = ["duckduckgo.com", "bing.com", "search.brave.com", "mojeek.com", "api.stackexchange.com",
                "api.github.com", "wikipedia.org", "developer.mozilla.org"]
CLOUD_HOSTS = ["api.anthropic.com"]

# v2.13.1: テレメトリー（利用状況・診断データ・広告計測の送信先）。ドメインの末尾で判定する
TELEMETRY_HOSTS = [
    # Microsoft（Edge・Windows・VS Code の診断データ・利用状況）
    "events.data.microsoft.com", "vortex.data.microsoft.com", "telemetry.microsoft.com", "settings-win.data.microsoft.com",
    "pipe.aria.microsoft.com", "aria.microsoft.com", "dc.services.visualstudio.com", "browser.pipe.aria.microsoft.com",
    "config.edge.skype.com", "edge.activity.windows.com", "c.bing.com", "c.msn.com", "bat.bing.com", "clarity.ms", "arc.msn.com",
    # Google（アクセス解析・広告計測）
    "google-analytics.com", "analytics.google.com", "googletagmanager.com", "doubleclick.net", "googlesyndication.com",
    "googleadservices.com", "app-measurement.com", "firebaselogging-pa.googleapis.com", "crashlytics.com",
    # X（広告・解析）
    "ads-twitter.com", "analytics.twitter.com", "ads-api.twitter.com", "ads-api.x.com", "analytics.x.com",
    # Meta
    "pixel.facebook.com", "an.facebook.com",
    # 解析・エラー収集のサービス
    "sentry.io", "segment.io", "segment.com", "mixpanel.com", "amplitude.com", "hotjar.com", "hotjar.io", "scorecardresearch.com",
    "nr-data.net", "browser-intake-datadoghq.com", "posthog.com", "i.posthog.com", "scarf.sh", "bugsnag.com", "fullstory.com",
    "quantserve.com", "chartbeat.net", "newrelic.com",
]
_TELEMETRY_LABEL = re.compile(r"(^|\.)(telemetry|analytics)[\w-]*(\.[^.]+){2,}$")   # サブドメインの名前（analytics.example.com）

# 呼び出し元モジュール → 用途
_MODULE_KIND = [("codeagent/tools/web.py", "search"), ("codeagent/research.py", "search"),
                ("codeagent/cloud.py", "cloud"), ("codeagent/tools/cloud_tools.py", "cloud"),
                ("codeagent/llm.py", "llm"), ("codeagent/endpoints.py", "llm"), ("codeagent/vram.py", "llm"),
                ("codeagent/memory/", "llm"), ("codeagent/browser.py", "browser")]

KIND_LABEL = {"telemetry": "テレメトリー", "telemetry_blocked": "テレメトリー（遮断済み）", "unknown": "無関係の可能性",
              "other": "その他", "local": "PC 内・LAN", "config": "設定の接続先", "llm": "LLM", "search": "Web 検索",
              "cloud": "クラウド AI", "task": "作業で開いた先", "allowed": "許可済み", "blocked": "遮断済み"}


def is_telemetry(host: str, extra=None, exclude=None) -> bool:
    h = (host or "").lower().rstrip(".")
    if not h or _is_ip(h):
        return False
    if exclude and _host_match(h, exclude):
        return False
    return _host_match(h, TELEMETRY_HOSTS + list(extra or [])) or bool(_TELEMETRY_LABEL.search(h))


def _host_match(host: str, pats) -> bool:
    host = (host or "").lower().rstrip(".")
    for p in pats or ():
        p = str(p).lower().lstrip("*.").rstrip(".")
        if p and (host == p or host.endswith("." + p)):
            return True
    return False


def _is_local_ip(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return False
    if getattr(a, "ipv4_mapped", None):
        a = a.ipv4_mapped
    if a.is_loopback or a.is_link_local or a.is_unspecified or a.is_multicast:
        return True
    return any(a in n for n in _LOCAL_NETS if n.version == a.version)


# PC 内・LAN として扱う範囲（Python の is_private は文書用のアドレスまで含むため、明示する）
_LOCAL_NETS = [ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10",
                                                  "fc00::/7")]


def _is_ip(s: str) -> bool:
    try:
        ipaddress.ip_address(s.split("%")[0])
        return True
    except ValueError:
        return False


def _urls_in(text: str) -> list[str]:
    return re.findall(r"https?://[^\s'\"<>|;)]+", text or "")


class NetWatch:
    """プロセスに 1 つ。get() で取り出す。"""

    def __init__(self, cfg=None):
        self.cfg = cfg
        self._lock = threading.RLock()
        self.events: OrderedDict[tuple, dict] = OrderedDict()   # (source, host, ip, port) → 記録
        self.ip_host: dict[str, str] = {}                        # IP → ホスト名（名前解決・ブラウザの記録から）
        self.task_hosts: set[str] = set()                        # 作業で開いた URL のホスト
        self.config_hosts: set[str] = set()
        self.allow: list[str] = []                               # ユーザーが問題なしにした先（ホストか IP）
        self.block: list[dict] = []                              # [{"target", "ts", "os": bool}]
        self.os_rules: list[str] = []                            # 入れた iptables 規則（説明用）
        self.hook_installed = False
        self.scanning = False
        self._scan_thread: threading.Thread | None = None
        self._browser_ctxs: list = []
        self._rdns: dict[str, str] = {}
        self._resolved: set[str] = set()
        self._own_pid = os.getpid()
        self.last_scan = 0.0
        self.scan_error = ""
        self.scan_note = ""
        self._load()

    # ------------------------------------------------------------------ 設定・保存
    def set_cfg(self, cfg) -> None:
        self.cfg = cfg
        hosts: set[str] = set()

        def walk(v):
            if isinstance(v, dict):
                for x in v.values():
                    walk(x)
            elif isinstance(v, list):
                for x in v:
                    walk(x)
            elif isinstance(v, str) and re.match(r"https?://", v):
                h = urlparse(v).hostname
                if h:
                    hosts.add(h.lower())
        try:
            walk(getattr(cfg, "data", {}) or {})
        except Exception:  # noqa: BLE001
            pass
        self.config_hosts = hosts

    def _cfg(self, key: str, default=None):
        try:
            return self.cfg.get("netwatch." + key, default) if self.cfg is not None else default
        except Exception:  # noqa: BLE001
            return default

    def _load(self) -> None:
        try:
            d = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            self.allow = [str(x) for x in d.get("allow", [])]
            self.block = [x for x in d.get("block", []) if isinstance(x, dict) and x.get("target")]
            self.os_rules = [str(x) for x in d.get("os_rules", [])]
        except (OSError, ValueError):
            pass

    def _save(self) -> None:
        try:
            STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
            STATE_PATH.write_text(json.dumps({"allow": self.allow, "block": self.block, "os_rules": self.os_rules},
                                             ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError:
            pass

    # ------------------------------------------------------------------ 分類
    def blocked_targets(self) -> set[str]:
        return {str(b["target"]).lower() for b in self.block}

    def mode(self) -> str:
        """telemetry = テレメトリーだけ警告（既定）／ all = 当てはまらない通信をすべて警告（v2.13.0 の動き）。"""
        return "all" if str(self._cfg("mode", "telemetry")) == "all" else "telemetry"

    def block_telemetry(self) -> bool:
        return bool(self._cfg("block_telemetry", True))

    def telemetry(self, host: str = "", ip: str = "") -> bool:
        h = host or (self.ip_host.get(ip, "") if ip else "")
        return is_telemetry(h, self._cfg("telemetry_hosts", []) or [], self._cfg("telemetry_exclude", []) or [])

    def alert_kinds(self) -> list[str]:
        return ["telemetry"] if self.mode() == "telemetry" else ["telemetry", "unknown"]

    def is_blocked(self, host: str = "", ip: str = "") -> bool:
        if self.block_telemetry() and self.telemetry(host, ip) and not self._allowed(host, ip):
            return True
        bl = self.blocked_targets()
        if not bl:
            return False
        if ip and ip.lower() in bl:
            return True
        if host and not _is_ip(host) and _host_match(host, bl):
            return True
        if ip and self.ip_host.get(ip) and _host_match(self.ip_host[ip], bl):
            return True
        return False

    def _allowed(self, host: str, ip: str) -> bool:
        h = (host or "").lower()
        return bool(h and (_host_match(h, self.allow) or h in self.allow) or (ip and ip in self.allow))

    def classify(self, host: str, ip: str = "", hint: str = "") -> str:
        h = (host or "").lower()
        if (ip and _is_local_ip(ip)) or (h and _is_ip(h) and _is_local_ip(h)) or h in ("localhost",):
            return "local"
        if self._allowed(h, ip):
            return "allowed"
        if self.telemetry(h, ip):
            return "telemetry_blocked" if self.is_blocked(h, ip) else "telemetry"
        if self.is_blocked(h, ip):
            return "blocked"
        if h and _host_match(h, CLOUD_HOSTS):
            return "cloud"
        if hint in ("cloud", "search", "llm") and hint:
            return hint
        if h and _host_match(h, SEARCH_HOSTS + list(self._cfg("search_hosts", []) or [])):
            return "search"
        if h and h in self.config_hosts:
            return "config"
        if h and _host_match(h, self.task_hosts):
            return "task"
        if hint == "page":
            return "task"
        return "unknown" if self.mode() == "all" else "other"

    # ------------------------------------------------------------------ 記録
    def note_task_url(self, url: str) -> None:
        """作業で開く URL（fetch_url・browser_open・ブラウザのアドレス欄・コマンドの中の URL）。"""
        h = urlparse(url).hostname if url else None
        if h:
            with self._lock:
                self.task_hosts.add(h.lower())

    def note_task_text(self, text: str) -> None:
        for u in _urls_in(text):
            self.note_task_url(u)

    def record(self, source: str, host: str = "", ip: str = "", port: int | None = None, proto: str = "tcp",
               hint: str = "", detail: str = "", pid: int | None = None, proc: str = "") -> dict:
        host = (host or "").lower().rstrip(".")
        if not host and ip:
            host = self.ip_host.get(ip, "")
        kind = self.classify(host, ip, hint)
        key = (source, host or ip, port)
        now = time.time()
        with self._lock:
            e = self.events.get(key)
            if e is None:
                e = {"source": source, "host": host, "ip": ip, "port": port, "proto": proto, "kind": kind, "hint": hint,
                     "first": now, "last": now, "count": 1, "detail": detail[:300], "pid": pid, "proc": proc[:120]}
                self.events[key] = e
                while len(self.events) > int(self._cfg("max_entries", 3000) or 3000):
                    self.events.popitem(last=False)
                self._log(e)
            else:
                e["last"] = now
                e["count"] += 1
                e["kind"] = kind
                if ip and not e.get("ip"):
                    e["ip"] = ip
                if detail and not e.get("detail"):
                    e["detail"] = detail[:300]
            return e

    def _log(self, e: dict) -> None:
        try:
            LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
            with LOG_PATH.open("a", encoding="utf-8") as f:
                f.write(json.dumps({k: e[k] for k in ("first", "source", "host", "ip", "port", "proto", "kind", "proc")},
                                   ensure_ascii=False) + "\n")
        except OSError:
            pass

    def list(self) -> list[dict]:
        with self._lock:
            out = []
            for e in self.events.values():
                e["kind"] = self.classify(e.get("host") or "", e.get("ip") or "", e.get("hint") or "")
                out.append(dict(e))
        ak = self.alert_kinds()
        out.sort(key=lambda x: (x["kind"] not in ak, not x["kind"].startswith("telemetry"), -x["last"]))
        return out

    def summary(self) -> dict:
        evs = self.list()
        counts: dict[str, int] = {}
        for e in evs:
            counts[e["kind"]] = counts.get(e["kind"], 0) + 1
        alert = sum(counts.get(k, 0) for k in self.alert_kinds())
        return {"counts": counts, "unknown": alert, "alert": alert, "alert_kinds": self.alert_kinds(), "mode": self.mode(),
                "block_telemetry": self.block_telemetry(), "scanning": self.scanning,
                "hook": self.hook_installed, "last_scan": self.last_scan, "scan_error": self.scan_error,
                "scan_note": self.scan_note, "block": self.block, "allow": self.allow}

    def clear(self) -> None:
        with self._lock:
            self.events.clear()

    # ------------------------------------------------------------------ 1. プロセス内（audit hook）
    def install_hook(self) -> None:
        if self.hook_installed or not self._cfg("enabled", True):
            return
        nw = self

        def hook(event, args):
            if event == "socket.getaddrinfo":
                try:
                    host = args[0].decode() if isinstance(args[0], bytes) else str(args[0] or "")
                except Exception:  # noqa: BLE001
                    return
                if not host or host in ("localhost",) or (_is_ip(host) and _is_local_ip(host)):
                    return
                if nw.is_blocked(host=host):
                    nw.record("AperCode（Python）", host, "", int(args[1]) if isinstance(args[1], int) else None,
                              detail="遮断した: " + nw._caller()[1], pid=nw._own_pid, proc="AperCode")
                    raise PermissionError(f"AperCode: {host} への通信は遮断しています（通信の監視）")
                nw._pending_host(host)
            elif event == "socket.connect":
                try:
                    addr = args[1]
                    if not isinstance(addr, tuple) or not addr:
                        return
                    ip, port = str(addr[0]), (int(addr[1]) if len(addr) > 1 else None)
                except Exception:  # noqa: BLE001
                    return
                if _is_local_ip(ip):
                    return
                host = nw._take_host(ip)
                if nw.is_blocked(host=host, ip=ip):
                    nw.record("AperCode（Python）", host, ip, port, detail="遮断した: " + nw._caller()[1],
                              pid=nw._own_pid, proc="AperCode")
                    raise PermissionError(f"AperCode: {host or ip} への通信は遮断しています（通信の監視）")
                hint, caller = nw._caller()
                nw.record("AperCode（Python）", host, ip, port, hint=hint, detail=caller, pid=nw._own_pid, proc="AperCode")
        try:
            sys.addaudithook(hook)
            self.hook_installed = True
        except Exception:  # noqa: BLE001
            pass

    _tls = threading.local()

    def _pending_host(self, host: str) -> None:
        self._tls.host = host

    def _take_host(self, ip: str) -> str:
        """直前に同じスレッドで名前解決したホストを、接続先の IP に結び付ける。"""
        h = getattr(self._tls, "host", "") or ""
        if h:
            self.ip_host[ip] = h
            return h
        return self.ip_host.get(ip, "")

    @staticmethod
    def _caller() -> tuple[str, str]:
        f = sys._getframe(2)
        first = ""
        while f is not None:
            fn = f.f_code.co_filename.replace("\\", "/")
            if "/codeagent/" in fn and not fn.endswith("/codeagent/netwatch.py"):
                rel = fn[fn.rfind("/codeagent/") + 1:]
                if not first:
                    first = f"{rel}:{f.f_lineno}"
                for pat, kind in _MODULE_KIND:
                    if pat in rel:
                        return kind, first
            f = f.f_back
        return "", first

    # ------------------------------------------------------------------ 2. 内蔵ブラウザ
    def attach_browser(self, context) -> None:
        if context in self._browser_ctxs:
            return
        self._browser_ctxs.append(context)

        def on_request(req):
            try:
                u = urlparse(req.url)
                if u.scheme not in ("http", "https", "ws", "wss") or not u.hostname:
                    return
                host = u.hostname.lower()
                if _is_ip(host) and _is_local_ip(host):
                    return
                nav = req.is_navigation_request() and req.frame == req.frame.page.main_frame
                if nav:
                    self.note_task_url(req.url)           # アドレス欄・リンク・browser_open でページを開いた
                self.record("内蔵ブラウザ", host, "", u.port or (443 if u.scheme in ("https", "wss") else 80),
                            hint="page", detail=("ページ: " if nav else "読み込み: ") + req.url[:200])
                if host not in self._resolved:
                    threading.Thread(target=self._resolve, args=(host,), daemon=True).start()
            except Exception:  # noqa: BLE001
                pass
        try:
            context.on("request", on_request)
        except Exception:  # noqa: BLE001
            pass

    async def apply_browser_blocks(self) -> None:
        for ctx in list(self._browser_ctxs):
            try:
                await ctx.unroute("**/*")
            except Exception:  # noqa: BLE001
                pass
            if not self.block and not self.block_telemetry():
                continue
            nw = self

            async def handler(route, request):
                h = (urlparse(request.url).hostname or "").lower()
                if nw.is_blocked(host=h):
                    nw.record("内蔵ブラウザ", h, "", None, hint="page", detail="遮断: " + request.url[:200])
                    await route.abort("blockedbyclient")
                else:
                    await route.fallback()
            try:
                await ctx.route("**/*", handler)
            except Exception:  # noqa: BLE001
                pass

    def _resolve(self, host: str) -> None:
        if host in self._resolved:
            return
        self._resolved.add(host)
        try:
            for info in socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP):
                ip = info[4][0]
                self.ip_host.setdefault(ip, host)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------ 3. OS の接続一覧
    def start_scan(self) -> None:
        if self.scanning:
            return
        self.scanning = True
        self._scan_thread = threading.Thread(target=self._scan_loop, daemon=True)
        self._scan_thread.start()

    def stop_scan(self) -> None:
        self.scanning = False

    def _scan_loop(self) -> None:
        while self.scanning:
            try:
                self.scan_once()
                self.scan_error = ""
            except Exception as e:  # noqa: BLE001
                self.scan_error = str(e)[:200]
            time.sleep(max(0.5, float(self._cfg("interval", 2.0) or 2.0)))

    def scan_once(self) -> int:
        n = 0
        targets = self._target_pids()
        if targets:
            inode_pid = _inodes_of(targets)
            for c in _read_proc_net("/proc/net"):
                pid = inode_pid.get(c["inode"])
                if pid is None or _is_local_ip(c["rip"]):
                    continue
                name = targets.get(pid, "")
                src = "内蔵ブラウザ（Edge 本体）" if name.startswith("edge") else "AperCode の子プロセス"
                if pid == self._own_pid:
                    continue                         # 自分のプロセスはフックで記録している
                host = self.ip_host.get(c["rip"]) or self._rdns_get(c["rip"])
                hint = "page" if src.startswith("内蔵ブラウザ") and self.ip_host.get(c["rip"]) else ""
                self.record(src, host, c["rip"], c["rport"], c["proto"], hint=hint, pid=pid, proc=_cmdline(pid))
                n += 1
        notes = []
        host_tcp = _read_raw("/proc/net")
        for name, pid in self._container_pids().items():
            raw = _read_raw(f"/proc/{pid}/net")
            if not raw:
                raw = _docker_exec_raw(name)
            if not raw:
                notes.append(f"{name}: 接続一覧を読めません")
                continue
            if raw.get("tcp") and raw.get("tcp") == host_tcp.get("tcp"):
                notes.append(f"{name}: コンテナが PC と同じネットワーク（--network host）を使っているため、PC の通信と区別できません")
                continue
            conns = []
            for k, v in raw.items():
                conns += parse_proc_net(v, k)
            for c in conns:
                if _is_local_ip(c["rip"]):
                    continue
                host = self.ip_host.get(c["rip"]) or self._rdns_get(c["rip"])
                self.record(f"LLM サーバー（docker: {name}）", host, c["rip"], c["rport"], c["proto"], proc=name)
                n += 1
        self.last_scan = time.time()
        self.scan_note = " / ".join(notes)
        return n

    def _target_pids(self) -> dict[int, str]:
        """AperCode とその子孫、内蔵ブラウザ用の Edge（cdp_url のポートで起動したもの）。"""
        out: dict[int, str] = {}
        children: dict[int, list[int]] = {}
        cmd: dict[int, str] = {}
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            pid = int(d)
            try:
                st = Path(f"/proc/{pid}/stat").read_text()
                ppid = int(st[st.rfind(")") + 2:].split()[1])
            except (OSError, ValueError, IndexError):
                continue
            children.setdefault(ppid, []).append(pid)
            cmd[pid] = _cmdline(pid)
        stack = [self._own_pid]
        while stack:
            p = stack.pop()
            if p in out:
                continue
            out[p] = "apercode"
            stack.extend(children.get(p, []))
        cdp = str((self.cfg.get("browser.cdp_url", "") if self.cfg is not None else "") or "")
        port = urlparse(cdp).port if cdp else None
        prof = str(self._cfg("edge_profile", "edge-x") or "edge-x")
        for pid, c in cmd.items():
            if pid in out:
                continue
            if (port and f"--remote-debugging-port={port}" in c) or (prof and f"/{prof}" in c and ("msedge" in c or "edge" in c)):
                stack = [pid]
                while stack:
                    p = stack.pop()
                    if p not in out:
                        out[p] = "edge"
                        stack.extend(children.get(p, []))
        return out

    def _container_pids(self) -> dict[str, int]:
        names = self._cfg("containers", ["strata"]) or []
        if not names or not shutil.which("docker"):
            return {}
        out: dict[str, int] = {}
        for n in names:
            try:
                r = subprocess.run(["docker", "inspect", "-f", "{{.State.Pid}}", str(n)], capture_output=True, text=True, timeout=5)
                pid = int((r.stdout or "0").strip() or 0)
                if pid > 0:
                    out[str(n)] = pid
            except (OSError, ValueError, subprocess.SubprocessError):
                continue
        return out

    def container_ips(self) -> dict[str, str]:
        out: dict[str, str] = {}
        if not shutil.which("docker"):
            return out
        for n in self._cfg("containers", ["strata"]) or []:
            try:
                r = subprocess.run(["docker", "inspect", "-f", "{{range .NetworkSettings.Networks}}{{.IPAddress}} {{end}}", str(n)],
                                   capture_output=True, text=True, timeout=5)
                ip = (r.stdout or "").split()
                if ip:
                    out[str(n)] = ip[0]
            except (OSError, subprocess.SubprocessError):
                continue
        return out

    def _rdns_get(self, ip: str) -> str:
        if ip in self._rdns:
            return self._rdns[ip]
        self._rdns[ip] = ""

        def run():
            try:
                self._rdns[ip] = socket.gethostbyaddr(ip)[0].lower()
            except Exception:  # noqa: BLE001
                pass
        threading.Thread(target=run, daemon=True).start()
        return ""

    # ------------------------------------------------------------------ 許可・遮断
    def add_allow(self, target: str) -> None:
        t = target.strip().lower()
        if t and t not in self.allow:
            self.allow.append(t)
            self._save()

    def remove_allow(self, target: str) -> None:
        self.allow = [x for x in self.allow if x != target.strip().lower()]
        self._save()

    def add_block(self, target: str, ips: list[str] | None = None, os_level: bool = False) -> dict:
        t = target.strip().lower()
        if not t:
            raise ValueError("遮断する先がありません")
        if t in ("localhost",) or (_is_ip(t) and _is_local_ip(t)):
            raise ValueError("PC 内・LAN の通信は遮断できません（LLM の接続が止まります）")
        if t not in self.blocked_targets():
            self.block.append({"target": t, "ts": time.time(), "os": bool(os_level), "ips": sorted(set(ips or []))})
        self._save()
        res = {"ok": True, "target": t, "os": None}
        if os_level:
            res["os"] = self.apply_os_block(t, ips or [])
        return res

    def remove_block(self, target: str) -> dict:
        t = target.strip().lower()
        ent = next((b for b in self.block if b["target"] == t), None)
        self.block = [b for b in self.block if b["target"] != t]
        self._save()
        res = {"ok": True, "os": None}
        if ent and ent.get("os"):
            res["os"] = self.remove_os_block(t, ent.get("ips") or [])
        return res

    # -- OS（iptables）。root が要るので pkexec で実行する
    def _ips_for(self, target: str, ips: list[str]) -> list[str]:
        out = set(ip for ip in ips if _is_ip(ip) and not _is_local_ip(ip))
        if _is_ip(target):
            out.add(target)
        else:
            out.update(ip for ip, h in self.ip_host.items() if _host_match(h, [target]) and not _is_local_ip(ip))
            try:
                for info in socket.getaddrinfo(target, None):
                    if not _is_local_ip(info[4][0]):
                        out.add(info[4][0])
            except Exception:  # noqa: BLE001
                pass
        return sorted(out)

    def os_commands(self, target: str, ips: list[str], add: bool = True) -> list[str]:
        op = "-I" if add else "-D"
        cmds: list[str] = []
        cips = list(self.container_ips().values())
        for ip in self._ips_for(target, ips):
            tool = "ip6tables" if ":" in ip else "iptables"
            cmds.append(f"{tool} {op} OUTPUT -d {ip} -m comment --comment {RULE_TAG} -j REJECT")
            if tool == "iptables":
                for cip in cips:
                    cmds.append(f"iptables {op} DOCKER-USER -s {cip} -d {ip} -m comment --comment {RULE_TAG} -j REJECT")
        return cmds

    def _run_root(self, cmds: list[str], add: bool) -> dict:
        if not cmds:
            return {"ok": False, "error": "IP アドレスが分かりません（名前解決できませんでした）", "commands": []}
        # 削除は「無い規則を消そうとした」失敗を無視する
        script = " ; ".join((c if add else c + " 2>/dev/null") for c in cmds)
        pk = shutil.which("pkexec")
        if not pk:
            return {"ok": False, "error": "pkexec がありません。表示したコマンドを sudo で実行してください", "commands": cmds}
        try:
            r = subprocess.run([pk, "sh", "-c", script], capture_output=True, text=True, timeout=180)
        except (OSError, subprocess.SubprocessError) as e:
            return {"ok": False, "error": str(e), "commands": cmds}
        ok = r.returncode == 0 or not add
        if r.returncode in (126, 127) and add:
            return {"ok": False, "error": "パスワードの入力がキャンセルされました", "commands": cmds}
        return {"ok": ok, "error": "" if ok else (r.stderr or r.stdout)[-400:], "commands": cmds}

    def apply_os_block(self, target: str, ips: list[str]) -> dict:
        cmds = self.os_commands(target, ips, add=True)
        res = self._run_root(cmds, True)
        if res["ok"]:
            for b in self.block:
                if b["target"] == target.strip().lower():
                    b["ips"] = self._ips_for(target, ips)
            self.os_rules = sorted(set(self.os_rules + cmds))
            self._save()
        return res

    def remove_os_block(self, target: str, ips: list[str]) -> dict:
        cmds = self.os_commands(target, ips, add=False)
        res = self._run_root(cmds, False)
        adds = set(self.os_commands(target, ips, add=True))
        self.os_rules = [r for r in self.os_rules if r not in adds]
        self._save()
        return res

    def reapply_os(self) -> dict:
        """再起動で消えた iptables の規則を入れ直す（同じ規則が二重にならないよう、先に消してから入れる）。"""
        cmds: list[str] = []
        for b in self.block:
            if b.get("os"):
                cmds += self.os_commands(b["target"], b.get("ips") or [], add=False)
                cmds += self.os_commands(b["target"], b.get("ips") or [], add=True)
        if not cmds:
            return {"ok": True, "commands": [], "error": ""}
        dels = [c + " 2>/dev/null" for c in cmds if " -D " in c]
        adds = [c for c in cmds if " -I " in c]
        return self._run_root(dels + adds, True) if adds else {"ok": True, "commands": [], "error": ""}


EDGE_RULES_PATH = Path.home() / ".apercode" / "edge-host-rules.txt"


def edge_host_rules(nw: "NetWatch") -> str:
    """v2.13.1: 内蔵ブラウザ用の Edge に渡す --host-resolver-rules（テレメトリーの名前解決を失敗させる）。
    Edge 本体の通信は AperCode からは止められないため、Edge の起動時にこの規則を渡して止める（root 不要）。"""
    if not nw.block_telemetry():
        return ""
    hosts = [h for h in TELEMETRY_HOSTS + list(nw._cfg("telemetry_hosts", []) or [])
             if not _host_match(h, nw._cfg("telemetry_exclude", []) or []) and not _host_match(h, nw.allow)]
    rules = []
    for h in dict.fromkeys(str(x).lower().lstrip("*.") for x in hosts):
        rules += [f"MAP {h} ~NOTFOUND", f"MAP *.{h} ~NOTFOUND"]
    return ", ".join(rules)


def write_edge_rules(nw: "NetWatch") -> Path | None:
    try:
        EDGE_RULES_PATH.parent.mkdir(parents=True, exist_ok=True)
        EDGE_RULES_PATH.write_text(edge_host_rules(nw) + "\n", encoding="utf-8")
        return EDGE_RULES_PATH
    except OSError:
        return None


# ---------------------------------------------------------------------- /proc の読み取り
_TCP_ESTABLISHED = "01"


def _hex_ip(h: str) -> str:
    b = bytes.fromhex(h)
    if len(b) == 4:
        return socket.inet_ntop(socket.AF_INET, b[::-1])
    # IPv6 は 4 バイトごとにリトルエンディアン
    w = b"".join(b[i:i + 4][::-1] for i in range(0, 16, 4))
    ip = socket.inet_ntop(socket.AF_INET6, w)
    if ip.startswith("::ffff:") and "." in ip:
        return ip[7:]
    return ip


def parse_proc_net(text: str, proto: str) -> list[dict]:
    out = []
    for line in text.splitlines()[1:]:
        f = line.split()
        if len(f) < 10:
            continue
        try:
            la, lp = f[1].split(":")
            ra, rp = f[2].split(":")
            st = f[3]
            rport = int(rp, 16)
            if proto.startswith("tcp") and st != _TCP_ESTABLISHED:
                continue
            if rport == 0:
                continue                              # 接続していない UDP・待ち受け
            out.append({"proto": proto.rstrip("6"), "lip": _hex_ip(la), "lport": int(lp, 16),
                        "rip": _hex_ip(ra), "rport": rport, "inode": f[9]})
        except (ValueError, OSError):
            continue
    return out


def _read_proc_net(base: str) -> list[dict]:
    out: list[dict] = []
    for name in ("tcp", "tcp6", "udp", "udp6"):
        try:
            out += parse_proc_net(Path(base, name).read_text(), name)
        except OSError:
            continue
    return out


def _read_raw(base: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for name in ("tcp", "tcp6", "udp", "udp6"):
        try:
            out[name] = Path(base, name).read_text()
        except OSError:
            continue
    return out


def _docker_exec_raw(name: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for f in ("tcp", "tcp6", "udp", "udp6"):
        try:
            r = subprocess.run(["docker", "exec", name, "cat", f"/proc/net/{f}"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0 and r.stdout:
                out[f] = r.stdout
        except (OSError, subprocess.SubprocessError):
            continue
    return out


def _inodes_of(pids) -> dict[str, int]:
    out: dict[str, int] = {}
    for pid in pids:
        d = f"/proc/{pid}/fd"
        try:
            for fd in os.listdir(d):
                try:
                    lk = os.readlink(f"{d}/{fd}")
                except OSError:
                    continue
                if lk.startswith("socket:["):
                    out[lk[8:-1]] = pid
        except OSError:
            continue
    return out


def _cmdline(pid: int) -> str:
    try:
        return Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace").strip()[:300]
    except OSError:
        return ""


_NW: NetWatch | None = None


def get(cfg=None) -> NetWatch:
    global _NW
    if _NW is None:
        _NW = NetWatch(cfg)
    if cfg is not None and _NW.cfg is not cfg:
        _NW.set_cfg(cfg)
    return _NW
