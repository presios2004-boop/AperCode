"""生成コードの検証レイヤー（v1.2.0）。

1. check_file(): write_file / edit_file 直後に言語別の構文・lint・型チェックを実行し、結果を LLM に差し戻す
2. detect_test_command(): プロジェクト構成からテストコマンドを推定（pytest / npm test / go test / cargo test …）
3. run_tests(): テストを実行し、結果を要約する

外部ツール（ruff / mypy / eslint / tsc / shellcheck …）は「入っていれば使う」。無ければ構文チェックのみ。
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path

from . import sandbox

MAX_OUT = 4000


@dataclass
class CheckResult:
    path: str
    ok: bool
    tools: list[str] = field(default_factory=list)   # 実行したツール名
    output: str = ""                                  # エラー・警告（ok なら空）
    skipped: str = ""                                 # チェック対象外の理由

    def summary(self) -> str:
        if self.skipped:
            return f"{self.path}: スキップ（{self.skipped}）"
        tools = "+".join(self.tools) if self.tools else "-"
        return f"{self.path}: {'OK' if self.ok else 'NG'} [{tools}]"


@dataclass
class TestResult:
    command: str
    exit_code: int
    passed: int | None = None
    failed: int | None = None
    output: str = ""
    detected: bool = True     # コマンドを自動検出できたか

    @property
    def ok(self) -> bool:
        return self.exit_code == 0

    def summary(self) -> str:
        if not self.detected:
            return "テストコマンドが見つかりません"
        counts = ""
        if self.passed is not None or self.failed is not None:
            counts = f" (passed {self.passed or 0}, failed {self.failed or 0})"
        return f"{'PASS' if self.ok else 'FAIL'}: {self.command}{counts}"


# ------------------------------------------------------------------ 実行ヘルパ
async def _run(cmd: list[str] | str, cwd: Path, timeout: int = 120, env: dict | None = None) -> tuple[int, str]:
    """コマンドを実行して (exit_code, 出力) を返す。ツールが無い場合は (127, '')。"""
    try:
        if sandbox.enabled():
            if isinstance(cmd, str):
                argv = sandbox.shell(cmd, cwd, cwd)
            else:
                exe = shutil.which(cmd[0]) if "/" not in cmd[0] else cmd[0]
                if not exe:
                    return 127, ""
                argv = sandbox.wrap([exe, *cmd[1:]], cwd, cwd)
        else:
            sandbox.check_required()
            argv = None
        e = {**sandbox.env_for(Path(cwd)), **(env or {})}
        if argv is not None:
            proc = await asyncio.create_subprocess_exec(
                *argv, cwd=str(cwd), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, env=e)
        elif isinstance(cmd, str):
            proc = await asyncio.create_subprocess_shell(
                cmd, cwd=str(cwd), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, env=e)
        else:
            proc = await asyncio.create_subprocess_exec(
                *cmd, cwd=str(cwd), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, env=e)
    except FileNotFoundError:
        return 127, ""
    except sandbox.SandboxError as ex:
        return 126, str(ex)
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        return -1, f"(タイムアウト {timeout}s)"
    text = out.decode("utf-8", errors="replace")
    if len(text) > MAX_OUT:
        text = text[:MAX_OUT // 2] + "\n... (中略) ...\n" + text[-MAX_OUT // 2:]
    return proc.returncode or 0, text


def _has(tool: str, cwd: Path | None = None) -> bool:
    if shutil.which(tool):
        return True
    # プロジェクト内の node_modules/.bin
    if cwd and (cwd / "node_modules" / ".bin" / tool).exists():
        return True
    return False


def _bin(tool: str, cwd: Path) -> str:
    local = cwd / "node_modules" / ".bin" / tool
    return str(local) if local.exists() else tool


def _python() -> str:
    """プロジェクトの venv があればそれを優先（.venv/bin/python, venv/bin/python）。"""
    return sys.executable


def _project_python(cwd: Path) -> str:
    for v in (".venv", "venv"):
        p = cwd / v / "bin" / "python"
        if p.exists():
            return str(p)
        p = cwd / v / "Scripts" / "python.exe"
        if p.exists():
            return str(p)
    return _python()


def _rel(p: Path, cwd: Path) -> str:
    try:
        return str(p.relative_to(cwd))
    except ValueError:
        return str(p)


# ------------------------------------------------------------------ 言語別チェック
# v1.10.0: 型チェッカーの誤りのうち「実行すると落ちる」種類だけを使う（スタイルや型注釈の不足では NG にしない）
MYPY_CODES = {"attr-defined", "name-defined", "call-arg", "has-type", "union-attr", "index", "operator", "misc"}
PYRIGHT_RULES = {"reportAttributeAccessIssue", "reportUndefinedVariable", "reportCallIssue", "reportOptionalMemberAccess",
                 "reportIndexIssue", "reportOperatorIssue", "reportPossiblyUnbound"}


def _mypy_cmd(cwd: Path) -> list[str] | None:
    py = _project_python(cwd)
    import subprocess
    try:
        if subprocess.run([py, "-c", "import mypy"], capture_output=True, timeout=20).returncode == 0:
            return [py, "-m", "mypy"]
    except Exception:  # noqa: BLE001
        pass
    return ["mypy"] if shutil.which("mypy") else None


async def _type_problems(p: Path, cwd: Path, lines: set[int]) -> tuple[str, list[str]]:
    """pyright（無ければ mypy）で型チェックし、変更した行の「実行すると落ちる」種類の誤りだけを返す。(ツール名, 問題)"""
    if not lines:
        return "", []
    rel = _rel(p, cwd)
    if shutil.which("pyright"):
        code, out = await _run(["pyright", "--outputjson", str(p)], cwd, 180)
        try:
            data = json.loads(out[out.find("{"):])
        except ValueError:
            return "pyright", []
        probs = []
        for d in data.get("generalDiagnostics", []):
            ln = d.get("range", {}).get("start", {}).get("line", -1) + 1
            if d.get("severity") == "error" and d.get("rule") in PYRIGHT_RULES and ln in lines:
                probs.append(f"{rel}:{ln}: {d.get('message', '').splitlines()[0]}  [{d.get('rule')}]")
        return "pyright", probs
    cmd = _mypy_cmd(cwd)
    if cmd is None:
        return "", []
    cache = cwd / ".apercode" / "mypy_cache"
    code, out = await _run(cmd + ["--ignore-missing-imports", "--follow-imports=silent", "--check-untyped-defs",
                                  "--no-error-summary", "--show-error-codes", "--no-color-output",
                                  "--cache-dir", str(cache), str(p)], cwd, 180)
    probs = []
    for m in re.finditer(r"^(.+?):(\d+): error: (.+?)\s+\[([\w-]+)\]\s*$", out, re.M):
        if int(m.group(2)) in lines and m.group(4) in MYPY_CODES and Path(m.group(1)).name == p.name:
            probs.append(f"{rel}:{m.group(2)}: {m.group(3)}  [{m.group(4)}]")
    return "mypy", probs


async def _check_python(p: Path, cwd: Path, lint: bool, types: bool, before: str | None = None,
                        structure: bool = True) -> CheckResult:
    py = _project_python(cwd)
    r = CheckResult(_rel(p, cwd), True)
    code, out = await _run([py, "-m", "py_compile", str(p)], cwd, 60)
    r.tools.append("py_compile")
    if code != 0:
        r.ok = False
        r.output = out.strip()
        return r          # 構文エラーがあれば lint は無意味
    if lint:
        if _has("ruff"):
            # 未定義名・未使用 import・構文的に危ないもの中心（スタイル警告は出さない）
            code, out = await _run(["ruff", "check", "--no-fix", "--output-format", "concise",
                                    "--select", "E9,F", str(p)], cwd, 60)
            r.tools.append("ruff")
            if code != 0 and out.strip():
                r.ok = False
                r.output = out.strip()
        elif _has("pyflakes"):
            code, out = await _run(["pyflakes", str(p)], cwd, 60)
            r.tools.append("pyflakes")
            if code != 0 and out.strip():
                r.ok = False
                r.output = out.strip()
    # v1.10.0: 構造チェック（存在しない self.xxx・引数の数の誤り）。今回の変更で増えた問題だけ
    if structure and r.ok:
        from . import pycheck
        try:
            after = p.read_text(encoding="utf-8", errors="replace")
            probs = pycheck.new_problems(after, before)
        except Exception:  # noqa: BLE001
            probs = []
        r.tools.append("structure")
        if probs:
            r.ok = False
            r.output = "\n".join(x.format(r.path) for x in probs[:20])
    # v1.10.0: 型チェック（pyright / mypy が入っていれば）。変更した行の、実行すると落ちる種類の誤りだけ
    if types and r.ok:
        from . import pycheck
        try:
            after = p.read_text(encoding="utf-8", errors="replace")
            tool, probs = await _type_problems(p, cwd, pycheck.added_lines(before, after))
        except Exception:  # noqa: BLE001
            tool, probs = "", []
        if tool:
            r.tools.append(tool)
        if probs:
            r.ok = False
            r.output = "\n".join(probs[:20])
    return r


async def _check_js(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    r = CheckResult(_rel(p, cwd), True)
    ext = p.suffix.lower()
    if ext in (".ts", ".tsx"):
        if _has("tsc", cwd):
            # tsconfig があればプロジェクト全体、無ければ単体
            if (cwd / "tsconfig.json").exists():
                code, out = await _run([_bin("tsc", cwd), "--noEmit", "-p", str(cwd)], cwd, 180)
            else:
                code, out = await _run([_bin("tsc", cwd), "--noEmit", "--esModuleInterop", "--jsx", "react", str(p)], cwd, 120)
            r.tools.append("tsc")
            if code != 0:
                r.ok = False
                r.output = out.strip()
                return r
        else:
            r.skipped = "tsc が無い"
    else:
        if _has("node"):
            from . import jscheck as J
            st = await J.check_js_file(p, cwd)   # node --check + import/require の解決確認（v1.5.0）
            r.tools.append("node --check")
            if not st.ok:
                r.ok = False
                r.output = "\n".join(st.notes)
                return r
        else:
            r.skipped = "node が無い"
            return r
    if lint and _has("eslint", cwd) and any((cwd / f).exists() for f in
                                            ("eslint.config.js", "eslint.config.mjs", ".eslintrc", ".eslintrc.js",
                                             ".eslintrc.json", ".eslintrc.cjs", ".eslintrc.yml")):
        code, out = await _run([_bin("eslint", cwd), "--no-color", str(p)], cwd, 120)
        r.tools.append("eslint")
        if code != 0 and out.strip():
            r.ok = False
            r.output = out.strip()
    return r


async def _check_html(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    """v1.5.0: HTML 内のインライン script の構文と <script src> の存在を確認する。"""
    from . import jscheck as J
    r = CheckResult(_rel(p, cwd), True)
    st = await J.check_html_file(p, cwd)
    r.tools.append("html/js")
    if not st.ok:
        r.ok = False
        r.output = "\n".join(st.notes)
    return r


async def _check_go(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    r = CheckResult(_rel(p, cwd), True)
    if not _has("go"):
        r.skipped = "go が無い"
        return r
    pkg = p.parent
    code, out = await _run(["go", "vet", "./" + _rel(pkg, cwd) if pkg != cwd else "."], cwd, 180)
    r.tools.append("go vet")
    if code != 0:
        r.ok = False
        r.output = out.strip()
    return r


async def _check_rust(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    r = CheckResult(_rel(p, cwd), True)
    if not _has("cargo") or not (cwd / "Cargo.toml").exists():
        r.skipped = "cargo / Cargo.toml が無い"
        return r
    code, out = await _run(["cargo", "check", "--quiet", "--message-format", "short"], cwd, 300)
    r.tools.append("cargo check")
    if code != 0:
        r.ok = False
        r.output = out.strip()
    return r


async def _check_shell(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    r = CheckResult(_rel(p, cwd), True)
    code, out = await _run(["bash", "-n", str(p)], cwd, 30)
    r.tools.append("bash -n")
    if code != 0 and code != 127:
        r.ok = False
        r.output = out.strip()
        return r
    if lint and _has("shellcheck"):
        code, out = await _run(["shellcheck", "-f", "gcc", "-S", "warning", str(p)], cwd, 60)
        r.tools.append("shellcheck")
        if code != 0 and out.strip():
            r.ok = False
            r.output = out.strip()
    return r


async def _check_json(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    r = CheckResult(_rel(p, cwd), True, tools=["json"])
    try:
        json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        r.ok = False
        r.output = f"JSON が不正です: {e}"
    return r


async def _check_yaml(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    r = CheckResult(_rel(p, cwd), True, tools=["yaml"])
    try:
        import yaml
        yaml.safe_load(p.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        r.ok = False
        r.output = f"YAML が不正です: {e}"
    return r


async def _check_c(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    r = CheckResult(_rel(p, cwd), True)
    cc = "g++" if p.suffix.lower() in (".cpp", ".cc", ".cxx", ".hpp") else "gcc"
    if not _has(cc):
        r.skipped = f"{cc} が無い"
        return r
    code, out = await _run([cc, "-fsyntax-only", str(p)], cwd, 120)
    r.tools.append(f"{cc} -fsyntax-only")
    if code != 0:
        r.ok = False
        r.output = out.strip()
    return r


# ------------------------------------------------------------------ v2.11.30: Java
JAVA_BUILD_FILES = ("pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts")


def _java_build_root(p: Path, cwd: Path) -> Path | None:
    """ファイルから作業ディレクトリまでさかのぼり、Maven / Gradle のプロジェクトの根（pom.xml などがある場所）を探す。"""
    d = p.parent
    cwd = cwd.resolve()
    while True:
        if any((d / f).exists() for f in JAVA_BUILD_FILES):
            return d
        if d.resolve() == cwd or d.parent == d:
            return None
        d = d.parent


def _java_source_root(p: Path) -> Path:
    """package 宣言から、ソースの根（パッケージのフォルダの上）を求める。宣言が無ければファイルのフォルダ。"""
    try:
        m = re.search(r"^\s*package\s+([\w.]+)\s*;", p.read_text(encoding="utf-8", errors="replace"), re.M)
    except OSError:
        m = None
    root = p.parent
    if m:
        for _ in m.group(1).split("."):
            root = root.parent
    return root


async def _check_java(p: Path, cwd: Path, lint: bool, types: bool) -> CheckResult:
    """v2.11.30: javac でコンパイルできるかを確かめる（クラスファイルは一時フォルダに出し、作業ディレクトリを汚さない）。
    Maven / Gradle のプロジェクトでは依存ライブラリが要るので、ファイル単位ではコンパイルせず、テストの実行（mvn / gradle test）に任せる。"""
    import tempfile
    r = CheckResult(_rel(p, cwd), True)
    if _java_build_root(p, cwd) is not None:
        r.skipped = "Maven / Gradle のプロジェクト（コンパイルはテストの実行 mvn test / gradle test で確かめる）"
        return r
    if not _has("javac"):
        r.skipped = "javac が無い（JDK を入れる: sudo apt install default-jdk）"
        return r
    src = _java_source_root(p)
    jars = [str(j) for d in ("lib", "libs") for j in sorted((cwd / d).glob("*.jar"))] if cwd.is_dir() else []
    with tempfile.TemporaryDirectory(prefix="apercode_javac_") as out:
        cmd = ["javac", "-d", out, "-encoding", "UTF-8", "-sourcepath", str(src),
               "-cp", ":".join([str(src)] + jars), str(p)]
        code, text = await _run(cmd, cwd, 180)
    r.tools.append("javac")
    if code != 0:
        r.ok = False
        r.output = text.strip()
    return r


CHECKERS = {
    ".py": _check_python,
    ".js": _check_js, ".mjs": _check_js, ".cjs": _check_js, ".jsx": _check_js, ".ts": _check_js, ".tsx": _check_js,
    ".go": _check_go,
    ".rs": _check_rust,
    ".sh": _check_shell, ".bash": _check_shell,
    ".json": _check_json,
    ".html": _check_html, ".htm": _check_html,
    ".yaml": _check_yaml, ".yml": _check_yaml,
    ".c": _check_c, ".h": _check_c, ".cpp": _check_c, ".cc": _check_c, ".hpp": _check_c,
    ".java": _check_java,
}


async def check_file(path: Path, project: Path, *, lint: bool = True, types: bool = False, timeout: int = 180,
                     before: str | None = None, structure: bool = True) -> CheckResult | None:
    """ファイル 1 件を検証する。対象外の拡張子なら None。"""
    fn = CHECKERS.get(path.suffix.lower())
    if not fn or not path.is_file():
        return None
    # backup/ や node_modules 内は対象外
    parts = set(path.parts)
    if parts & {"node_modules", "backup", "__pycache__", ".git", ".venv", "venv"}:
        return None
    try:
        if fn is _check_python:
            return await asyncio.wait_for(_check_python(path, project, lint, types, before, structure), timeout=timeout)
        return await asyncio.wait_for(fn(path, project, lint, types), timeout=timeout)
    except asyncio.TimeoutError:
        return CheckResult(_rel(path, project), True, skipped=f"タイムアウト {timeout}s")
    except Exception as e:  # noqa: BLE001
        return CheckResult(_rel(path, project), True, skipped=f"チェック失敗: {e}")


# ------------------------------------------------------------------ テスト
def detect_test_command(project: Path, ignore_dirs: tuple[str, ...] = ("backup",)) -> str | None:
    """プロジェクト構成からテストコマンドを推定する。見つからなければ None。

    ignore_dirs: pytest に収集させないディレクトリ（バックアップ世代の中のテストを拾わないため）。
    """
    py = _project_python(project)
    ignores = " ".join(f"--ignore={d}" for d in ignore_dirs if (project / d).is_dir())
    pytest_cmd = f"{py} -m pytest -q -x --no-header -p no:cacheprovider" + (f" {ignores}" if ignores else "")
    if (project / "package.json").exists():
        try:
            pkg = json.loads((project / "package.json").read_text(encoding="utf-8"))
            script = (pkg.get("scripts") or {}).get("test", "")
            if script and "no test specified" not in script:
                mgr = "pnpm" if (project / "pnpm-lock.yaml").exists() else "yarn" if (project / "yarn.lock").exists() else "npm"
                return f"{mgr} test"
        except Exception:  # noqa: BLE001
            pass
    if (project / "Cargo.toml").exists() and _has("cargo"):
        return "cargo test --quiet"
    if (project / "go.mod").exists() and _has("go"):
        return "go test ./..."
    # v2.11.30: Java（Maven / Gradle）。依存ライブラリの置き場は作業ディレクトリの中にする（サンドボックスではホームが見えないため）
    if (project / "pom.xml").exists() and _has("mvn"):
        return "mvn -q -B -Dmaven.repo.local=.apercode/m2 test"
    if any((project / f).exists() for f in ("build.gradle", "build.gradle.kts")):
        if (project / "gradlew").exists():
            return "GRADLE_USER_HOME=.apercode/gradle ./gradlew test -q"
        if _has("gradle"):
            return "GRADLE_USER_HOME=.apercode/gradle gradle test -q"
    if (project / "Makefile").exists():
        try:
            if re.search(r"^test\s*:", (project / "Makefile").read_text(encoding="utf-8", errors="ignore"), re.M):
                return "make test"
        except OSError:
            pass
    # Python
    has_tests = any(next(iter(project.glob(pat)), None) is not None
                    for pat in ("tests/**/test_*.py", "test/**/test_*.py", "test_*.py", "*_test.py", "tests/**/*_test.py"))
    if has_tests or (project / "pytest.ini").exists() or (project / "conftest.py").exists():
        # pytest が使えるか
        if _pytest_available(py):
            return pytest_cmd
        # unittest: tests/ がパッケージでない場合は discover できないのでファイルを列挙して渡す
        files = []
        for pat in ("tests/**/test_*.py", "test/**/test_*.py", "test_*.py", "*_test.py", "tests/**/*_test.py"):
            files += [str(f.relative_to(project)) for f in project.glob(pat)]
        files = sorted(set(files))[:50]
        if files:
            return f"{py} -m unittest -q " + " ".join(files)
        return f"{py} -m unittest discover -q"
    if (project / "pyproject.toml").exists() or (project / "setup.py").exists():
        if _pytest_available(py):
            return pytest_cmd
    return None


def _pytest_available(py: str) -> bool:
    import subprocess
    try:
        return subprocess.run([py, "-c", "import pytest"], capture_output=True, timeout=20).returncode == 0
    except Exception:  # noqa: BLE001
        return False


def _parse_counts(out: str) -> tuple[int | None, int | None]:
    passed = failed = None
    m = re.search(r"(\d+) passed", out)
    if m:
        passed = int(m.group(1))
    m = re.search(r"(\d+) failed", out)
    if m:
        failed = int(m.group(1))
    m = re.search(r"(\d+) errors?\b", out)
    if m and failed is None:
        failed = int(m.group(1))
    # jest: Tests: 1 failed, 3 passed
    m = re.search(r"Tests:\s+(?:(\d+) failed, )?(?:(\d+) passed)", out)
    if m:
        failed = int(m.group(1)) if m.group(1) else failed
        passed = int(m.group(2)) if m.group(2) else passed
    # unittest: Ran 5 tests ... FAILED (failures=1)
    m = re.search(r"Ran (\d+) tests?", out)
    if m and passed is None:
        total = int(m.group(1))
        f = re.search(r"failures=(\d+)", out)
        e = re.search(r"errors=(\d+)", out)
        failed = (int(f.group(1)) if f else 0) + (int(e.group(1)) if e else 0)
        passed = total - failed
    return passed, failed


async def run_tests(project: Path, command: str | None = None, timeout: int = 600,
                    ignore_dirs: tuple[str, ...] = ("backup",), env: dict | None = None,
                    display: str | None = None) -> TestResult:
    cmd = command or detect_test_command(project, ignore_dirs)
    if not cmd:
        return TestResult(command="", exit_code=1, detected=False, output="")
    code, out = await _run(cmd, project, timeout, env={"CI": "1", "PYTHONDONTWRITEBYTECODE": "1", **(env or {})})
    if display:
        cmd, command = display, None            # 表示は元のコマンド。0 件判定も自動検出と同じに扱う
    passed, failed = _parse_counts(out)
    # テストが 1 件も無い（unittest discover の Ran 0 tests / pytest の no tests ran）は「未検出」扱い
    if command is None and (re.search(r"Ran 0 tests", out) or "no tests ran" in out or
                            (code == 5 and "pytest" in cmd)):
        note = ("\n(注: pytest が入っていないため unittest で実行しました。pytest 形式（関数 test_*）のテストは "
                "pytest が必要です: pip install pytest)" if "unittest" in cmd else "")
        return TestResult(command=cmd, exit_code=code, detected=False, output=out + note)
    return TestResult(command=cmd, exit_code=code, passed=passed, failed=failed, output=out)


async def run_tests_cov(project: Path, changes: dict[str, dict], timeout: int = 600,
                        ignore_dirs: tuple[str, ...] = ("backup",), patterns: list[str] | None = None):
    """v1.10.0: テストを実行し、pytest + coverage が使えれば「今回変更した行のうち実行されなかった行」も返す。

    戻り値: (TestResult, CoverageReport | None)。coverage が使えない・テスト失敗・Python の変更が無いときは None。
    """
    from . import coverage_check as CC
    import tempfile
    cmd = detect_test_command(project, ignore_dirs)
    if not cmd:
        return TestResult(command="", exit_code=1, detected=False, output=""), None
    py = _project_python(project)
    wrapped = CC.wrap_command(cmd) if any(str(r).endswith(".py") for r in changes) else None
    if not wrapped or not await asyncio.to_thread(CC.coverage_available, py):
        return await run_tests(project, None, timeout, ignore_dirs), None
    tmp = Path(tempfile.mkdtemp(prefix="apercode_cov_"))
    data = tmp / ".coverage"
    try:
        res = await run_tests(project, wrapped, timeout, ignore_dirs, env={"COVERAGE_FILE": str(data)}, display=cmd)
        rep = None
        if res.detected and res.ok:
            cov = await asyncio.to_thread(CC.load_json, project, py, data)
            if cov is not None:
                rep = CC.analyze(cov, project, changes, lambda r: is_test_file(r, patterns))
        return res, rep
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------------ テストファイルの保護（v1.2.1）
# 「テスト失敗 → 修正」のループ中にテストの方を書き換えて通す（assertion weakening）のを防ぐ。
DEFAULT_TEST_PATTERNS = [
    r"(^|/)tests?/", r"(^|/)__tests__/", r"(^|/)spec/",
    r"(^|/)test_[^/]*\.py$", r"_test\.py$", r"(^|/)conftest\.py$",
    r"\.(test|spec)\.[cm]?[jt]sx?$", r"_test\.go$", r"(^|/)tests\.rs$",
    r"Test[^/]*\.(java|kt|cs|php)$", r"_spec\.rb$", r"(^|/)test\.sh$",
]


def is_test_file(rel: str, patterns: list[str] | None = None) -> bool:
    rel = rel.replace("\\", "/")
    for pat in patterns or DEFAULT_TEST_PATTERNS:
        try:
            if re.search(pat, rel):
                return True
        except re.error:
            continue
    return False


def command_touches_tests(command: str, patterns: list[str] | None = None) -> str | None:
    """シェルコマンドがテストファイルを書き換えそうなら、その根拠（一致した語）を返す。

    テストを「実行する」だけのコマンド（pytest tests/ など）は対象外。書き込み系の語と
    テストパスの両方を含むときだけ検出する。
    """
    # v2.12.4: 「2>&1」「>/dev/null」などはファイルへの書き込みではない（pytest ... 2>&1 | tail を誤って止めていた）
    cmd = re.sub(r"\d*>&\d+|&>\s*/dev/null|\d*>>?\s*/dev/null", " ", command)
    # リダイレクト（> / >>）は書き込み先だけを見る
    for tgt in re.findall(r"(?<![<>])>>?\s*([^\s|;&<>]+)", cmd):
        if is_test_file(tgt.strip("'\""), patterns):
            return tgt
    if not re.search(r"(\bsed\s+-i|\btee\b|\brm\b|\bmv\b|\bcp\b|\btruncate\b|\bpatch\b|\bgit\s+(checkout|restore|rm)\b|"
                     r"\bpython3?\s+-c\b|\bperl\s+-[pn]?i\b|\bcat\s*<<)", cmd):
        return None
    for tok in re.findall(r"[\w./\\-]+", cmd):
        if "/" in tok or "." in tok:
            if is_test_file(tok.strip("'\""), patterns):
                return tok
    return None


def snapshot_tests(project: Path, patterns: list[str] | None = None, max_files: int = 500) -> dict[str, str]:
    """既存テストファイルの {相対パス: sha1} を返す（ターン開始時の基準）。"""
    import hashlib
    out: dict[str, str] = {}
    try:
        for p in project.rglob("*"):
            if len(out) >= max_files:
                break
            if not p.is_file():
                continue
            rel = str(p.relative_to(project))
            if any(part in ("node_modules", ".git", "__pycache__", ".venv", "venv", "backup", "target", "dist", "build")
                   for part in p.parts):
                continue
            if is_test_file(rel, patterns):
                try:
                    out[rel] = hashlib.sha1(p.read_bytes()).hexdigest()
                except OSError:
                    pass
    except OSError:
        pass
    return out


def changed_tests(project: Path, baseline: dict[str, str], patterns: list[str] | None = None) -> list[str]:
    """基準と比べて変更・削除された既存テストファイルの一覧（新規追加は含めない）。"""
    import hashlib
    diff = []
    for rel, h in baseline.items():
        p = project / rel
        if not p.is_file():
            diff.append(rel + " (削除)")
            continue
        try:
            if hashlib.sha1(p.read_bytes()).hexdigest() != h:
                diff.append(rel)
        except OSError:
            diff.append(rel)
    return diff


# ------------------------------------------------------------------ 変更量（レビュー閾値用）
def count_changed_lines(before: str | None, after: str) -> int:
    """変更前後のテキストから差分行数（追加+削除）を数える。新規ファイルは全行。"""
    import difflib
    if before is None:
        return len(after.splitlines())
    n = 0
    for line in difflib.unified_diff(before.splitlines(), after.splitlines(), lineterm="", n=0):
        if line.startswith(("+", "-")) and not line.startswith(("+++", "---")):
            n += 1
    return n


def unified_diff(before: str | None, after: str, name: str, max_chars: int = 12000) -> str:
    import difflib
    a = (before or "").splitlines()
    b = after.splitlines()
    text = "\n".join(difflib.unified_diff(a, b, fromfile=f"a/{name}", tofile=f"b/{name}", lineterm="", n=3))
    if len(text) > max_chars:
        text = text[:max_chars] + "\n... (差分が長いため省略)"
    return text
