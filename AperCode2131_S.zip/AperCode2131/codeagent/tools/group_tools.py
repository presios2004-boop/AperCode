"""open_tools: 閉じているツール群を開く（v2.12.0。toolgroups.py）。"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register
from .. import toolgroups as TG


async def _open(ctx: ToolContext, a: dict) -> str:
    groups = a.get("groups")
    if isinstance(groups, str):
        groups = [x.strip() for x in groups.replace("、", ",").split(",") if x.strip()]
    if not isinstance(groups, list) or not groups:
        raise ToolError("groups（開く群の名前の配列）を指定してください。使える群: " + ", ".join(TG.GROUPS))
    bad = [g for g in groups if g not in TG.GROUPS]
    good = [g for g in groups if g in TG.GROUPS]
    if ctx.tool_groups is None:
        ctx.tool_groups = set()
    already = [g for g in good if g in ctx.tool_groups]
    ctx.tool_groups |= set(good)
    from ..prompts import prompt_language
    lang = prompt_language()
    out = TG.describe_opened(good, lang) if good else ""
    if already:
        out += ("\n（" if lang != "en" else "\n(") + ", ".join(already) + (" は既に開いていました）" if lang != "en" else " were already open)")
    if bad:
        out += ("\n不明な群: " if lang != "en" else "\nUnknown groups: ") + ", ".join(bad) + \
               ("。使える群: " if lang != "en" else ". Available: ") + ", ".join(TG.GROUPS)
    return out.strip()


register(Tool(
    "open_tools",
    "まだ読み込んでいないツール群（mt5・research・browser・process・gui・collab・skills・misc）を開く。"
    "開いた群のツールは次の手番から呼べる。作業にその分野のツールが必要になったら、他のツールを呼ぶ前にこれで開く",
    {"type": "object",
     "properties": {"groups": {"type": "array", "items": {"type": "string"},
                               "description": "開く群の名前。例: [\"mt5\"]、[\"browser\", \"process\"]"}},
     "required": ["groups"]},
    _open,
    summarize=lambda a: "ツール群を開く: " + ", ".join(a.get("groups") or []) if isinstance(a.get("groups"), list) else "ツール群を開く",
))
