"""v2.12.3: 会話モード（auto）で、作業の依頼に文章だけで答えたら 1 回だけ促し直す。"""
from __future__ import annotations

from codeagent.agent import Agent
from conftest import tc

GOOD = "def add(a, b):\n    return a + b\n"


def test_looks_like_work_classifier():
    f = lambda q: Agent._looks_like_work(Agent, q)  # noqa: E731
    assert f("テストが失敗しています。原因を調べて直してください。テストファイルは変更しないでください。")
    assert f("slugify を直して") and f("ToDo アプリに優先度を追加してください。") and f("Fix the pagination bug in pager.py")
    assert not f("この関数は何をしていますか？") and not f("なぜこのテストが落ちるのか教えて") and not f("続けて")
    assert not f("pager.py を読んで、バグの原因を説明して") and not f("README を要約して") and not f("What does this function do?")


def test_work_request_answered_in_prose_is_nudged_once(h):
    proj = h.project(with_test=False)
    script = [("text", "原因は off-by-one です。start = (page - 1) * size にすると直ります"),
              ("text", "説明のみの依頼と判断しました")]
    agent, llm, store, s = h.make(script, proj, mode="auto")
    h.run(agent, s, "テストが失敗しています。原因を調べて直してください。")
    s2 = store.load(s.id)
    nudges = [m for m in s2.messages if m.get("kind") == "nudge" and "作業として進めて" in m.get("content", "")]
    assert len(nudges) == 1 and len(llm.systems) == 2
    assert any("文章だけで終わりました" in e.get("text", "") for e in h.of("info"))
    # 2 回目も文章なら、それ以上は促さない
    h.run(agent, store.load(s.id), "もう一度、直してください")


def test_nudge_leads_to_work_switch(h):
    proj = h.project(with_test=False)
    asked = []

    async def approve(req):
        asked.append(req)
        return f"work:{proj}" if req.get("kind") == "mode_switch" else "allow"
    h.approve = approve
    script = [("text", "add 関数が無いのが原因です"),
              ("tools", [tc("write_file", path="calc.py", content=GOOD)]),      # 促されてツールを呼ぶ → 作業の開始
              ("tools", [tc("set_plan", steps=["calc.py に add を実装する"], kind="code")]),
              ("tools", [tc("write_file", path="calc.py", content=GOOD)]),
              ("tools", [tc("step_done", summary="add を実装", evidence="確認した")]),
              ("text", "完了しました")]
    agent, llm, store, s = h.make(script, proj, mode="auto")
    h.run(agent, s, "calc.py に add 関数を追加して直してください")
    assert asked and asked[0]["kind"] == "mode_switch"
    assert any(e.get("type") == "mode" and e.get("working") for e in h.events)
    wrote = [e["output"] for e in h.of("tool_result") if e.get("name") == "write_file"]
    assert "作業モードに切り替えました" in wrote[0] and "作成:" in wrote[1]     # 促し → 切り替え → 作業で実際に書いた


def test_question_is_not_nudged(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "paginate は 1 ページ分を切り出す関数です")], proj, mode="auto")
    h.run(agent, s, "pager.py の paginate は何をする関数か説明して")
    assert len(llm.systems) == 1
    assert not any("文章だけで終わりました" in e.get("text", "") for e in h.of("info"))
