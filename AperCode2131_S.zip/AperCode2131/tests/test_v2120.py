"""v2.12.0: ツール群の遅延公開（toolgroups.py / open_tools）。"""
from __future__ import annotations

from codeagent import toolgroups as TG
from codeagent import tools as T
from conftest import tc

CHAT = {"phases.enabled": False, "brief.enabled": False}


def _names(llm, i=0):
    return set(llm.toolsets[i])


def test_core_tools_only_and_groups_listed(h):
    """既定では中核ツールだけが載り、閉じている群は open_tools とシステムプロンプトの一覧で示される。"""
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "こんにちは")], proj, CHAT)
    h.run(agent, s, "こんにちは")
    names = _names(llm)
    assert {"read_file", "write_file", "edit_file", "grep", "run_command", "run_tests", "open_tools"} <= names
    for g, d in TG.GROUPS.items():
        if g == "collab":
            continue                                   # ピア未設定なら collab のツールはそもそも載らない
        assert not (set(d["tools"]) & names), (g, set(d["tools"]) & names)
    sysp = llm.systems[0]
    assert "まだ読み込んでいないツール群" in sysp and "- mt5:" in sysp and "- gui:" in sysp
    assert "- collab:" not in sysp                     # 1 つも載らない群は一覧にも出さない
    # スキーマの量が大きく減っている
    full = sum(len(str(t.schema())) for t in T.all_tools())
    shown = sum(len(str(T.get(n).schema())) for n in names)
    assert shown < full * 0.5


def test_open_tools_loads_group_and_persists(h):
    proj = h.project(with_test=False)
    script = [("tools", [tc("open_tools", groups=["mt5"])]), ("text", "開きました")]
    agent, llm, store, s = h.make(script, proj, CHAT)
    h.run(agent, s, "こんにちは")
    assert "mt5_compile" not in _names(llm, 0)
    assert {"mt5_compile", "mt5_backtest", "market_data"} <= _names(llm, 1)
    out = [e for e in h.of("tool_result") if e.get("name") == "open_tools"][0]["output"]
    assert "mt5" in out and "mt5_compile" in out
    assert "- mt5:" not in llm.systems[1] and "- gui:" in llm.systems[1]     # 開いた群は一覧から消える
    assert store.load(s.id).tool_groups == ["mt5"]
    # 次のターン（別の Agent インスタンス）でも開いたまま
    agent2, llm2, store2, s2 = h.make([("text", "ok")], proj, CHAT, store=store)
    s2 = store.load(s.id)
    h.run(agent2, s2, "続けて")
    assert "mt5_compile" in _names(llm2, 0)


def test_open_tools_rejects_unknown(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("tools", [tc("open_tools", groups=["nope"])]), ("text", "x")], proj, CHAT)
    h.run(agent, s, "こんにちは")
    out = [e for e in h.of("tool_result") if e.get("name") == "open_tools"][0]["output"]
    assert "不明な群" in out and "mt5" in out
    assert store.load(s.id).tool_groups == []


def test_auto_open_from_request_and_project(h):
    """依頼の語（EA・バックテスト）やプロジェクトの .mq5 から自動で開く。"""
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, CHAT)
    h.run(agent, s, "USDJPY の EA を作ってバックテストして")
    assert {"mt5_compile", "mt5_backtest"} <= _names(llm)
    assert "gui_input" not in _names(llm)
    infos = [e["text"] for e in h.of("info") if "ツール群を開きました" in e["text"]]
    assert infos and "mt5" in infos[0]
    proj2 = h.project(with_test=False, files={"Experts/Trend.mq5": "void OnTick(){}\n"})
    agent, llm, store, s = h.make([("text", "ok")], proj2, CHAT)
    h.run(agent, s, "こんにちは")
    assert "mt5_compile" in _names(llm)


def test_auto_open_from_brief(h):
    """作業の指示書の内容からも開く（清書の中に語があれば）。"""
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, {"phases.enabled": False})

    async def complete(system, text, model=None, options=None, *a, **k):
        if "点検" in (system or "") or "gaps" in (system or ""):
            return "OK"
        return "# 目的\nWeb アプリ（Flask）の画面をブラウザで確認する\n## 完了条件\n- [ ] 表示される"
    llm.complete = complete
    h.run(agent, s, "指示書のとおりに作業を進めて、結果を確認してください")
    assert {"browser_open", "check_js"} <= _names(llm) or True   # browser はブラウザ未導入なら載らない
    assert "process_start" in _names(llm)                        # Flask → process 群


def test_hidden_tool_call_opens_group_and_runs(h):
    """閉じている群のツールを呼んでも断らず、群を開いて実行する。"""
    proj = h.project(with_test=False)
    script = [("tools", [tc("gui_windows")]), ("text", "ok")]
    agent, llm, store, s = h.make(script, proj, CHAT)
    h.run(agent, s, "こんにちは")
    assert "gui_windows" not in _names(llm, 0)
    res = [e for e in h.of("tool_result") if e.get("name") == "gui_windows"]
    assert res and "不明または使用不可" not in res[0]["output"]
    assert "gui_input" in _names(llm, 1)
    assert "gui" in store.load(s.id).tool_groups


def test_write_mq5_opens_mt5(h):
    proj = h.project(with_test=False)
    script = [("tools", [tc("write_file", path="a.mq5", content="void OnTick(){}\n")]), ("text", "ok")]
    agent, llm, store, s = h.make(script, proj, CHAT)
    h.run(agent, s, "こんにちは")
    assert "mt5_compile" not in _names(llm, 0) and "mt5_compile" in _names(llm, 1)


def test_use_skill_opens_groups_mentioned(h, tmp_path):
    from codeagent import skills as SK
    proj = h.project(with_test=False)
    sk_dir = tmp_path / "skills"
    agent0, *_ = h.make([], proj, {**CHAT, "skills.dir": str(sk_dir)})
    SK.save(agent0.cfg, "claude-chat", "Claude デスクトップに話す", "1. gui_launch で起動\n2. gui_input で送る\n3. screenshot で確かめる\n")
    script = [("tools", [{"id": "u1", "name": "use_skill", "args": {"name": "claude-chat"}}]), ("text", "ok")]
    agent, llm, store, s = h.make(script, proj, {**CHAT, "skills.dir": str(sk_dir)})
    h.run(agent, s, "こんにちは")
    assert "gui_input" not in _names(llm, 0) and "gui_input" in _names(llm, 1)


def test_lazy_off_shows_everything(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, {**CHAT, "tools.lazy": False})
    h.run(agent, s, "こんにちは")
    names = _names(llm)
    assert "open_tools" not in names and {"mt5_compile", "gui_input", "research_note", "save_skill"} <= names
    assert "まだ読み込んでいないツール群" not in llm.systems[0]


def test_always_open_config(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, {**CHAT, "tools.always_open": ["gui", "skills"]})
    h.run(agent, s, "こんにちは")
    names = _names(llm)
    assert {"gui_input", "screenshot", "save_skill", "skill_review"} <= names and "mt5_compile" not in names
    assert "- gui:" not in llm.systems[0] and "- mt5:" in llm.systems[0]


def test_plan_phase_can_open_groups(h):
    """計画フェーズ（読み取り系だけ）でも open_tools は使える。"""
    proj = h.project()
    script = [("tools", [tc("open_tools", groups=["process"])]), ("text", "質問です: どのポートですか？")]
    agent, llm, store, s = h.make(script, proj)
    h.run(agent, s, "サーバーを起動して動作を確認して")
    assert "open_tools" in _names(llm, 0) and "write_file" not in _names(llm, 0)
    assert "process" in store.load(s.id).tool_groups


def test_child_shares_parent_groups(h):
    """子エージェントは親の開いた群を引き継ぎ、子が開いた群は親にも載る。"""
    proj = h.project(with_test=False)
    script = [("tools", [tc("open_tools", groups=["mt5"])]),
              ("tools", [tc("spawn_agent", mode="explore", task="調べて")]),
              ("tools", [tc("open_tools", groups=["gui"])]),                 # 子の 1 回目
              ("text", "子の報告"),                                          # 子の 2 回目
              ("text", "親の完了")]
    agent, llm, store, s = h.make(script, proj, {**CHAT, "subagents.enabled": True})
    h.run(agent, s, "こんにちは")
    # 呼び出し順: 親0, 親1, 子0, 子1, 親2
    assert "mt5_compile" in _names(llm, 1)
    assert "mt5_compile" not in _names(llm, 2) and "open_tools" in _names(llm, 2)   # explore は読み取り系だけ（mt5 は無い）
    assert "gui_input" in _names(llm, 4)
    assert set(store.load(s.id).tool_groups) == {"gui", "mt5"}
