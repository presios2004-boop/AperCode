"""v2.12.2: 頼まれていない振る舞いの変更をしない規則・指示書の例の転記・会話モードでの作業開始の後押し。"""
from __future__ import annotations

from codeagent import prompts as PR
from codeagent import brief as BR

CHAT = {"phases.enabled": False, "brief.enabled": False}


def test_system_prompt_has_no_unrequested_change_rule(tmp_path):
    s = PR.build_system_prompt(tmp_path, tmp_path)
    assert "頼まれていない振る舞いの変更はしない" in s and "出力・表示の形式" in s
    assert "Modify existing files" not in s


def test_brief_prompt_copies_examples():
    assert "完了条件にそのまま書く" in BR.BRIEF_PROMPT
    assert "Copy any example or format" in BR.BRIEF_PROMPT_EN


def test_chat_block_nudges_to_call_tools(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, CHAT, mode="auto")
    h.run(agent, s, "slugify を直して")
    sysp = llm.systems[0]
    assert "いまは会話モード" in sysp and "文章で返して終わらせず" in sysp and "write_file / edit_file / run_command" in sysp
