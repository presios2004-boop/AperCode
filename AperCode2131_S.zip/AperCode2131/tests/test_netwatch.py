"""v2.13.0: 通信の監視と遮断（codeagent/netwatch.py）。実際の外部通信はしない。"""
from __future__ import annotations

import asyncio
import socket

import pytest

from codeagent import netwatch as NW


class _Cfg:
    def __init__(self, data=None):
        self.data = data or {}

    def get(self, key, default=None):
        cur = self.data
        for k in key.split("."):
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur


@pytest.fixture
def nw(tmp_path, monkeypatch):
    monkeypatch.setattr(NW, "STATE_PATH", tmp_path / "netwatch.json")
    monkeypatch.setattr(NW, "LOG_PATH", tmp_path / "netwatch.jsonl")
    w = NW.NetWatch(_Cfg({"llm": {"base_url": "http://192.168.1.10:8080/v1"},
                          "web": {"searxng_url": "https://searx.example.org"},
                          "netwatch": {"mode": "all", "block_telemetry": False}}))   # v2.13.0 の動き（すべて警告）
    w.set_cfg(w.cfg)
    return w


def test_classify(nw):
    assert nw.classify("", "127.0.0.1") == "local"
    assert nw.classify("", "192.168.1.10") == "local"
    assert nw.classify("api.anthropic.com", "160.79.104.10") == "cloud"
    assert nw.classify("html.duckduckgo.com") == "search"
    assert nw.classify("ja.wikipedia.org") == "search"
    assert nw.classify("searx.example.org") == "config"
    assert nw.classify("odd-host.example.net", "203.0.113.9") == "unknown"
    nw.note_task_text("curl -s https://pypi.org/simple/ && echo ok")
    assert nw.classify("pypi.org") == "task" and nw.classify("files.pypi.org") == "task" and nw.classify("pypi.example.org") == "unknown"
    assert nw.classify("cdn.example.com", hint="page") == "task"          # 開いたページが読み込む先
    assert nw.classify("x.example.com", hint="cloud") == "cloud"          # cloud.py から呼ばれた
    nw.add_allow("odd-host.example.net")
    assert nw.classify("odd-host.example.net") == "allowed"


def test_block_list_and_persistence(nw):
    with pytest.raises(ValueError):
        nw.add_block("127.0.0.1")
    with pytest.raises(ValueError):
        nw.add_block("localhost")
    nw.add_block("tracker.example.com")
    assert nw.is_blocked(host="a.tracker.example.com") and not nw.is_blocked(host="example.com")
    assert nw.classify("tracker.example.com") == "blocked"
    nw.ip_host["203.0.113.7"] = "tracker.example.com"
    assert nw.is_blocked(ip="203.0.113.7")
    again = NW.NetWatch(nw.cfg)                   # 保存した一覧を読み直す
    assert again.is_blocked(host="tracker.example.com")
    nw.remove_block("tracker.example.com")
    assert not NW.NetWatch(nw.cfg).is_blocked(host="tracker.example.com")


def test_record_merges_and_lists_unknown_first(nw):
    nw.record("AperCode（Python）", "html.duckduckgo.com", "52.0.0.1", 443, hint="search")
    nw.record("AperCode（Python）", "html.duckduckgo.com", "52.0.0.1", 443, hint="search")
    nw.record("LLM サーバー（docker: strata）", "", "203.0.113.9", 443)
    evs = nw.list()
    assert evs[0]["kind"] == "unknown" and evs[0]["ip"] == "203.0.113.9"
    dd = [e for e in evs if e["host"] == "html.duckduckgo.com"][0]
    assert dd["count"] == 2 and dd["kind"] == "search"
    assert nw.summary()["unknown"] == 1
    assert NW.LOG_PATH.read_text().count("\n") == 2           # 初めて見た通信先だけ記録


def test_audit_hook_records_and_blocks(nw):
    nw.install_hook()
    assert nw.hook_installed
    nw.add_block("blocked.invalid")
    with pytest.raises(PermissionError):
        socket.getaddrinfo("blocked.invalid", 443)
    nw.add_block("203.0.113.50")
    s = socket.socket()
    s.settimeout(0.01)
    try:
        with pytest.raises(PermissionError):
            s.connect(("203.0.113.50", 80))                   # 接続する前に止める（外へは出ない）
    finally:
        s.close()
    s3 = socket.socket()
    try:
        s3.connect(("127.0.0.1", 9))                          # PC 内は記録しない
    except OSError:
        pass
    finally:
        s3.close()
    evs = {(e["ip"] or e["host"]): e for e in nw.list()}
    assert evs["203.0.113.50"]["source"] == "AperCode（Python）" and "遮断した" in evs["203.0.113.50"]["detail"]
    assert "127.0.0.1" not in evs
    assert "blocked.invalid" in evs


def test_parse_proc_net():
    tcp = ("  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode\n"
           "   0: 0100007F:1F90 00000000:0000 0A 00000000:00000000 00:00000000 00000000  1000        0 111 1\n"
           "   1: 0F02000A:D4F2 0A7100CB:01BB 01 00000000:00000000 00:00000000 00000000  1000        0 222 1\n"
           "   2: 0F02000A:D4F3 0A7100CB:01BB 06 00000000:00000000 00:00000000 00000000  1000        0 333 1\n")
    rows = NW.parse_proc_net(tcp, "tcp")
    assert rows == [{"proto": "tcp", "lip": "10.0.2.15", "lport": 54514, "rip": "203.0.113.10", "rport": 443, "inode": "222"}]
    tcp6 = ("  sl  local_address remote_address st\n"
            "   0: 0000000000000000FFFF00000F02000A:D4F2 0000000000000000FFFF00000A7100CB:01BB 01 0:0 0:0 0 1000 0 444 1\n")
    assert NW.parse_proc_net(tcp6, "tcp6")[0]["rip"] == "203.0.113.10"


def test_scan_once_finds_child_process_connection(nw, monkeypatch):
    """自分の子孫のプロセスの接続を、/proc から見つける（接続は差し替え）。"""
    import os
    import subprocess
    import sys
    child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(5)"])
    try:
        monkeypatch.setattr(NW, "_inodes_of", lambda pids: {"999": child.pid} if child.pid in pids else {})
        monkeypatch.setattr(NW, "_read_proc_net", lambda base: [{"proto": "tcp", "lip": "10.0.0.2", "lport": 5000,
                                                                "rip": "203.0.113.77", "rport": 443, "inode": "999"}])
        monkeypatch.setattr(nw, "_container_pids", lambda: {})
        assert child.pid in nw._target_pids() and os.getpid() in nw._target_pids()
        nw.scan_once()
        e = [x for x in nw.list() if x["ip"] == "203.0.113.77"][0]
        assert e["source"] == "AperCode の子プロセス" and e["kind"] == "unknown" and "time.sleep" in e["proc"]
    finally:
        child.kill()


def test_os_block_commands_and_no_pkexec(nw, monkeypatch):
    monkeypatch.setattr(nw, "container_ips", lambda: {"strata": "172.17.0.2"})
    cmds = nw.os_commands("203.0.113.9", [], add=True)
    assert cmds == ["iptables -I OUTPUT -d 203.0.113.9 -m comment --comment apercode-netwatch -j REJECT",
                    "iptables -I DOCKER-USER -s 172.17.0.2 -d 203.0.113.9 -m comment --comment apercode-netwatch -j REJECT"]
    assert nw.os_commands("2001:db8::1", [], add=False)[0].startswith("ip6tables -D OUTPUT -d 2001:db8::1")
    monkeypatch.setattr(NW.shutil, "which", lambda n: None)
    r = nw.add_block("203.0.113.9", os_level=True)
    assert r["os"]["ok"] is False and "pkexec" in r["os"]["error"] and r["os"]["commands"] == cmds


def test_browser_requests_are_recorded_and_blocked(nw):
    class Frame:
        pass

    class Page:
        def __init__(self):
            self.main_frame = Frame()

    pg = Page()
    pg.main_frame.page = pg

    class Req:
        def __init__(self, url, nav):
            self.url, self._nav, self.frame = url, nav, pg.main_frame

        def is_navigation_request(self):
            return self._nav

    class Ctx:
        def __init__(self):
            self.handlers, self.routes = {}, []

        def on(self, ev, fn):
            self.handlers[ev] = fn

        async def route(self, pat, fn):
            self.routes.append(fn)

        async def unroute(self, pat):
            self.routes.clear()

    ctx = Ctx()
    nw.attach_browser(ctx)
    ctx.handlers["request"](Req("https://news.example.com/a", True))
    ctx.handlers["request"](Req("https://ads.example.net/px.gif", False))
    ctx.handlers["request"](Req("http://127.0.0.1:8790/", True))
    hosts = {e["host"]: e for e in nw.list()}
    assert "127.0.0.1" not in hosts
    assert hosts["news.example.com"]["kind"] == "task" and hosts["ads.example.net"]["kind"] == "task"
    assert "news.example.com" in nw.task_hosts

    nw.add_block("ads.example.net")
    asyncio.run(nw.apply_browser_blocks())
    assert len(ctx.routes) == 1

    class Route:
        def __init__(self):
            self.done = ""

        async def abort(self, why):
            self.done = "abort"

        async def fallback(self):
            self.done = "go"
    r1, r2 = Route(), Route()
    asyncio.run(ctx.routes[0](r1, Req("https://ads.example.net/x.js", False)))
    asyncio.run(ctx.routes[0](r2, Req("https://news.example.com/b", False)))
    assert r1.done == "abort" and r2.done == "go"


def _client(tmp_path, monkeypatch, admin_lock=False):
    from pathlib import Path
    from fastapi.testclient import TestClient
    from codeagent.config import Config
    from codeagent.server import app as APP
    root = Path(__file__).resolve().parents[1]
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    monkeypatch.setattr(NW, "STATE_PATH", tmp_path / "netwatch.json")
    monkeypatch.setattr(NW, "LOG_PATH", tmp_path / "netwatch.jsonl")
    monkeypatch.setattr(NW, "_NW", None)
    cfg = Config.load(root / "config.yaml" if (root / "config.yaml").exists() else root / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("workspace", "root"): str(tmp_path), ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    monkeypatch.setattr(type(cfg), "state", lambda self: dict(getattr(self, "_st", {})), raising=False)
    monkeypatch.setattr(type(cfg), "save_state", lambda self, st: setattr(self, "_st", dict(st)), raising=False)
    (tmp_path / "w").mkdir()
    cfg.data.setdefault("security", {})["admin_lock"] = admin_lock
    cfg.data["netwatch"] = {"mode": "all", "block_telemetry": False}
    return TestClient(APP.create_app(cfg))


def test_api_list_block_allow(tmp_path, monkeypatch):
    c = _client(tmp_path, monkeypatch)
    NW.get().record("内蔵ブラウザ（Edge 本体）", "odd-host.example.net", "203.0.113.9", 443)
    r = c.get("/api/netwatch").json()
    assert r["summary"]["unknown"] == 1 and r["events"][0]["host"] == "odd-host.example.net"
    assert c.get("/api/netwatch?summary=1").json()["summary"]["unknown"] == 1
    assert c.post("/api/netwatch/block", json={"target": "127.0.0.1"}).status_code == 400
    assert c.post("/api/netwatch/block", json={"target": "odd-host.example.net"}).json()["ok"]
    r = c.get("/api/netwatch").json()
    assert r["events"][0]["kind"] == "blocked" and r["summary"]["block"][0]["target"] == "odd-host.example.net"
    c.post("/api/netwatch/unblock", json={"target": "odd-host.example.net"})
    c.post("/api/netwatch/allow", json={"target": "odd-host.example.net"})
    assert c.get("/api/netwatch").json()["events"][0]["kind"] == "allowed"
    pv = c.post("/api/netwatch/preview", json={"target": "203.0.113.9"}).json()
    assert any("-d 203.0.113.9" in x for x in pv["commands"])


def test_block_requires_admin(tmp_path, monkeypatch):
    c = _client(tmp_path, monkeypatch, admin_lock=True)
    for u in ("block", "unblock", "allow", "unallow", "reapply"):
        assert c.post(f"/api/netwatch/{u}", json={"target": "x.example.com"}).status_code == 403
    assert c.get("/api/netwatch").status_code == 200


# ---- v2.13.1: テレメトリーだけ警告・自動遮断
@pytest.fixture
def nwt(tmp_path, monkeypatch):
    monkeypatch.setattr(NW, "STATE_PATH", tmp_path / "netwatch.json")
    monkeypatch.setattr(NW, "LOG_PATH", tmp_path / "netwatch.jsonl")
    monkeypatch.setattr(NW, "EDGE_RULES_PATH", tmp_path / "edge-host-rules.txt")
    w = NW.NetWatch(_Cfg({"netwatch": {"telemetry_hosts": ["metrics.example.com"], "telemetry_exclude": ["analytics.mysite.jp"]}}))
    w.set_cfg(w.cfg)
    return w


def test_is_telemetry():
    t = NW.is_telemetry
    for h in ("browser.events.data.microsoft.com", "self.events.data.microsoft.com", "www.google-analytics.com",
              "static.ads-twitter.com", "o123.ingest.sentry.io", "telemetry.example.io", "analytics.x.com"):
        assert t(h), h
    for h in ("x.com", "api.x.com", "abs.twimg.com", "pbs.twimg.com", "analyticsvidhya.com", "www.microsoft.com",
              "edge.microsoft.com", "203.0.113.9", ""):
        assert not t(h), h


def test_telemetry_mode_only_warns_on_telemetry(nwt):
    assert nwt.mode() == "telemetry" and nwt.block_telemetry()
    # X に投稿するときの通信（Edge 本体の CDN・Microsoft の IP など）は警告しない
    nwt.record("内蔵ブラウザ（Edge 本体）", "", "2600:140b:1c00:47::1734:8c8e", 443)
    nwt.record("内蔵ブラウザ（Edge 本体）", "g2600-140b.deploy.static.akamaitechnologies.com", "2600:140b::1", 443)
    nwt.record("内蔵ブラウザ", "api.x.com", "", 443, hint="page")
    nwt.record("AperCode（Python）", "browser.events.data.microsoft.com", "20.42.73.29", 443)
    nwt.record("AperCode（Python）", "metrics.example.com", "198.51.100.1", 443)
    nwt.record("AperCode（Python）", "analytics.mysite.jp", "198.51.100.2", 443)
    kinds = {e["host"] or e["ip"]: e["kind"] for e in nwt.list()}
    assert kinds["2600:140b:1c00:47::1734:8c8e"] == "other"
    assert kinds["g2600-140b.deploy.static.akamaitechnologies.com"] == "other"
    assert kinds["api.x.com"] == "task"
    assert kinds["browser.events.data.microsoft.com"] == "telemetry_blocked"
    assert kinds["metrics.example.com"] == "telemetry_blocked"
    assert kinds["analytics.mysite.jp"] == "other"                         # 除外
    s = nwt.summary()
    assert s["alert"] == 0 and s["alert_kinds"] == ["telemetry"]


def test_telemetry_warn_without_block(nwt):
    nwt.cfg.data["netwatch"]["block_telemetry"] = False
    nwt.record("AperCode（Python）", "www.google-analytics.com", "142.250.0.1", 443)
    assert nwt.list()[0]["kind"] == "telemetry" and nwt.summary()["alert"] == 1
    assert not nwt.is_blocked(host="www.google-analytics.com")
    nwt.add_allow("google-analytics.com")                                  # 「問題なし」
    assert nwt.list()[0]["kind"] == "allowed" and nwt.summary()["alert"] == 0


def test_telemetry_auto_block_in_process_and_browser(nwt):
    nwt.install_hook()
    with pytest.raises(PermissionError):
        socket.getaddrinfo("vortex.data.microsoft.com", 443)
    assert nwt.is_blocked(host="www.google-analytics.com") and not nwt.is_blocked(host="x.com")
    nwt.add_allow("google-analytics.com")
    assert not nwt.is_blocked(host="www.google-analytics.com")             # 許可した先は止めない

    class Ctx:
        def __init__(self):
            self.routes = []

        def on(self, ev, fn):
            pass

        async def route(self, pat, fn):
            self.routes.append(fn)

        async def unroute(self, pat):
            self.routes.clear()
    ctx = Ctx()
    nwt.attach_browser(ctx)
    asyncio.run(nwt.apply_browser_blocks())
    assert len(ctx.routes) == 1                                            # 遮断の一覧が空でもテレメトリーのために入れる


def test_edge_host_rules(nwt):
    r = NW.edge_host_rules(nwt)
    assert "MAP events.data.microsoft.com ~NOTFOUND" in r and "MAP *.events.data.microsoft.com ~NOTFOUND" in r
    assert "MAP metrics.example.com ~NOTFOUND" in r and "x.com " not in r.replace("ads-api.x.com", "").replace("analytics.x.com", "")
    p = NW.write_edge_rules(nwt)
    assert p.read_text().strip() == r
    nwt.cfg.data["netwatch"]["block_telemetry"] = False
    assert NW.edge_host_rules(nwt) == ""
