"""v2.12.4: テスト失敗後のテスト保護（_test_lock）の誤ブロックを直す。

1. このセッションで AperCode 自身が新しく作ったテストは、テスト失敗後も直せる
2. 「pytest tests/x.py 2>&1 | tail」のようにテストを実行するだけのコマンドを止めない
"""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from codeagent import verify as V
from codeagent.agent import Agent, VerifyState
from codeagent.session import Session


class _Cfg(dict):
    def get(self, k, d=None):
        return super().get(k, d)


def _agent():
    a = Agent.__new__(Agent)
    a.cfg = _Cfg()
    return a


def _st(proj: Path, baseline: dict):
    vs = VerifyState()
    vs.test_baseline = dict(baseline)
    vs.tests_locked = True
    ctx = SimpleNamespace(verify=vs, project_dir=proj, resolve=lambda p: (proj / p).resolve())
    return SimpleNamespace(ctx=ctx)


def test_command_running_tests_is_not_blocked():
    f = V.command_touches_tests
    assert f(".venv/bin/python -m pytest tests/test_a.py -q 2>&1 | tail -15") is None
    assert f("pytest tests/test_a.py > /dev/null 2>&1") is None
    assert f("pytest tests/test_a.py > out.txt") is None
    assert f("pytest tests/test_a.py &>/dev/null") is None
    # 書き込みは今まで通り検出する
    assert f("echo x > tests/test_a.py") == "tests/test_a.py"
    assert f("echo x >> tests/test_a.py") == "tests/test_a.py"
    assert f("sed -i 's/1.0/2.0/' tests/test_a.py") == "tests/test_a.py"
    assert f("cat << EOF > tests/test_a.py") == "tests/test_a.py"
    assert f("rm tests/test_a.py 2>&1") == "tests/test_a.py"


def test_own_new_test_is_editable_after_failure(tmp_path):
    (tmp_path / "tests").mkdir()
    old = tmp_path / "tests" / "test_old.py"
    old.write_text("def test_x():\n    assert 1\n")
    new = tmp_path / "tests" / "test_new.py"
    st = _st(tmp_path, {"tests/test_old.py": "sha"})
    s = Session.new(str(tmp_path))
    a = _agent()
    # 新規作成（失敗後でも新規テストの追加は許可）→ 自作として記録
    assert a._test_lock(st, "write_file", {"path": "tests/test_new.py"}, s) is None
    new.write_text("def test_y():\n    assert 1 == 2\n")
    a._note_own_test(st, s, new, None)
    assert s.own_tests == ["tests/test_new.py"]
    # 自作テストは直せる。元からあるテストは今まで通り保護する
    assert a._test_lock(st, "edit_file", {"path": "tests/test_new.py"}, s) is None
    assert a._test_lock(st, "edit_file", {"path": "tests/test_old.py"}, s) == "tests/test_old.py"
    assert a._test_lock(st, "run_command", {"command": "sed -i 's/2/1/' tests/test_new.py"}, s) is None
    assert a._test_lock(st, "run_command", {"command": "sed -i 's/2/1/' tests/test_old.py"}, s) == "tests/test_old.py"
    # session が無い（子エージェントなど）ときは従来どおり
    assert a._test_lock(st, "edit_file", {"path": "tests/test_new.py"}) == "tests/test_new.py"


def test_existing_or_overwritten_file_is_not_recorded_as_own(tmp_path):
    (tmp_path / "tests").mkdir()
    old = tmp_path / "tests" / "test_old.py"
    old.write_text("x")
    st = _st(tmp_path, {"tests/test_old.py": "sha"})
    s = Session.new(str(tmp_path))
    a = _agent()
    a._note_own_test(st, s, old, None)                 # 基準（ターン開始時）にあるテスト
    a._note_own_test(st, s, old, "x")                  # 上書き（before あり）
    src = tmp_path / "calc.py"
    src.write_text("x")
    a._note_own_test(st, s, src, None)                 # テストではない
    assert s.own_tests == []


def test_own_tests_persist_in_session(tmp_path):
    from codeagent.session import SessionStore
    store = SessionStore(tmp_path / "s")
    s = Session.new(str(tmp_path))
    s.own_tests = ["tests/test_new.py"]
    store.save(s)
    assert store.load(s.id).own_tests == ["tests/test_new.py"]


def test_agent_can_fix_its_own_new_test_after_failure(h):
    from conftest import GOOD, tc
    proj = h.project(files={"calc.py": GOOD})
    wrong = "from calc import add\n\n\ndef test_new():\n    assert add(1, 1) == 3\n"
    right = "from calc import add\n\n\ndef test_new():\n    assert add(1, 1) == 2\n"
    script = [("tools", [tc("set_plan", steps=["add のテストを追加する"], kind="code")]),
              ("tools", [tc("write_file", path="tests/test_new.py", content=wrong)]),
              ("tools", [tc("run_tests")]),
              ("tools", [tc("edit_file", path="tests/test_new.py", old_string="== 3", new_string="== 2")]),
              ("tools", [tc("edit_file", path="tests/test_calc.py", old_string="== 5", new_string="== 6")]),
              ("tools", [tc("run_tests")]),
              ("tools", [tc("step_done", summary="テストを追加", evidence="run_tests 通過")]),
              ("text", "完了しました")]
    agent, llm, store, s = h.make(script, proj, overrides={"verify.lock_tests": "deny"})
    h.run(agent, s, "add のテストを追加してください")
    assert (proj / "tests" / "test_new.py").read_text() == right          # 自作テストは直せた
    assert "== 5" in (proj / "tests" / "test_calc.py").read_text()       # 既存テストは守られた
    blocked = [e for e in h.of("tool_result") if "既存のテストファイルを変更できません" in str(e.get("output", ""))]
    assert len(blocked) == 1 and "tests/test_calc.py" in blocked[0]["output"]
    assert store.load(s.id).own_tests == ["tests/test_new.py"]
