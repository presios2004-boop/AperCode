"""v2.12.0: リポジトリマップ（repomap.py）。"""
from __future__ import annotations

from pathlib import Path

from codeagent.repomap import RepoMap

CHAT = {"phases.enabled": False, "brief.enabled": False}


class _Cfg:
    def __init__(self, d=None):
        self.d = d or {}

    def get(self, k, default=None):
        return self.d.get(k, default)


PY = '''import os

class Store(Base):
    """x"""
    def __init__(self, path, *, cache=None):
        pass
    async def load(self):
        pass
    def __repr__(self):
        return ""

def helper(a, b=1, *args, **kw):
    return a

async def main():
    pass
'''
MQ5 = '''#include <Trade/Trade.mqh>
input int    InpPeriod = 14;
input double InpLot = 0.1;
int OnInit()
{
   return INIT_SUCCEEDED;
}
void OnTick()
  {
  if(x) return;
  }
bool IsNewBar(string sym, ENUM_TIMEFRAMES tf)
{
   return true;
}
'''
JS = '''export function add(a, b) { return a + b }
const inc = (x) => x + 1;
export default class Counter extends Base {
  bump() {}
}
'''


def _proj(tmp_path: Path) -> Path:
    p = tmp_path / "proj"
    (p / "src").mkdir(parents=True)
    (p / "src" / "store.py").write_text(PY)
    (p / "ea.mq5").write_text(MQ5)
    (p / "web" / "static").mkdir(parents=True)
    (p / "web" / "static" / "app.js").write_text(JS)
    (p / "tests").mkdir()
    (p / "tests" / "test_store.py").write_text("def test_x():\n    pass\n")
    (p / ".venv" / "lib").mkdir(parents=True)
    (p / ".venv" / "lib" / "big.py").write_text("def hidden():\n    pass\n")
    (p / "node_modules" / "m").mkdir(parents=True)
    (p / "node_modules" / "m" / "index.js").write_text("function nope(){}\n")
    (p / "backup" / "20260101-000000").mkdir(parents=True)
    (p / "backup" / "20260101-000000" / "old.py").write_text("def old():\n    pass\n")
    (p / ".apercode").mkdir()
    (p / ".apercode" / "x.py").write_text("def x():\n    pass\n")
    (p / "data.csv").write_text("a,b\n1,2\n")
    return p


def test_build_tree_and_symbols(tmp_path):
    p = _proj(tmp_path)
    s = RepoMap().build(p, _Cfg())
    assert "## リポジトリマップ" in s
    # 木: 除外フォルダは出ない、データファイルは名前だけ
    assert "src/" in s and "web/" in s and "data.csv" in s
    body = s.split("除いてある。\n", 1)[1]
    assert ".venv" not in body and "node_modules" not in body and "backup/" not in body and ".apercode" not in body
    assert "hidden()" not in body and "nope()" not in body and "old()" not in body
    # Python: クラス・メソッド（__repr__ のような特殊メソッドは省く）・関数・既定値・可変長引数
    assert "src/store.py:" in s and "class Store(Base)" in s and "def __init__(self, path, *, cache=…)" not in s
    assert "  def __init__(self, path, cache=…)" in s and "  async def load(self)" in s and "__repr__" not in s
    assert "def helper(a, b=…, *args, **kw)" in s and "async def main()" in s
    # MQL5: input と関数（if は拾わない）
    assert "input int InpPeriod = 14" in s and "OnInit()" in s and "OnTick()" in s and "IsNewBar(string sym, ENUM_TIMEFRAMES tf)" in s
    assert "if(x)" not in s
    # JS
    assert "function add(a, b)" in s and "const inc = (x) =>" in s and "class Counter" in s
    # 行番号は出さない（編集でずれるため）。注記がある
    assert "   3: class Store" not in s and "  class Store(Base)" in s
    assert "行番号は示さず" in s and "read_file / grep" in s
    # テストは本体より後
    assert s.index("src/store.py:") < s.index("tests/test_store.py:")


def test_budget_and_cache(tmp_path):
    p = _proj(tmp_path)
    for i in range(40):
        (p / "src" / f"m{i:02d}.py").write_text("".join(f"def f{j}(a, b):\n    pass\n\n" for j in range(30)))
    rm = RepoMap()
    s = rm.build(p, _Cfg({"repomap.max_chars": 3000}))
    assert len(s) <= 3400 and "ファイルは省略" in s
    # 2 回目は解析し直さない（キャッシュ）: ファイルを変えると更新される
    cache = rm._cache[str(p)]
    fi = cache["src/store.py"]
    (p / "src" / "store.py").write_text(PY + "\ndef added(z):\n    pass\n")
    import os
    os.utime(p / "src" / "store.py", (fi.mtime + 10, fi.mtime + 10))
    rm.build(p, _Cfg())
    assert cache["src/store.py"] is not fi and any("def added(z)" in t for _, t in cache["src/store.py"].symbols)
    # 消したファイルはキャッシュからも消える
    (p / "ea.mq5").unlink()
    rm.build(p, _Cfg())
    assert "ea.mq5" not in cache


def test_disabled_and_empty(tmp_path):
    p = _proj(tmp_path)
    assert RepoMap().build(p, _Cfg({"repomap.enabled": False})) == ""
    e = tmp_path / "empty"
    e.mkdir()
    assert RepoMap().build(e, _Cfg()) == ""
    assert RepoMap().build(tmp_path / "nope", _Cfg()) == ""


def test_map_in_system_prompt_and_notice(h):
    proj = h.project(with_test=True, files={"calc.py": "def add(a, b):\n    return a + b\n"})
    agent, llm, store, s = h.make([("text", "ok"), ("text", "ok")], proj, CHAT)
    h.run(agent, s, "こんにちは")
    sysp = llm.systems[0]
    assert "## リポジトリマップ" in sysp and "calc.py:" in sysp and "def add(a, b)" in sysp and "tests/" in sysp
    assert sysp.index("## リポジトリマップ") > sysp.index("## 環境")
    infos = [e["text"] for e in h.of("info") if "リポジトリマップ" in e["text"]]
    assert len(infos) == 1 and "2 ファイルの関数・クラス" in infos[0]
    h.run(agent, s, "もう一度")                        # 変わっていなければ知らせない
    assert len([e for e in h.of("info") if "リポジトリマップ" in e["text"]]) == 1


def test_map_can_be_disabled(h):
    proj = h.project(with_test=False, files={"calc.py": "def add(a, b):\n    return a + b\n"})
    agent, llm, store, s = h.make([("text", "ok")], proj, {**CHAT, "repomap.enabled": False})
    h.run(agent, s, "こんにちは")
    assert "リポジトリマップ" not in llm.systems[0]
