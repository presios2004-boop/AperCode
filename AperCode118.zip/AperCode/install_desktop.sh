#!/usr/bin/env bash
# AperCode をアプリメニュー / デスクトップから起動できるようにする（Linux, freedesktop 準拠）
#   bash install_desktop.sh          # インストール
#   bash install_desktop.sh --remove # 削除
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$DIR/.venv/bin/python3"
APPS="$HOME/.local/share/applications"
DESKTOP_FILE="$APPS/apercode.desktop"
ICON="$DIR/assets/icon.png"

if [ "$1" = "--remove" ]; then
  rm -f "$DESKTOP_FILE" "$HOME/デスクトップ/apercode.desktop" "$HOME/Desktop/apercode.desktop"
  echo "削除しました"
  exit 0
fi

if [ ! -x "$PY" ]; then
  echo "仮想環境がありません。先に: python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt"
  exit 1
fi

mkdir -p "$APPS"
cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=AperCode
Comment=ローカル LLM コーディングエージェント
Exec=$PY $DIR/app.py
Icon=$ICON
Terminal=false
Categories=Development;
StartupWMClass=AperCode
EOF
chmod +x "$DESKTOP_FILE"

# デスクトップにもコピー（存在する方のフォルダへ）
for D in "$HOME/デスクトップ" "$HOME/Desktop"; do
  if [ -d "$D" ]; then
    cp "$DESKTOP_FILE" "$D/apercode.desktop"
    chmod +x "$D/apercode.desktop"
    # Cinnamon/Nemo で「信頼済み」にする
    command -v gio >/dev/null && gio set "$D/apercode.desktop" metadata::trusted true 2>/dev/null || true
    echo "デスクトップにショートカットを作成: $D/apercode.desktop"
    break
  fi
done

command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" 2>/dev/null || true
echo "インストール完了: アプリメニューの「開発」に AperCode が追加されました"
echo "専用ウィンドウで開くには（任意）: $DIR/.venv/bin/pip install \"pywebview[qt]\""
