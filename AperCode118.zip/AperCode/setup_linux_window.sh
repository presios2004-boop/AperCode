#!/usr/bin/env bash
# Linux 用: 日本語入力（fcitx5 / ibus + Mozc）がそのまま使える専用ウィンドウ環境を整える。
#
# 方法: OS 標準の GTK + WebKit2GTK（python3-gi）を使う pywebview の GTK バックエンドに切り替える。
#       pip 版 Qt は OS の入力メソッドプラグインを持たないため、代わりにこちらを使う。
#       仮想環境を --system-site-packages で作り直す（OS の gi モジュールが見えるようにする）。
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "== 1/3 システムパッケージ（GTK / WebKit2GTK の Python バインディング）"
sudo apt install -y python3-gi python3-gi-cairo gir1.2-gtk-3.0 gir1.2-webkit2-4.1 2>/dev/null \
  || sudo apt install -y python3-gi python3-gi-cairo gir1.2-gtk-3.0 gir1.2-webkit2-4.0

echo "== 2/3 仮想環境を作り直し（--system-site-packages）"
deactivate 2>/dev/null || true
rm -rf .venv
python3 -m venv --system-site-packages .venv
.venv/bin/pip install -q -r requirements.txt
.venv/bin/pip install -q pywebview
.venv/bin/pip uninstall -y -q PyQt6 PyQt6-Qt6 PyQt6-WebEngine PyQt6-WebEngine-Qt6 PyQt6-sip qtpy 2>/dev/null || true

echo "== 3/3 確認"
.venv/bin/python3 -c "import gi; gi.require_version('Gtk','3.0'); gi.require_version('WebKit2','4.1'); from gi.repository import Gtk, WebKit2; print('GTK バックエンド: OK')" \
  || .venv/bin/python3 -c "import gi; gi.require_version('Gtk','3.0'); gi.require_version('WebKit2','4.0'); from gi.repository import Gtk, WebKit2; print('GTK バックエンド: OK (4.0)')"
echo "完了。python3 app.py で起動すると GTK の専用ウィンドウが開き、OS の日本語入力が使えます。"
