"""変更前ファイルの自動バックアップ。

write_file（上書き）/ edit_file の直前に、元ファイルを
    <project>/backup/<YYYYMMDD-HHMMSS>/<プロジェクト相対パス>
へコピーする。タイムスタンプは 1 ターン（ユーザー入力 1 回）につき 1 つで、
そのターンで変更した全ファイルの「変更前の状態」が同じフォルダにまとまる。

復元: backup/<日時>/ の中身をプロジェクトに上書きコピーするだけ（restore_backup ツール、または手動 cp -r）。
"""
from __future__ import annotations

import shutil
import time
from pathlib import Path

from .config import Config


class BackupManager:
    def __init__(self, cfg: Config, project: Path):
        self.enabled = bool(cfg.get("backup.enabled", True))
        self.dirname = str(cfg.get("backup.dir", "backup"))
        self.keep_days = int(cfg.get("backup.keep_days", 30))
        self.max_file_mb = float(cfg.get("backup.max_file_mb", 20))
        self.project = project.resolve()
        self.root = self.project / self.dirname
        self._stamp: str | None = None       # このターンのフォルダ名（最初のバックアップ時に確定）
        self.saved: list[str] = []            # このターンで退避した相対パス

    def begin_turn(self):
        self._stamp = None
        self.saved = []

    def _in_project(self, p: Path) -> bool:
        p = p.resolve()
        return p == self.project or self.project in p.parents

    def save(self, path: Path) -> Path | None:
        """path の現在の内容を退避する。退避先を返す（対象外なら None）。"""
        if not self.enabled:
            return None
        p = path.resolve()
        if not p.is_file() or not self._in_project(p):
            return None
        rel = p.relative_to(self.project)
        if rel.parts and rel.parts[0] == self.dirname:      # バックアップ自体は退避しない
            return None
        if p.stat().st_size > self.max_file_mb * 1024 * 1024:
            return None
        if self._stamp is None:
            self._stamp = time.strftime("%Y%m%d-%H%M%S")
            self.prune()
        dest = self.root / self._stamp / rel
        if dest.exists():                                     # 同一ターン内で同じファイルを再変更 → 最初の状態を保持
            return dest
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
        self.saved.append(str(rel))
        return dest

    def prune(self):
        """keep_days より古い世代を削除する。"""
        if self.keep_days <= 0 or not self.root.is_dir():
            return
        cutoff = time.time() - self.keep_days * 86400
        for d in self.root.iterdir():
            try:
                if d.is_dir() and d.stat().st_mtime < cutoff:
                    shutil.rmtree(d, ignore_errors=True)
            except OSError:
                pass

    def list(self) -> list[dict]:
        if not self.root.is_dir():
            return []
        out = []
        for d in sorted(self.root.iterdir(), reverse=True):
            if d.is_dir():
                files = [str(f.relative_to(d)) for f in d.rglob("*") if f.is_file()]
                out.append({"stamp": d.name, "files": files})
        return out

    def restore(self, stamp: str, files: list[str] | None = None) -> list[str]:
        """指定世代のファイルをプロジェクトへ書き戻す。復元前に現在の状態も退避する。"""
        src = self.root / stamp
        if not src.is_dir():
            raise FileNotFoundError(f"バックアップがありません: {stamp}")
        targets = [src / f for f in files] if files else [f for f in src.rglob("*") if f.is_file()]
        restored = []
        for f in targets:
            if not f.is_file():
                continue
            rel = f.relative_to(src)
            dest = self.project / rel
            self.save(dest)                       # 復元前の状態を新しい世代へ退避
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dest)
            restored.append(str(rel))
        return restored
