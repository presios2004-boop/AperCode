"""エージェントループ: ユーザー入力 → LLM → ツール実行 → LLM … を繰り返す。

- コンテキスト圧縮: 履歴が閾値を超えたら古い部分を LLM で要約し 1 メッセージに置き換える
- サブエージェント: spawn_agent ツールで独立コンテキストの子ループを起動する

UI とは emit(event: dict) コールバックと、承認要求用の ask_approval コルーチンで接続する。
"""
from __future__ import annotations

import asyncio
import time
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from . import tools as T
from .config import Config
from .llm import LLMClient
from .backup import BackupManager
from .memory import MemoryStore, Embedder
from .prompts import build_system_prompt, SUBAGENT_PROMPT, SUMMARY_PROMPT, REFLECT_PROMPT
from .session import Session, SessionStore

# プロジェクトの言語・ツールをファイル構成から推定するための対応表（タグは小文字）
EXT_TAGS = {
    ".py": "python", ".mq5": "mql5", ".mqh": "mql5", ".mq4": "mql4", ".js": "javascript", ".ts": "typescript",
    ".tsx": "react", ".jsx": "react", ".go": "go", ".rs": "rust", ".java": "java", ".kt": "kotlin", ".c": "c",
    ".cpp": "c++", ".h": "c", ".hpp": "c++", ".cs": "c#", ".rb": "ruby", ".php": "php", ".sh": "bash",
    ".sql": "sql", ".html": "html", ".css": "css", ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
    ".dockerfile": "docker", ".ipynb": "jupyter", ".swift": "swift", ".dart": "flutter", ".lua": "lua",
}
FILE_TAGS = {
    "requirements.txt": "python", "pyproject.toml": "python", "package.json": "node", "Cargo.toml": "rust",
    "go.mod": "go", "Dockerfile": "docker", "docker-compose.yml": "docker", "Makefile": "make",
    "CMakeLists.txt": "cmake", ".git": "git", "pytest.ini": "pytest", "tsconfig.json": "typescript",
}


def detect_project_tags(project: Path, max_files: int = 400) -> list[str]:
    counts: dict[str, int] = {}
    try:
        for i, p in enumerate(project.rglob("*")):
            if i > max_files * 5:
                break
            if any(part in (".git", "node_modules", "__pycache__", ".venv", "venv") for part in p.parts):
                continue
            if p.name in FILE_TAGS:
                counts[FILE_TAGS[p.name]] = counts.get(FILE_TAGS[p.name], 0) + 5
            t = EXT_TAGS.get(p.suffix.lower())
            if t and p.is_file():
                counts[t] = counts.get(t, 0) + 1
    except OSError:
        pass
    return [t for t, _ in sorted(counts.items(), key=lambda x: -x[1])[:6]]

def _parse_json_array(text: str) -> list[dict]:
    """LLM 出力から JSON 配列を取り出す（前後の説明文やコードフェンスを許容）。"""
    import json, re
    text = text.strip()
    m = re.search(r"\[.*\]", text, re.S)
    if not m:
        return []
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return []
    return [d for d in data if isinstance(d, dict)] if isinstance(data, list) else []


# 常時許可の対象外にする「取り返しのつかない」コマンド（config の permissions.dangerous_commands で上書き可）
DEFAULT_DANGEROUS = [
    r"\brm\b", r"\brmdir\b", r"\bshred\b", r"\bunlink\b",
    r"\bgit\s+(reset\s+--hard|clean\b|checkout\s+--\s|restore\b|push\s+(-f|--force)|branch\s+-D|stash\s+drop)",
    r"\bsudo\b", r"\bsu\b", r"\bdd\b", r"\bmkfs", r"\bfdisk\b", r"\bparted\b",
    r"\bchmod\s+-R\b", r"\bchown\b", r"\bkill(all)?\b", r"\bpkill\b", r"\b(shutdown|reboot|poweroff)\b",
    r"\btruncate\b", r">\s*/dev/", r"\bdrop\s+(table|database)\b", r"\bpip3?\s+uninstall\b",
    r"\bapt(-get)?\s+(remove|purge|autoremove)\b", r"\bcurl\b[^|]*\|\s*(ba|z)?sh\b", r"\bwget\b[^|]*\|\s*(ba|z)?sh\b",
    r"\bmv\b.*\s/", r"\bcrontab\s+-r\b", r"\bsystemctl\s+(stop|disable|mask)\b",
]

Emit = Callable[[dict], Awaitable[None]]
AskApproval = Callable[[dict], Awaitable[str]]  # 戻り値: "allow" | "allow_always" | "deny"


@dataclass
class LoopState:
    """1 つのエージェントループ（親または子）の状態。"""
    messages: list[dict]
    system: str
    tool_names: list[str] | None          # None = 全ツール
    ctx: T.ToolContext
    model: str | None = None
    usage: dict = field(default_factory=lambda: {"prompt_tokens": 0, "completion_tokens": 0})
    last_prompt_tokens: int = 0
    on_save: Callable[[], None] | None = None
    compacted_len: int = -1               # 直近の圧縮直後のメッセージ数（連続圧縮の防止用）


class Agent:
    def __init__(self, cfg: Config, llm: LLMClient, store: SessionStore):
        self.cfg = cfg
        self.llm = llm
        self.store = store
        self.session_allow: dict[str, set[str]] = {}  # session_id -> 常時許可したツール名
        self._cancel: dict[str, asyncio.Event] = {}
        self.memory: MemoryStore | None = None
        self._bg_tasks: set[asyncio.Task] = set()
        if cfg.get("memory.enabled", True):
            from .config import expand
            self.memory = MemoryStore(expand(cfg.get("memory.db_path", "~/.apercode/memory.sqlite")),
                                      Embedder(llm.base_url, cfg.get("memory.embed_model")))
        T.load_builtin()

    def cancel(self, session_id: str):
        ev = self._cancel.get(session_id)
        if ev:
            ev.set()

    # ------------------------------------------------------------------ 権限
    # 「このセッションでは常に許可」でまとめて許可されるツール群（編集・実行系）
    EDIT_RUN_GROUP = {"write_file", "edit_file", "run_command", "mt5_compile", "mt5_backtest", "make_icon"}

    def _session_allowed(self, session: Session) -> set[str]:
        """セッションごとの常時許可（メモリ上 + セッション JSON に永続化）。"""
        s = self.session_allow.setdefault(session.id, set())
        s.update(getattr(session, "allow", []) or [])
        return s

    def _grant(self, session: Session, key: str):
        self._session_allowed(session).add(key)
        session.allow = sorted(self._session_allowed(session))
        self.store.save(session)

    def _dangerous(self, name: str, args: dict) -> str | None:
        """取り返しのつかない操作なら理由を返す（常時許可の対象外にする）。"""
        import re
        if name == "restore_backup":
            return "バックアップからの復元"
        if name != "run_command":
            return None
        cmd = str(args.get("command", ""))
        pats = self.cfg.get("permissions.dangerous_commands") or DEFAULT_DANGEROUS
        for pat in pats:
            try:
                if re.search(pat, cmd):
                    return f"危険なコマンド（{pat}）"
            except re.error:
                continue
        return None

    def _decide(self, session: Session, name: str, args: dict) -> str:
        mode = self.cfg.permission(name)
        if mode in ("allow", "deny"):
            return mode
        allowed = self._session_allowed(session)
        if name in allowed or (name in self.EDIT_RUN_GROUP and "edit_run" in allowed):
            return "allow"
        if name == "run_command":
            cmd = str(args.get("command", "")).strip()
            for pat in self.cfg.get("permissions.auto_allow_commands", []) or []:
                if cmd.startswith(pat):
                    return "allow"
        return "ask"

    # ------------------------------------------------------------------ 入口
    async def run(self, session: Session, user_text: str, emit: Emit, ask_approval: AskApproval,
                  attachments: list[dict] | None = None):
        cancel = asyncio.Event()
        self._cancel[session.id] = cancel
        project = Path(session.project_dir)
        backup = BackupManager(self.cfg, project)
        backup.begin_turn()
        ctx = T.ToolContext(self.cfg, project, depth=0, memory=self.memory, backup=backup)
        project_tags = detect_project_tags(project)
        memories_text = await self._recall(user_text, project, project_tags, emit)
        state = LoopState(messages=session.messages,
                          system=build_system_prompt(project, self.cfg.workspace_root, memories_text),
                          tool_names=None, ctx=ctx, usage=session.usage,
                          last_prompt_tokens=session.last_prompt_tokens,
                          on_save=lambda: self.store.save(session))

        start_len = len(session.messages)
        user_msg = {"role": "user", "content": user_text, "ts": time.time()}
        if attachments:
            user_msg.update(self._store_attachments(session, user_text, attachments))
        session.messages.append(user_msg)
        if session.title == "新しいセッション":
            session.title = user_text.strip().splitlines()[0][:40]
        self.store.save(session)
        try:
            await self._loop(state, session, emit, ask_approval, cancel,
                             max_iter=int(self.cfg.get("llm.max_iterations", 40)))
            if backup.saved:
                await emit({"type": "info", "text": f"変更前のファイル {len(backup.saved)} 件を {backup.dirname}/{backup._stamp}/ に退避しました"})
        finally:
            session.last_prompt_tokens = state.last_prompt_tokens
            self._cancel.pop(session.id, None)
            self.store.save(session)
            await emit({"type": "done", "usage": session.usage,
                        "context": self._context_info(state)})
        # 振り返り（教訓抽出）は応答完了後にバックグラウンドで行う。失敗しても会話には影響させない
        if not cancel.is_set():
            turn = list(session.messages[start_len:])
            task = asyncio.create_task(self._reflect_safe(turn, project, project_tags, emit))
            self._bg_tasks.add(task)
            task.add_done_callback(self._bg_tasks.discard)

    async def _reflect_safe(self, turn: list[dict], project: Path, tags: list[str], emit: Emit) -> None:
        try:
            await asyncio.wait_for(self._reflect(turn, project, tags, emit), timeout=float(self.cfg.get("memory.reflect_timeout", 180)))
        except asyncio.TimeoutError:
            await emit({"type": "info", "text": "教訓の抽出がタイムアウトしたためスキップしました"})
        except Exception as e:  # noqa: BLE001
            try:
                await emit({"type": "info", "text": f"教訓の抽出をスキップ: {e}"})
            except Exception:
                pass

    def _store_attachments(self, session: Session, user_text: str, attachments: list[dict]) -> dict:
        """添付を処理する。画像はセッション用フォルダにファイル保存し、テキストは本文に埋め込む。"""
        import base64
        files_dir = self.store.root / f"{session.id}_files"
        images: list[str] = []
        texts: list[str] = []
        content = user_text
        for i, a in enumerate(attachments[:10]):
            kind = a.get("kind")
            name = str(a.get("name") or f"attachment{i}")
            if kind == "image":
                data = str(a.get("data", ""))
                if "," in data:
                    header, b64 = data.split(",", 1)
                    ext = "png" if "png" in header else "jpg" if "jpe" in header else "webp" if "webp" in header else "gif" if "gif" in header else "png"
                else:
                    b64, ext = data, "png"
                try:
                    raw = base64.b64decode(b64)
                except Exception:
                    continue
                if len(raw) > 8 * 1024 * 1024:
                    continue
                files_dir.mkdir(parents=True, exist_ok=True)
                fname = f"{int(time.time()*1000)}_{i}.{ext}"
                (files_dir / fname).write_bytes(raw)
                images.append(fname)
            elif kind == "text":
                body = str(a.get("content", ""))[:60_000]
                texts.append(name)
                content += f"\n\n[添付テキスト: {name}]\n```\n{body}\n```"
        out: dict = {"content": content}
        if images:
            out["images"] = images  # ファイル名（セッション用フォルダ内）
        if texts:
            out["text_attachments"] = texts
        return out

    def _image_b64(self, session: Session, fname: str) -> str | None:
        import base64
        p = self.store.root / f"{session.id}_files" / fname
        if not p.is_file():
            return None
        return base64.b64encode(p.read_bytes()).decode()

    async def compact_now(self, session: Session, emit: Emit) -> None:
        """UI からの手動圧縮。"""
        project = Path(session.project_dir)
        ctx = T.ToolContext(self.cfg, project)
        state = LoopState(messages=session.messages, system="", tool_names=None, ctx=ctx,
                          usage=session.usage, on_save=lambda: self.store.save(session))
        await self._compact(state, session, emit, force=True)
        session.last_prompt_tokens = 0
        self.store.save(session)
        await emit({"type": "done", "usage": session.usage, "context": self._context_info(state)})

    # ------------------------------------------------------------------ ループ本体
    async def _loop(self, st: LoopState, session: Session, emit: Emit, ask_approval: AskApproval,
                    cancel: asyncio.Event, max_iter: int) -> str:
        """LLM とツールを往復する。最後のアシスタント発話を返す。

        行き詰まり検知: 同じツール呼び出しの繰り返し／連続エラーを検知したら、Web 検索など別アプローチを
        促すメッセージを履歴に差し込む。上限に達したら黙って止まらず、状況報告を生成させる。
        """
        import json as _json
        last_text = ""
        sig_count: dict[str, int] = {}      # 同一ツール呼び出しの回数
        consecutive_errors = 0
        nudges = 0
        searched_recently = False
        limit_hit = False
        for _ in range(max_iter):
            if cancel.is_set():
                await emit({"type": "info", "text": "中断しました"})
                break
            if st.ctx.depth == 0:
                await self._compact(st, session, emit)

            text_parts: list[str] = []
            tool_calls: list[dict] = []
            await emit({"type": "status", "phase": "thinking", "detail": st.model or self.llm.model})
            history = self._history(st.messages, session, with_images=st.ctx.depth == 0)
            try:
                try:
                    stream = self.llm.chat(st.system, history, T.schemas(st.tool_names), st.model)
                    first = await stream.__anext__()
                except StopAsyncIteration:
                    first = None
                except Exception as e:
                    # 画像非対応モデルの場合は画像を外して再試行
                    if any(m.get("images") for m in history) and any(w in str(e).lower() for w in ("image", "vision", "multimodal")):
                        await emit({"type": "info", "text": "このモデルは画像に対応していないため、画像を除いて送信します"})
                        history = self._history(st.messages, session, with_images=False)
                        stream = self.llm.chat(st.system, history, T.schemas(st.tool_names), st.model)
                        first = await stream.__anext__()
                    else:
                        raise

                async def _chain():
                    if first is not None:
                        yield first
                    async for ev in stream:
                        yield ev

                async for kind, data in _chain():
                    if cancel.is_set():
                        break
                    if kind == "text":
                        if not text_parts:
                            await emit({"type": "status", "phase": "generating", "detail": ""})
                        text_parts.append(data)
                        await emit({"type": "text", "delta": data})
                    elif kind == "tool_call":
                        tool_calls.append(data)
                    elif kind == "done":
                        st.usage["prompt_tokens"] += data.get("prompt_tokens", 0)
                        st.usage["completion_tokens"] += data.get("completion_tokens", 0)
                        st.last_prompt_tokens = data.get("prompt_tokens", 0) or st.last_prompt_tokens
            except Exception as e:  # LLM 通信エラー
                await emit({"type": "error", "text": f"LLM エラー: {e}"})
                break

            content = "".join(text_parts)
            last_text = content or last_text
            st.messages.append({"role": "assistant", "content": content, "tool_calls": tool_calls,
                                "ts": time.time()})
            if st.on_save:
                st.on_save()
            if not tool_calls:
                break

            repeated = False
            for tc in tool_calls:
                if cancel.is_set():
                    break
                sig = tc.get("name", "") + ":" + _json.dumps(tc.get("args", {}), sort_keys=True, ensure_ascii=False)[:500]
                sig_count[sig] = sig_count.get(sig, 0) + 1
                if sig_count[sig] >= 3:
                    repeated = True
                if tc.get("name") in ("web_search", "fetch_url", "search_memory"):
                    searched_recently = True
                result = await self._exec_tool(st, session, tc, emit, ask_approval, cancel)
                is_err = result.startswith(("エラー", "不明", "ユーザーがこの操作を拒否")) or "(exit " in result and "(exit 0)" not in result
                consecutive_errors = consecutive_errors + 1 if is_err else 0
                st.messages.append({"role": "tool", "tool_call_id": tc["id"], "name": tc["name"],
                                    "content": result, "ts": time.time()})
                if st.on_save:
                    st.on_save()

            # ---- 行き詰まり検知 → 別アプローチ（Web 検索）を促す
            stuck = repeated or (consecutive_errors >= 3 and not searched_recently)
            if stuck and nudges < 3:
                nudges += 1
                if repeated:
                    why = "同じツール呼び出しを 3 回以上繰り返しています"
                else:
                    why = f"ツールの失敗が {consecutive_errors} 回連続しています"
                nudge = (f"【システム】{why}。同じ操作をこれ以上繰り返さないでください。次の手順で別のアプローチを取ってください: "
                         "(1) 直近のエラー文を読み直して原因の仮説を立てる (2) search_memory で過去の解決策を確認 "
                         "(3) web_search でエラー文・ライブラリ名を検索し fetch_url で解決策を読む (4) 別の方法を試す。"
                         "それでも解決しない場合は、試したこと・分かったこと・残る選択肢を整理してユーザーに報告して終了してください。")
                st.messages.append({"role": "user", "kind": "nudge", "content": nudge, "ts": time.time()})
                await emit({"type": "info", "text": f"行き詰まりを検知（{why}）。Web 検索などの別アプローチを促しました"})
                sig_count.clear()
                consecutive_errors = 0
                searched_recently = False
        else:
            limit_hit = True

        # ---- 上限到達: 黙って止まらず、状況報告を生成させる
        if limit_hit and not cancel.is_set():
            await emit({"type": "info", "text": f"ツール呼び出し上限 ({max_iter}) に達しました。状況報告を生成します"})
            st.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content":
                "【システム】ツール呼び出しの上限に達したため、いったん作業を止めます。ツールは使わずに、"
                "ここまでに完了したこと・未完了のこと・発生している問題と原因の推測・次に試すべき手順を簡潔に報告してください。"
                "ユーザーが「続けて」と送れば作業を再開できます。"})
            await emit({"type": "status", "phase": "generating", "detail": "状況報告"})
            parts: list[str] = []
            try:
                async for kind, data in self.llm.chat(st.system, self._history(st.messages, session, with_images=False),
                                                      [], st.model):
                    if kind == "text":
                        parts.append(data)
                        await emit({"type": "text", "delta": data})
                    elif kind == "done":
                        st.usage["prompt_tokens"] += data.get("prompt_tokens", 0)
                        st.usage["completion_tokens"] += data.get("completion_tokens", 0)
            except Exception as e:
                await emit({"type": "error", "text": f"状況報告の生成に失敗: {e}"})
            report = "".join(parts).strip()
            if report:
                st.messages.append({"role": "assistant", "content": report, "tool_calls": [], "ts": time.time()})
                last_text = report
            if st.on_save:
                st.on_save()
            if st.ctx.depth == 0:
                await emit({"type": "info", "text": "「続けて」と送ると作業を再開します（上限は config.yaml の llm.max_iterations で変更可）"})
        return last_text

    async def _exec_tool(self, st: LoopState, session: Session, tc: dict, emit: Emit,
                         ask_approval: AskApproval, cancel: asyncio.Event) -> str:
        name, args = tc.get("name"), tc.get("args") or {}
        tool = T.get(name) if name else None
        allowed = st.tool_names is None or name in (st.tool_names or [])
        if not tool or not allowed:
            msg = f"不明または使用不可のツール: {name}"
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg
        summary = tool.summarize(args)
        await emit({"type": "tool_call", "id": tc["id"], "name": name, "args": args, "summary": summary})

        decision = self._decide(session, name, args)
        reason = ""
        always_key: str | None = "edit_run" if name in self.EDIT_RUN_GROUP else name
        # 作業ディレクトリの外に触れる操作は、ツールの権限設定に関わらずユーザーの許可を求める
        outside = self._outside_paths(st.ctx, name, args)
        if outside:
            mode = str(self.cfg.get("permissions.outside_project", "ask"))
            if mode == "deny":
                decision = "deny"
            elif mode == "ask" and "outside_project" not in self._session_allowed(session):
                decision = "ask"
                reason = "作業ディレクトリの外へのアクセス: " + ", ".join(outside[:3])
                always_key = "outside_project"
        # 取り返しのつかない操作は常時許可の対象外（毎回確認）
        danger = self._dangerous(name, args) if decision != "deny" else None
        if danger:
            decision = "ask"
            reason = (reason + " / " if reason else "") + danger
            always_key = None
        if decision == "ask":
            await emit({"type": "status", "phase": "approval", "detail": name})
            decision = await ask_approval({"id": tc["id"], "name": name, "args": args, "summary": summary,
                                           "reason": reason, "always": always_key is not None,
                                           "always_label": ("このセッションでは編集・実行を常に許可" if always_key == "edit_run"
                                                            else "このセッションでは常に許可")})
            if decision == "allow_always":
                if always_key:
                    self._grant(session, always_key)
                decision = "allow"
        if decision != "allow":
            msg = "ユーザーがこの操作を拒否しました。別の方法を検討するか、ユーザーに確認してください。"
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg

        # サブエージェントの実体を注入（子のイベントは parent id 付きで流す）
        if name == "spawn_agent":
            st.ctx.spawn = lambda a: self._spawn(st, session, a, tc["id"], emit, ask_approval, cancel)

        t0 = time.time()
        await emit({"type": "status", "phase": "tool", "detail": f"{name} {summary}"[:80]})
        try:
            out = await tool.handler(st.ctx, args)
            err = False
        except T.ToolError as e:
            out, err = f"エラー: {e}", True
        except Exception as e:
            out, err = f"エラー: {type(e).__name__}: {e}\n{traceback.format_exc()[-1500:]}", True
        await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": out, "error": err,
                    "elapsed": round(time.time() - t0, 2)})
        return out

    # ------------------------------------------------------------------ 作業ディレクトリ外の検出
    _ABS_PATH_RE = None

    def _outside_paths(self, ctx: T.ToolContext, name: str, args: dict) -> list[str]:
        """ツール引数が作業ディレクトリ（ctx.project_dir）の外を指していれば、そのパス一覧を返す。"""
        import re
        if self._ABS_PATH_RE is None:
            self._ABS_PATH_RE = re.compile(r"(?<![\w@:.~/])(~/[^\s'\"`;|&<>)]*|/[^\s'\"`;|&<>)]+)")
        project = ctx.project_dir.resolve()

        def is_outside(p: Path) -> bool:
            try:
                p = p.expanduser().resolve()
            except OSError:
                return False
            return p != project and project not in p.parents

        found: list[str] = []
        for key in ("path", "cwd", "image", "out"):
            v = args.get(key)
            if isinstance(v, str) and v.strip():
                p = Path(v).expanduser()
                if not p.is_absolute():
                    p = project / p
                if is_outside(p):
                    found.append(v)
        if name == "run_command":
            cmd = str(args.get("command", ""))
            for m in self._ABS_PATH_RE.finditer(cmd):
                cand = m.group(1)
                # /dev/null, /usr/bin/… など明らかにシステム側の読み取り専用パスは対象外
                if cand.startswith(("/dev/", "/usr/", "/bin/", "/etc/", "/proc/", "/sys/", "/opt/", "/lib", "/tmp/")):
                    continue
                if is_outside(Path(cand)):
                    found.append(cand)
            # cd による移動（相対でも親方向なら外）
            for m in re.finditer(r"(?:^|[;&|]\s*)cd\s+([^\s;&|]+)", cmd):
                target = m.group(1).strip("'\"")
                if target in ("-",):
                    found.append("cd -")
                    continue
                p = Path(target).expanduser()
                if not p.is_absolute():
                    p = project / p
                if is_outside(p):
                    found.append(f"cd {target}")
        # 重複除去（順序維持）
        seen, out = set(), []
        for f in found:
            if f not in seen:
                seen.add(f); out.append(f)
        return out

    # ------------------------------------------------------------------ サブエージェント
    async def _spawn(self, parent: LoopState, session: Session, a: dict, parent_id: str,
                     emit: Emit, ask_approval: AskApproval, cancel: asyncio.Event) -> str:
        if not self.cfg.get("subagents.enabled", True):
            raise T.ToolError("サブエージェントは無効化されています")
        max_depth = int(self.cfg.get("subagents.max_depth", 1))
        if parent.ctx.depth >= max_depth:
            raise T.ToolError(f"サブエージェントの深さ上限 ({max_depth}) に達しています。自分で作業してください")
        mode = a.get("mode", "code")
        tool_names = list(T.READ_ONLY_TOOLS if mode == "explore" else T.CODE_TOOLS)
        if parent.ctx.depth + 1 < max_depth:
            tool_names.append("spawn_agent")
        model = self.cfg.get(f"subagents.{mode}_model") or parent.model

        child_ctx = T.ToolContext(self.cfg, parent.ctx.project_dir, depth=parent.ctx.depth + 1, memory=self.memory,
                                  backup=parent.ctx.backup)
        system = build_system_prompt(parent.ctx.project_dir, self.cfg.workspace_root) + SUBAGENT_PROMPT.format(mode=mode)
        task = a["task"] + (f"\n\n## 補足情報\n{a['context']}" if a.get("context") else "")
        child = LoopState(messages=[{"role": "user", "content": task}], system=system,
                          tool_names=tool_names, ctx=child_ctx, model=model, usage=parent.usage)

        async def child_emit(ev: dict):
            await emit({"type": "sub", "parent": parent_id, "event": ev})

        await emit({"type": "subagent_start", "id": parent_id, "mode": mode, "task": a["task"]})
        result = await self._loop(child, session, child_emit, ask_approval, cancel,
                                  max_iter=int(self.cfg.get("subagents.max_iterations", 30)))
        if not result.strip():
            # 最終報告が無い場合は最後のツール結果を返す
            tails = [m["content"] for m in child.messages if m["role"] == "tool"]
            result = "(子エージェントは最終報告を返しませんでした)\n最後のツール結果:\n" + (tails[-1][:3000] if tails else "なし")
        n_tools = sum(1 for m in child.messages if m["role"] == "tool")
        return f"[子エージェント ({mode}) 完了: ツール呼び出し {n_tools} 回]\n{result}"

    # ------------------------------------------------------------------ 経験メモリ
    async def _recall(self, user_text: str, project: Path, tags: list[str], emit: Emit) -> str:
        """ユーザー入力に関連する経験を検索し、プロンプト注入用テキストを返す。"""
        if not self.memory or self.memory.count() == 0:
            return ""
        if len(user_text.strip()) < 8:  # 「はい」「OK」などの短い相づちには注入しない
            return ""
        try:
            hits = await self.memory.search(user_text, limit=int(self.cfg.get("memory.inject_top_k", 3)),
                                            tags=tags, project=str(project),
                                            min_score=float(self.cfg.get("memory.inject_min_score", 0.4)))
        except Exception as e:
            await emit({"type": "info", "text": f"経験メモリの検索に失敗: {e}"})
            return ""
        if not hits:
            return ""
        self.memory.touch([m.id for m in hits])
        await emit({"type": "memories_used", "items": [m.to_dict() for m in hits]})
        return "\n".join(f"- {m.to_prompt()}" for m in hits)

    async def _reflect(self, turn_messages: list[dict], project: Path, tags: list[str], emit: Emit) -> None:
        """今回のターンから教訓を抽出して保存する（memory.reflect: auto のとき）。"""
        if not self.memory or self.cfg.get("memory.reflect", "auto") != "auto":
            return
        n_tools = sum(1 for m in turn_messages if m["role"] == "tool")
        if n_tools < int(self.cfg.get("memory.reflect_min_tools", 3)):
            return
        await emit({"type": "status", "phase": "reflecting", "detail": "バックグラウンド"})
        try:
            # 長すぎる記録は末尾（最新）側を優先して 24k 文字に抑える（Ollama のメモリ負荷を抑えるため）
            raw = await self.llm.complete(REFLECT_PROMPT, self._transcript(turn_messages)[-24_000:])
            items = _parse_json_array(raw)
        except Exception as e:
            await emit({"type": "info", "text": f"教訓の抽出に失敗: {e}"})
            return
        saved = []
        for it in items[:5]:
            lesson = str(it.get("lesson", "")).strip()
            if not lesson:
                continue
            outcome = it.get("outcome", "info")
            outcome = outcome if outcome in ("success", "failure", "info") else "info"
            item_tags = [str(t) for t in (it.get("tags") or [])] or tags[:2]
            m, dup = await self.memory.add(lesson=lesson, situation=str(it.get("situation", ""))[:300],
                                           action=str(it.get("action", ""))[:300], outcome=outcome,
                                           tags=item_tags, project=str(project), source="auto",
                                           dedup_threshold=float(self.cfg.get("memory.dedup_threshold", 0.92)))
            if m:
                saved.append(m.to_dict())
        if saved:
            await emit({"type": "memories_saved", "items": saved})
        await emit({"type": "status", "phase": None})

    # ------------------------------------------------------------------ 圧縮
    def _estimate_tokens(self, messages: list[dict]) -> int:
        cpt = float(self.cfg.get("compaction.chars_per_token", 2.5))
        n = 0
        for m in messages:
            n += len(m.get("content") or "")
            for tc in m.get("tool_calls") or []:
                n += len(str(tc.get("args", "")))
        return int(n / cpt)

    def _context_info(self, st: LoopState) -> dict:
        est = max(self._estimate_tokens(st.messages), st.last_prompt_tokens)
        return {"estimated_tokens": est, "num_ctx": self.llm.num_ctx, "messages": len(st.messages)}

    async def _compact(self, st: LoopState, session: Session, emit: Emit, force: bool = False) -> None:
        if not force and not self.cfg.get("compaction.enabled", True):
            return
        threshold = int(self.llm.num_ctx * float(self.cfg.get("compaction.threshold", 0.7)))
        est = max(self._estimate_tokens(st.messages), st.last_prompt_tokens)
        if not force and est < threshold:
            return
        keep = int(self.cfg.get("compaction.keep_recent", 8))
        msgs = st.messages
        if len(msgs) <= keep + 2 or (not force and st.compacted_len >= 0 and len(msgs) - st.compacted_len < 4):
            if force:
                await emit({"type": "info", "text": "履歴が短いため要約は不要です"})
            return
        # 切れ目: assistant(tool_calls) と tool の対を分断しない位置（user か、tool 直後の assistant）
        cut = len(msgs) - keep
        while cut > 1 and not (msgs[cut]["role"] == "user" or
                               (msgs[cut]["role"] == "assistant" and msgs[cut - 1]["role"] != "assistant")):
            cut -= 1
        old, recent = msgs[:cut], msgs[cut:]
        if not old:
            return

        await emit({"type": "info", "text": f"コンテキスト圧縮中… (推定 {est:,} / {self.llm.num_ctx:,} tokens, {len(old)} 件を要約)"})
        transcript = self._transcript(old)
        await emit({"type": "status", "phase": "compacting", "detail": ""})
        try:
            summary = await self.llm.complete(SUMMARY_PROMPT, transcript)
        except Exception as e:
            await emit({"type": "error", "text": f"要約に失敗しました: {e}"})
            return
        summary = summary.strip() or "(要約なし)"
        # 以前の要約があれば統合済みなので置換、無ければ先頭に挿入
        summary_msg = {"role": "user", "kind": "summary", "ts": time.time(),
                       "content": "【これまでの作業の要約（自動圧縮）】\n" + summary}
        ack = {"role": "assistant", "content": "要約を確認しました。この内容を踏まえて作業を続けます。", "tool_calls": [], "ts": time.time()}
        session.archive.append({"ts": time.time(), "messages": [m for m in old if m.get("kind") != "summary"]})
        msgs[:] = [summary_msg, ack] + recent
        st.last_prompt_tokens = 0
        st.compacted_len = len(msgs)
        if st.on_save:
            st.on_save()
        await emit({"type": "compacted", "summary": summary, "removed": len(old), "kept": len(recent)})

    @staticmethod
    def _transcript(messages: list[dict]) -> str:
        lines = []
        for m in messages:
            r = m["role"]
            if r == "user":
                lines.append(f"[USER]\n{m['content']}")
            elif r == "assistant":
                if m.get("content"):
                    lines.append(f"[ASSISTANT]\n{m['content']}")
                for tc in m.get("tool_calls") or []:
                    args = str(tc.get("args", ""))
                    lines.append(f"[TOOL CALL] {tc['name']} {args[:400]}")
            elif r == "tool":
                lines.append(f"[TOOL RESULT {m.get('name')}]\n{(m['content'] or '')[:1200]}")
        text = "\n\n".join(lines)
        return text[-80_000:]

    # ---------------------------------------------------------------- 履歴
    def _history(self, messages: list[dict], session: Session | None = None, with_images: bool = True) -> list[dict]:
        """LLM に渡す履歴。古いツール結果は短縮し、画像は直近 2 件のユーザー発話分だけ base64 で添付する。"""
        msgs = [{k: v for k, v in m.items() if k not in ("ts", "kind", "text_attachments")} for m in messages]
        tool_idx = [i for i, m in enumerate(msgs) if m["role"] == "tool"]
        for i in tool_idx[:-6]:
            c = msgs[i]["content"]
            if len(c) > 1500:
                msgs[i]["content"] = c[:1500] + "\n...(省略)"
        img_idx = [i for i, m in enumerate(msgs) if m["role"] == "user" and m.get("images")]
        for n, i in enumerate(reversed(img_idx)):
            names = msgs[i].pop("images")
            b64s = [b for b in (self._image_b64(session, f) for f in names)] if (session and with_images and n < 2) else []
            b64s = [b for b in b64s if b]
            if b64s:
                msgs[i]["images"] = b64s
            else:
                msgs[i]["content"] = f"[画像 {len(names)} 枚を添付]\n" + msgs[i]["content"]
        return msgs
