"""Web 検索・ページ取得ツール: web_search / fetch_url

- web_search: DuckDuckGo（HTML 版、API キー不要）または SearXNG（config の web.searxng_url）
- fetch_url : URL の本文をテキスト化して返す（HTML はタグを除去し、本文らしい部分を抽出）
どちらも読み取り専用。config の web.enabled で無効化できる。
"""
from __future__ import annotations

import html
import re
from html.parser import HTMLParser
from urllib.parse import parse_qs, quote_plus, urlparse

import httpx

from . import Tool, ToolContext, ToolError, register

UA = "Mozilla/5.0 (X11; Linux x86_64) AperCode/1.0 (+local coding agent)"


def _cfg(ctx: ToolContext, key: str, default):
    return ctx.cfg.get(f"web.{key}", default)


# ------------------------------------------------------------------ 検索
async def _search_duckduckgo(query: str, n: int, timeout: float) -> list[dict]:
    url = "https://html.duckduckgo.com/html/"
    async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA}, follow_redirects=True) as c:
        r = await c.post(url, data={"q": query, "kl": "jp-jp"})
        r.raise_for_status()
    text = r.text
    results = []
    # 結果ブロック: <a class="result__a" href="...">title</a> ... <a class="result__snippet" ...>snippet</a>
    for m in re.finditer(r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=<a[^>]*class="result__a"|$)',
                         text, re.S):
        href, title_html, rest = m.group(1), m.group(2), m.group(3)
        # リダイレクト形式 //duckduckgo.com/l/?uddg=<url>
        if "uddg=" in href:
            q = parse_qs(urlparse(href).query)
            href = q.get("uddg", [href])[0]
        sn = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', rest, re.S)
        snippet = _strip(sn.group(1)) if sn else ""
        results.append({"title": _strip(title_html), "url": href, "snippet": snippet})
        if len(results) >= n:
            break
    return results


async def _search_duckduckgo_lite(query: str, n: int, timeout: float) -> list[dict]:
    """html 版がブロックされた場合の代替（lite 版）。"""
    async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA}, follow_redirects=True) as c:
        r = await c.post("https://lite.duckduckgo.com/lite/", data={"q": query, "kl": "jp-jp"})
        r.raise_for_status()
    text = r.text
    results = []
    links = re.findall(r'<a[^>]*class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', text, re.S)
    snippets = re.findall(r'<td[^>]*class="result-snippet"[^>]*>(.*?)</td>', text, re.S)
    for i, (href, title) in enumerate(links[:n]):
        if "uddg=" in href:
            href = parse_qs(urlparse(href).query).get("uddg", [href])[0]
        results.append({"title": _strip(title), "url": href,
                        "snippet": _strip(snippets[i]) if i < len(snippets) else ""})
    return results


async def _search_ddgs_package(query: str, n: int) -> list[dict] | None:
    """ddgs パッケージが入っていればそれを使う（任意依存）。"""
    try:
        from ddgs import DDGS  # type: ignore
    except ImportError:
        try:
            from duckduckgo_search import DDGS  # type: ignore
        except ImportError:
            return None
    import asyncio
    def run():
        with DDGS() as d:
            return [{"title": r.get("title", ""), "url": r.get("href", ""), "snippet": r.get("body", "")}
                    for r in d.text(query, max_results=n)]
    return await asyncio.get_event_loop().run_in_executor(None, run)


async def _search_searxng(base: str, query: str, n: int, timeout: float) -> list[dict]:
    async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA}) as c:
        r = await c.get(base.rstrip("/") + "/search", params={"q": query, "format": "json", "language": "ja"})
        r.raise_for_status()
    out = []
    for it in r.json().get("results", [])[:n]:
        out.append({"title": it.get("title", ""), "url": it.get("url", ""), "snippet": it.get("content", "")})
    return out


async def web_search(ctx: ToolContext, a: dict) -> str:
    if not _cfg(ctx, "enabled", True):
        raise ToolError("Web 検索は無効です (config.yaml web.enabled)")
    query = (a.get("query") or "").strip()
    if not query:
        raise ToolError("query は必須です")
    n = int(a.get("max_results") or _cfg(ctx, "max_results", 5))
    timeout = float(_cfg(ctx, "timeout", 20))
    provider = str(_cfg(ctx, "provider", "duckduckgo")).lower()
    searx = _cfg(ctx, "searxng_url", "")
    results: list[dict] = []
    errors: list[str] = []
    if provider == "searxng" and searx:
        try:
            results = await _search_searxng(searx, query, n, timeout)
        except httpx.HTTPError as e:
            errors.append(f"searxng: {e}")
    else:
        for fn in (lambda: _search_duckduckgo(query, n, timeout),
                   lambda: _search_duckduckgo_lite(query, n, timeout),
                   lambda: _search_ddgs_package(query, n)):
            try:
                res = await fn()
                if res:
                    results = res
                    break
            except httpx.HTTPError as e:
                errors.append(str(e))
            except Exception as e:  # noqa: BLE001
                errors.append(str(e))
    if not results and errors:
        raise ToolError("検索に失敗しました: " + " / ".join(errors[-2:]) +
                        "（ネットワーク、または検索サイト側のブロック。config.yaml の web.provider を searxng にする、"
                        "pip install ddgs を試す、などの代替あり）")
    if not results:
        return "検索結果がありません。別のキーワード（英語、エラーメッセージの一部、ライブラリ名など）で試してください"
    lines = [f"検索: {query}"]
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r['title']}\n   {r['url']}\n   {r['snippet'][:300]}")
    lines.append("詳細を読むには fetch_url を使ってください")
    return "\n".join(lines)


# ------------------------------------------------------------------ 取得
class _TextExtractor(HTMLParser):
    """script/style/nav 等を除き、本文テキストを抽出する簡易パーサ。"""
    SKIP = {"script", "style", "noscript", "svg", "header", "footer", "nav", "aside", "form", "iframe"}
    BLOCK = {"p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "pre", "br", "tr", "section", "article",
             "blockquote", "td", "th", "dd", "dt"}

    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self._skip = 0
        self._pre = 0
        self.title = ""
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self._skip += 1
        if tag == "pre":
            self._pre += 1
        if tag == "title":
            self._in_title = True
        if tag in self.BLOCK:
            self.parts.append("\n")
        if tag == "code" and not self._pre:
            self.parts.append("`")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip:
            self._skip -= 1
        if tag == "pre" and self._pre:
            self._pre -= 1
            self.parts.append("\n")
        if tag == "title":
            self._in_title = False
        if tag in self.BLOCK:
            self.parts.append("\n")
        if tag == "code" and not self._pre:
            self.parts.append("`")

    def handle_data(self, data):
        if self._in_title:
            self.title += data
            return
        if self._skip:
            return
        self.parts.append(data if self._pre else re.sub(r"[ \t]+", " ", data))

    def text(self) -> str:
        t = "".join(self.parts)
        t = re.sub(r"\n[ \t]+", "\n", t)
        t = re.sub(r"\n{3,}", "\n\n", t)
        return t.strip()


def _strip(s: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", s)).strip()


async def fetch_url(ctx: ToolContext, a: dict) -> str:
    if not _cfg(ctx, "enabled", True):
        raise ToolError("Web アクセスは無効です (config.yaml web.enabled)")
    url = (a.get("url") or "").strip()
    if not re.match(r"^https?://", url):
        raise ToolError("http(s):// で始まる URL を指定してください")
    max_chars = int(a.get("max_chars") or _cfg(ctx, "fetch_max_chars", 12000))
    timeout = float(_cfg(ctx, "timeout", 20))
    try:
        async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA, "Accept-Language": "ja,en"},
                                     follow_redirects=True) as c:
            r = await c.get(url)
            r.raise_for_status()
    except httpx.HTTPError as e:
        raise ToolError(f"取得に失敗しました: {e}")
    ctype = r.headers.get("content-type", "")
    body = r.text
    if "html" in ctype or body.lstrip()[:15].lower().startswith(("<!doctype", "<html")):
        p = _TextExtractor()
        try:
            p.feed(body)
        except Exception:
            pass
        text = p.text()
        title = p.title.strip()
    else:
        text, title = body, ""
    head = f"URL: {str(r.url)}\n" + (f"タイトル: {title}\n" if title else "")
    if len(text) > max_chars:
        text = text[:max_chars] + f"\n... (省略: 全 {len(text)} 文字。必要なら max_chars を増やす)"
    return head + "\n" + text


register(Tool(
    "web_search",
    "Web を検索する（DuckDuckGo）。エラーメッセージの意味、ライブラリの使い方、設定方法など、"
    "手元の情報だけでは解決できないときに使う。エラー文をそのまま検索すると当たりやすい。",
    {"type": "object", "properties": {
        "query": {"type": "string", "description": "検索語（英語の方が結果が多い。エラー文はそのまま）"},
        "max_results": {"type": "integer", "description": "既定 5"}},
     "required": ["query"]},
    web_search, lambda a: a.get("query", "")[:80]))

register(Tool(
    "fetch_url",
    "URL のページ本文をテキストで取得する。web_search の結果を詳しく読むとき、公式ドキュメントや"
    "GitHub の Issue / README を確認するときに使う。",
    {"type": "object", "properties": {
        "url": {"type": "string"},
        "max_chars": {"type": "integer", "description": "既定 12000"}},
     "required": ["url"]},
    fetch_url, lambda a: a.get("url", "")[:80]))
