"""シェルコマンド実行ツール"""
from __future__ import annotations

import asyncio
import os

from . import Tool, ToolContext, ToolError, register

MAX_OUT = 30_000


async def run_shell(cmd: str, cwd: str, timeout: int = 120, env: dict | None = None) -> tuple[int, str]:
    proc = await asyncio.create_subprocess_shell(
        cmd, cwd=cwd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        env={**os.environ, **(env or {})})
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        return -1, f"(タイムアウト {timeout}s)"
    text = out.decode("utf-8", errors="replace")
    if len(text) > MAX_OUT:
        text = text[:MAX_OUT // 2] + "\n... (中略) ...\n" + text[-MAX_OUT // 2:]
    return proc.returncode or 0, text


async def run_command(ctx: ToolContext, a: dict) -> str:
    cmd = a["command"]
    cwd = ctx.resolve(a.get("cwd", ".")) if a.get("cwd") else ctx.project_dir
    if not cwd.is_dir():
        raise ToolError(f"cwd がありません: {cwd}")
    timeout = int(a.get("timeout", 120))
    code, out = await run_shell(cmd, str(cwd), timeout)
    return f"$ {cmd}\n(exit {code})\n{out}"


register(Tool("run_command",
              "シェルコマンドを実行する（bash）。ビルド・テスト・git 操作などに使う。長時間かかるものは timeout を指定。",
              {"type": "object", "properties": {
                  "command": {"type": "string"},
                  "cwd": {"type": "string", "description": "作業ディレクトリ（省略時はプロジェクト）"},
                  "timeout": {"type": "integer", "description": "秒（既定 120）"}},
               "required": ["command"]}, run_command, lambda a: a.get("command", "")))
