"""make_icon: アプリアイコンを生成する（Pillow）。ツールとしても CLI としても使える。

生成物: PNG（16/32/48/64/128/256/512）、.ico（Windows）、SVG（ベクタ）
デザイン: 角丸の背景 + 文字（頭文字など）/ 図形（circle, ring, chevron, bolt）/ 既存画像の埋め込み

CLI:  python3 -m codeagent.tools.icon --text AC --bg "#171a21" --fg "#5b8cff" --out assets/icon
"""
from __future__ import annotations

import argparse
from pathlib import Path

from . import Tool, ToolContext, ToolError, register

SIZES = (16, 32, 48, 64, 128, 256, 512)


def _hex(c: str) -> tuple[int, int, int, int]:
    c = c.lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    if len(c) == 6:
        c += "ff"
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4, 6))  # type: ignore[return-value]


def _font(size: int):
    from PIL import ImageFont
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "C:/Windows/Fonts/arialbd.ttf", "/System/Library/Fonts/Helvetica.ttc",
    ]
    for c in candidates:
        if Path(c).exists():
            try:
                return ImageFont.truetype(c, size)
            except OSError:
                continue
    return ImageFont.load_default()


def render(size: int, text: str = "", shape: str = "", bg: str = "#171a21", fg: str = "#5b8cff",
           accent: str = "#3fb950", border: str | None = None, radius: float = 0.2, image: str | None = None):
    """1 サイズ分の RGBA 画像を返す。"""
    from PIL import Image, ImageDraw
    S = size
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pad = max(1, S // 32)
    r = int(S * radius)
    d.rounded_rectangle((pad, pad, S - pad - 1, S - pad - 1), radius=r, fill=_hex(bg))
    if border:
        d.rounded_rectangle((pad, pad, S - pad - 1, S - pad - 1), radius=r, outline=_hex(border), width=max(1, S // 40))
    if image:
        src = Image.open(image).convert("RGBA")
        inner = int(S * 0.7)
        src.thumbnail((inner, inner))
        img.alpha_composite(src, ((S - src.width) // 2, (S - src.height) // 2))
    c = _hex(fg)
    if shape == "circle":
        m = int(S * 0.25)
        d.ellipse((m, m, S - m, S - m), fill=c)
    elif shape == "ring":
        m = int(S * 0.22)
        d.ellipse((m, m, S - m, S - m), outline=c, width=max(2, S // 9))
    elif shape == "chevron":
        w = max(2, S // 11)
        d.line([(S * 0.28, S * 0.33), (S * 0.46, S * 0.5), (S * 0.28, S * 0.67)], fill=c, width=w, joint="curve")
        d.rounded_rectangle((S * 0.52, S * 0.6, S * 0.76, S * 0.68), radius=max(1, S // 40), fill=(230, 232, 238, 255))
        d.ellipse((S * 0.68, S * 0.27, S * 0.8, S * 0.39), fill=_hex(accent))
    elif shape == "bolt":
        pts = [(S * 0.55, S * 0.18), (S * 0.32, S * 0.55), (S * 0.48, S * 0.55), (S * 0.42, S * 0.82),
               (S * 0.68, S * 0.43), (S * 0.52, S * 0.43)]
        d.polygon(pts, fill=c)
    if text:
        fsize = int(S * (0.52 if len(text) <= 2 else 0.36 if len(text) <= 4 else 0.26))
        font = _font(fsize)
        bbox = d.textbbox((0, 0), text, font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        d.text(((S - tw) / 2 - bbox[0], (S - th) / 2 - bbox[1]), text, font=font, fill=c)
    return img


def svg(text: str = "", shape: str = "", bg: str = "#171a21", fg: str = "#5b8cff", accent: str = "#3fb950",
        border: str | None = None, radius: float = 0.2) -> str:
    S = 256
    r = int(S * radius)
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{S}" height="{S}" viewBox="0 0 {S} {S}">',
             f'<rect x="4" y="4" width="{S-8}" height="{S-8}" rx="{r}" fill="{bg}"' +
             (f' stroke="{border}" stroke-width="6"' if border else "") + "/>"]
    if shape == "circle":
        parts.append(f'<circle cx="{S/2}" cy="{S/2}" r="{S*0.25}" fill="{fg}"/>')
    elif shape == "ring":
        parts.append(f'<circle cx="{S/2}" cy="{S/2}" r="{S*0.28}" fill="none" stroke="{fg}" stroke-width="{S//9}"/>')
    elif shape == "chevron":
        parts.append(f'<polyline points="{S*0.28},{S*0.33} {S*0.46},{S*0.5} {S*0.28},{S*0.67}" fill="none" stroke="{fg}" '
                     f'stroke-width="{S//11}" stroke-linecap="round" stroke-linejoin="round"/>'
                     f'<rect x="{S*0.52}" y="{S*0.6}" width="{S*0.24}" height="{S*0.08}" rx="6" fill="#e6e8ee"/>'
                     f'<circle cx="{S*0.74}" cy="{S*0.33}" r="{S*0.06}" fill="{accent}"/>')
    elif shape == "bolt":
        pts = " ".join(f"{x},{y}" for x, y in [(S*0.55, S*0.18), (S*0.32, S*0.55), (S*0.48, S*0.55), (S*0.42, S*0.82),
                                                (S*0.68, S*0.43), (S*0.52, S*0.43)])
        parts.append(f'<polygon points="{pts}" fill="{fg}"/>')
    if text:
        fs = int(S * (0.52 if len(text) <= 2 else 0.36 if len(text) <= 4 else 0.26))
        parts.append(f'<text x="50%" y="50%" dominant-baseline="central" text-anchor="middle" '
                     f'font-family="DejaVu Sans, Arial, sans-serif" font-weight="bold" font-size="{fs}" fill="{fg}">{text}</text>')
    parts.append("</svg>")
    return "\n".join(parts)


def make_icon_set(out_base: Path, **kw) -> list[Path]:
    """out_base（拡張子なし）を元に PNG 各サイズ・.ico・.svg を生成し、生成ファイル一覧を返す。"""
    try:
        from PIL import Image  # noqa: F401
    except ImportError:
        raise RuntimeError("Pillow が必要です: pip install pillow")
    out_base.parent.mkdir(parents=True, exist_ok=True)
    files: list[Path] = []
    imgs = {s: render(s, **kw) for s in SIZES}
    for s, img in imgs.items():
        p = out_base.with_name(f"{out_base.name}-{s}.png")
        img.save(p)
        files.append(p)
    main = out_base.with_suffix(".png")
    imgs[256].save(main)
    files.append(main)
    ico = out_base.with_suffix(".ico")
    imgs[256].save(ico, format="ICO", sizes=[(s, s) for s in (16, 32, 48, 64, 128, 256)])
    files.append(ico)
    svg_kw = {k: v for k, v in kw.items() if k != "image"}
    svg_p = out_base.with_suffix(".svg")
    svg_p.write_text(svg(**svg_kw), encoding="utf-8")
    files.append(svg_p)
    return files


async def make_icon(ctx: ToolContext, a: dict) -> str:
    out = ctx.resolve(a.get("out") or "assets/icon")
    image = ctx.resolve(a["image"]) if a.get("image") else None
    if image and not image.is_file():
        raise ToolError(f"画像がありません: {image}")
    try:
        files = make_icon_set(out, text=a.get("text", ""), shape=a.get("shape", ""), bg=a.get("bg", "#171a21"),
                              fg=a.get("fg", "#5b8cff"), accent=a.get("accent", "#3fb950"), border=a.get("border"),
                              radius=float(a.get("radius", 0.2)), image=str(image) if image else None)
    except RuntimeError as e:
        raise ToolError(str(e))
    return "生成しました:\n" + "\n".join(str(f.relative_to(ctx.project_dir)) if ctx.project_dir in f.parents else str(f) for f in files)


register(Tool(
    "make_icon",
    "アプリのアイコン画像一式（PNG 16〜512px, .ico, .svg）を生成する。頭文字などの文字、図形（circle/ring/chevron/bolt）、"
    "既存画像の埋め込み、背景色・前景色・角丸を指定できる。",
    {"type": "object", "properties": {
        "out": {"type": "string", "description": "出力ベース名（拡張子なし）。既定 assets/icon"},
        "text": {"type": "string", "description": "中央に描く文字（1〜4 文字推奨）"},
        "shape": {"type": "string", "enum": ["", "circle", "ring", "chevron", "bolt"]},
        "image": {"type": "string", "description": "中央に埋め込む既存画像のパス（任意）"},
        "bg": {"type": "string", "description": "背景色 例 #171a21"},
        "fg": {"type": "string", "description": "前景色 例 #5b8cff"},
        "accent": {"type": "string"}, "border": {"type": "string", "description": "枠線色（任意）"},
        "radius": {"type": "number", "description": "角丸の割合 0〜0.5。既定 0.2"}},
     }, make_icon, lambda a: f"{a.get('out','assets/icon')} text={a.get('text','')} shape={a.get('shape','')}"))


def main():
    ap = argparse.ArgumentParser(description="アプリアイコン生成")
    ap.add_argument("--out", default="assets/icon", help="出力ベース名（拡張子なし）")
    ap.add_argument("--text", default="")
    ap.add_argument("--shape", default="", choices=["", "circle", "ring", "chevron", "bolt"])
    ap.add_argument("--image", default=None)
    ap.add_argument("--bg", default="#171a21")
    ap.add_argument("--fg", default="#5b8cff")
    ap.add_argument("--accent", default="#3fb950")
    ap.add_argument("--border", default=None)
    ap.add_argument("--radius", type=float, default=0.2)
    a = ap.parse_args()
    files = make_icon_set(Path(a.out), text=a.text, shape=a.shape, bg=a.bg, fg=a.fg, accent=a.accent,
                          border=a.border, radius=a.radius, image=a.image)
    print("\n".join(str(f) for f in files))


if __name__ == "__main__":
    main()
