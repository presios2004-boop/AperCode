"""spawn_agent: サブタスクを独立したコンテキストの子エージェントに委譲する。

実体（子エージェントのループ）は agent.py 側にあり、ToolContext.spawn として注入される。
ここではツール定義と入口だけを持つ。
"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register


async def spawn_agent(ctx: ToolContext, a: dict) -> str:
    if ctx.spawn is None:
        raise ToolError("この環境ではサブエージェントを使えません")
    mode = a.get("mode", "code")
    if mode not in ("explore", "code"):
        raise ToolError("mode は explore または code を指定してください")
    if not a.get("task"):
        raise ToolError("task は必須です")
    return await ctx.spawn(a)


register(Tool(
    "spawn_agent",
    "サブタスクを子エージェントに委譲する。子は独立したコンテキストで動き、最後に結果を報告する。"
    "大きな作業を分割するとき、広範囲の調査をするとき、親のコンテキストを節約したいときに使う。"
    "mode=explore は読み取り専用（調査・設計の下調べ）、mode=code はファイル編集・コマンド実行が可能。"
    "task には目的・対象ファイル・完了条件・報告してほしい内容を具体的に書く。子は親の会話を見られない。",
    {"type": "object", "properties": {
        "task": {"type": "string", "description": "子エージェントへの指示（自己完結した具体的な内容）"},
        "mode": {"type": "string", "enum": ["explore", "code"], "description": "explore=読み取り専用, code=編集可"},
        "context": {"type": "string", "description": "子に渡す補足情報（設計方針・既知の制約など、任意）"}},
     "required": ["task"]},
    spawn_agent,
    lambda a: f"[{a.get('mode','code')}] {str(a.get('task',''))[:80]}"))
