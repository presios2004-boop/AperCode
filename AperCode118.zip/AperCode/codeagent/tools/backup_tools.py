"""list_backups / restore_backup: 変更前バックアップの一覧と復元。"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register


async def list_backups(ctx: ToolContext, a: dict) -> str:
    if not ctx.backup:
        raise ToolError("バックアップは無効です (config.yaml backup.enabled)")
    gens = ctx.backup.list()[: int(a.get("limit", 20))]
    if not gens:
        return "バックアップはありません"
    lines = [f"バックアップ先: {ctx.backup.root}"]
    for g in gens:
        lines.append(f"- {g['stamp']}: {len(g['files'])} ファイル  " + ", ".join(g["files"][:8]) + (" ..." if len(g["files"]) > 8 else ""))
    return "\n".join(lines)


async def restore_backup(ctx: ToolContext, a: dict) -> str:
    if not ctx.backup:
        raise ToolError("バックアップは無効です")
    stamp = str(a.get("stamp") or "").strip()
    if not stamp:
        gens = ctx.backup.list()
        if not gens:
            raise ToolError("バックアップはありません")
        stamp = gens[0]["stamp"]
    try:
        restored = ctx.backup.restore(stamp, a.get("files") or None)
    except FileNotFoundError as e:
        raise ToolError(str(e))
    if not restored:
        return f"{stamp}: 復元対象がありません"
    return f"{stamp} から {len(restored)} ファイルを復元しました（復元前の状態も新しい世代に退避済み）:\n" + "\n".join(restored)


register(Tool("list_backups",
              "変更前ファイルのバックアップ世代（backup/<日時>/）を一覧する。変更を元に戻したいときにまず確認する。",
              {"type": "object", "properties": {"limit": {"type": "integer"}}}, list_backups, lambda a: ""))

register(Tool("restore_backup",
              "バックアップ世代からファイルをプロジェクトへ書き戻す。stamp 省略時は最新世代。files で対象を絞れる。"
              "復元前の現在の状態も自動で退避されるので安全にやり直せる。",
              {"type": "object", "properties": {
                  "stamp": {"type": "string", "description": "世代名（例: 20260920-153000）。省略で最新"},
                  "files": {"type": "array", "items": {"type": "string"}, "description": "復元するファイル（プロジェクト相対）。省略で全部"}},
               }, restore_backup, lambda a: a.get("stamp", "最新")))
