"""VRAM の空き容量からコンテキストサイズ（num_ctx）を自動で決める。

考え方:
  KV キャッシュのサイズ ≈ 2 (K,V) × 層数 × KV ヘッド数 × ヘッド次元 × 2 byte (f16) × トークン数
  使えるメモリ = 空き VRAM（モデルがロード済みならその分を戻す） − モデル本体 − 予備
  num_ctx = 使えるメモリ ÷ 1 トークンあたりの KV サイズ  → 4096 の倍数に切り下げ、上下限で丸める

GPU が無い（CPU 実行）場合は空き RAM を同じ式で使う。情報が取れない場合は設定値をそのまま使う。
"""
from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass, asdict

import httpx


@dataclass
class CtxEstimate:
    num_ctx: int
    reason: str                 # 人が読める説明
    free_mb: int = 0            # 空きメモリ（VRAM または RAM）
    model_mb: int = 0           # モデル本体のサイズ
    kv_bytes_per_token: int = 0
    device: str = "unknown"     # gpu | cpu | unknown
    model_max_ctx: int = 0      # モデルが対応する最大コンテキスト
    configured: int = 0         # 設定ファイルの値（上限）

    def to_dict(self) -> dict:
        return asdict(self)


# ------------------------------------------------------------------ メモリ情報
def gpu_free_total_mb() -> tuple[int, int] | None:
    """(free_mb, total_mb)。複数 GPU なら空きが最大のもの。取得できなければ None。"""
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=memory.free,memory.total", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5).stdout
            best = None
            for line in out.strip().splitlines():
                free, total = [int(float(x.strip())) for x in line.split(",")[:2]]
                if best is None or free > best[0]:
                    best = (free, total)
            if best:
                return best
        except Exception:
            pass
    if shutil.which("rocm-smi"):
        try:
            out = subprocess.run(["rocm-smi", "--showmeminfo", "vram", "--csv"], capture_output=True, text=True, timeout=5).stdout
            best = None
            for line in out.strip().splitlines()[1:]:
                cols = [c.strip() for c in line.split(",")]
                nums = [int(c) for c in cols if c.isdigit()]
                if len(nums) >= 2:
                    total, used = nums[0] // (1024 * 1024), nums[1] // (1024 * 1024)
                    free = total - used
                    if best is None or free > best[0]:
                        best = (free, total)
            if best:
                return best
        except Exception:
            pass
    return None


def ram_free_total_mb() -> tuple[int, int] | None:
    try:
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                info[k] = int(v.strip().split()[0]) // 1024
        return info.get("MemAvailable", 0), info.get("MemTotal", 0)
    except Exception:
        return None


# ------------------------------------------------------------------ モデル情報
def _model_info(base_url: str, model: str) -> tuple[dict, int]:
    """(/api/show の model_info + details, モデルサイズ MB)。"""
    info: dict = {}
    size_mb = 0
    try:
        r = httpx.post(f"{base_url}/api/show", json={"model": model}, timeout=10)
        if r.status_code == 200:
            d = r.json()
            info = dict(d.get("model_info") or {})
            info["_details"] = d.get("details") or {}
    except Exception:
        pass
    try:
        r = httpx.get(f"{base_url}/api/tags", timeout=5)
        for m in r.json().get("models", []):
            if m.get("name") == model or m.get("model") == model:
                size_mb = int(m.get("size", 0)) // (1024 * 1024)
    except Exception:
        pass
    return info, size_mb


def _loaded_vram_mb(base_url: str, model: str) -> int:
    """モデルが既にロード済みなら、その VRAM 使用量（空き容量に戻して計算するため）。"""
    try:
        r = httpx.get(f"{base_url}/api/ps", timeout=5)
        for m in r.json().get("models", []):
            if m.get("name") == model or m.get("model") == model:
                return int(m.get("size_vram", 0)) // (1024 * 1024)
    except Exception:
        pass
    return 0


def _kv_bytes_per_token(info: dict) -> tuple[int, int]:
    """(1 トークンあたりの KV キャッシュ bytes, モデルの最大コンテキスト)。不明なら (0, 0)。"""
    arch = None
    for k in info:
        if k.endswith(".block_count"):
            arch = k.split(".")[0]
            break
    if not arch:
        return 0, 0
    g = lambda name, default=0: int(info.get(f"{arch}.{name}", default) or default)  # noqa: E731
    layers = g("block_count")
    heads = g("attention.head_count")
    kv_heads = g("attention.head_count_kv", heads) or heads
    embed = g("embedding_length")
    head_dim = g("attention.key_length") or (embed // heads if heads else 0)
    max_ctx = g("context_length")
    if not (layers and kv_heads and head_dim):
        return 0, max_ctx
    # K と V、f16（2 byte）
    return 2 * layers * kv_heads * head_dim * 2, max_ctx


# ------------------------------------------------------------------ 推定
KV_TYPE_FACTOR = {"f16": 1.0, "bf16": 1.0, "q8_0": 0.5, "q4_0": 0.28}


def estimate_num_ctx(base_url: str, model: str, configured: int, *, min_ctx: int = 8192,
                     max_ctx: int | None = None, reserve_mb: int = 1024, step: int = 4096,
                     kv_cache_type: str = "f16", ram_offload_ratio: float = 0.0) -> CtxEstimate:
    """ram_offload_ratio: GPU に載りきらない分を RAM に逃がす前提で、空き RAM のこの割合を KV 用に加算する（0 で無効）。"""
    max_ctx = max_ctx or configured
    info, model_mb = _model_info(base_url, model)
    per_tok, model_max = _kv_bytes_per_token(info)
    per_tok = int(per_tok * KV_TYPE_FACTOR.get(str(kv_cache_type).lower(), 1.0))
    if not per_tok:
        return CtxEstimate(num_ctx=configured, reason="モデル情報が取得できないため設定値を使用", configured=configured,
                           model_mb=model_mb, model_max_ctx=model_max)

    gpu = gpu_free_total_mb()
    if gpu:
        free_mb, total_mb = gpu
        device = "gpu"
        free_mb += _loaded_vram_mb(base_url, model)   # 既にロード済みなら戻す
    else:
        ram = ram_free_total_mb()
        if not ram:
            return CtxEstimate(num_ctx=configured, reason="メモリ情報が取得できないため設定値を使用", configured=configured,
                               model_mb=model_mb, kv_bytes_per_token=per_tok, model_max_ctx=model_max)
        free_mb, total_mb = ram
        device = "cpu"
        reserve_mb = max(reserve_mb, 4096)             # CPU 実行は OS 側の余裕を多めに

    avail_mb = free_mb - model_mb - reserve_mb
    offload_note = ""
    if device == "gpu" and ram_offload_ratio > 0:
        ram = ram_free_total_mb()
        if ram:
            extra = int(ram[0] * ram_offload_ratio)
            avail_mb += extra
            offload_note = f"（RAM 退避分 +{extra} MB を含む。GPU に載りきらない分は遅くなる）"
    if avail_mb <= 0:
        # モデルすら載らない → 最小値にして警告
        return CtxEstimate(num_ctx=min_ctx, reason=f"空き{device.upper()}メモリ {free_mb} MB がモデル {model_mb} MB に足りないため最小値",
                           free_mb=free_mb, model_mb=model_mb, kv_bytes_per_token=per_tok, device=device,
                           model_max_ctx=model_max, configured=configured)
    # 計算グラフ等の一時メモリ分として KV に使えるのは 8 割程度と見積もる
    tokens = int(avail_mb * 1024 * 1024 * 0.8 / per_tok)
    n = (tokens // step) * step
    upper = min(max_ctx, model_max or max_ctx)
    n = max(min_ctx, min(n, upper))
    reason = (f"{device.upper()} 空き {free_mb} MB − モデル {model_mb} MB − 予備 {reserve_mb} MB{offload_note} → "
              f"KV {per_tok/1024:.0f} KB/token ({kv_cache_type}) → 約 {tokens:,} tokens、上限 {upper:,}")
    return CtxEstimate(num_ctx=n, reason=reason, free_mb=free_mb, model_mb=model_mb, kv_bytes_per_token=per_tok,
                       device=device, model_max_ctx=model_max, configured=configured)
