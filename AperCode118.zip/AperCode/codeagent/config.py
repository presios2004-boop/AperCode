"""設定ファイルの読み込み。"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

DEFAULT_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.yaml"
EXAMPLE_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.example.yaml"
DATA_DIR = Path.home() / ".apercode"                              # ユーザーデータ（設定上書き・セッション・メモリ・ログ）
USER_CONFIG_PATH = DATA_DIR / "config.yaml"                       # ユーザー固有の上書き（任意）
STATE_PATH = DATA_DIR / "state.json"                              # 最近使ったプロジェクトなど


def ensure_data_dir() -> Path:
    """~/.apercode を用意する。旧名 ~/.codeagent があり新しい方が無ければ移行（リネーム）する。"""
    legacy = Path.home() / ".codeagent"
    if not DATA_DIR.exists() and legacy.is_dir():
        try:
            legacy.rename(DATA_DIR)
        except OSError:
            pass
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return DATA_DIR


def _deep_merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def expand(p: str | Path) -> Path:
    s = str(p)
    if s.startswith("~/.codeagent/") or s.startswith("~/.codeagent"):
        s = s.replace("~/.codeagent", "~/.apercode", 1)   # 旧データディレクトリ名の互換
    return Path(os.path.expandvars(os.path.expanduser(s))).resolve()


class Config:
    def __init__(self, data: dict[str, Any]):
        self.data = data

    @classmethod
    def load(cls, path: str | Path | None = None) -> "Config":
        """config.yaml（無ければ config.example.yaml）を読み、~/.apercode/config.yaml があれば上書きする。"""
        ensure_data_dir()
        if path:
            base_path = Path(path)
        else:
            base_path = DEFAULT_CONFIG_PATH if DEFAULT_CONFIG_PATH.exists() else EXAMPLE_CONFIG_PATH
        with open(base_path, encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        if not path and USER_CONFIG_PATH.exists():
            with open(USER_CONFIG_PATH, encoding="utf-8") as f:
                data = _deep_merge(data, yaml.safe_load(f) or {})
        cfg = cls(data)
        cfg.path = base_path
        return cfg

    def get(self, dotted: str, default: Any = None) -> Any:
        cur: Any = self.data
        for key in dotted.split("."):
            if not isinstance(cur, dict) or key not in cur:
                return default
            cur = cur[key]
        return cur

    # --- よく使う値 ---
    @property
    def workspace_root(self) -> Path:
        return expand(self.get("workspace.root", "~"))

    @property
    def default_project(self) -> Path:
        """既定のプロジェクト: 設定値 → 最近使ったもの → ワークスペースのルート。"""
        v = self.get("workspace.default_project")
        if v:
            return expand(v)
        recent = self.state().get("recent_projects") or []
        for r in recent:
            if Path(r).is_dir():
                return Path(r)
        return self.workspace_root

    # --- 状態ファイル（最近使ったプロジェクトなど） ---
    @staticmethod
    def state() -> dict:
        import json
        try:
            return json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    @staticmethod
    def save_state(data: dict) -> None:
        import json
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")

    def remember_project(self, path: str | Path, limit: int = 10) -> None:
        st = self.state()
        recent = [str(path)] + [r for r in st.get("recent_projects", []) if r != str(path)]
        st["recent_projects"] = recent[:limit]
        self.save_state(st)

    def in_workspace(self, p: Path) -> bool:
        root = self.workspace_root
        p = p.resolve()
        return p == root or root in p.parents

    @property
    def sessions_dir(self) -> Path:
        p = expand(self.get("server.sessions_dir", "~/.apercode/sessions"))
        p.mkdir(parents=True, exist_ok=True)
        return p

    def permission(self, tool_name: str) -> str:
        return str(self.get(f"permissions.{tool_name}", "ask"))
