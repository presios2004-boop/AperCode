"""履歴の圧縮を、速く・正確にする（v2.11.31）。

1. 記録（facts）: 圧縮で消える履歴から、ユーザーの指示（原文）・変更したファイル・実行したコマンドと終了コード・読んだ URL・
   エラー・保存したものを、LLM を使わずに機械的に取り出す。要約に添えて残し、以前の圧縮の記録とも合わせる。
   件数・名前・数字の写し間違い（小型モデルの要約で多かった誤り）を、要約に頼らずに残すため。
2. 要約の検証: 要約に出てくる数字・ファイル名・URL が、要約のもとにした記録に本当にあるかを確かめ、無いものを含む行は消す。
   消す行が多すぎる要約（サブ LLM のもの）は使わない（メイン LLM で作り直す）。
"""
from __future__ import annotations

import re
import unicodedata

CAPS = {"requests": 6, "files": 40, "commands": 12, "urls": 20, "errors": 6, "saved": 20}
LABELS = {"requests": "ユーザーの指示（原文）", "files": "変更したファイル", "commands": "実行したコマンド（終了コード）",
          "urls": "読んだ URL", "errors": "エラー（最近のもの）", "saved": "保存したもの"}
_SAVED_RE = re.compile(r"(?:ノートを保存しました|シナリオを保存しました|イベントを保存しました|スキル \S+ を保存しました|"
                       r"保存しました|saved)[:：]?\s*([^\s（(]+)", re.I)


def _short(s: str, n: int) -> str:
    s = " ".join(str(s or "").split())
    return s if len(s) <= n else s[:n] + "…"


def extract(messages: list[dict]) -> dict:
    """消える範囲のメッセージから、記録を取り出す（以前の要約のメッセージは除く）。"""
    f: dict[str, list] = {k: [] for k in CAPS}
    calls: dict[str, dict] = {}
    for m in messages:
        if m.get("kind") == "summary":
            continue
        role = m.get("role")
        if role == "user" and not m.get("kind"):
            f["requests"].append(_short(m.get("content"), 300))
        elif role == "assistant":
            for tc in m.get("tool_calls") or []:
                calls[str(tc.get("id"))] = tc
                a = tc.get("args") or {}
                name = tc.get("name")
                if name in ("write_file", "edit_file") and a.get("path"):
                    f["files"].append(str(a["path"]))
                elif name in ("fetch_url", "browser_open") and a.get("url"):
                    f["urls"].append(str(a["url"])[:200])
        elif role == "tool":
            out = str(m.get("content") or "")
            tc = calls.get(str(m.get("tool_call_id"))) or {}
            name = m.get("name") or tc.get("name")
            if out.startswith(("エラー", "Error")):
                f["errors"].append(f"{name}: {_short(out.splitlines()[0] if out else '', 200)}")
            if name in ("run_command", "process_start"):
                mm = re.search(r"\(exit (-?\d+)\)", out)
                cmd = str((tc.get("args") or {}).get("command") or "")
                if cmd:
                    f["commands"].append(f"{_short(cmd, 160)} → exit {mm.group(1) if mm else '?'}")
            for s in _SAVED_RE.findall(out[:2000]):
                if "/" in s or "." in s:
                    f["saved"].append(s[:200])
    return f


def merge(old: dict | None, new: dict) -> dict:
    """以前の記録と合わせる（重複を除き、それぞれ新しい方から上限まで）。"""
    out: dict[str, list] = {}
    for k, cap in CAPS.items():
        seen, items = set(), []
        for v in list((old or {}).get(k) or []) + list(new.get(k) or []):
            if v not in seen:
                seen.add(v)
                items.append(v)
        out[k] = items[-cap:]
    return out


def render(f: dict) -> str:
    if not any(f.get(k) for k in CAPS):
        return ""
    lines = ["", "## 記録（AperCode が履歴から機械的に取り出した事実。要約と食い違うときは、こちらが正しい）"]
    for k in CAPS:
        if f.get(k):
            lines.append(f"### {LABELS[k]}")
            lines += [f"- {v}" for v in f[k]]
    return "\n".join(lines)


# ------------------------------------------------------------------ 要約の検証
_NUM_RE = re.compile(r"(?<![\w.])\d+(?:[.,]\d+)+%?|(?<![\w.])\d{3,}%?|(?<![\w.])\d+%")
_PATH_RE = re.compile(r"(?:https?://\S+|[\w./~-]*\w\.(?:py|mq5|mqh|ex5|md|json|csv|html?|js|ts|java|txt|ya?ml|sh|xlsx|pdf|png))")


def _norm(s: str) -> str:
    return unicodedata.normalize("NFKC", s or "").replace(",", "").replace("，", "").casefold()


def facts_in(text: str) -> list[str]:
    """要約の中の、確かめるべき事実（数字・ファイル名・URL）。"""
    out = [m.group(0).rstrip(".,)）」") for m in _PATH_RE.finditer(text)]
    t = _PATH_RE.sub(" ", text)
    out += [m.group(0) for m in _NUM_RE.finditer(t)]
    return out


def verify(summary: str, source: str) -> tuple[str, list[str], int]:
    """要約のうち、もとの記録に無い事実を含む行を消す。(消した後の要約, 見つからなかった事実, 消した行数)"""
    src = _norm(source)
    missing: list[str] = []
    kept, removed = [], 0
    for line in (summary or "").splitlines():
        bad = [x for x in facts_in(line) if _norm(x).rstrip("%") not in src]
        if bad:
            missing += bad
            removed += 1
            continue
        kept.append(line)
    return "\n".join(kept), missing, removed
