"""作業の指示書（v1.8.0）: ユーザーが最初に指示した目的を md ファイルに清書し、LLM の毎回のリクエストに自動で添える。

ローカル LLM は長い作業の途中で最初の目的を忘れやすい。会話履歴は圧縮で要約されていくので、目的は履歴とは別に
ファイルとして保持し、AperCode（ハーネス）が LLM を呼ぶたびにファイルを読み直してシステムプロンプトに入れる。
LLM に「読みに行かせる」のではないので、読み忘れが起きない。ユーザーがファイルを直接編集すれば次の呼び出しから反映される。

置き場所: <プロジェクト>/.apercode/briefs/<セッションID>.md
- 最初の指示で作成（LLM が清書。失敗したら原文のまま）
- 以降のユーザーの指示は「追加・変更の指示」として追記（「続けて」などの短い返事は追記しない）
- 目的を達成したら LLM が finish_brief ツールで削除（テスト失敗・自動検証 NG が残っていれば拒否）。画面からも削除できる
"""
from __future__ import annotations

import re
import time
from pathlib import Path

BRIEF_PROMPT = """あなたはユーザーの依頼を「作業の指示書」に清書する係です。
以下のユーザーの依頼文を読み、コーディングエージェントが作業の最後まで目的を見失わないための指示書を Markdown で書いてください。

形式（この見出しだけを使う。該当が無い見出しは省略）:
# 目的
（何を実現したいのかを 1〜3 行で）
## 要件
- （ユーザーが求めていること。箇条書き）
## 制約・注意
- （使う言語・ライブラリ・触ってはいけないもの・方針など、ユーザーが指定したこと）
## 完了条件
- [ ] （何ができたら完了か。確認できる形で）

規則:
- ユーザーが書いていないことを付け足さない（推測で要件を増やさない）。曖昧な点は「（未指定）」と書く
- ファイル名・パス・数値・固有名詞はそのまま残す
- 40 行以内。前置きや説明は書かず、指示書だけを出力する
"""

BRIEF_PROMPT_EN = """You turn the user's request into a "task brief".
Read the request below and write, in Markdown, a brief that keeps a coding agent on target until the end of the work.

Format (use only these headings; omit a heading that has nothing):
# Goal
(what the user wants to achieve, 1-3 lines)
## Requirements
- (what the user asked for, as bullets)
## Constraints
- (languages, libraries, things not to touch, policies the user specified)
## Done when
- [ ] (what must be true for the task to be finished, in a checkable form)

Rules:
- Do not add anything the user did not say (no guessed requirements). Write "(unspecified)" for unclear points
- Keep file names, paths, numbers and proper nouns verbatim
- At most 40 lines. Output only the brief, no preamble
"""

# v2.0.0: 指示書の不足点検。ユーザーが指示書を正確に書くとは限らないので、作業を始める前に足りない点を洗い出す
CLARIFY_PROMPT = """あなたはコーディングエージェント AperCode の作業前点検係です。
以下の「作業の指示書」を読み、このまま作業を始めると困る不足がないかを点検してください。

点検する観点:
1. 完了条件: 何ができたら終わりかが確認できる形か。会話・繰り返し・監視などの作業では「いつ終えるか（終了条件）」があるか
2. 対象: 作業するファイル・フォルダ・アプリ・相手・場所が特定できるか
3. 取り返しのつかない操作: 削除・上書き・送信・公開・購入などがある場合、その範囲が決まっているか
4. 成果物: 形式や置き場所が結果を大きく左右するのに、決まっていないか

5. 既存のファイル: 下の「作業ディレクトリにある既存のファイル」に、今回の依頼と同じ目的・同じ種類のもの（以前の調査結果・データ・
   分析・成果物など）があるのに、それを使うか・新しく作り直すかが指示書に書かれていないか

6. 範囲の解釈: 対象・期間・件数・条件の範囲が二通り以上に読める箇所がないか。とくに、目的と手順で範囲が違って見えるもの
   （例: 目的は「10 月会合の EA」、手順は「過去 5 年分の会合を調べ、その前後の値動きを調べる」→ 値動きを調べるのは 10 月会合だけか、すべての会合か）や、
   「1 で調べた期間」「それら」「該当するもの」のように指す範囲がはっきりしない言い方

出力の形式（この形式の行だけを書く。前置き・説明は書かない）:
SCOPE: （観点 6 に当てはまるときだけ。二つの読み方のどちらかを聞く質問。最大 2 つ）
EXISTING: （観点 5 に当てはまるときだけ。対象のフォルダ・ファイル名を挙げて、使うか新しく作り直すかを聞く質問を 1 つ）
QUESTION: （作業前にユーザーへ聞くべき質問。AperCode が自分で決めると大きな手戻りや損害になるものだけ。最大 3 つ）
SCOPE・EXISTING・QUESTION は、質問文のあとに「||」で区切って選択肢を 2〜4 個書く（ユーザーは記号で選ぶ）:
  例: SCOPE: 手順 2 の値動きの調査の範囲はどれですか？ || A) 10 月会合だけ || B) 過去 5 年のすべての会合
  例: EXISTING: data/boj/ にある以前の調査結果を使いますか？ || A) 使う || B) 使わずに新しく作り直す
  選択肢は互いに重ならない、具体的な内容にする（「その他」「任せる」は書かない。AperCode が自動で付ける）
ASSUME: （AperCode が妥当に決められる点。「〜とする」の形で仮定を書く。最大 5 つ）
不足が無ければ OK とだけ書く。

規則:
- 指示書に書いてあることを質問しない。細かい好みは質問せず ASSUME にする
- やり方・手段（アプリの起動方法・使うツール・作業の手順など）は AperCode が決めることなので、質問せず ASSUME にする
- 終了条件が相手の行動（「相手が終了を告げたら」など）だけに頼っている場合は、それが来なかったときの上限（往復数・時間）を ASSUME に書く
- 質問は 1 つ 1 文で、必ず「||」で選択肢を付ける
- SCOPE は、本当に結果が大きく変わる読み違いのときだけ書く。どちらに読んでも結果がほぼ同じなら書かない
- EXISTING は、指示書が既存のファイルの扱い（使う・使わない・作り直す・上書きする）をすでに決めているときは書かない。
  依頼と関係のないファイル（ツール・設定・別の作業のもの）については書かない
"""

CLARIFY_PROMPT_EN = """You check a task brief for the coding agent AperCode before the work starts.
Read the brief below and find gaps that would cause trouble if the work started as is.

Check:
1. Done condition: can "finished" be checked? For conversations, repeated work or monitoring: is there a stop condition?
2. Target: are the files, folders, apps, counterpart or place identifiable?
3. Irreversible operations: if there is deleting, overwriting, sending, publishing or buying, is its scope decided?
4. Deliverable: is a format or location that matters a lot left undecided?

5. Existing files: among "Existing files in the working directory" below, are there files for the same purpose / of the same kind as this
   request (earlier research, data, analysis, deliverables) while the brief does not say whether to use them or build anew?

6. Scope: can the range of targets, period, count or conditions be read in two or more ways? Especially when the goal and the steps
   seem to imply different ranges (e.g. goal: "an EA for the October meeting", steps: "find the meetings of the past 5 years and study the
   moves around them" -> study only the October meetings, or all meetings?), or vague references such as "the period found in step 1",
   "those", "the relevant ones"

Output format (only lines in this format, no preamble):
SCOPE: (only for check 6: a question asking which of the readings is meant; at most 2)
EXISTING: (only for check 5: one question naming the folder / files and asking whether to use them or build anew)
QUESTION: (a question to ask the user before starting — only where AperCode deciding alone could cause big rework or damage; at most 3)
For SCOPE, EXISTING and QUESTION, write 2-4 choices after the question, separated by "||" (the user picks by letter):
  e.g. SCOPE: Which range should step 2 study? || A) only the October meetings || B) all meetings of the past 5 years
  e.g. EXISTING: Use the earlier results in data/boj/? || A) use them || B) ignore them and build anew
  Choices must be concrete and must not overlap (do not write "other" or "up to you"; AperCode adds that)
ASSUME: (a point AperCode can reasonably decide, written as an assumption; at most 5)
If nothing is missing, write only OK.

Rules:
- Do not ask about what the brief already says. Put minor preferences under ASSUME
- Methods and means (how to launch an app, which tools, the order of work) are AperCode's decision: put them under ASSUME, never ask
- If the stop condition depends only on someone else's action ("until they say goodbye"), add a fallback limit (rounds or time) under ASSUME
- One sentence per question, always with choices after "||"
- Write SCOPE only when the two readings would change the result a lot; skip it if both lead to about the same work
- Do not write EXISTING when the brief already decides how to treat existing files (use / do not use / rebuild / overwrite),
  or for files unrelated to the request (tools, settings, other work)
"""


def parse_clarify(raw: str) -> tuple[list[str], list[str]]:
    """点検結果から（質問, 仮定）を取り出す。形式に合わない行は無視する。"""
    qs: list[str] = []
    ass: list[str] = []
    for ln in clean_llm_output(raw).splitlines():
        m = re.match(r"^\s*[-*]?\s*(QUESTION|ASSUME|質問|仮定)\s*[:：]\s*(.+?)\s*$", ln, re.I)
        if not m:
            continue
        body = m.group(2).strip()
        if len(body) < 4 or body.upper() == "OK":
            continue
        (qs if m.group(1).upper() in ("QUESTION", "質問") else ass).append(body)
    return qs[:3], ass[:5]


def parse_scope(raw: str) -> list[str]:
    """v2.11.11: 点検結果から、範囲の解釈が分かれる点の質問（SCOPE）を取り出す。"""
    out: list[str] = []
    for ln in clean_llm_output(raw).splitlines():
        m = re.match(r"^\s*[-*]?\s*(SCOPE|範囲)\s*[:：]\s*(.+?)\s*$", ln, re.I)
        if m and len(m.group(2).strip()) >= 4 and m.group(2).strip().upper() != "OK":
            out.append(m.group(2).strip())
    return out[:2]


def parse_existing(raw: str) -> list[str]:
    """v2.11.9: 点検結果から、既存のファイルを使うかどうかの質問（EXISTING）を取り出す。"""
    out: list[str] = []
    for ln in clean_llm_output(raw).splitlines():
        m = re.match(r"^\s*[-*]?\s*(EXISTING|既存)\s*[:：]\s*(.+?)\s*$", ln, re.I)
        if m and len(m.group(2).strip()) >= 4 and m.group(2).strip().upper() != "OK":
            out.append(m.group(2).strip())
    return out[:1]


_OVERVIEW_SKIP = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
                  ".apercode", ".cache", ".idea", ".vscode", "backup", "skills"}


def existing_overview(project: Path, skip: tuple[str, ...] = (), max_dirs: int = 30, max_files: int = 40) -> str:
    """v2.11.9: 作業ディレクトリにある既存のファイルの概要（フォルダごとの件数と更新日、最近のファイル）。指示書の点検に渡す。"""
    import os
    project = Path(project)
    if not project.is_dir():
        return ""
    skipset = _OVERVIEW_SKIP | set(skip)
    dirs: dict[str, list] = {}
    files: list[tuple[float, str]] = []
    n = 0
    for root, ds, fs in os.walk(project):
        ds[:] = [d for d in ds if d not in skipset and not d.startswith(".")]
        rel_root = os.path.relpath(root, project)
        key = "/".join(Path(rel_root).parts[:2]) if rel_root != "." else "."
        for f in fs:
            if f.startswith("."):
                continue
            try:
                mt = os.path.getmtime(os.path.join(root, f))
            except OSError:
                continue
            d = dirs.setdefault(key, [0, 0.0])
            d[0] += 1
            d[1] = max(d[1], mt)
            files.append((mt, os.path.relpath(os.path.join(root, f), project)))
            n += 1
            if n > 20000:
                break
    if not files:
        return ""
    lines = ["フォルダ（ファイル数・最終更新）:"]
    for k, (c, mt) in sorted(dirs.items(), key=lambda kv: -kv[1][1])[:max_dirs]:
        lines.append(f"- {k}/ … {c} 件・{time.strftime('%Y-%m-%d %H:%M', time.localtime(mt))}")
    lines.append("最近のファイル:")
    for mt, rel in sorted(files, reverse=True)[:max_files]:
        lines.append(f"- {rel}（{time.strftime('%Y-%m-%d %H:%M', time.localtime(mt))}）")
    return "\n".join(lines)


# ---------------------------------------------------------------- v2.11.22: 作業前の確認を選択式にする
_OPT_RE = re.compile(r"^\s*\(?([A-Da-dＡ-Ｄａ-ｄ])[\).）．:：]\s*(.+?)\s*$")
_EITHER_RE = re.compile(r"^(?P<head>.*?[はを、,]\s*)?(?P<a>[^、,？?]{2,80}?)(?P<ea>ですか|でしょうか|ますか)[、,]\s*(?:それとも\s*)?"
                        r"(?P<b>.{2,80}?)(?P<eb>ですか|でしょうか|ますか)\s*[？?]?\s*$")
LETTERS = "ABCD"


def split_question(text: str) -> tuple[str, list[str]]:
    """「質問 || A) 選択肢 || B) 選択肢」を（質問, [選択肢]）に分ける。
    選択肢が無く「〜ですか、それとも〜ですか」の形なら、二つの読み方を選択肢にする（LLM が形式を守らなかったとき）。"""
    parts = [p.strip() for p in str(text or "").split("||")]
    q, opts = parts[0], []
    for p in parts[1:]:
        m = _OPT_RE.match(p)
        v = (m.group(2) if m else p).strip()
        if v and v not in opts:
            opts.append(v)
    if not opts:
        m = _EITHER_RE.match(q)
        if m:
            a = m.group("a").strip() + ("ます" if m.group("ea") == "ますか" else "")
            b = m.group("b").strip() + ("ます" if m.group("eb") == "ますか" else "")
            head = (m.group("head") or "").strip()
            if len(a) >= 2 and len(b) >= 2:
                opts = [a, b]
                q = (head.rstrip("、, ") + "、どちらですか？") if head else "どちらですか？"
    return q, opts[:4]


def format_clarify(questions: list[str], en: bool = False) -> str:
    """作業前の確認の文章（番号付きの質問と、記号付きの選択肢・答え方の例）。"""
    lines: list[str] = []
    any_opts = False
    for i, raw in enumerate(questions, 1):
        q, opts = split_question(raw)
        lines.append(f"{i}. {q}")
        for j, o in enumerate(opts):
            lines.append(f"   {LETTERS[j]}. {o}")
        any_opts = any_opts or bool(opts)
        lines.append("")
    n = len(questions)
    if en:
        if any_opts:
            ex = "1-A" if n == 1 else ", ".join(f"{k}-A" for k in range(1, min(n, 3) + 1))
            how = (f"How to answer: question number and choice letter, e.g. \"{ex}\". For anything not in the choices, write it in words "
                   f"(e.g. \"1: ...\"). \"up to you\" lets AperCode choose.")
        else:
            how = "How to answer: write the question number and your answer, e.g. \"1: ...\". \"up to you\" lets AperCode choose."
    else:
        if any_opts:
            ex = "1-A" if n == 1 else "、".join(f"{k}-A" for k in range(1, min(n, 3) + 1))
            how = (f"答え方: 質問の番号と選択肢の記号を書いてください（例:「{ex}」）。選択肢にないときは文章で書いてください"
                   f"（例:「1: ○○も含める」）。「任せる」と書くと AperCode が選びます。")
        else:
            how = "答え方: 質問の番号のあとに答えを書いてください（例:「1: ○○」）。「任せる」と書くと AperCode が選びます。"
    return "\n".join(lines).rstrip() + "\n\n" + how


_ANS_RE = re.compile(r"(?:^|(?<=[\s、,，;；/。]))(?:(\d)\s*(?:[-ー－:：.．)）は]\s*)?)?([A-Da-dＡ-Ｄａ-ｄ])(?=$|[\s、,，;；/。.！!]|で|に|を|が|の|に)")


def expand_answer(text: str, questions: list[str]) -> str:
    """「1-A, 2-B」のような記号の答えを、質問と選んだ選択肢の文章にする（指示書に追記して LLM が読めるように）。
    記号で読み取れない答えは、そのまま残す。"""
    t = (text or "").strip()
    if not questions or not t:
        return t
    parsed = [split_question(q) for q in questions]
    picks: dict[int, str] = {}
    for m in _ANS_RE.finditer(t):
        if not m.group(1) and m.group(2) not in "ABCDＡＢＣＤ":
            continue                                  # 番号の無い小文字（英文の "a" など）は選択肢の記号とみなさない
        num = int(m.group(1)) if m.group(1) else (1 if len(parsed) == 1 else 0)
        letter = m.group(2).translate(str.maketrans("ＡＢＣＤａｂｃｄ", "ABCDabcd")).upper()
        if 1 <= num <= len(parsed):
            opts = parsed[num - 1][1]
            k = LETTERS.index(letter)
            if k < len(opts):
                picks[num] = f"{letter}. {opts[k]}"
    if not picks:
        return t
    lines = [f"{n}. {parsed[n - 1][0]} → {picks[n]}" for n in sorted(picks)]
    rest = _ANS_RE.sub(" ", t).strip(" 、,，;；/")
    if rest and rest not in ("。", "."):
        lines.append(f"（ユーザーの返事の原文: {t}）")
    return "\n".join(lines)


def append_assumptions(p: Path, assumptions: list[str]) -> None:
    if not assumptions:
        return
    with open(p, "a", encoding="utf-8") as f:
        f.write("\n## AperCode の仮定（違っていれば指示してください）\n" + "\n".join(f"- {a}" for a in assumptions) + "\n")


def append_answer(p: Path, text: str) -> None:
    t = text.strip()[:1500]
    stamp = time.strftime("%m/%d %H:%M")
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"\n## 作業前の確認への回答（{stamp}）\n" + "\n".join("> " + ln for ln in t.splitlines()) + "\n")


CONTINUE_WORDS = re.compile(r"^(続けて|つづけて|続行|はい|いいえ|ok|okay|yes|no|go|continue|進めて|お願いします|おねがいします|よろしく|了解|りょうかい|どうぞ|やって)[。．!！\s]*$",
                            re.I)


def path_for(project: Path, session_id: str) -> Path:
    return project / ".apercode" / "briefs" / f"{session_id}.md"


def rel(project: Path, p: Path) -> str:
    try:
        return str(p.relative_to(project))
    except ValueError:
        return str(p)


def read(p: Path, max_chars: int = 4000) -> str:
    try:
        s = p.read_text("utf-8", errors="replace").strip()
    except (FileNotFoundError, OSError):
        return ""
    return s if len(s) <= max_chars else s[:max_chars] + "\n…（長いため省略）"


def is_meaningful(text: str, min_chars: int) -> bool:
    t = (text or "").strip()
    return len(t) >= min_chars and not CONTINUE_WORDS.match(t)


def is_followup(text: str) -> bool:
    t = (text or "").strip()
    return len(t) >= 6 and not CONTINUE_WORDS.match(t)


def header(created: float) -> str:
    return f"<!-- AperCode 作業の指示書（{time.strftime('%Y-%m-%d %H:%M', time.localtime(created))} 作成）。編集すると次の LLM 呼び出しから反映されます。目的を達成すると自動で削除されます -->\n"


def write_new(p: Path, body: str, original: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    body = body.strip()
    orig = original.strip()
    if len(orig) > 3000:
        orig = orig[:3000] + "…"
    quoted = "\n".join("> " + ln for ln in orig.splitlines())
    p.write_text(header(time.time()) + body + "\n\n## ユーザーの原文\n" + quoted + "\n", encoding="utf-8")


def append_instruction(p: Path, text: str) -> None:
    t = text.strip()
    if len(t) > 1500:
        t = t[:1500] + "…"
    stamp = time.strftime("%m/%d %H:%M")
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"\n## 追加・変更の指示（{stamp}）\n" + "\n".join("> " + ln for ln in t.splitlines()) + "\n")


def clean_llm_output(raw: str) -> str:
    s = (raw or "").strip()
    s = re.sub(r"^```(?:markdown|md)?\s*\n", "", s)
    s = re.sub(r"\n```\s*$", "", s)
    s = re.sub(r"<think>.*?</think>", "", s, flags=re.S).strip()
    return s


# ------------------------------------------------------------------ v2.11.10: 依頼の日時の基準
_KANJI = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
_REL_N = re.compile(r"(過去|直近|ここ|この|最近の?|前の?|今後|向こう|これから(?:の)?|先|last|past|previous|next|coming)\s*"
                    r"(\d+|[一二三四五六七八九十]+)\s*(年間|年|か月|ヶ月|カ月|ヵ月|箇月|週間|週|日間|日|営業日|years?|months?|weeks?|days?)", re.I)
_REL_WORDS = [
    (r"今日|本日|\btoday\b", "today"), (r"昨日|\byesterday\b", "yesterday"), (r"明日|\btomorrow\b", "tomorrow"),
    (r"今週|\bthis week\b", "this_week"), (r"先週|\blast week\b", "last_week"), (r"来週|\bnext week\b", "next_week"),
    (r"今月|\bthis month\b", "this_month"), (r"先月|\blast month\b", "last_month"), (r"来月|\bnext month\b", "next_month"),
    (r"月末", "month_end"), (r"今年|本年|\bthis year\b", "this_year"), (r"昨年|去年|\blast year\b", "last_year"),
    (r"来年|\bnext year\b", "next_year"), (r"年末|年内|\bend of (?:the )?year\b|\byear[- ]end\b", "year_end"),
]


def _num(s: str) -> int:
    if s.isdigit():
        return int(s)
    if s.startswith("十"):
        return 10 + _KANJI.get(s[1:], 0) if len(s) > 1 else 10
    if "十" in s:
        a, b = s.split("十", 1)
        return _KANJI.get(a, 1) * 10 + (_KANJI.get(b, 0) if b else 0)
    return _KANJI.get(s, 0)


def _shift_months(d, months: int):
    import calendar
    y, m = divmod(d.month - 1 + months, 12)
    y += d.year
    m += 1
    return d.replace(year=y, month=m, day=min(d.day, calendar.monthrange(y, m)[1]))


def time_anchor(text: str, now=None) -> list[str]:
    """依頼文の相対的な日時の表現（過去 5 年・直近 1 年・来月・年末など）を、今日を基準に具体的な日付に直した行。無ければ []。"""
    from datetime import datetime, timedelta
    import calendar
    now = now or datetime.now().astimezone()
    d = now.date()
    out: list[str] = []
    for m in _REL_N.finditer(text or ""):
        n = _num(m.group(2))
        if n <= 0 or n > 100:
            continue
        unit = m.group(3).lower()
        fwd = m.group(1).lower() in ("今後", "向こう", "これから", "これからの", "先", "next", "coming")
        if unit.startswith(("年", "year")):
            other = d.replace(year=d.year + (n if fwd else -n)) if not (d.month == 2 and d.day == 29) else d + timedelta(days=(365 * n if fwd else -365 * n))
        elif unit.startswith(("か月", "ヶ月", "カ月", "ヵ月", "箇月", "month")):
            other = _shift_months(d, n if fwd else -n)
        elif unit.startswith(("週", "week")):
            other = d + timedelta(weeks=n if fwd else -n)
        elif unit.startswith("営業日"):
            other, k = d, 0
            while k < n:
                other += timedelta(days=1 if fwd else -1)
                if other.weekday() < 5:
                    k += 1
        else:
            other = d + timedelta(days=n if fwd else -n)
        a, b = (d, other) if fwd else (other, d)
        out.append(f"「{m.group(0).strip()}」= {a.isoformat()} 〜 {b.isoformat()}")
    for pat, key in _REL_WORDS:
        mm = re.search(pat, text or "", re.I)
        if not mm:
            continue
        w = mm.group(0)
        if key == "today":
            v = d.isoformat()
        elif key == "yesterday":
            v = (d - timedelta(days=1)).isoformat()
        elif key == "tomorrow":
            v = (d + timedelta(days=1)).isoformat()
        elif key in ("this_week", "last_week", "next_week"):
            mon = d - timedelta(days=d.weekday()) + timedelta(weeks={"this_week": 0, "last_week": -1, "next_week": 1}[key])
            v = f"{mon.isoformat()} 〜 {(mon + timedelta(days=6)).isoformat()}"
        elif key in ("this_month", "last_month", "next_month"):
            f = _shift_months(d.replace(day=1), {"this_month": 0, "last_month": -1, "next_month": 1}[key])
            v = f"{f.isoformat()} 〜 {f.replace(day=calendar.monthrange(f.year, f.month)[1]).isoformat()}"
        elif key == "month_end":
            v = d.replace(day=calendar.monthrange(d.year, d.month)[1]).isoformat()
        elif key in ("this_year", "last_year", "next_year"):
            y = d.year + {"this_year": 0, "last_year": -1, "next_year": 1}[key]
            v = f"{y}-01-01 〜 {y}-12-31"
        else:
            v = f"{d.year}-12-31"
        out.append(f"「{w}」= {v}")
    seen, uniq = set(), []
    for x in out:
        if x not in seen:
            seen.add(x)
            uniq.append(x)
    return uniq[:8]


def append_time_anchor(p: Path, text: str, now=None) -> list[str]:
    """依頼に相対的な日時の表現があれば、基準日と具体的な日付の範囲を指示書に書き足す。"""
    from datetime import datetime
    lines = time_anchor(text, now)
    if not lines:
        return []
    now = now or datetime.now().astimezone()
    body = (f"\n\n## 日時の基準（AperCode が依頼の時点の日付から計算）\n- 依頼の日時: {now.strftime('%Y-%m-%d %H:%M')}（{now.tzname() or 'local'}）\n"
            + "".join(f"- {x}\n" for x in lines))
    with p.open("a", encoding="utf-8") as f:
        f.write(body)
    return lines
