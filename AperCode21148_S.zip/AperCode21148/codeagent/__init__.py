"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "2.11.48"
__app_name__ = "AperCode"
