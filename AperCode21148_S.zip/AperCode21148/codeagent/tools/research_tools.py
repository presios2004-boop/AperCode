"""相場分析のツール（v2.11.0）: research_note / research_summary / market_stats / research_scenarios。"""
from __future__ import annotations

from pathlib import Path

from . import Tool, ToolContext, ToolError, register
from .. import research as R


async def research_note(ctx: ToolContext, a: dict) -> str:
    try:
        path, data, warns = R.save_note(ctx.project_dir, a, getattr(ctx, "fetched", None) or {})
    except R.ResearchError as e:
        raise ToolError(str(e))
    q = data["quotes"]
    out = [f"ノートを保存しました: {path}（ID: {data['id']}、種類 {data['kind']}）"]
    if data["kind"] == "claim":
        out.append(f"対象: {data['subject']}／主張: {data['claim'][:80]}／引用 {data['quotes_verified']}/{len(q)} 件を本文で確認")
    elif data["kind"] == "news":
        out.append(f"ニュース: 価格への影響 {R.STANCE_JA.get(data['stance'], data['stance'])}／重要度 {data['importance']}／"
                   f"引用 {data['quotes_verified']}/{len(q)} 件を本文で確認")
    else:
        out.append(f"見通し: {R.STANCE_JA[data['stance']]}／確信度 {data['conviction']}／目標水準 {len(data['targets'])} 件／要因 {len(data['drivers'])} 件／"
                   f"イベント {len(data['events'])} 件／引用 {data['quotes_verified']}/{len(q)} 件を本文で確認")
    out += [f"⚠ {w}" for w in warns]
    out.append("資料を全部書き出したら research_summary で集計する")
    return "\n".join(out)


async def research_summary(ctx: ToolContext, a: dict) -> str:
    try:
        data, md = R.summarize(ctx.project_dir, str(a.get("topic") or ""), max_age_days=int(a.get("max_age_days") or 120),
                               news_days=int(a.get("news_days") or 14))
    except R.ResearchError as e:
        raise ToolError(str(e))
    return f"（保存: {R.topic_dir(ctx.project_dir, data['topic']) / 'summary.md'}）\n\n" + md


async def market_stats(ctx: ToolContext, a: dict) -> str:
    p = ctx.resolve(str(a.get("path") or ""))
    if not p.is_file():
        raise ToolError(f"ファイルがありません: {p}（MT5 からは market_data で書き出せる）")
    try:
        data, md = R.market_stats(p, str(a.get("topic") or ""), ctx.project_dir)
    except R.ResearchError as e:
        raise ToolError(str(e))
    return f"（保存: {data['report']}）\n\n" + md


async def research_scenarios(ctx: ToolContext, a: dict) -> str:
    try:
        path, md, warns = R.save_scenarios(ctx.project_dir, str(a.get("topic") or ""), a.get("scenarios") or [])
    except R.ResearchError as e:
        raise ToolError(str(e))
    return f"シナリオを保存しました: {path}\n" + "".join(f"⚠ {w}\n" for w in warns) + "\n" + md


_NOTE_SCHEMA = {
    "type": "object", "properties": {
        "kind": {"type": "string", "description": "ノートの種類: outlook（金融機関・アナリスト・市場コンセンサスの見通し。既定）/ "
                 "news（ニュース・出来事。見通しの票には入れず、直近の流れとして集計）/ claim（相場以外の一般の調査の主張）"},
        "impact": {"type": "string", "description": "news: topic の価格への影響 up / down / neutral"},
        "importance": {"type": "string", "description": "news: 重要度 high / medium / low"},
        "headline": {"type": "string", "description": "news: 見出し"},
        "claim": {"type": "string", "description": "claim: 資料の主張（1〜2 文）"},
        "subject": {"type": "string", "description": "claim: 何についての主張か（同じ対象の主張どうしを比べる。表記をそろえる）"},
        "topic": {"type": "string", "description": "分析のテーマ（例: USDJPY）。同じテーマのノートがまとめて集計される"},
        "source": {"type": "object", "description": "資料の出どころ", "properties": {
            "institution": {"type": "string", "description": "発行元（例: 日本銀行, MUFG, OANDA）"},
            "title": {"type": "string"}, "author": {"type": "string"},
            "url": {"type": "string", "description": "読んだ URL（fetch_url / browser で読んだもの）"},
            "path": {"type": "string", "description": "ファイルなら read_document で読んだパス"},
            "published": {"type": "string", "description": "発行日 YYYY-MM-DD"},
            "type": {"type": "string", "description": "official（中央銀行・政府）/ bank / analyst / broker / media / blog"}}},
        "stance": {"type": "string", "description": "topic の価格の見通し: up / down / range / neutral"},
        "horizon": {"type": "string", "description": "見通しの期間（例: 1か月, 2026年末）"},
        "conviction": {"type": "string", "description": "資料の確信度: high / medium / low"},
        "targets": {"type": "array", "description": "資料が挙げた水準 [{level, by, kind: target|support|resistance}]",
                    "items": {"type": "object"}},
        "drivers": {"type": "array", "description": "根拠の要因 [{factor, effect: up|down|range, note}]（例: 日米金利差, 日銀の利上げ, 介入警戒）",
                    "items": {"type": "object"}},
        "events": {"type": "array", "description": "注目イベント [{date, name, impact}]", "items": {"type": "object"}},
        "quotes": {"type": "array", "items": {"type": "string"},
                   "description": "見通しの根拠になる原文の引用（1〜5 個、資料の文をそのまま。言い換えない）"},
        "summary": {"type": "string", "description": "資料の要点（3 行程度）"}},
    "required": ["topic", "source", "quotes"]}

register(Tool("research_note",
              "読んだ資料（レポート・記事・中央銀行の発表・ニュースなど）1 本を、決まった形のノートに書き出す。資料を 1 本読むたびに使う。"
              "kind で種類を分ける: outlook（見通し。stance 必須）/ news（ニュース。impact・importance）/ claim（相場以外の一般の調査。claim・subject）。"
              "引用は本文にあるかを AperCode が確かめる。",
              _NOTE_SCHEMA, research_note,
              lambda a: f"{a.get('topic', '')}: {(a.get('source') or {}).get('institution', '')} {a.get('stance', '')}"))
register(Tool("research_summary",
              "テーマのノートを集計する（見通しの票と重み付きの合意、目標水準の中央値・ばらつき、同じ発行元の見方の変化、"
              "直近のニュースの流れ、よく挙がる要因、イベントの日程、資料どうしの食い違い、一般の調査の主張の対象ごとのまとめ）。"
              "計算は AperCode が行う。シナリオや結論を考える前に使う。",
              {"type": "object", "properties": {
                  "topic": {"type": "string"},
                  "news_days": {"type": "integer", "description": "直近何日のニュースを流れとして集計するか（既定 14 日）"},
                  "max_age_days": {"type": "integer", "description": "これより古い資料は除く（既定 120 日）"}},
               "required": ["topic"]}, research_summary, lambda a: a.get("topic", "")))
register(Tool("market_stats",
              "価格データ（CSV）を分析する: 期間ごとの値動きと値幅、ATR、ボラティリティ、トレンドの強さ（効率比）、月ごとの相場の型、"
              "よく止まった水準、資料の目標水準までの距離。資料の主張を数字で確かめるときに使う。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": "CSV のパス（market_data で書き出したもの、または MT5 から書き出したもの）"},
                  "topic": {"type": "string", "description": "research のテーマ（指定すると目標水準までの距離も出す）"}},
               "required": ["path"]}, market_stats, lambda a: a.get("path", "")))
register(Tool("research_scenarios",
              "メインとリスクのシナリオを決まった型で保存する。各シナリオ: role（main / risk）, name, premise（前提）, "
              "triggers（発動条件）, invalidation（否定される条件）, regime（trend_up / trend_down / range / high_volatility）, "
              "horizon, strategy, ea_params（EA の設定の目安）, evidence（根拠のノート ID）, probability（任意）。EA を作る前に使う。",
              {"type": "object", "properties": {
                  "topic": {"type": "string"},
                  "scenarios": {"type": "array", "items": {"type": "object"}}},
               "required": ["topic", "scenarios"]}, research_scenarios,
              lambda a: f"{a.get('topic', '')}: {len(a.get('scenarios') or [])} 件"))


async def event_calendar(ctx: ToolContext, a: dict) -> str:
    """v2.11.5: 会合・指標などの日程を出典つきで記録し、一覧する（過去の同じ種類のイベントでまとめて検証するため）。"""
    topic = str(a.get("topic") or "")
    if str(a.get("action") or "list").lower() == "add":
        try:
            path, events, warns = R.save_events(ctx.project_dir, topic, a.get("events") or [], getattr(ctx, "fetched", None) or {})
        except R.ResearchError as e:
            raise ToolError(str(e))
        return (f"イベントを保存しました: {path}（全 {len(events)} 件）\n" + "".join(f"⚠ {w}\n" for w in warns) + "\n"
                + R.events_md(topic, R.select_events(events, a.get("kind") or "")))
    events = R.select_events(R.load_events(ctx.project_dir, topic), a.get("kind") or "", a.get("since") or "", a.get("until") or "")
    return R.events_md(topic, events)


register(Tool("event_calendar",
              "会合・経済指標などのイベントの日程を、出典つきで記録・一覧する（research/<topic>/events.json）。"
              "期間限定・イベント向けの EA を、過去の同じ種類のイベント（FOMC・日銀会合など）でまとめて検証する（mt5_event_backtest）ために使う。"
              "日付は記憶で書かず、公式サイトなどで読んだものだけを書く。",
              {"type": "object", "properties": {
                  "action": {"type": "string", "description": "add（追加・更新）/ list（一覧。既定）"},
                  "topic": {"type": "string", "description": "テーマ（例: USDJPY）"},
                  "events": {"type": "array", "items": {"type": "object"},
                             "description": "add のとき: [{date: YYYY-MM-DD, kind: FOMC/BOJ/ECB/BOE/CPI/NFP/GDP/INTERVENTION/OTHER, name, time: HH:MM, "
                                            "source: 日程を確かめた URL, note, forecast: 市場予想（コンセンサス）, actual: 結果, previous: 前回値, unit}]。"
                                            "結果は後から同じ日付・種類で actual だけを足してよい"},
                  "kind": {"type": "string", "description": "種類で絞る（例: FOMC、BOJ,FOMC）"},
                  "since": {"type": "string", "description": "list: この日付以降（YYYY-MM-DD）"},
                  "until": {"type": "string", "description": "list: この日付まで（YYYY-MM-DD）"}},
               "required": ["topic"]}, event_calendar,
              lambda a: f"{a.get('action', 'list')} {a.get('topic', '')} {len(a.get('events') or [])} 件"))


async def event_reaction(ctx: ToolContext, a: dict) -> str:
    """v2.11.30: 過去のイベント（event_calendar）の前後の値動きを、価格データから集計する。"""
    p = ctx.resolve(str(a.get("path") or ""))
    if not p.is_file():
        raise ToolError(f"ファイルがありません: {p}（MT5 からは market_data で書き出せる。時間足は H1 以下がよい）")
    try:
        data, md = R.event_reaction(ctx.project_dir, str(a.get("topic") or ""), p, str(a.get("kind") or ""),
                                    a.get("hours") or None, float(a.get("offset_hours") or 0))
    except R.ResearchError as e:
        raise ToolError(str(e))
    return f"（保存: {data['report']}）\n\n" + md


register(Tool("event_reaction",
              "記録した過去のイベント（event_calendar。FOMC・日銀会合・CPI など）の前後で、価格がどう動いたかを価格データ（CSV）から集計する: "
              "N 時間後の値動き（pips）の平均・中央値・上昇した割合・値幅。予想（コンセンサス）と結果がそろっていれば、上振れ・下振れで分けて比べる。"
              "イベント向けの EA の方向（順張り・値幅狙い・イベント前の手仕舞い）を決める根拠にする。",
              {"type": "object", "properties": {
                  "topic": {"type": "string"},
                  "path": {"type": "string", "description": "価格データの CSV（market_data で書き出したもの。H1 以下の時間足がよい）"},
                  "kind": {"type": "string", "description": "イベントの種類で絞る（例: FOMC、BOJ,FOMC）"},
                  "hours": {"type": "array", "items": {"type": "number"}, "description": "何時間後の値動きを測るか（既定 [1, 4, 24]）"},
                  "offset_hours": {"type": "number", "description": "イベントの時刻を価格データの時刻に合わせる差（時間）。"
                                   "例: イベントが日本時間、データが MT5 のサーバー時間（日本時間 −6 時間など）なら -6"}},
               "required": ["topic", "path"]}, event_reaction,
              lambda a: f"{a.get('topic', '')} {a.get('kind', '')} {a.get('path', '')}"))
