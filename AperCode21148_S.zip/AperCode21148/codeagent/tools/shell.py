"""シェルコマンド実行ツール"""
from __future__ import annotations

import asyncio
import os  # noqa: F401
from pathlib import Path

from .. import sandbox

from . import Tool, ToolContext, ToolError, register

MAX_OUT = 30_000


async def run_shell(cmd: str, cwd: str, timeout: int = 120, env: dict | None = None,
                    root: str | None = None, sandboxed: bool = True) -> tuple[int, str]:
    """v2.5.0: サンドボックス（bubblewrap）の中で実行する。root = 書き込みを許す作業ディレクトリ（省略時は cwd）
    sandboxed=False は AperCode 自身が決めたコマンド（MT5 のコンパイルなど、設定された場所の道具）だけに使う。LLM のコマンドには使わない"""
    if sandboxed:
        try:
            argv = sandbox.shell(cmd, Path(cwd), Path(root) if root else None)
        except sandbox.SandboxError as e:
            return 126, str(e)
        base_env = sandbox.env_for(Path(root or cwd))
    else:
        argv, base_env = ["/bin/bash", "-c", cmd], dict(os.environ)
    proc = await asyncio.create_subprocess_exec(
        *argv, cwd=cwd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        start_new_session=not sandboxed, env={**base_env, **(env or {})})
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        _kill(proc, sandboxed)
        return -1, f"(タイムアウト {timeout}s)"
    except asyncio.CancelledError:          # v2.9.0: 強制停止 → コマンドも止める
        _kill(proc, sandboxed)
        raise
    text = out.decode("utf-8", errors="replace")
    if len(text) > MAX_OUT:
        text = text[:MAX_OUT // 2] + "\n... (中略) ...\n" + text[-MAX_OUT // 2:]
    return proc.returncode or 0, text


def _kill(proc, sandboxed: bool) -> None:
    """止める。サンドボックスの外で動かしたもの（wine など子を残すもの）はプロセスグループごと止める。"""
    try:
        if not sandboxed:
            import signal
            os.killpg(proc.pid, signal.SIGKILL)
        else:
            proc.kill()
    except (ProcessLookupError, PermissionError):
        pass


# v2.11.24: サンドボックスの中からは画面のアプリ（ブラウザなど）を起動できない。コマンドが終わると一緒に終了し、
# ホーム（ブラウザのプロファイル）も PC のプロセスも見えないため。起動しようとしたら、使うべきツールを返す
GUI_LAUNCHERS = {"xdg-open", "gio", "exo-open", "gnome-open", "kde-open", "kde-open5", "x-www-browser", "sensible-browser",
                 "gnome-www-browser", "www-browser", "firefox", "firefox-esr", "google-chrome", "google-chrome-stable", "chromium",
                 "chromium-browser", "brave-browser", "microsoft-edge", "microsoft-edge-stable", "opera", "vivaldi", "epiphany",
                 "falkon", "midori", "thunderbird", "libreoffice", "nautilus", "nemo", "thunar", "xdg-email"}
_NON_GUI_FLAGS = {"--version", "-v", "-V", "--help", "-h", "--headless", "--screenshot", "--dump-dom", "--print-to-pdf"}


def gui_launch_hint(cmd: str) -> str | None:
    """サンドボックスの中で画面のアプリを起動しようとしているなら、代わりに使うツールの案内（そうでなければ None）。"""
    if not sandbox.enabled():
        return None
    from ..deletion import _split
    for seg in _split(cmd or ""):
        while seg and ("=" in seg[0] and not seg[0].startswith("-")):          # DISPLAY=:0 などの代入
            seg = seg[1:]
        while seg and os.path.basename(seg[0]) in ("nohup", "setsid", "env", "exec", "command", "sudo", "timeout"):
            seg = seg[1:]
            while seg and (seg[0].startswith("-") or seg[0].replace(".", "").isdigit() or "=" in seg[0]):
                seg = seg[1:]
        if not seg:
            continue
        exe, args = os.path.basename(seg[0]), seg[1:]
        if exe not in GUI_LAUNCHERS or any(x in _NON_GUI_FLAGS for x in args):
            continue
        if exe == "gio" and (not args or args[0] != "open"):
            continue
        url = next((x for x in args if "://" in x), "")
        return ("このコマンドは実行していません。run_command / process_start はサンドボックスの中で動くため、画面のアプリ（ブラウザなど）を"
                f"起動できません（コマンドが終わると一緒に終了し、ホームのプロファイルも PC のプロセスも見えません）: {exe}\n"
                "代わりに次のツールを使ってください:\n"
                + (f"- ユーザーに Web ページを見せる・操作する: browser_open(url=\"{url or 'https://…'}\")（AperCode の内蔵ブラウザ。"
                   "画面のパネルに表示され、browser_read / browser_click / browser_type で操作できる）\n"
                   f"- PC のブラウザ（{exe if exe not in ('xdg-open', 'gio', 'exo-open', 'x-www-browser', 'sensible-browser') else 'firefox など'}）で開くよう"
                   f"求められたとき: gui_launch(command=\"{('firefox' if exe in ('xdg-open', 'gio', 'exo-open', 'x-www-browser', 'sensible-browser') else exe)} {url or 'https://…'}\", "
                   "title=\"ウィンドウのタイトルの一部（例: Firefox）\")\n"
                   "- ページの内容を読むだけ: fetch_url / web_search" if exe not in ("libreoffice", "nautilus", "nemo", "thunar", "thunderbird")
                   else f"- gui_launch(command=\"{' '.join([exe] + args)[:120]}\", title=\"ウィンドウのタイトルの一部\")\n")
                + "\n起動できたかは ps ではなく gui_windows / screenshot で確かめる（サンドボックスの中の ps には PC のプロセスが出ない）")
    return None


async def run_command(ctx: ToolContext, a: dict) -> str:
    cmd = a["command"]
    hint = gui_launch_hint(cmd)
    if hint:
        raise ToolError(hint)
    cwd = ctx.resolve(a.get("cwd", ".")) if a.get("cwd") else ctx.project_dir
    if not cwd.is_dir():
        raise ToolError(f"cwd がありません: {cwd}")
    timeout = int(a.get("timeout", 120))
    code, out = await run_shell(cmd, str(cwd), timeout, root=str(ctx.project_dir))
    return f"$ {cmd}\n(exit {code})\n{out}"


register(Tool("run_command",
              "シェルコマンドを実行する（bash）。ビルド・テスト・git 操作などに使う。長時間かかるものは timeout を指定。"
              "サンドボックスの中で動くため、画面のアプリ（ブラウザなど）は起動できない（Web ページは browser_open、アプリは gui_launch）。",
              {"type": "object", "properties": {
                  "command": {"type": "string"},
                  "cwd": {"type": "string", "description": "作業ディレクトリ（省略時はプロジェクト）"},
                  "timeout": {"type": "integer", "description": "秒（既定 120）"}},
               "required": ["command"]}, run_command, lambda a: a.get("command", "")))
