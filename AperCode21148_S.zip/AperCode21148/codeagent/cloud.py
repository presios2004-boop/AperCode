"""クラウド AI への「相談」クライアント（v1.2.4）。

ローカル LLM が行き詰まったとき、状況をまとめてクラウドの強いモデルにヒントを求めるために使う。
会話全体を渡すのではなく、目的・エラー・試したこと・関連コードの抜粋だけを 1 回の単発リクエストで送る。

対応プロバイダ（公開版）: anthropic（Claude, Messages API）のみ。
API キーは config の cloud.api_key、無ければ環境変数 ANTHROPIC_API_KEY から読む。
送信先は https://api.anthropic.com に固定する（v2.11.19: 他のプロバイダ・カスタム URL の処理を削除。cloud.provider と
cloud.base_url の値は無視する）。
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass

import httpx

# プロバイダのプリセット。models は UI のプルダウン用（手入力も可）
PROVIDERS: dict[str, dict] = {
    # 公開版は動作確認済みの Anthropic（Claude API）だけに対応する
    "anthropic": {"label": "Anthropic Claude", "env": "ANTHROPIC_API_KEY", "base_url": "https://api.anthropic.com",
                  "models": ["claude-sonnet-5-5", "claude-opus-5-5", "claude-fable-5-1", "claude-haiku-5-5"]},
}

# 送信前にマスクする秘密情報らしきもの
_SECRET_PATTERNS = [
    r"(?i)(api[_-]?key|secret|token|password|passwd|authorization)\s*[:=]\s*['\"]?([A-Za-z0-9_\-./+=]{12,})",
    r"\bsk-[A-Za-z0-9_\-]{16,}\b", r"\bsk-ant-[A-Za-z0-9_\-]{16,}\b", r"\bAIza[0-9A-Za-z_\-]{30,}\b",
    r"\bgh[pousr]_[A-Za-z0-9]{30,}\b", r"\bxox[baprs]-[A-Za-z0-9\-]{10,}\b",
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----",
]


def mask_secrets(text: str) -> tuple[str, int]:
    """秘密情報らしき文字列を <masked> に置き換える。(結果, 置換数)"""
    n = 0
    for pat in _SECRET_PATTERNS:
        def _rep(m):
            nonlocal n
            n += 1
            if m.lastindex and m.lastindex >= 2:
                return m.group(0).replace(m.group(2), "<masked>")
            return "<masked>"
        text = re.sub(pat, _rep, text)
    return text, n


@dataclass
class CloudSettings:
    provider: str = "anthropic"
    model: str = ""
    api_key: str = ""
    base_url: str = ""
    timeout: float = 120.0
    max_tokens_cap: int = 32000          # v2.11.12: 本文が空（思考で使い切り）のときにやり直す上限

    @classmethod
    def from_cfg(cls, cfg, role: str = "") -> "CloudSettings":
        """role: consult（ask_cloud）/ chat（cloud_chat）/ review（最終レビュー）。cloud.models.<role> があればそのモデルを使う（v2.11.8）。"""
        prov = "anthropic"                    # 公開版は Claude のみ（他のプロバイダが設定されていても Claude を使う）
        preset = PROVIDERS[prov]
        key = str(cfg.get("cloud.api_key", "") or "") or os.environ.get(preset["env"], "")
        model = str(cfg.get("cloud.model", "") or "") or (preset["models"][0] if preset["models"] else "")
        if role in ROLES:
            model = str((cfg.get("cloud.models", {}) or {}).get(role) or "").strip() or model
        base = preset["base_url"]             # v2.11.19: 送信先は Anthropic の API に固定（cloud.base_url は使わない）
        return cls(provider=prov, model=model, api_key=key, base_url=base,
                   timeout=float(cfg.get("cloud.timeout", 300)),
                   max_tokens_cap=int(cfg.get("cloud.max_tokens_cap", 32000) or 32000))

    @property
    def ready(self) -> bool:
        return bool(self.api_key and self.model)

    def describe(self) -> str:
        return f"{PROVIDERS.get(self.provider, {}).get('label', self.provider)} / {self.model}"


ROLES = ("consult", "chat", "review")
ROLE_LABEL = {"consult": "相談", "chat": "会話", "review": "レビュー"}


class CloudClient:
    def __init__(self, s: CloudSettings):
        self.s = s

    async def ask(self, system: str, prompt: str, max_tokens: int = 4096) -> str:
        s = self.s
        if not s.api_key:
            raise RuntimeError(f"API キーが設定されていません（cloud.api_key または環境変数 "
                               f"{PROVIDERS.get(s.provider, PROVIDERS['anthropic'])['env']}）")
        async with httpx.AsyncClient(timeout=httpx.Timeout(s.timeout, connect=15.0)) as c:
            # v2.11.12: 思考（adaptive thinking）が既定でオンのモデル（Haiku 5.5 など）は、思考に max_tokens を使い切ると
            # 本文が空のまま終わる（stop_reason=max_tokens）。そのときは上限を広げて 1 回だけやり直し、それでも空ならエラーにする
            limit = max(int(max_tokens), 256)
            for attempt in range(2):
                r = await c.post("https://api.anthropic.com/v1/messages",
                                 headers={"x-api-key": s.api_key, "anthropic-version": "2023-06-01",
                                          "content-type": "application/json"},
                                 json={"model": s.model, "max_tokens": limit, "system": system,
                                       "messages": [{"role": "user", "content": prompt}]})
                self._raise(r)
                data = r.json()
                text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
                if text:
                    return text
                stop = data.get("stop_reason")
                kinds = sorted({str(b.get("type")) for b in data.get("content", [])})
                if stop == "max_tokens" and attempt == 0 and limit < s.max_tokens_cap:
                    limit = min(max(limit * 4, 16000), s.max_tokens_cap)
                    continue
                raise RuntimeError(f"クラウド AI の応答に本文がありませんでした（stop_reason={stop}、含まれていたもの: {', '.join(kinds) or 'なし'}、"
                                   f"max_tokens={limit}）。思考で上限を使い切った可能性があります。cloud.max_tokens を増やすか、別のモデルを試してください")

    @staticmethod
    def _raise(r: httpx.Response) -> None:
        if r.status_code >= 400:
            txt = r.text[:400]
            hint = ""
            if r.status_code in (401, 403):
                hint = "（API キーが無効か、権限がありません）"
            elif r.status_code == 404:
                hint = "（モデル名が間違っている可能性）"
            elif r.status_code == 429:
                hint = "（レート制限または残高不足）"
            raise RuntimeError(f"クラウド API エラー {r.status_code}{hint}: {txt}")

    async def test(self) -> str:
        """接続テスト: 短い応答を返す。"""
        return await self.ask("You are a connectivity test. Reply with exactly: OK", "ping", max_tokens=2048)


ASK_SYSTEM = """You are a senior software engineer acting as an escalation point for a local coding agent that is stuck.
The agent cannot see you and will implement your advice itself, so be concrete and verifiable.
Reply in Japanese. Structure:
1. 原因の仮説（確度の高い順に最大 3 つ。それぞれ根拠を 1 行）
2. 確認方法（各仮説を確かめるコマンドやコード）
3. 修正案（unified diff またはコード断片。ファイルパスを明示）
4. それでも直らない場合の次の一手
Do not restate the problem. Do not pad. If information is missing, say exactly what to gather."""


def build_prompt(goal: str, error: str, tried: str, code: str, question: str, env: str) -> str:
    parts = [f"## 目的\n{goal.strip()}"]
    if env:
        parts.append(f"## 環境\n{env.strip()}")
    if error:
        parts.append(f"## エラー / 症状\n```\n{error.strip()[:6000]}\n```")
    if tried:
        parts.append(f"## 試したことと結果\n{tried.strip()[:3000]}")
    if code:
        parts.append(f"## 関連コード（抜粋）\n{code[:20000]}")
    if question:
        parts.append(f"## 質問\n{question.strip()[:1000]}")
    return "\n\n".join(parts)


# v2.11.6: 完了前の最終レビュー（AperCode が作った変更を、クラウド AI が 1 回で読んで指摘する）
REVIEW_SYSTEM = """You are a senior code reviewer doing the final review of changes made by a local coding agent before it reports
completion. You receive the task, a unified diff and the current content of the changed files. You cannot run code.
Review critically for: bugs and logic errors, boundary conditions, unhandled errors, mismatches with callers (arguments, return
values, renamed or undefined references), requirements in the task that the change misses, security problems (injection, missing
path validation, hard-coded secrets), resource leaks, infinite loops and clear performance problems. For MQL5 / trading code also
check order handling (SL/TP, position count, magic number), use of the forming bar vs closed bars, and indicator handle handling.
Do not comment on style, naming, comments or minor refactors. Be concrete: name the file and line, say what goes wrong and how to fix it.
Write "problem" and "fix" in {lang}.
Output only one JSON object at the end (you may write brief reasoning before it):
{"ok": true|false, "issues": [{"file": "path", "line": number or null, "severity": "high|medium|low", "problem": "...", "fix": "..."}]}
"ok" is true only when there is no high or medium issue. Use [] when there are no issues."""


def build_review_prompt(task: str, diff: str, files: dict[str, str], max_chars: int = 60000) -> str:
    """タスク・diff・変更後のファイル全体（入るだけ）を 1 つの文章にする。"""
    parts = [f"## Task\n{(task or '(unknown)').strip()[:3000]}", f"## Diff\n```diff\n{diff}\n```"]
    used = sum(len(p) for p in parts)
    for path, text in files.items():
        block = f"## Current content: {path}\n```\n" + "\n".join(f"{i:4d}| {l}" for i, l in enumerate(text.splitlines(), 1)) + "\n```"
        if used + len(block) > max_chars:
            parts.append(f"## Current content: {path}\n(omitted: too long)")
            continue
        parts.append(block)
        used += len(block)
    return "\n\n".join(parts)


def parse_review_json(text: str) -> dict | None:
    """レビューの応答から最後の {"ok": ..., "issues": [...]} を取り出す。無ければ None。"""
    # v2.11.18: 正規表現で {...} を切り出すと、文字列の中の波括弧（対処案のコード例 `if(x){ ... }` など）で
    # 失敗していた。各 "{" から JSON として読み取る（raw_decode は文字列の中の括弧を正しく扱う）。
    import json as _json
    text = text or ""
    dec = _json.JSONDecoder()
    found = None
    i = text.find("{")
    while i >= 0:
        try:
            data, end = dec.raw_decode(text, i)
        except _json.JSONDecodeError:
            i = text.find("{", i + 1)
            continue
        if isinstance(data, dict) and "ok" in data:
            found = data                                      # 最後のものを使う
            i = text.find("{", end)
        else:
            i = text.find("{", i + 1)
    if found is None:
        return None
    found["issues"] = [x for x in (found.get("issues") or []) if isinstance(x, dict)]
    return found


# ---------------------------------------------------------------- v2.11.20: 2 回目以降のレビュー（前回の指摘の確認＋新しい high・medium だけ）
REVIEW_FOLLOWUP = """

This is a FOLLOW-UP review. The previous review's findings are listed under "Previous findings" with ids.
1. For each previous finding, check the current code and report whether it is fixed: "fixed", "not_fixed" or "partial"
   (add a short "note" when not fixed or partial). Judge only that finding; do not widen it.
2. Report a NEW issue only when its severity is high or medium. Do not report low issues. Do not report again, under a
   different wording or severity, a problem that is one of the previous findings (use its status instead).
   Problems introduced by the fixes count as new issues.
Output only one JSON object at the end:
{"ok": true|false, "previous": [{"id": number, "status": "fixed|not_fixed|partial", "note": "..."}],
 "issues": [{"file": "path", "line": number or null, "severity": "high|medium", "problem": "...", "fix": "..."}]}
"ok" is true only when every previous finding is fixed and there is no new issue."""


def open_review_issues(issues: list[dict]) -> list[dict]:
    """次のレビューで直ったかを確かめる指摘（high・medium）。"""
    out = []
    for i in issues or []:
        if str(i.get("severity", "medium")).lower() in ("high", "medium"):
            out.append({k: i.get(k) for k in ("file", "line", "severity", "problem", "fix")})
    return out


def build_followup_section(prev: list[dict]) -> str:
    """前回の指摘（id 付き）をレビューの依頼文に足す部分。"""
    lines = ["## Previous findings (check whether each is fixed)"]
    for n, i in enumerate(prev, 1):
        loc = f"{i.get('file', '')}" + (f":{i['line']}" if i.get("line") else "")
        lines.append(f"{n}. [{i.get('severity', 'medium')}] {loc} {str(i.get('problem', ''))[:600]}"
                     + (f"\n   suggested fix: {str(i.get('fix', ''))[:300]}" if i.get("fix") else ""))
    return "\n".join(lines)


def apply_followup(data: dict, prev: list[dict]) -> dict:
    """2 回目以降のレビューの結果を整理する。
    issues = 直っていない前回の指摘（"followup": "not_fixed" など）＋ 新しい high・medium の指摘（low は捨てる）。
    fixed = 直った前回の指摘。状態の返事が無い前回の指摘は「未確認」として残す。"""
    status: dict[int, dict] = {}
    for p in data.get("previous") or []:
        if isinstance(p, dict):
            try:
                status[int(p.get("id"))] = p
            except (TypeError, ValueError):
                continue
    remaining, fixed = [], []
    for n, i in enumerate(prev, 1):
        st = status.get(n) or {}
        s = str(st.get("status") or "unknown").lower()
        if s == "fixed":
            fixed.append(i)
            continue
        item = dict(i)
        item["followup"] = s if s in ("not_fixed", "partial") else "unknown"
        if st.get("note"):
            item["problem"] = f"{i.get('problem', '')}（今回の確認: {st['note']}）"
        remaining.append(item)
    new = [i for i in data.get("issues") or [] if str(i.get("severity", "medium")).lower() in ("high", "medium")]
    dropped = len(data.get("issues") or []) - len(new)
    out = dict(data)
    out["issues"] = remaining + new
    out["new_issues"] = new
    out["fixed"] = fixed
    out["dropped_low"] = dropped
    out["ok"] = not out["issues"]
    return out


FOLLOWUP_LABEL = {"not_fixed": "未修正", "partial": "一部のみ修正", "unknown": "確認できず"}


def format_issue(i: dict) -> str:
    tag = FOLLOWUP_LABEL.get(str(i.get("followup") or ""), "")
    return (f"- [{i.get('severity', '?')}]" + (f"[前回の指摘・{tag}]" if tag else "") + f" {i.get('file', '')}"
            + (f":{i['line']}" if i.get("line") else "") + f" {i.get('problem', '')}\n  対処案: {i.get('fix', '')}")
