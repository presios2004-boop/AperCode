"""作業に合わせて思考モードと温度を切り替える（v2.11.29）。

AperCode が把握している作業の段階（計画・実装・修正・調査・完了確認・報告）・作業の種類（コード・操作・会話）・
会話モードから、LLM を呼ぶたびに設定（プロファイル）を選ぶ。LLM に「今どの作業か」を判定させない。

Qwen3 の推奨: 思考モードでは温度を下げすぎない（0.6 前後。低すぎると思考が同じところを回り続けやすい）。
温度を低くするのは、思考オフの機械的な手順（決まった操作・抽出）に限る。
llm.adaptive: false で無効（llm.temperature と llm.think をそのまま使う）。プロファイルの値は llm.profiles で上書きできる。
"""
from __future__ import annotations

import re

# think: on / off / auto（モデル既定）
DEFAULT_PROFILES: dict[str, dict] = {
    "idea":    {"think": "on",  "temperature": 0.9, "top_p": 0.95, "top_k": 40},   # アイデア出し・相談
    "chat":    {"think": "on",  "temperature": 0.7, "top_p": 0.9,  "top_k": 20},   # 会話・質問への回答・報告
    "plan":    {"think": "on",  "temperature": 0.6, "top_p": 0.95, "top_k": 20},   # 計画・調査・分析のまとめ・完了確認
    "code":    {"think": "on",  "temperature": 0.6, "top_p": 0.95, "top_k": 20},   # コードの設計・実装・修正方針
    "review":  {"think": "on",  "temperature": 0.6, "top_p": 0.95, "top_k": 20},   # レビュー（子エージェント）
    "execute": {"think": "off", "temperature": 0.2, "top_p": 0.8,  "top_k": 20},   # 決まった手順の実行（GUI・ブラウザの操作）
    "extract": {"think": "off", "temperature": 0.1, "top_p": 0.8,  "top_k": 20},   # 抽出・整形（指示書・教訓・要約の下書き）
}
LABEL = {"idea": "アイデア", "chat": "会話", "plan": "計画・調査", "code": "コード", "review": "レビュー",
         "execute": "操作", "extract": "抽出"}

IDEA_RE = re.compile(r"アイデア|アイディア|案を|案は|ブレスト|ブレインストーム|発想|ひらめ|提案して|考えを聞かせ|どう思う|"
                     r"brainstorm|ideas?\b|suggest", re.I)


def enabled(cfg) -> bool:
    return bool(cfg.get("llm.adaptive", True))


def profile(cfg, name: str) -> dict:
    """名前のプロファイル（既定値に llm.profiles.<name> を重ねたもの）。"""
    base = dict(DEFAULT_PROFILES.get(name) or DEFAULT_PROFILES["code"])
    over = (cfg.get("llm.profiles", {}) or {}).get(name) or {}
    if isinstance(over, dict):
        base.update({k: v for k, v in over.items() if v is not None})
    return base


def choose(*, chat_mode: bool, phase: str | None, kind: str | None, depth: int = 0, sub_mode: str | None = None,
           request: str = "") -> str:
    """作業の状態からプロファイル名を選ぶ。"""
    if depth > 0:
        return "review" if sub_mode in ("review", "explore") else "code"
    if chat_mode or phase == "report":
        return "idea" if IDEA_RE.search(request or "") else "chat"
    if not phase:
        return "code"                     # 作業モードで、作業フェーズを使っていない（phases.enabled: false など）
    if phase in ("plan", "investigate", "done_check"):
        return "idea" if phase == "plan" and IDEA_RE.search(request or "") else "plan"
    if phase in ("implement", "fix"):
        if kind == "operate":
            return "execute"
        if kind == "converse":
            return "chat"                 # 相手への返事を考える（会話の文章は思考ありで）
        return "code"
    return "code"


def call_args(cfg, name: str, provider: str) -> tuple[dict | None, str | None]:
    """（Ollama の options の上書き, think）。無効・Ollama 以外なら (None, None)。
    llm.think が on / off に固定されていれば、思考はそちらを優先する（ユーザーの明示的な設定）。"""
    if not enabled(cfg) or provider != "ollama":
        return None, None
    p = profile(cfg, name)
    opts = {k: p[k] for k in ("temperature", "top_p", "top_k") if p.get(k) is not None}
    fixed = str(cfg.get("llm.think", "auto") or "auto").lower()
    think = fixed if fixed in ("on", "off") else (str(p.get("think") or "auto").lower())
    return opts, (think if think in ("on", "off") else None)
