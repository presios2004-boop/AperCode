"""メインモデルの接続先（v2.11.43）: クラウド AI・LAN 上の LLM をメインモデルとして選べるようにする。

接続先は ~/.apercode/config.yaml の llm.endpoints に保存する（API キーを含むので本人だけが読める権限にする）。
API キーは画面にも AperCode（LLM）にも見せない。画面には「設定済み」かどうかだけを返す。

種類:
  ollama    … LAN 上の Ollama（例: http://192.168.1.10:11434）。API キーは任意（認証付きのリバースプロキシ向け）
  openai    … OpenAI 互換 API（LM Studio・vLLM・llama.cpp server・OpenRouter・OpenAI など。例: http://host:1234/v1）
  anthropic … Anthropic（Claude）の API（URL は空欄で既定）
"""
from __future__ import annotations

import re
import time
import uuid

TYPES = {"ollama": "LAN の Ollama", "openai": "OpenAI 互換 API", "anthropic": "Anthropic（Claude）"}
DEFAULT_CTX = {"ollama": 32768, "openai": 128000, "anthropic": 200000}
ANTHROPIC_URL = "https://api.anthropic.com"
ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,31}$")


class EndpointError(ValueError):
    pass


PATH_GETTER = None                       # サーバーが設定ファイルの場所を渡す（テストで差し替えられるように）


def _user_path():
    if PATH_GETTER is not None:
        return PATH_GETTER()
    from .config import USER_CONFIG_PATH
    return USER_CONFIG_PATH


def _read_user() -> dict:
    import yaml
    p = _user_path()
    if p.exists():
        try:
            return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception:  # noqa: BLE001
            return {}
    return {}


def _write_user(user: dict) -> None:
    import yaml
    p = _user_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(yaml.safe_dump(user, allow_unicode=True, sort_keys=False), encoding="utf-8")
    try:
        p.chmod(0o600)                       # API キーを含むので本人のみ読める
    except OSError:
        pass


def all_raw(cfg=None) -> list[dict]:
    """API キーを含む接続先の一覧（サーバーの中だけで使う）。"""
    eps = ((_read_user().get("llm") or {}).get("endpoints")) or []
    return [e for e in eps if isinstance(e, dict) and e.get("id")]


def get(eid: str) -> dict | None:
    return next((e for e in all_raw() if e.get("id") == eid), None)


def public(e: dict) -> dict:
    """画面に返す形（API キーは返さない）。"""
    t = str(e.get("type") or "openai")
    return {"id": e["id"], "name": str(e.get("name") or e["id"]), "type": t, "type_label": TYPES.get(t, t),
            "url": str(e.get("url") or ""), "key_set": bool(e.get("api_key")), "num_ctx": int(e.get("num_ctx") or DEFAULT_CTX.get(t, 32768)),
            "models": [str(m) for m in (e.get("models") or [])][:200], "model": str(e.get("model") or ""),
            "tested": e.get("tested") or None}


def list_public() -> list[dict]:
    return [public(e) for e in all_raw()]


def _clean_url(t: str, url: str) -> str:
    url = (url or "").strip().rstrip("/")
    if t == "anthropic" and not url:
        return ANTHROPIC_URL
    if url and not re.match(r"^https?://", url):
        raise EndpointError("URL は http:// か https:// で始めてください")
    if not url:
        raise EndpointError("URL を入力してください")
    return url


def upsert(data: dict) -> dict:
    """接続先を追加・更新する。api_key: None = 変更しない / "" = 消す。"""
    t = str(data.get("type") or "").strip()
    if t not in TYPES:
        raise EndpointError(f"種類が不正です: {t}")
    name = str(data.get("name") or "").strip()[:40]
    if not name:
        raise EndpointError("名前を入力してください（例: LAN の PC、Claude）")
    user = _read_user()
    llm = dict(user.get("llm") or {})
    eps = [e for e in (llm.get("endpoints") or []) if isinstance(e, dict) and e.get("id")]
    eid = str(data.get("id") or "").strip()
    cur = next((e for e in eps if e["id"] == eid), None) if eid else None
    if cur is None:
        base = re.sub(r"[^a-z0-9_-]+", "-", name.lower()).strip("-")[:20] or "ep"
        eid = base if ID_RE.match(base) and not any(e["id"] == base for e in eps) else f"{base[:12]}-{uuid.uuid4().hex[:6]}"
        cur = {"id": eid}
        eps.append(cur)
    cur.update({"name": name, "type": t, "url": _clean_url(t, str(data.get("url") or ""))})
    if data.get("api_key") is not None:
        k = str(data["api_key"]).strip()
        if k:
            cur["api_key"] = k
        else:
            cur.pop("api_key", None)
    try:
        n = int(data.get("num_ctx") or 0)
    except (TypeError, ValueError):
        n = 0
    cur["num_ctx"] = max(2048, n) if n else DEFAULT_CTX[t]
    if data.get("model") is not None:
        cur["model"] = str(data["model"]).strip()
    if isinstance(data.get("models"), list):
        cur["models"] = [str(m) for m in data["models"]][:200]
    llm["endpoints"] = eps
    user["llm"] = llm
    _write_user(user)
    return public(cur)


def set_models(eid: str, models: list[str], ok: bool, note: str = "") -> None:
    user = _read_user()
    llm = dict(user.get("llm") or {})
    for e in llm.get("endpoints") or []:
        if isinstance(e, dict) and e.get("id") == eid:
            if models:
                e["models"] = [str(m) for m in models][:200]
            e["tested"] = {"ok": ok, "ts": time.time(), "note": note[:200]}
    user["llm"] = llm
    _write_user(user)


def delete(eid: str) -> None:
    user = _read_user()
    llm = dict(user.get("llm") or {})
    eps = [e for e in (llm.get("endpoints") or []) if isinstance(e, dict) and e.get("id") != eid]
    llm["endpoints"] = eps
    user["llm"] = llm
    _write_user(user)


def headers(e: dict) -> dict:
    k = str(e.get("api_key") or "")
    if str(e.get("type")) == "anthropic":
        return {"x-api-key": k, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    return {"Authorization": f"Bearer {k}"} if k else {}


async def list_models(e: dict) -> list[str]:
    import httpx
    t, url = str(e.get("type")), str(e.get("url") or "").rstrip("/")
    async with httpx.AsyncClient(timeout=10) as c:
        if t == "ollama":
            r = await c.get(f"{url}/api/tags", headers=headers(e))
            r.raise_for_status()
            return [m["name"] for m in r.json().get("models", [])]
        if t == "anthropic":
            r = await c.get(f"{url}/v1/models", headers=headers(e))
            r.raise_for_status()
            return [m["id"] for m in r.json().get("data", [])]
        r = await c.get(f"{url}/models", headers=headers(e))
        r.raise_for_status()
        return [m.get("id") for m in r.json().get("data", []) if m.get("id")]


async def ping(e: dict, model: str) -> str:
    """モデルに短い返事をさせて、使えるかを確かめる。"""
    import httpx
    t, url = str(e.get("type")), str(e.get("url") or "").rstrip("/")
    msg = [{"role": "user", "content": "Reply with just: OK"}]
    async with httpx.AsyncClient(timeout=60) as c:
        if t == "ollama":
            r = await c.post(f"{url}/api/chat", headers=headers(e),
                             json={"model": model, "messages": msg, "stream": False, "options": {"num_predict": 16}})
            r.raise_for_status()
            return str((r.json().get("message") or {}).get("content") or "").strip()
        if t == "anthropic":
            r = await c.post(f"{url}/v1/messages", headers=headers(e), json={"model": model, "max_tokens": 16, "messages": msg})
            if r.status_code != 200:
                raise RuntimeError(f"{r.status_code}: {r.text[:300]}")
            return "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text").strip()
        r = await c.post(f"{url}/chat/completions", headers=headers(e), json={"model": model, "messages": msg, "max_tokens": 16})
        if r.status_code != 200:
            raise RuntimeError(f"{r.status_code}: {r.text[:300]}")
        ch = (r.json().get("choices") or [{}])[0]
        return str((ch.get("message") or {}).get("content") or "").strip()


def mask(text: str, e: dict) -> str:
    """エラー文などに API キーが混ざっても画面に出さない。"""
    k = str(e.get("api_key") or "")
    return text.replace(k, "***") if k and len(k) > 4 else text
