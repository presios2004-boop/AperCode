"""操作の記録からスキルを作る（v2.11.23）。

画面の「⏺ スキルを作成」で記録を始めると、以後ユーザーの指示で AperCode が実行した操作（アプリの起動・ウィンドウへの入力・
ブラウザでの検索やクリックなど）のうち、成功したものを順に記録する。「⏹ 記録を終える」で、記録した操作から次の 2 つを作る。
  - replay.json … LLM なしでそのまま再生できる手順（replay_skill ツールで再生。各操作は通常どおり承認・安全の確認を通る）
  - SKILL.md    … 手順の説明。再生が途中で失敗したとき（画面が変わったなど）に、LLM がこれを見て残りを進める
検索語・入力した文章・URL は「実行のたびに変える値（パラメータ）」にでき、replay_skill の params で差し替えられる。
"""
from __future__ import annotations

import copy
import json
import re
import time

# 記録する操作（外の世界に作用する・流れの一部になるもの）。ファイルの編集などの成果物づくりは記録しない
RECORDABLE = {
    "gui_launch", "gui_activate", "gui_input", "screenshot",
    "browser_open", "browser_click", "browser_type", "browser_press", "browser_scroll", "browser_read", "browser_screenshot",
    "browser_close", "web_search", "fetch_url", "run_command", "process_start",
}
# パラメータの候補にする引数（ツール → 引数名）
PARAM_ARGS = {"web_search": ("query",), "browser_type": ("text",), "gui_input": ("text",), "browser_open": ("url",),
              "fetch_url": ("url",), "gui_launch": ("command",)}
SUGGEST = {"query": "query", "text": "text", "url": "url", "command": "app"}
# 再生のときに次の操作の前に待つ秒数（起動・前面化の直後は画面が落ち着くまで待つ）
WAIT_AFTER = {"gui_launch": 1.5, "gui_activate": 0.8, "browser_open": 0.5}
MAX_STEPS = 60
PARAM_RE = re.compile(r"^[a-z][a-z0-9_]{0,30}$")


class RecorderError(ValueError):
    pass


def new() -> dict:
    return {"active": True, "started": time.time(), "steps": [], "requests": []}


def active(session) -> bool:
    return bool((getattr(session, "skill_rec", None) or {}).get("active"))


def record_step(session, tool: str, args: dict) -> bool:
    """成功した操作を記録する。記録中でない・対象外の操作なら何もしない。"""
    rec = getattr(session, "skill_rec", None) or {}
    if not rec.get("active") or tool not in RECORDABLE:
        return False
    steps = rec.setdefault("steps", [])
    if len(steps) >= MAX_STEPS:
        return False
    a = {k: v for k, v in (args or {}).items() if v is not None}
    if steps and steps[-1]["tool"] == tool and steps[-1]["args"] == a and tool in ("screenshot", "browser_read", "browser_screenshot"):
        return False                                   # 同じ確認の繰り返しは 1 回にまとめる
    steps.append({"tool": tool, "args": copy.deepcopy(a), "ts": time.time()})
    return True


def record_request(session, text: str) -> None:
    rec = getattr(session, "skill_rec", None) or {}
    t = (text or "").strip()
    if rec.get("active") and t:
        rec.setdefault("requests", []).append(t[:500])


def label(tool: str, args: dict) -> str:
    """手順の 1 行の説明（画面と SKILL.md 用）。"""
    a = args or {}
    q = lambda k, n=80: str(a.get(k, ""))[:n]  # noqa: E731
    if tool == "gui_launch":
        return f"アプリを起動: {q('command')}（ウィンドウ「{q('title', 40)}」を待つ）"
    if tool == "gui_activate":
        return f"ウィンドウを前面に出す: {q('window')}"
    if tool == "gui_input":
        parts = []
        if a.get("click"):
            parts.append(f"{a['click']} をクリック")
        if a.get("text"):
            parts.append(f"「{q('text', 60)}」を入力")
        if a.get("keys"):
            parts.append("キー " + "+".join(str(k) for k in a["keys"]))
        return f"ウィンドウ「{q('window', 40)}」に入力: " + ("、".join(parts) or "（操作なし）")
    if tool == "screenshot":
        return "画面のスクリーンショットを撮って確認する"
    if tool == "browser_open":
        return f"ブラウザで開く: {q('url', 120)}"
    if tool == "browser_click":
        return f"ブラウザでクリック: {q('target')}"
    if tool == "browser_type":
        return f"ブラウザで入力: {q('target', 50)} に「{q('text', 60)}」" + ("（送信）" if a.get("submit") else "")
    if tool == "browser_press":
        return f"ブラウザでキー: {q('key')}"
    if tool == "browser_scroll":
        return f"ブラウザでスクロール: {q('direction') or 'down'}"
    if tool == "browser_read":
        return "ブラウザのページを読む"
    if tool == "browser_screenshot":
        return "ブラウザのスクリーンショットを撮る"
    if tool == "browser_close":
        return "ブラウザを閉じる"
    if tool == "web_search":
        return f"Web 検索: 「{q('query')}」"
    if tool == "fetch_url":
        return f"ページを取得: {q('url', 120)}"
    if tool in ("run_command", "process_start"):
        return f"コマンドを実行: {q('command', 120)}"
    return f"{tool} {json.dumps(a, ensure_ascii=False)[:100]}"


def view(rec: dict) -> dict:
    """画面用: 記録した手順と、パラメータの候補。"""
    steps = (rec or {}).get("steps") or []
    cands: list[dict] = []
    seen: set[str] = set()
    for i, s in enumerate(steps):
        for k in PARAM_ARGS.get(s["tool"], ()):
            v = s["args"].get(k)
            if isinstance(v, str) and v.strip() and v not in seen:
                seen.add(v)
                base = SUGGEST.get(k, k)
                n = sum(1 for c in cands if c["suggest"].startswith(base))
                cands.append({"value": v, "tool": s["tool"], "arg": k, "step": i,
                              "suggest": base if n == 0 else f"{base}{n + 1}"})
    return {"active": bool((rec or {}).get("active")), "started": (rec or {}).get("started"),
            "requests": (rec or {}).get("requests") or [],
            "steps": [{"i": i, "tool": s["tool"], "label": label(s["tool"], s["args"])} for i, s in enumerate(steps)],
            "params": cands}


def _subst(obj, value: str, ph: str):
    if isinstance(obj, str):
        return obj.replace(value, ph)
    if isinstance(obj, list):
        return [_subst(x, value, ph) for x in obj]
    if isinstance(obj, dict):
        return {k: _subst(v, value, ph) for k, v in obj.items()}
    return obj


def build(rec: dict, name: str, description: str, keep: list[int] | None = None,
          params: list[dict] | None = None) -> tuple[str, dict, int]:
    """記録から（SKILL.md の本文, replay.json の中身, マスクした秘密情報の数）を作る。
    keep: 残す手順の番号（None なら全部）。params: [{"value": 記録した値, "name": パラメータ名, "description": 説明}]"""
    from .cloud import mask_secrets
    steps_all = (rec or {}).get("steps") or []
    idx = list(range(len(steps_all))) if keep is None else [i for i in keep if 0 <= int(i) < len(steps_all)]
    steps = [copy.deepcopy(steps_all[int(i)]) for i in idx]
    if not steps:
        raise RecorderError("スキルにする操作がありません（記録中に AperCode がアプリの起動・ブラウザの操作などを実行すると記録されます）")
    out_params: dict[str, dict] = {}
    for p in params or []:
        v, pn = str(p.get("value") or ""), str(p.get("name") or "").strip()
        if not v or not pn:
            continue
        if not PARAM_RE.match(pn):
            raise RecorderError(f"パラメータ名は英小文字・数字・_ で書いてください: {pn}")
        if pn in out_params:
            raise RecorderError(f"パラメータ名が重複しています: {pn}")
        out_params[pn] = {"default": v, "description": str(p.get("description") or "").strip()[:200]}
        for s in steps:
            s["args"] = _subst(s["args"], v, "{{" + pn + "}}")
    masked = 0
    replay_steps = []
    for s in steps:
        txt, n = mask_secrets(json.dumps(s["args"], ensure_ascii=False))
        masked += n
        try:
            args = json.loads(txt)
        except ValueError:
            args = s["args"]
        st = {"tool": s["tool"], "args": args}
        if WAIT_AFTER.get(s["tool"]):
            st["wait_after"] = WAIT_AFTER[s["tool"]]
        replay_steps.append(st)
    replay = {"version": 1, "params": out_params, "steps": replay_steps}
    reqs = (rec or {}).get("requests") or []
    lines = [f"# {name}", "", description.strip(), ""]
    if reqs:
        lines += ["## 記録したときのユーザーの依頼", *[f"- {r.splitlines()[0][:200]}" for r in reqs[:8]], ""]
    lines += ["## 実行のしかた",
              f"1. まず replay_skill（name: \"{name}\"）で replay.json の手順をそのまま再生する。"
              + ("ユーザーの依頼に合わせて params を渡す。" if out_params else ""),
              "2. 再生が途中で失敗したとき（画面・ページの変化、ウィンドウが見つからないなど）は、失敗した手順から先を、"
              "下の手順を見ながら gui_* / browser_* などのツールで続ける。スクリーンショットで画面を確かめてから操作する。",
              "3. 終わったら、結果（読んだ内容・画面の状態）をユーザーに伝える。", ""]
    if out_params:
        lines += ["## パラメータ（実行のたびに変える値）"]
        for pn, d in out_params.items():
            lines.append(f"- `{pn}`: {d['description'] or '（説明なし）'}（記録したときの値: 「{d['default'][:80]}」）")
        lines.append("")
    lines += ["## 手順（記録した操作）"]
    for n, s in enumerate(replay_steps, 1):
        lines.append(f"{n}. {label(s['tool'], s['args'])}")
    lines += ["", "（AperCode の「⏺ スキルを作成」で記録した操作から作ったスキル。座標でのクリックは画面の大きさや配置が変わるとずれる）"]
    return "\n".join(lines) + "\n", replay, masked


def fill(replay: dict, values: dict | None) -> list[dict]:
    """パラメータ（{{name}}）を値に置き換えた手順。値が無ければ記録したときの値を使う。"""
    vals = {k: str(v) for k, v in (values or {}).items() if v is not None}
    params = replay.get("params") or {}
    unknown = [k for k in vals if k not in params]
    if unknown:
        raise RecorderError(f"このスキルに無いパラメータ: {', '.join(unknown)}（使えるもの: {', '.join(params) or 'なし'}）")
    steps = copy.deepcopy(replay.get("steps") or [])
    for pn, d in params.items():
        v = vals.get(pn, str((d or {}).get("default", "")))
        for s in steps:
            s["args"] = _subst(s["args"], "{{" + pn + "}}", v)
    for s in steps:
        if s.get("tool") not in RECORDABLE:
            raise RecorderError(f"再生できない操作が含まれています: {s.get('tool')}")
    return steps
