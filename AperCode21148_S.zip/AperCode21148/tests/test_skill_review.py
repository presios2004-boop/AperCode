"""v2.11.34 の回帰テスト: AperCode が作った・変えたスキルをレビューし、要修正なら直るまで使わない。"""
from __future__ import annotations

import asyncio
import uuid

from codeagent import skill_review as SR
from codeagent import skills as SK

GOOD = "# CSV の整形\n\n## 手順\n1. read_file で CSV を読む\n2. 列をそろえて write_file で書く\n\n## 完了の判定\n- 列数がそろっている\n"
BAD = ("キーボードショートカットを表示するには、はてなマークを押してください。\n新しいチャット\n"
       "順番にお見せしますので修正お願いします。出力はMD形式でお願いします。\n\n"
       "---\nname: other-skill\ndescription: 別のスキル\n---\n\n# 別のスキル\n手順\n\n# さらに別\n\n# もう一つ\n")


class _Cfg:
    def __init__(self, d):
        self.data = {"skills": {"dir": str(d), "review": {"enabled": True, "llm": True}}, "cloud": {"enabled": False}}

    def get(self, k, default=None):
        cur = self.data
        for x in k.split("."):
            if not isinstance(cur, dict) or x not in cur:
                return default
            cur = cur[x]
        return cur


def test_lint_finds_broken_skill(tmp_path):
    cfg = _Cfg(tmp_path / "skills")
    SK.save(cfg, "good-one", "CSV を整形するスキル。列がずれた CSV を直すときに使う", GOOD)
    assert [i for i in SR.lint(tmp_path / "skills" / "good-one") if i["severity"] == "error"] == []
    SK.save(cfg, "bad-one", "壊れたスキルのテスト用の説明です", BAD, files={"run.py": "def f(:\n  pass\n"})
    li = SR.lint(tmp_path / "skills" / "bad-one")
    probs = " / ".join(i["problem"] for i in li if i["severity"] == "error")
    assert "別のスキルの YAML" in probs and "Web 画面の文字" in probs and "Python の文法エラー" in probs
    assert any("相談相手への依頼" in i["problem"] for i in li) and any("大見出し" in i["problem"] for i in li)
    # YAML なし・巨大
    d = tmp_path / "skills" / "raw"
    d.mkdir()
    (d / "SKILL.md").write_text("# 手順\n" + "あ" * 61_000, encoding="utf-8")
    p = " / ".join(i["problem"] for i in SR.lint(d))
    assert "YAML" in p and "長すぎます" in p


def test_parse_and_decide():
    d = SR.parse_result('前置き {"verdict": "fix", "summary": "ほぼ良い", "issues": [{"severity": "high", "where": "手順 2", '
                        '"problem": "送信前の確認がない", "fix": "確認を入れる"}]} 後書き')
    assert d["verdict"] == "fix" and d["issues"][0]["severity"] == "high"
    assert SR.decide([], d) == "needs_fix"                            # high があれば要修正
    assert SR.decide([], {"verdict": "fix", "issues": [{"severity": "medium"}]}) == "ok"
    assert SR.decide([{"severity": "error"}], {"verdict": "ok", "issues": []}) == "needs_fix"
    assert SR.parse_result("JSON ではない") is None


def test_review_blocks_use_until_fixed(tmp_path):
    cfg = _Cfg(tmp_path / "skills")
    SK.save(cfg, "bad-one", "壊れたスキルのテスト用の説明です", BAD)
    calls = []

    async def complete(system, text):
        calls.append(text)
        return '{"verdict": "ok", "summary": "問題なし", "issues": []}'
    r = asyncio.run(SR.review(cfg, "bad-one", complete=complete))
    assert r["status"] == "needs_fix" and calls == []                 # 機械的な点検で要修正なら LLM は後回し
    sk = [s for s in SK.list_skills(cfg) if s["name"] == "bad-one"][0]
    assert sk["status"] == "needs_fix" and sk["review"]["issues"]
    try:
        SK.get(cfg, "bad-one")
        raise AssertionError("要修正のスキルが使えてしまった")
    except SK.SkillError as e:
        assert "要修正" in str(e) and "edit_skill" in str(e)
    assert "bad-one" not in SK.prompt_block(cfg)
    SK.edit(cfg, "bad-one", content=GOOD)
    r = asyncio.run(SR.review(cfg, "bad-one", complete=complete))
    assert r["status"] == "ok" and len(calls) == 1 and r["llm"]["by"] == "メイン LLM" and r["stage"] == "main"   # 1 回に 1 段
    assert SK.get(cfg, "bad-one")["name"] == "bad-one"
    # ユーザーが「このまま使う」を選べば使える
    SK.edit(cfg, "bad-one", content=BAD)
    asyncio.run(SR.review(cfg, "bad-one", complete=complete))
    SK.confirm(cfg, "bad-one")
    sk = [s for s in SK.list_skills(cfg) if s["name"] == "bad-one"][0]
    assert sk["status"] == "ok" and sk["review"]["overridden"]


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def test_agent_save_skill_gets_review_and_fixes(h):
    proj = h.project(with_test=False)
    sk_dir = h.root / "skills"
    script = [("tools", [call("save_skill", name="csv-fix", description="CSV を整形するスキル。列がずれた CSV に使う",
                              instructions=BAD)]),
              ("tools", [call("edit_skill", name="csv-fix", content=GOOD)]),
              ("text", "直しました")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "brief.enabled": False, "skills.dir": str(sk_dir),
                                                 "cloud.enabled": False, "permissions.save_skill": "allow",
                                                 "permissions.edit_skill": "allow"})

    async def fake_complete(system, text, model=None, options=None, *a, **k):
        return '{"verdict": "fix", "summary": "手順は具体的", "issues": [{"severity": "low", "where": "-", "problem": "例が少ない", "fix": ""}]}'
    llm.complete = fake_complete
    h.run(agent, s, "CSV を整形するスキルを作って")
    outs = [e["output"] for e in h.of("tool_result") if e.get("name") in ("save_skill", "edit_skill")]
    assert "要修正" in outs[0] and "edit_skill" in outs[0] and "Web 画面の文字" in outs[0]
    assert "スキルのレビュー" in outs[1] and "要修正" not in outs[1] and "メイン LLM" in outs[1]
    sk = [x for x in SK.list_skills(agent.cfg) if x["name"] == "csv-fix"][0]
    assert sk["status"] == "ok" and sk["review"]["status"] == "ok"


def test_review_api(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from pathlib import Path
    from codeagent.config import Config
    from codeagent.server import app as APP
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    root = Path(__file__).resolve().parents[1]
    cfg = Config.load(root / "config.yaml" if (root / "config.yaml").exists() else root / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False, ("cloud", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("skills", "dir"): str(tmp_path / "skills"), ("workspace", "root"): str(tmp_path),
                 ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    (tmp_path / "w").mkdir()
    SK.save(cfg, "bad-one", "壊れたスキルのテスト用の説明です", BAD)
    c = TestClient(APP.create_app(cfg))
    r = c.post("/api/skills/bad-one/review").json()
    assert r["status"] == "needs_fix" and r["review"]["issues"]
    sk = [x for x in c.get("/api/skills").json()["skills"] if x["name"] == "bad-one"][0]
    assert sk["status"] == "needs_fix"
    assert c.post("/api/skills/nope/review").status_code == 400


def test_skill_review_tool_reads_saved_findings(h):
    """v2.11.35: 既にあるスキルのレビュー結果（medium・low も含めて全部）を AperCode が skill_review で読める。"""
    proj = h.project(with_test=False)
    sk_dir = h.root / "skills"
    agent0, *_ = h.make([], proj, {"skills.dir": str(sk_dir)})
    SK.save(agent0.cfg, "x-post", "X に投稿するスキル。トピックを調べてポストする", GOOD)
    saved = {"status": "needs_fix", "lint": [], "ts": 1.0, "sha": "x",
             "llm": {"verdict": "fix", "summary": "送信前の確認がない", "by": "テスト",
                     "issues": [{"severity": "high", "where": "ステップ5", "problem": "送信前の確認がない", "fix": "承認を得る"},
                                {"severity": "medium", "where": "ハッシュタグ", "problem": "#LaocalLLM は誤記", "fix": "#LocalLLM"},
                                {"severity": "low", "where": "ステップ6", "problem": "Ctrl+W ではウィンドウが閉じない", "fix": ""}]}}
    SK.set_review(agent0.cfg, "x-post", saved)
    script = [("tools", [call("skill_review")]), ("tools", [call("skill_review", name="x-post")]),
              ("tools", [call("use_skill", name="x-post")]), ("text", "読みました")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "brief.enabled": False, "skills.dir": str(sk_dir)})
    h.run(agent, s, "レビューで要修正になったスキルを直して")
    outs = [e["output"] for e in h.of("tool_result") if e.get("name") in ("skill_review", "use_skill")]
    assert "x-post: ✗ 要修正（指摘 3 件）" in outs[0]
    assert "#LaocalLLM は誤記" in outs[1] and "Ctrl+W" in outs[1] and "直し方: 承認を得る" in outs[1]
    assert outs[1].index("[high]") < outs[1].index("[medium]") < outs[1].index("[low]")
    assert "ユーザーに質問" in outs[1]                                   # 方針の判断は勝手に決めない
    assert "skill_review（name: x-post）" in outs[2]                    # use_skill のエラーから案内する
    assert "skill_review" in agent.llm.toolsets[0]
