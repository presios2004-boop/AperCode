"""v2.11.30 の回帰テスト: Java のコンパイル確認と、Maven / Gradle のテストの検出。"""
from __future__ import annotations

import asyncio
import shutil

import pytest

from codeagent import verify as V

needs_javac = pytest.mark.skipif(not shutil.which("javac"), reason="javac が無い")


@needs_javac
def test_java_compile_ok_and_error(tmp_path):
    (tmp_path / "src" / "app").mkdir(parents=True)
    util = tmp_path / "src" / "app" / "Util.java"
    util.write_text("package app;\npublic class Util { public static int twice(int x) { return x * 2; } }\n")
    main = tmp_path / "src" / "app" / "Main.java"
    main.write_text("package app;\npublic class Main { public static void main(String[] a) { System.out.println(Util.twice(2)); } }\n")
    r = asyncio.run(V.check_file(main, tmp_path))
    assert r is not None and r.ok and "javac" in r.tools, r.output       # 同じパッケージの別ファイルも解決できる
    assert not list(tmp_path.rglob("*.class"))                              # クラスファイルで作業ディレクトリを汚さない
    main.write_text("package app;\npublic class Main { public static void main(String[] a) { int x = \"s\"; } }\n")
    r = asyncio.run(V.check_file(main, tmp_path))
    assert not r.ok and "incompatible types" in r.output


def test_java_build_projects(tmp_path):
    (tmp_path / "pom.xml").write_text("<project/>")
    (tmp_path / "src").mkdir()
    f = tmp_path / "src" / "A.java"
    f.write_text("public class A {}\n")
    r = asyncio.run(V.check_file(f, tmp_path))
    assert r.ok and "Maven / Gradle" in (r.skipped or "")
    if shutil.which("mvn"):
        assert V.detect_test_command(tmp_path).startswith("mvn -q -B -Dmaven.repo.local=.apercode/m2 test")
    g = tmp_path / "g"
    g.mkdir()
    (g / "build.gradle").write_text("")
    (g / "gradlew").write_text("#!/bin/sh\n")
    assert V.detect_test_command(g) == "GRADLE_USER_HOME=.apercode/gradle ./gradlew test -q"
