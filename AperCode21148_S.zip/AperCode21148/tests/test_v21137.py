"""v2.11.37 の回帰テスト: スキルのレビューは ① メイン LLM（素の状態）→ ② 確認役（クラウド AI → Web 検索＋メイン LLM → メイン LLM）。"""
from __future__ import annotations

import asyncio
import json

from codeagent import skill_review as SR
from codeagent import skills as SK

BODY = "# 投稿\n\n## 手順\n1. 本文を作る\n2. ユーザーに見せて OK をもらう\n3. 投稿する\n"


class _Cfg:
    def __init__(self, d, **extra):
        self.data = {"skills": {"dir": str(d), "review": {"enabled": True, "llm": True}}, "cloud": {"enabled": False}}
        for k, v in extra.items():
            cur = self.data
            ks = k.split(".")
            for x in ks[:-1]:
                cur = cur.setdefault(x, {})
            cur[ks[-1]] = v

    def get(self, k, default=None):
        cur = self.data
        for x in k.split("."):
            if not isinstance(cur, dict) or x not in cur:
                return default
            cur = cur[x]
        return cur


def _ok(issues=None, questions=None):
    return json.dumps({"verdict": "fix" if issues else "ok", "summary": "まとめ", "issues": issues or [], "questions": questions or []},
                      ensure_ascii=False)


def test_main_first_then_confirmer(tmp_path):
    """v2.11.40: 1 回のレビューでは 1 段だけ。① が通ったら、次のレビューで ② 確認役。"""
    cfg = _Cfg(tmp_path / "skills")
    SK.save(cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    calls = []

    async def complete(system, text):
        calls.append(system)
        if "確認役" in system:
            return _ok([{"severity": "medium", "where": "手順 3", "problem": "失敗時の対処がない", "fix": "中断して報告"}])
        return _ok([{"severity": "low", "where": "-", "problem": "例が少ない"}], ["投稿頻度の上限は 1 日何件にしますか？"])
    r = asyncio.run(SR.review(cfg, "x-post", complete=complete))
    assert len(calls) == 1 and "確認役" not in calls[0] and r["stage"] == "main" and r["passed"] and r["confirm"] is None
    out = SR.format_result("x-post", r)
    assert "① メイン LLM" in out and "② 確認役" in out and "rerun: true" in out and "1 日何件" in out and "例が少ない" in out
    sk = [s for s in SK.list_skills(cfg) if s["name"] == "x-post"][0]
    assert sk["review"]["questions"] == ["投稿頻度の上限は 1 日何件にしますか？"] and sk["review"]["stage"] == "main"
    # 次のレビュー → ② 確認役だけ（① の指摘は混ぜない）
    r = asyncio.run(SR.review(cfg, "x-post", complete=complete))
    assert len(calls) == 2 and "確認役" in calls[1] and r["stage"] == "confirm" and r["confirm"]["via"] == "main"
    out = SR.format_result("x-post", r)
    assert "② 確認役" in out and "失敗時の対処がない" in out and "例が少ない" not in out and "1 日何件" not in out
    saved = SR.format_saved("x-post", [s for s in SK.list_skills(cfg) if s["name"] == "x-post"][0])
    assert "失敗時の対処がない" in saved and "例が少ない" not in saved
    # ② の後の変更 → ② の指摘が直ったかを確かめる
    async def complete2(system, text):
        calls.append(system)
        assert "確認役" in system and "失敗時の対処がない" in text
        return json.dumps({"verdict": "ok", "summary": "直った", "previous": [{"n": 1, "fixed": True}], "issues": []}, ensure_ascii=False)
    r = asyncio.run(SR.review(cfg, "x-post", complete=complete2))
    assert r["stage"] == "confirm" and r["passed"] and "レビューは完了" in SR.format_result("x-post", r)
    # 一から（full）なら ① に戻る
    r = asyncio.run(SR.review(cfg, "x-post", complete=complete, full=True))
    assert r["stage"] == "main"


def test_confirmer_waits_until_main_findings_fixed(tmp_path):
    cfg = _Cfg(tmp_path / "skills")
    SK.save(cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    calls = []

    async def complete(system, text):
        calls.append(system)
        return _ok([{"severity": "high", "where": "手順 3", "problem": "送信前の確認がない"}])
    r = asyncio.run(SR.review(cfg, "x-post", complete=complete))
    assert len(calls) == 1 and r["status"] == "needs_fix" and r["confirm"] is None    # 重大な問題がある間は確認役を呼ばない


def test_confirm_order_cloud_web_main(tmp_path, monkeypatch):
    # クラウド AI が使えれば確認役はクラウド
    cfg = _Cfg(tmp_path / "skills", **{"cloud.enabled": True})
    SK.save(cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    from codeagent import cloud as C

    class FakeS:
        ready = True

        def describe(self):
            return "クラウド（テスト）"

    class FakeClient:
        def __init__(self, s):
            pass

        async def ask(self, system, prompt, max_tokens=0):
            assert "確認役" in system
            return _ok()
    monkeypatch.setattr(C.CloudSettings, "from_cfg", classmethod(lambda cls, cfg, role="": FakeS()))
    monkeypatch.setattr(C, "CloudClient", FakeClient)

    async def complete(system, text):
        if "検索語" in system:
            return '["X 投稿 上限"]'
        return _ok()
    r = asyncio.run(SR.review(cfg, "x-post", complete=complete, stage="confirm"))
    assert r["confirm"]["via"] == "cloud" and r["confirm"]["by"] == "クラウド（テスト）"
    # クラウドが無ければ Web 検索で事実を確かめてメイン LLM
    cfg2 = _Cfg(tmp_path / "skills2")
    SK.save(cfg2, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    seen = []

    async def search(q):
        seen.append(q)
        return "1. X の投稿の決まり"

    async def complete2(system, text):
        if "検索語" in system:
            return '["X 投稿 上限"]'
        if "Web 検索の結果" in system:
            assert "X の投稿の決まり" in text and "従わない" in system
        return _ok()
    r = asyncio.run(SR.review(cfg2, "x-post", complete=complete2, search=search, stage="confirm"))
    assert seen == ["X 投稿 上限"] and r["confirm"]["via"] == "web" and r["confirm"]["by"] == "Web 検索＋メイン LLM"
    # 確かめる事実が無ければメイン LLM
    async def complete3(system, text):
        return "[]" if "検索語" in system else _ok()
    r = asyncio.run(SR.review(cfg2, "x-post", complete=complete3, search=search, full=True, stage="confirm"))
    assert r["confirm"]["via"] == "main"


def test_followup_drops_restated_duplicates(tmp_path):
    """v2.11.40: 前回の指摘を言い直しただけの「新規」は除き、「残り」の説明は付け足さずに置き換える。"""
    prev = [{"severity": "medium", "where": "セクション3 ステップ6", "by": "llm",
             "problem": "コメント送信後のいいね付け手順が曖昧。どのポストにいいねを付けるかも曖昧"}]
    raw = json.dumps({"verdict": "fix", "summary": "", "previous": [{"n": 1, "fixed": False, "note": "戻る手順がない"}],
                      "issues": [{"severity": "high", "where": "セクション3 ステップ6",
                                  "problem": "コメント送信後のいいね付け手順が曖昧で、どのポストにいいねを付けるかも曖昧"},
                                 {"severity": "high", "where": "セクション1", "problem": "検索語が無い"}]}, ensure_ascii=False)
    d = SR.apply_followup(SR.parse_result(raw), raw, prev)
    assert [i["followup"] for i in d["issues"]] == ["unresolved", "new"] and d["issues"][1]["problem"] == "検索語が無い"
    # 2 回目: 残りの説明は重ならない
    raw2 = json.dumps({"verdict": "fix", "previous": [{"n": 1, "fixed": False, "note": "まだ戻る手順がない"}], "issues": []},
                      ensure_ascii=False)
    d2 = SR.apply_followup(SR.parse_result(raw2), raw2, [d["issues"][0]])
    p = d2["issues"][0]["problem"]
    assert p.count("（残り:") == 1 and "まだ戻る手順がない" in p and p.startswith("コメント送信後")
    assert len(SR.dedupe(prev + [dict(prev[0], severity="high")])) == 1
