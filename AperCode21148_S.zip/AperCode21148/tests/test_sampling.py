"""v2.11.29 の回帰テスト: 作業に合わせて思考モードと温度を切り替える。"""
from __future__ import annotations

import uuid

from codeagent import sampling as SM


class _Cfg:
    def __init__(self, d):
        self.d = d

    def get(self, k, default=None):
        return self.d.get(k, default)


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def test_choose():
    assert SM.choose(chat_mode=True, phase=None, kind=None, request="使い方を教えて") == "chat"
    assert SM.choose(chat_mode=True, phase=None, kind=None, request="新しい EA のアイデアを出して") == "idea"
    assert SM.choose(chat_mode=False, phase="plan", kind=None) == "plan"
    assert SM.choose(chat_mode=False, phase="investigate", kind="code") == "plan"
    assert SM.choose(chat_mode=False, phase="implement", kind="code") == "code"
    assert SM.choose(chat_mode=False, phase="fix", kind="code") == "code"
    assert SM.choose(chat_mode=False, phase="implement", kind="operate") == "execute"
    assert SM.choose(chat_mode=False, phase="implement", kind="converse") == "chat"
    assert SM.choose(chat_mode=False, phase="implement", kind="code", depth=1, sub_mode="review") == "review"


def test_call_args():
    opts, think = SM.call_args(_Cfg({}), "execute", "ollama")
    assert opts["temperature"] == 0.2 and think == "off"
    opts, think = SM.call_args(_Cfg({}), "code", "ollama")
    assert opts["temperature"] == 0.6 and think == "on"                       # Qwen3 の推奨: 思考ありは 0.6 前後
    opts, think = SM.call_args(_Cfg({"llm.think": "off"}), "code", "ollama")
    assert think == "off"                                                    # 思考を固定していればそちらを優先
    opts, _ = SM.call_args(_Cfg({"llm.profiles": {"idea": {"temperature": 1.1}}}), "idea", "ollama")
    assert opts["temperature"] == 1.1 and opts["top_k"] == 40
    assert SM.call_args(_Cfg({"llm.adaptive": False}), "code", "ollama") == (None, None)
    assert SM.call_args(_Cfg({}), "code", "anthropic") == (None, None)


def test_agent_passes_profile_to_llm(h):
    proj = h.project(with_test=False)
    seen = []
    agent, llm, store, s = h.make([("tools", [call("list_dir", path=".")]), ("text", "done")], proj,
                                  {"phases.enabled": False, "brief.enabled": False})
    orig = llm.chat

    def spy(system, messages, tools, model=None, options=None, think=None, *a, **k):
        seen.append((options, think))
        return orig(system, messages, tools, model, options, think, *a, **k)
    llm.chat = spy
    h.run(agent, s, "ファイルを確認して")
    assert seen and seen[0][0] and seen[0][0]["temperature"] == 0.6 and seen[0][1] == "on"


def test_think_fallback_for_models_without_thinking():
    import asyncio
    from codeagent.llm import LLMClient
    from codeagent.config import Config
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    cfg = Config.load(root / "config.yaml" if (root / "config.yaml").exists() else root / "config.example.yaml")
    c = LLMClient(cfg)
    calls = []

    async def fake(system, messages, tools, model, options=None, think=None):
        calls.append(think)
        if think is not None:
            raise RuntimeError('"llama3.1:8b" does not support thinking')
        yield ("text", "ok")
        yield ("done", {})
    c._chat = fake

    async def run():
        return [ev async for ev in c.chat("s", [{"role": "user", "content": "x"}], [], "llama3.1:8b", think="on")]
    evs = asyncio.run(run())
    assert ("text", "ok") in evs and calls == ["on", None]
    calls.clear()
    asyncio.run(run())
    assert calls == [None]                                                   # 2 回目からは think を送らない
