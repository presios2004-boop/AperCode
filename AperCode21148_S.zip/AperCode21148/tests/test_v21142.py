"""v2.11.42 の回帰テスト: 会話から作業へ移るときのロスを減らす。
- 会話モードで set_plan を呼んだら、作業を始めるか確かめ、出そうとした計画を作業の開始後に引き継ぐ
- 会話で話し合ってから作業を始めたときは、細かい不足を質問せず仮定にする
- 「OK、進めて」のような短い返事で認めた提案の削除は、もう一度聞かない
"""
from __future__ import annotations

import uuid

from codeagent import phases as PH
from codeagent.agent import Agent
from codeagent.tools import phase_tools as PT


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def _work_on_switch(h):
    async def approve(req):
        return "work" if req.get("kind") == "mode_switch" else "allow"
    h.approve = approve


def test_set_plan_in_chat_mode_switches_and_carries_plan(h):
    proj = h.project(with_test=False)
    script = [("tools", [call("set_plan", steps=["x-comment の内容を x-explore-follow に取り込む", "x-comment を削除する"])]),
              ("text", "了解しました")]
    _work_on_switch(h)
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": True, "brief.clarify": "ask"}, mode="auto")
    llm.clarify = "QUESTION: クラウド添削を含めますか？ A. 含める B. 含めない"
    h.run(agent, s, "では x-comment を x-explore-follow に統合してください")
    s = store.load(s.id)
    assert s.working                                                          # 作業へ切り替えた
    nudges = [m["content"] for m in s.messages if m.get("kind") == "nudge"]
    assert any("会話の中で出そうとした計画" in n and "x-explore-follow に取り込む" in n for n in nudges)
    assert not s.clarify_pending                                              # 会話で話し合ったので細かい不足は質問しない
    assert s.pending_work == {}


def test_held_back_action_is_reported_after_switch(h):
    proj = h.project(with_test=False)
    script = [("tools", [call("write_file", path="a.md", content="x\n")]), ("text", "了解")]
    _work_on_switch(h)
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": True}, mode="auto")
    h.run(agent, s, "a.md に x と書くファイルを作ってください")
    nudges = [m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge"]
    assert any("止めた操作（まだ実行していない" in n and "write_file" in n for n in nudges)


def test_approved_proposal_counts_for_deletion():
    msgs = [{"role": "user", "content": "x-explore-follow と x-comment を統合したいです"},
            {"role": "assistant", "content": "統合の案です: 1) 1件モードを追加 2) 統合後に x-comment フォルダを削除します。よろしいですか？", "tool_calls": []},
            {"role": "user", "content": "はい。それでOKです。進めてください"}]
    ap = Agent._approved_proposal(msgs, "はい。それでOKです。進めてください")
    assert "削除" in ap
    assert Agent._approved_proposal(msgs, "x-explore-follow と x-comment を統合したいです") == ""   # 長い依頼は対象外

    class Ctx:
        phase = PH.PhaseState(active=True, phase="plan")
        request = "はい。それでOKです。進めてください"
        approved = ap
    import asyncio
    out = asyncio.run(PT.set_plan(Ctx(), {"steps": ["1件モードを追加", "x-comment フォルダを削除"]}))
    assert "計画を登録しました" in out                                         # もう一度は聞かない
    Ctx.approved = ""
    Ctx.phase = PH.PhaseState(active=True, phase="plan")
    try:
        asyncio.run(PT.set_plan(Ctx(), {"steps": ["x-comment フォルダを削除"]}))
        raise AssertionError
    except Exception as e:
        assert "削除の指示がありません" in str(e)                               # 認めた提案が無ければこれまでどおり確かめる
