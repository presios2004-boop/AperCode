"""v2.11.30 の回帰テスト: ニュース・見方の変化・一般の調査の主張・市場予想と結果・イベント時の値動き。"""
from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from codeagent import research as R

NOW = datetime(2026, 10, 16)


def _src(inst, pub, url=None, stype="bank"):
    return {"institution": inst, "url": url or f"https://{inst}.example/{pub}", "published": pub, "type": stype}


def test_news_revisions_and_conflict(tmp_path):
    R.save_note(tmp_path, {"topic": "USDJPY", "source": _src("MUFG", "2026-09-01"), "stance": "down",
                           "targets": [{"level": 140}], "quotes": ["a"]})
    R.save_note(tmp_path, {"topic": "USDJPY", "source": _src("MUFG", "2026-10-10"), "stance": "up",
                           "targets": [{"level": 155}], "quotes": ["b"]})
    R.save_note(tmp_path, {"topic": "USDJPY", "source": _src("Mizuho", "2026-10-12"), "stance": "up", "quotes": ["c"]})
    for i, d in enumerate(("2026-10-13", "2026-10-14", "2026-10-15")):
        R.save_note(tmp_path, {"topic": "USDJPY", "kind": "news", "impact": "down", "importance": "high",
                               "headline": f"円高要因 {i}", "source": _src(f"News{i}", d, stype="media"), "quotes": ["n"]})
    data, md = R.summarize(tmp_path, "USDJPY", now=NOW)
    assert data["tally"]["up"] == 2 and data["tally"]["down"] == 0          # ニュースは見通しの票に入れない（古い MUFG は新しい方と比べる）
    assert data["news"]["count"] == 3 and data["news"]["tilt"] < 0
    rv = data["revisions"][0]
    assert rv["institution"] == "MUFG" and rv["stance_from"] == "down" and rv["stance_to"] == "up" and rv["target_to"] == 155
    assert any("ニュースの流れ" in c and "逆向き" in c for c in data["conflicts"])
    assert "## 見方の変化" in md and "MUFG: 下落 → 上昇" in md and "## 直近 14 日のニュースの流れ" in md


def test_claims_general_research(tmp_path):
    R.save_note(tmp_path, {"topic": "local-llm", "kind": "claim", "subject": "Qwen3 の思考モードの温度",
                           "claim": "思考モードでは温度 0.6 を推奨", "source": _src("Qwen", "2026-05-01", stype="official"),
                           "quotes": ["q"]})
    R.save_note(tmp_path, {"topic": "local-llm", "kind": "claim", "subject": "Qwen3 の思考モードの温度",
                           "claim": "温度 0 が最も正確", "source": _src("Blog", "2025-01-01", stype="blog"), "quotes": ["q"]})
    data, md = R.summarize(tmp_path, "local-llm", now=NOW, max_age_days=365)
    g = data["claims"][0]
    assert g["check"] and len(g["items"]) == 2 and g["items"][1]["stale"]
    assert "⚠ 主張が複数あります" in md and "（古い）" in md and data["used"] == 0
    with pytest.raises(R.ResearchError, match="subject"):
        R.save_note(tmp_path, {"topic": "x", "kind": "claim", "claim": "c", "source": _src("A", "2026-01-01"), "quotes": ["q"]})


def _csv(path, start, hours, f):
    lines = ["time,open,high,low,close"]
    for i in range(hours):
        t = start + timedelta(hours=i)
        p = f(i)
        lines.append(f"{t:%Y.%m.%d %H:%M},{p:.3f},{p + 0.05:.3f},{p - 0.05:.3f},{p:.3f}")
    path.write_text("\n".join(lines))


def test_event_surprise_and_reaction(tmp_path):
    start = datetime(2026, 1, 1)
    days = [5, 12, 19, 26]                                                # 4 回のイベント（10:00）。上振れは上昇、下振れは下落
    ev = []
    for k, dday in enumerate(days):
        ev.append({"date": f"2026-01-{dday:02d}", "kind": "CPI", "time": "10:00", "source": "https://stat.example/cpi",
                   "forecast": 3.0, "actual": 3.2 if k % 2 == 0 else 2.8})
    R.save_events(tmp_path, "USDJPY", ev)
    R.save_events(tmp_path, "USDJPY", [{"date": "2026-01-05", "kind": "CPI", "source": "https://stat.example/cpi", "previous": 2.9}])
    e0 = R.load_events(tmp_path, "USDJPY")[0]
    assert e0["forecast"] == 3.0 and e0["actual"] == 3.2 and e0["previous"] == 2.9 and e0["surprise"] == pytest.approx(0.2)

    def price(i):
        t = start + timedelta(hours=i)
        p = 150.0
        for k, dday in enumerate(days):
            t0 = datetime(2026, 1, dday, 10)
            if t >= t0:
                p += (0.5 if k % 2 == 0 else -0.5) * min((t - t0).total_seconds() / 3600, 4) / 4
        return p
    csvp = tmp_path / "usdjpy_h1.csv"
    _csv(csvp, start, 24 * 31, price)
    data, md = R.event_reaction(tmp_path, "USDJPY", csvp, "CPI", [1, 4], offset_hours=0)
    g = data["groups"]
    assert g["all"]["n"] == 4 and g["surprise_up"]["4h"]["mean"] > 40 and g["surprise_down"]["4h"]["mean"] < -40
    assert g["surprise_up"]["4h"]["up_ratio"] == 1.0
    assert "結果 > 予想（上振れ）" in md and "offset_hours が 0" in md and (tmp_path / "research" / "USDJPY" / "event_reaction_CPI.json").exists()
    md2 = R.events_md("USDJPY", R.load_events(tmp_path, "USDJPY"))
    assert "| 3 | 3.2 | +0.2 |" in md2
