"""v2.11.32 の回帰テスト: 起動時のトップ画面でモードを選んでから始める（既定は会話）。"""
from __future__ import annotations

import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from codeagent.config import Config
    from codeagent.server import app as APP
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    cfg = Config.load(ROOT / "config.yaml" if (ROOT / "config.yaml").exists() else ROOT / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("workspace", "root"): str(tmp_path), ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    (tmp_path / "w").mkdir()
    return TestClient(APP.create_app(cfg))


def test_new_session_takes_mode(tmp_path, monkeypatch):
    c = _client(tmp_path, monkeypatch)
    assert c.get("/api/config").json()["home_mode"] == "chat"
    s = c.post("/api/sessions", json={"mode": "work"}).json()
    assert s["mode"] == "work" and s["working"] is True
    s = c.post("/api/sessions", json={"mode": "chat"}).json()
    assert s["mode"] == "chat" and s["working"] is False
    assert c.post("/api/sessions", json={"mode": "bogus"}).json()["mode"] == "auto"
    assert c.post("/api/sessions", json={}).json()["mode"] == "auto"            # 従来どおり modes.default


def test_index_has_home_screen():
    html = (ROOT / "codeagent" / "server" / "static" / "index.html").read_text(encoding="utf-8")
    for x in ('id="home"', 'data-m="chat"', 'data-m="work"', 'data-m="auto"', "homeShow();",
              "createSession($('#projdir').value.trim(),false,homeMode)", "$('#newsess').onclick=()=>homeShow();"):
        assert x in html, x
    assert "const first=document.querySelector('.sess');" not in html          # 起動時に前のセッションを勝手に開かない


def test_chat_mode_tells_user_how_to_switch(h):
    proj = h.project(with_test=False)
    call = {"id": uuid.uuid4().hex[:8], "name": "write_file", "args": {"path": "a.py", "content": "x\n"}}
    call2 = {"id": uuid.uuid4().hex[:8], "name": "write_file", "args": {"path": "b.py", "content": "x\n"}}
    agent, llm, store, s = h.make([("tools", [call]), ("tools", [call2]), ("text", "会話で答えます")], proj,
                                  {"phases.enabled": False, "brief.enabled": False}, mode="chat")
    h.run(agent, s, "a.py を作って")
    assert not (proj / "a.py").exists() and not (proj / "b.py").exists()
    hints = [e for e in h.of("info") if "🛠 作業" in e.get("text", "")]
    assert len(hints) == 1 and "write_file" in hints[0]["text"]                 # 1 ターンに 1 回


def test_log_menu_copies_selection_kept_at_right_click():
    """v2.11.33: 右クリックメニューの「選択範囲をコピー」は、右クリックした時点の選択を使う（メニューを押すと選択が外れるため）。"""
    html = (ROOT / "codeagent" / "server" / "static" / "index.html").read_text(encoding="utf-8")
    assert "lmSel=sel?sel.toString():''" in html and "if(act==='copysel')t=lmSel;" in html
    assert "lmenu.addEventListener('mousedown',e=>e.preventDefault())" in html
    assert "#logmenu{display:none;position:fixed;z-index:20;-webkit-user-select:none;user-select:none;" in html
