"""v2.11.38 の回帰テスト: ユーザーが質問に答えた直後は、まず set_plan から始めるよう伝える。"""
from __future__ import annotations

from codeagent import phases as PH

HINT = "ユーザーの回答を受けました"


def _nudges(store, s):
    return [m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge"]


def test_answer_in_plan_phase_gets_set_plan_hint(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "わかりました")], proj, {"brief.enabled": False})
    s.phase = PH.PhaseState(active=True, phase="plan").to_dict()         # 前のターンで計画の途中に質問した
    store.save(s)
    h.run(agent, s, "Q1-A、Q2-B で進めてください")
    ns = _nudges(store, s)
    assert ns and HINT in ns[0] and "set_plan" in ns[0]
    assert [e for e in h.of("info") if "まず計画（set_plan）から始める" in e.get("text", "")]
    msgs = store.load(s.id).messages
    i = next(n for n, m in enumerate(msgs) if m.get("content") == "Q1-A、Q2-B で進めてください")
    assert msgs[i + 1].get("kind") == "nudge"                             # 回答の直後に入る


def test_clarify_answer_gets_set_plan_hint(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "わかりました")], proj, {"brief.enabled": True, "brief.clarify": "ask"})
    llm.clarify = "QUESTION: どちらの言語で書きますか？ A. 日本語 B. 英語"
    h.run(agent, s, "X に投稿する文章を作ってください。内容は新しいモデルの話題です")
    s = store.load(s.id)
    assert s.clarify_pending                                              # 作業前の確認が出た → 回答する
    llm.script = [("text", "わかりました")]
    h.run(agent, s, "1-A")
    assert any(HINT in n for n in _nudges(store, s))


def test_first_request_has_no_hint(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "回答です")], proj, {"brief.enabled": False})
    h.run(agent, s, "calc.py の使い方を教えてください。詳しく")
    assert not any(HINT in n for n in _nudges(store, s))
