"""v2.11.28 → v2.11.31 の回帰テスト: 要約（コンテキスト圧縮）は既定でサブ LLM が背景で作る（v2.11.31。数字・名前を検証する）。
教訓の抽出はサブ LLM のまま。"""
from __future__ import annotations

from pathlib import Path

from codeagent.config import Config

ROOT = Path(__file__).resolve().parents[1]


def test_background_summary_on_by_default():
    for name in ("config.yaml", "config.example.yaml"):
        p = ROOT / name
        if p.exists():
            c = Config.load(p)
            assert c.get("compaction.background") is True, name
            assert c.get("compaction.verify_max_removed") == 0.3 and c.get("compaction.facts") is True, name
    from codeagent.server import app as APP
    assert APP.SETTING_DEFAULTS["compaction.background"] is True
    src = (ROOT / "codeagent" / "agent.py").read_text(encoding="utf-8")
    assert 'self.cfg.get("compaction.background", True)' in src
    assert 'self.cfg.get("memory.reflect_with_sub", True)' in src          # 教訓抽出はサブ LLM のまま
