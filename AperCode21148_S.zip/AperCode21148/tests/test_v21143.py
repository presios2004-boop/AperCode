"""v2.11.43 の回帰テスト: メインモデルにクラウド AI・LAN 上の LLM（接続先）を選べる。API キーは画面にも AperCode にも出さない。"""
from __future__ import annotations

import asyncio
import json
import stat
from pathlib import Path

import httpx
import pytest

from codeagent import endpoints as EP

ROOT = Path(__file__).resolve().parents[1]
KEY = "sk-test-secret-987654"


@pytest.fixture
def user_path(tmp_path, monkeypatch):
    p = tmp_path / "user.yaml"
    monkeypatch.setattr(EP, "PATH_GETTER", lambda: p)
    return p


def test_upsert_keeps_key_private(user_path):
    e = EP.upsert({"name": "LAN の PC", "type": "openai", "url": "http://192.168.1.5:1234/v1/", "api_key": KEY})
    assert e["id"] == "lan-pc" and e["url"] == "http://192.168.1.5:1234/v1" and e["key_set"] is True
    assert "api_key" not in e and KEY not in json.dumps(EP.list_public())
    assert stat.S_IMODE(user_path.stat().st_mode) == 0o600
    assert EP.get("lan-pc")["api_key"] == KEY
    EP.upsert({"id": "lan-pc", "name": "LAN の PC", "type": "openai", "url": "http://192.168.1.5:1234/v1", "api_key": None})
    assert EP.get("lan-pc")["api_key"] == KEY                          # None = 変えない
    EP.upsert({"id": "lan-pc", "name": "LAN の PC", "type": "openai", "url": "http://192.168.1.5:1234/v1", "api_key": ""})
    assert "api_key" not in EP.get("lan-pc")                           # "" = 消す
    c = EP.upsert({"name": "Claude", "type": "anthropic", "url": "", "api_key": KEY})
    assert c["url"] == EP.ANTHROPIC_URL and c["num_ctx"] == 200000
    with pytest.raises(EP.EndpointError):
        EP.upsert({"name": "x", "type": "openai", "url": "ftp://a"})
    with pytest.raises(EP.EndpointError):
        EP.upsert({"name": "x", "type": "bogus", "url": "http://a"})
    EP.delete("lan-pc")
    assert [x["id"] for x in EP.list_public()] == ["claude"]
    assert EP.mask(f"401 bad key {KEY}", {"api_key": KEY}) == "401 bad key ***"


def _client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from codeagent.config import Config
    from codeagent.server import app as APP
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    monkeypatch.setattr(EP, "PATH_GETTER", None)
    cfg = Config.load(ROOT / "config.yaml" if (ROOT / "config.yaml").exists() else ROOT / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("workspace", "root"): str(tmp_path), ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    monkeypatch.setattr(type(cfg), "state", lambda self: dict(getattr(self, "_st", {})), raising=False)
    monkeypatch.setattr(type(cfg), "save_state", lambda self, st: setattr(self, "_st", dict(st)), raising=False)
    (tmp_path / "w").mkdir()
    app = APP.create_app(cfg)
    return TestClient(app), app


def test_api_never_returns_key_and_switches(tmp_path, monkeypatch):
    c, app = _client(tmp_path, monkeypatch)
    calls = []

    async def fake_models(e):
        calls.append(("models", e.get("api_key")))
        if e.get("api_key") != KEY:
            raise RuntimeError(f"401 unauthorized for key {e.get('api_key')}")
        return ["m-a", "m-b"]

    async def fake_ping(e, model):
        calls.append(("ping", model))
        return "OK"
    monkeypatch.setattr(EP, "list_models", fake_models)
    monkeypatch.setattr(EP, "ping", fake_ping)
    base = {"name": "LAN の PC", "type": "openai", "url": "http://10.0.0.2:1234/v1"}
    r = c.post("/api/endpoints/test", json={**base, "api_key": KEY}).json()   # 保存前の入力で試せる
    assert r["ok"] and r["model"] == "m-a" and r["models"] == ["m-a", "m-b"]
    saved = c.post("/api/endpoints", json={**base, "api_key": KEY}).json()
    eid = saved["endpoint"]["id"]
    # 保存済みのキーで試せる（api_key を送らない）・結果を保存
    r = c.post("/api/endpoints/test", json={**base, "id": eid, "model": "m-b"}).json()
    assert r["ok"] and ("ping", "m-b") in calls
    lst = c.get("/api/endpoints").json()
    assert lst["endpoints"][0]["models"] == ["m-a", "m-b"] and lst["endpoints"][0]["tested"]["ok"]
    # 誤ったキー: エラー文にキーが出ない
    r = c.post("/api/endpoints/test", json={**base, "id": eid, "api_key": "sk-wrong-key-xyz"})
    assert r.status_code == 400 and "sk-wrong-key-xyz" not in r.text
    # 切り替え
    r = c.post("/api/model", json={"endpoint": eid, "model": "m-b"}).json()
    assert r["endpoint"] == eid and r["model"] == "m-b" and r["endpoint_name"] == "LAN の PC"
    cf = c.get("/api/config").json()
    assert cf["endpoint"] == eid and cf["model"] == "m-b"
    m = c.get("/api/models").json()
    assert m["endpoints"][0]["id"] == eid and m["endpoints"][0]["models"] == ["m-a", "m-b"]
    assert c.post("/api/model", json={"endpoint": "nope"}).status_code == 404
    for path in ("/api/endpoints", "/api/config", "/api/models", "/api/settings"):
        assert KEY not in c.get(path).text, path
    # 使用中の接続先を消すとローカルに戻る
    r = c.delete(f"/api/endpoints/{eid}").json()
    assert r["endpoints"] == [] and c.get("/api/config").json()["endpoint"] in ("", None)


def _llm():
    from codeagent.config import Config
    from codeagent.llm import LLMClient
    cfg = Config.load(ROOT / "config.yaml" if (ROOT / "config.yaml").exists() else ROOT / "config.example.yaml")
    cfg.data.setdefault("llm", {})["base_url"] = "http://127.0.0.1:9"
    return LLMClient(cfg)


def test_use_endpoint_and_restore():
    llm = _llm()
    local = (llm.provider, llm.base_url, llm.num_ctx)
    llm.use_endpoint({"id": "c", "name": "Claude", "type": "anthropic", "url": "", "api_key": KEY}, "claude-x")
    assert llm.provider == "anthropic" and llm.base_url == EP.ANTHROPIC_URL and llm.num_ctx == 200000
    assert "api_key" not in llm.endpoint and llm._ep_headers["x-api-key"] == KEY and llm.describe() == "Claude"
    llm.use_endpoint(None, "qwen")
    assert (llm.provider, llm.base_url, llm.num_ctx) == local and llm._ep_headers == {} and llm.endpoint is None


def test_openai_stream_parsing():
    llm = _llm()
    llm.use_endpoint({"id": "o", "name": "O", "type": "openai", "url": "http://x/v1", "api_key": KEY}, "m")
    seen = {}

    def handler(req: httpx.Request):
        seen["auth"] = req.headers.get("authorization")
        seen["body"] = json.loads(req.content)
        chunks = [{"choices": [{"delta": {"reasoning_content": "考え"}}]},
                  {"choices": [{"delta": {"content": "読みます"}}]},
                  {"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "call.1", "function": {"name": "read_file", "arguments": '{"pa'}}]}}]},
                  {"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": 'th": "a.py"}'}}]}}]},
                  {"choices": [], "usage": {"prompt_tokens": 12, "completion_tokens": 3}}]
        body = "".join(f"data: {json.dumps(c)}\n\n" for c in chunks) + "data: [DONE]\n\n"
        return httpx.Response(200, text=body, headers={"content-type": "text/event-stream"})
    llm._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    msgs = [{"role": "user", "content": "a.py を読んで"},
            {"role": "assistant", "content": "", "tool_calls": [{"id": "t1", "name": "ls", "args": {"p": "."}}]},
            {"role": "tool", "tool_call_id": "t1", "content": "a.py"}]

    async def run():
        return [ev async for ev in llm.chat("SYS", msgs, [{"type": "function", "function": {"name": "read_file"}}])]
    evs = asyncio.run(run())
    assert seen["auth"] == f"Bearer {KEY}" and seen["body"]["model"] == "m" and seen["body"]["tools"]
    om = seen["body"]["messages"]
    assert om[0] == {"role": "system", "content": "SYS"} and om[2]["tool_calls"][0]["function"]["arguments"] == '{"p": "."}'
    assert om[3] == {"role": "tool", "tool_call_id": "t1", "content": "a.py"}
    assert ("thinking", "考え") in evs and ("text", "読みます") in evs
    tc = [d for k, d in evs if k == "tool_call"][0]
    assert tc["name"] == "read_file" and tc["args"] == {"path": "a.py"} and tc["id"] == "call1"
    assert evs[-1] == ("done", {"prompt_tokens": 12, "completion_tokens": 3})


def test_helper_model_off_with_endpoint(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([], proj)
    agent.llm.endpoint = {"id": "c", "name": "Claude"}
    assert asyncio.run(_maybe(agent._helper_model())) is None


async def _maybe(x):
    return await x if asyncio.iscoroutine(x) else x


def test_index_has_endpoint_ui():
    html = (ROOT / "codeagent" / "server" / "static" / "index.html").read_text(encoding="utf-8")
    for x in ('id="epmodal"', 'id="ep-key" type="password"', 'id="ep-test"', "'+ep'", "E|"):
        assert x in html, x


def test_anthropic_prompt_cache():
    """v2.11.44: Anthropic のプロンプトキャッシュ（ツール定義・システムプロンプト・会話の区切り）と使用量の集計。"""
    llm = _llm()
    llm.use_endpoint({"id": "c", "name": "Claude", "type": "anthropic", "url": "", "api_key": KEY}, "claude-x")
    seen = {}

    def handler(req: httpx.Request):
        seen["body"] = json.loads(req.content)
        return httpx.Response(200, json={"content": [{"type": "text", "text": "OK"}],
                                         "usage": {"input_tokens": 50, "output_tokens": 5,
                                                   "cache_read_input_tokens": 900, "cache_creation_input_tokens": 50}})
    llm._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    msgs = [{"role": "user", "content": "一つ目"}, {"role": "assistant", "content": "はい"},
            {"role": "user", "content": "二つ目"},
            {"role": "assistant", "content": "", "tool_calls": [{"id": "t1", "name": "ls", "args": {}}]},
            {"role": "tool", "tool_call_id": "t1", "content": "a.py"}]
    tools = [{"type": "function", "function": {"name": n, "parameters": {"type": "object"}}} for n in ("ls", "read_file")]

    async def run():
        return [ev async for ev in llm.chat("SYS", msgs, tools)]
    evs = asyncio.run(run())
    b = seen["body"]
    assert b["system"] == [{"type": "text", "text": "SYS", "cache_control": {"type": "ephemeral"}}]
    assert "cache_control" in b["tools"][-1] and "cache_control" not in b["tools"][0]
    assert b["messages"][-1]["content"][-1]["cache_control"] == {"type": "ephemeral"}          # 最後（tool_result）
    assert b["messages"][2]["content"][0]["cache_control"] == {"type": "ephemeral"}            # 前のユーザー（前回の最後）
    assert b["messages"][0]["content"] == "一つ目"
    n = json.dumps(b).count("cache_control")
    assert n == 4
    assert evs[-1] == ("done", {"prompt_tokens": 1000, "completion_tokens": 5, "cache_read_tokens": 900, "cache_write_tokens": 50})
    # Anthropic 以外（Strata などの互換サーバー）には付けない
    llm.use_endpoint({"id": "s", "name": "Strata", "type": "anthropic", "url": "http://10.0.0.3:8080", "api_key": KEY}, "q")
    asyncio.run(run())
    assert "cache_control" not in json.dumps(seen["body"])
