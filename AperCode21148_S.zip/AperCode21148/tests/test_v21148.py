"""v2.11.48 の回帰テスト: 本文に XML で書かれたツール呼び出しが今は使えないツールでも、作業を止めない。"""
from __future__ import annotations

import uuid


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def xml(name, **params):
    body = "".join(f"<parameter={k}>\n{v}\n</parameter>\n" for k, v in params.items())
    return f"進めます。\n<tool_call>\n<function={name}>\n{body}</function>\n</tool_call>"


def test_unavailable_xml_tool_is_sent_back_instead_of_stopping(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", xml("edit_brief", append="追記")), ("text", "完了しました")], proj,
                                  {"phases.enabled": False})
    h.run(agent, s, "メモを整理して")
    assert any("今は使えないツール" in (e.get("text") or "") for e in h.of("info"))
    nudges = [m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge"]
    assert any("edit_brief" in n and "使えるツール:" in n for n in nudges)
    assert not llm.script                                   # 差し戻した後に、もう一度 LLM を呼んでいる


def test_unavailable_xml_in_plan_phase_keeps_phase_open(h):
    proj = h.project(with_test=False)
    script = [("text", xml("edit_brief", append="x")), ("tools", [call("set_plan", steps=["a.txt を作る"])]),
              ("tools", [call("write_file", path="a.txt", content="a\n")]), ("tools", [call("step_done", summary="作った")]),
              ("text", "完了しました"), ("text", "完了しました")]
    agent, llm, store, s = h.make(script, proj, {"verify.create_missing_tests": False})
    h.run(agent, s, "a.txt というファイルを作って、中身は a にしてください")
    assert [e for e in h.of("tool_result") if e.get("name") == "set_plan"]        # 計画フェーズが閉じずに set_plan を受け付けた
    assert (proj / "a.txt").exists()


def test_xml_set_plan_reopens_closed_phase(h):
    proj = h.project(with_test=False)
    script = [("text", xml("set_plan", steps='["a.txt を作る"]')), ("tools", [call("write_file", path="a.txt", content="a\n")]),
              ("tools", [call("step_done", summary="作った")]), ("text", "完了しました"), ("text", "完了しました")]
    agent, llm, store, s = h.make(script, proj, {"verify.create_missing_tests": False})
    h.run(agent, s, "続けて")                                 # 短い返事では作業フェーズを開かない
    assert any("作業フェーズを開き直して" in (e.get("text") or "") for e in h.of("info"))
    assert [e for e in h.of("tool_result") if e.get("name") == "set_plan"]
    assert (proj / "a.txt").exists()
