"""v2.11.39 の回帰テスト: edit_skill に複数の置き換え（edits）をまとめて渡せる。"""
from __future__ import annotations

import uuid

from codeagent import skills as SK

BODY = "# 投稿\n\n## 手順\n1. Ctrl+w で閉じる\n2. ui_launch で起動\n3. 投稿する\n"


class _Cfg:
    def __init__(self, d):
        self.data = {"skills": {"dir": str(d)}}

    def get(self, k, default=None):
        cur = self.data
        for x in k.split("."):
            if not isinstance(cur, dict) or x not in cur:
                return default
            cur = cur[x]
        return cur


def _md(cfg):
    return (SK.skills_dir(cfg) / "x-post" / "SKILL.md").read_text(encoding="utf-8")


def test_edits_applied_together(tmp_path):
    cfg = _Cfg(tmp_path / "skills")
    SK.save(cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    r = SK.edit(cfg, "x-post", edits=[{"old_string": "Ctrl+w で閉じる", "new_string": "タブ数を確かめて閉じる"},
                                     {"old": "ui_launch", "new": "gui_launch"},                       # old / new の書き方も受ける
                                     {"old_string": "考察ポストを投稿する", "new_string": "考察を投稿する"}])  # YAML の説明
    md = _md(cfg)
    assert "タブ数を確かめて閉じる" in md and "gui_launch" in md and "ui_launch で" not in md.replace("gui_launch", "")
    assert SK._parse(md)[0]["description"].startswith("X に考察を投稿する") and r["action"] == "3 か所を置き換え"
    # JSON の文字列で渡しても受ける（AperCode が文字列で送ってきたことがある）
    SK.edit(cfg, "x-post", edits='[{"old": "3. 投稿する", "new": "3. 承認を得て投稿する"}]')
    assert "承認を得て投稿する" in _md(cfg)


def test_edits_all_or_nothing(tmp_path):
    cfg = _Cfg(tmp_path / "skills")
    SK.save(cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    before = _md(cfg)
    try:
        SK.edit(cfg, "x-post", edits=[{"old_string": "Ctrl+w で閉じる", "new_string": "閉じる"},
                                     {"old_string": "存在しない文", "new_string": "x"}])
        raise AssertionError
    except SK.SkillError as e:
        assert "2 件目" in str(e) and "どれも変更していません" in str(e)
    assert _md(cfg) == before
    for bad in ("not json", [{"new_string": "x"}], [1]):
        try:
            SK.edit(cfg, "x-post", edits=bad)
            raise AssertionError
        except SK.SkillError:
            pass


def test_edit_skill_tool_accepts_edits(h):
    proj = h.project(with_test=False)
    sk_dir = h.root / "skills"
    agent0, *_ = h.make([], proj, {"skills.dir": str(sk_dir)})
    SK.save(agent0.cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    call = {"id": uuid.uuid4().hex[:8], "name": "edit_skill",
            "args": {"name": "x-post", "edits": [{"old_string": "Ctrl+w", "new_string": "Ctrl+Shift+W"},
                                                 {"old_string": "ui_launch", "new_string": "gui_launch"}]}}
    agent, llm, store, s = h.make([("tools", [call]), ("text", "直しました")], proj,
                                  {"phases.enabled": False, "brief.enabled": False, "skills.dir": str(sk_dir),
                                   "permissions.edit_skill": "allow", "skills.review.llm": False})
    h.run(agent, s, "x-post を直して")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "edit_skill"][0]
    assert "2 か所を置き換え" in out
    md = (sk_dir / "x-post" / "SKILL.md").read_text(encoding="utf-8")
    assert "Ctrl+Shift+W" in md and "gui_launch" in md
