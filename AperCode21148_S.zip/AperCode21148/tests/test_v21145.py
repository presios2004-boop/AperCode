"""v2.11.45 の回帰テスト: ask_cloud が失敗したときの代わり（Web 検索 → メイン LLM）。"""
from __future__ import annotations

import uuid

from codeagent import cloud as C
from codeagent import tools as T

CLOUD = {"cloud.enabled": True, "cloud.provider": "anthropic", "cloud.model": "claude-test", "cloud.api_key": "sk-test"}
OVER = {**CLOUD, "phases.enabled": False, "permissions.ask_cloud": "allow", "security.ask_on_injection": False,
        "security.taint_guard": False}


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def _ask():
    return call("ask_cloud", goal="EA の改善案", error="ValueError: invalid literal for int() at /tmp/x/a.py",
                tried="移動平均の期間を変えた")


def _out(h):
    return [e["output"] for e in h.of("tool_result") if e.get("name") == "ask_cloud"][0]


def _boom(monkeypatch):
    async def boom(self, system, prompt, max_tokens=4096):
        raise RuntimeError("HTTP 529 overloaded")
    monkeypatch.setattr(C.CloudClient, "ask", boom)


def test_cloud_failure_falls_back_to_web(h, monkeypatch):
    _boom(monkeypatch)
    queries = []

    async def web(ctx, a):
        queries.append(a["query"])
        return f"検索: {a['query']}\n1. 結果\n   https://example.com/x\n   短い説明"
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", web)
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("tools", [_ask()]), ("text", "done")], proj, OVER)
    h.run(agent, s, "EA のアイデアについてクラウドAIと相談して")
    out = _out(h)
    assert "代わりに Web で検索しました" in out and "HTTP 529" in out and "https://example.com/x" in out
    assert queries == ["ValueError: invalid literal for int() at"]          # エラー文の行（パスは除く）で検索する


def test_cloud_and_web_failure_falls_back_to_main_llm(h, monkeypatch):
    _boom(monkeypatch)

    async def web(ctx, a):
        return "検索結果がありません。別のキーワードで試してください"
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", web)
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("tools", [_ask()]), ("text", "done")], proj, OVER)
    seen = []

    async def complete(system, text, model=None, options=None, *a, **k):
        seen.append((system, text))
        return "仮説: 入力に数字以外が混ざっている"
    llm.complete = complete
    h.run(agent, s, "EA のアイデアについてクラウドAIと相談して")
    out = _out(h)
    assert "代わりにメイン LLM が相談内容を検討しました" in out and "仮説: 入力に数字以外" in out
    assert "Web 検索: 結果なし" in out
    asked = [x for x in seen if x[0] == C.ASK_SYSTEM]            # 指示書の清書などの呼び出しは除く
    assert asked and "移動平均の期間を変えた" in asked[-1][1]


def test_fallback_can_be_turned_off(h, monkeypatch):
    _boom(monkeypatch)
    T.load_builtin()
    proj = h.project(with_test=False)
    over = {**OVER, "cloud.fallback_web": False, "cloud.fallback_local": False}
    agent, llm, store, s = h.make([("tools", [_ask()]), ("text", "done")], proj, over)
    h.run(agent, s, "EA のアイデアについてクラウドAIと相談して")
    out = _out(h)
    assert "クラウド相談に失敗" in out and "代わりに" not in out


def test_preconditions_do_not_fall_back(h, monkeypatch):
    called = []

    async def web(ctx, a):
        called.append(a)
        return "検索: x\n1. 結果\n   https://example.com\n   s"
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", web)
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("tools", [_ask()]), ("text", "done")], proj, OVER)
    h.run(agent, s, "EA のアイデアを出して")                  # 失敗も検索もない → 発動条件を満たさない（代わりもしない）
    assert "まだクラウド相談は使えません" in _out(h) and not called
