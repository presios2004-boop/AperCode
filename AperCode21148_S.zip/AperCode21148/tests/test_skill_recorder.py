"""v2.11.23 の回帰テスト: 操作を記録してスキルを作り（replay.json ＋ SKILL.md）、replay_skill で再生する。"""
from __future__ import annotations

import json
import uuid

import pytest

from codeagent import skill_recorder as REC
from codeagent import skills as SK
from codeagent import tools as T


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


class _S:
    def __init__(self):
        self.skill_rec = REC.new()


def test_record_view_build_fill():
    s = _S()
    assert REC.record_step(s, "gui_launch", {"command": "claude-desktop", "title": "Claude"})
    assert REC.record_step(s, "web_search", {"query": "日銀 会合 日程"})
    assert not REC.record_step(s, "write_file", {"path": "a.py", "content": "x"})       # 成果物づくりは記録しない
    assert REC.record_step(s, "browser_type", {"target": "#q", "text": "日銀 会合 日程", "submit": True})
    REC.record_request(s, "Claude を起動して日銀の日程を調べて")
    v = REC.view(s.skill_rec)
    assert [x["tool"] for x in v["steps"]] == ["gui_launch", "web_search", "browser_type"]
    assert {c["value"] for c in v["params"]} == {"claude-desktop", "日銀 会合 日程"}            # 同じ値は 1 つにまとめる
    md, replay, masked = REC.build(s.skill_rec, "boj-search", "日銀の日程を調べるスキル。テスト用",
                                   params=[{"value": "日銀 会合 日程", "name": "query", "description": "検索語"}])
    assert replay["params"]["query"]["default"] == "日銀 会合 日程"
    assert replay["steps"][1]["args"]["query"] == "{{query}}" and replay["steps"][2]["args"]["text"] == "{{query}}"
    assert replay["steps"][0]["wait_after"] == 1.5 and masked == 0
    assert "replay_skill" in md and "`query`: 検索語" in md and "Claude を起動して" in md and "1. アプリを起動: claude-desktop" in md
    steps = REC.fill(replay, {"query": "FOMC 日程"})
    assert steps[1]["args"]["query"] == "FOMC 日程" and steps[2]["args"]["text"] == "FOMC 日程"
    assert REC.fill(replay, {})[1]["args"]["query"] == "日銀 会合 日程"                       # 省略したら記録したときの値
    with pytest.raises(REC.RecorderError):
        REC.fill(replay, {"nope": "x"})
    with pytest.raises(REC.RecorderError):
        REC.build(s.skill_rec, "x", "説明です説明です", keep=[])
    _, r2, _ = REC.build(s.skill_rec, "x", "説明です説明です", keep=[1])
    assert [x["tool"] for x in r2["steps"]] == ["web_search"]


def test_secrets_are_masked():
    s = _S()
    REC.record_step(s, "gui_input", {"window": "App", "text": "api_key=sk-abcdefghijklmnopqrstuvwxyz123456"})
    _, replay, masked = REC.build(s.skill_rec, "x", "説明です説明です")
    assert masked >= 1 and "sk-abcdef" not in json.dumps(replay)


def _web(log, fail_on=None):
    async def web(ctx, a):
        log.append(a.get("query"))
        if fail_on and a.get("query") == fail_on:
            raise T.ToolError("検索に失敗")
        return f"検索: {a.get('query')}\n1. 結果"
    return web


def test_agent_records_successful_actions_only(h, monkeypatch):
    log = []
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", _web(log, fail_on="だめな検索"))
    proj = h.project(with_test=False)
    script = [("tools", [call("web_search", query="日銀 会合 日程")]),
              ("tools", [call("web_search", query="だめな検索")]),
              ("tools", [call("write_file", path="memo.md", content="# x\n")]),
              ("text", "調べました")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "brief.enabled": False})
    s.skill_rec = REC.new()
    store.save(s)
    h.run(agent, s, "日銀の会合日程を検索して")
    rec = store.load(s.id).skill_rec
    assert [x["tool"] for x in rec["steps"]] == ["web_search"] and rec["steps"][0]["args"]["query"] == "日銀 会合 日程"
    assert rec["requests"] == ["日銀の会合日程を検索して"]
    assert [e for e in h.of("skill_rec") if e["steps"] == 1]


def _save_recorded(h, steps, params=None):
    s = _S()
    for tool, args in steps:
        REC.record_step(s, tool, args)
    md, replay, _ = REC.build(s.skill_rec, "web-check", "Web で検索して確かめるスキル。テスト用", params=params)
    cfg_dir = h.root / "skills"

    class C:
        data = {"skills": {"dir": str(cfg_dir)}}

        def get(self, k, d=None):
            cur = self.data
            for x in k.split("."):
                if not isinstance(cur, dict) or x not in cur:
                    return d
                cur = cur[x]
            return cur
    SK.save(C(), "web-check", "Web で検索して確かめるスキル。テスト用", md, {"replay.json": json.dumps(replay, ensure_ascii=False)})


def test_replay_skill_runs_steps_with_params(h, monkeypatch):
    log = []
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", _web(log))
    _save_recorded(h, [("web_search", {"query": "日銀 会合 日程"}), ("web_search", {"query": "日銀 会合 日程 2026"})],
                   params=[{"value": "日銀 会合 日程", "name": "query"}])
    proj = h.project(with_test=False)
    script = [("tools", [call("replay_skill", name="web-check", params={"query": "FOMC 日程"})]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "brief.enabled": False, "skills.dir": str(h.root / "skills")})
    h.run(agent, s, "web-check を実行して")
    assert log == ["FOMC 日程", "FOMC 日程 2026"]                                             # 部分一致の値も差し替わる
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "replay_skill"][0]
    assert "手順 2 件を再生しました" in out and "[2/2] Web 検索: 「FOMC 日程 2026」" in out
    assert len([e for e in h.of("tool_call") if e.get("name") == "web_search"]) == 2                # 各操作は画面にも出る


def test_replay_stops_on_failure_and_lists_rest(h, monkeypatch):
    log = []
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", _web(log, fail_on="B"))
    _save_recorded(h, [("web_search", {"query": "A"}), ("web_search", {"query": "B"}), ("web_search", {"query": "C"})])
    proj = h.project(with_test=False)
    script = [("tools", [call("replay_skill", name="web-check")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "brief.enabled": False, "skills.dir": str(h.root / "skills")})
    h.run(agent, s, "web-check を実行して")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "replay_skill"][0]
    assert log == ["A", "B"] and "再生が止まりました】手順 2/3" in out and "3. Web 検索: 「C」" in out and "start: 2" in out


def test_replay_respects_denied_approval(h, monkeypatch):
    log = []
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", _web(log))
    _save_recorded(h, [("run_command", {"command": "echo hi"}), ("web_search", {"query": "A"})])

    async def deny(req):
        return "deny"
    h.approve = deny
    proj = h.project(with_test=False)
    script = [("tools", [call("replay_skill", name="web-check")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "brief.enabled": False, "skills.dir": str(h.root / "skills"),
                                                 "permissions.run_command": "ask", "autonomy.enabled": False})
    h.run(agent, s, "web-check を実行して")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "replay_skill"][0]
    assert "再生が止まりました】手順 1/2" in out and log == []                                   # 承認を飛ばさない


def test_recording_api(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from pathlib import Path
    from codeagent.config import Config
    from codeagent.server import app as APP
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    root = Path(__file__).resolve().parents[1]
    cfg = Config.load(root / "config.yaml" if (root / "config.yaml").exists() else root / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("skills", "dir"): str(tmp_path / "skills"), ("workspace", "root"): str(tmp_path),
                 ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    (tmp_path / "w").mkdir()
    c = TestClient(APP.create_app(cfg))
    sid = c.post("/api/sessions", json={"project_dir": str(tmp_path / "w")}).json()["id"]
    assert c.post(f"/api/sessions/{sid}/skill_rec/start").json()["active"] is True
    from codeagent.session import SessionStore
    store = SessionStore(tmp_path / "sessions")
    s = store.load(sid)
    REC.record_step(s, "web_search", {"query": "日銀 会合"})
    REC.record_step(s, "browser_open", {"url": "https://www.boj.or.jp/"})
    store.save(s)
    v = c.get(f"/api/sessions/{sid}/skill_rec").json()
    assert len(v["steps"]) == 2 and v["params"][0]["suggest"] == "query"
    r = c.post(f"/api/sessions/{sid}/skill_rec/stop", json={"name": "Bad Name", "description": "説明です説明です"})
    assert r.status_code == 400
    r = c.post(f"/api/sessions/{sid}/skill_rec/stop", json={"name": "boj-check", "description": "日銀のページを開いて確かめる",
                                                            "params": [{"value": "日銀 会合", "name": "query"}]}).json()
    assert r["ok"] and r["steps"] == 2 and r["params"] == ["query"]
    d = tmp_path / "skills" / "boj-check"
    assert "{{query}}" in (d / "replay.json").read_text() and "replay_skill" in (d / "SKILL.md").read_text()
    assert c.get(f"/api/sessions/{sid}/skill_rec").json()["active"] is False
    sk = [x for x in c.get("/api/skills").json()["skills"] if x["name"] == "boj-check"][0]
    assert sk["status"] == "ok" and "replay.json" in sk["files"]
