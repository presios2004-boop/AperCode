"""v2.11.24 の回帰テスト: Web ページ・アプリを開く依頼（サンドボックスの中から GUI を起動しない・引数名の誤り）。"""
from __future__ import annotations

import asyncio
import uuid

from codeagent import sandbox
from codeagent import tools as T
from codeagent.tools import shell as S


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def test_gui_launch_hint(monkeypatch):
    monkeypatch.setattr(sandbox, "enabled", lambda: True)
    for c in ("xdg-open https://www.google.com", "DISPLAY=:0 firefox https://www.google.com &",
              "firefox --new-window https://www.google.com &\nsleep 3", "nohup setsid google-chrome x", "ls && xdg-open ."):
        h = S.gui_launch_hint(c)
        assert h and "browser_open" in h and "gui_launch" in h, c
    assert 'browser_open(url="https://www.google.com")' in S.gui_launch_hint("xdg-open https://www.google.com")
    assert 'gui_launch(command="firefox https://www.google.com"' in S.gui_launch_hint("xdg-open https://www.google.com")
    for c in ("firefox --version", "which firefox", "echo firefox", "gio list", "python app.py",
              "libreoffice --headless --convert-to pdf a.odt"):
        assert S.gui_launch_hint(c) is None, c
    monkeypatch.setattr(sandbox, "enabled", lambda: False)
    assert S.gui_launch_hint("xdg-open https://www.google.com") is None              # サンドボックスが無ければ起動できる


def test_run_command_refuses_gui_and_bad_arg_name(h, monkeypatch):
    monkeypatch.setattr(sandbox, "enabled", lambda: True)
    proj = h.project(with_test=False)
    script = [("tools", [call("run_command", command="xdg-open https://www.google.com")]),
              ("tools", [call("run_command", cmd="ls", timeout=10)]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "brief.enabled": False,
                                                 "permissions.run_command": "allow"})
    h.run(agent, s, "Google を開いて")
    outs = [e for e in h.of("tool_result") if e.get("name") == "run_command"]
    assert outs[0]["error"] and "このコマンドは実行していません" in outs[0]["output"] and "browser_open" in outs[0]["output"]
    assert outs[1]["error"] and "必須の引数 command がありません" in outs[1]["output"] and "cmd はこのツールの引数ではありません" in outs[1]["output"]
    assert "Traceback" not in outs[1]["output"]
    sysp = llm.systems[0]
    assert "Web ページ・アプリを開く依頼" in sysp and "（PC のブラウザを含む）" in sysp


def test_gui_launch_opens_url_even_if_browser_is_open(monkeypatch):
    from codeagent import gui as G
    from codeagent.tools import gui_tools as GT
    seen = []

    async def launch(command, title, timeout=40, always_run=False):
        seen.append((command, always_run))
        return G.Window(id="0x1", title="Google — Mozilla Firefox", x=0, y=0, w=800, h=600), True
    monkeypatch.setattr(G, "launch", launch)
    out = asyncio.run(GT.gui_launch(None, {"command": "firefox https://www.google.com", "title": "Firefox"}))
    assert seen[-1] == ("firefox https://www.google.com", True) and out.startswith("URL を開きました")
    asyncio.run(GT.gui_launch(None, {"command": "claude-desktop", "title": "Claude"}))
    assert seen[-1] == ("claude-desktop", False)


def test_missing_args_message():
    T.load_builtin()
    assert T.missing_args(T.get("run_command"), {"command": "ls"}) == ""
    m = T.missing_args(T.get("run_command"), {"cmd": "ls"})
    assert "使える引数: command, cwd, timeout" in m
