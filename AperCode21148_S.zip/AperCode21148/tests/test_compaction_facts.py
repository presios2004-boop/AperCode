"""v2.11.31 の回帰テスト: 背景での履歴圧縮を速く・正確にする。
- 推定トークン数は、実際に送る量（古いツール結果は 1500 文字）で数える
- 履歴から機械的に記録（指示・ファイル・コマンド・URL・エラー）を取り出し、圧縮をまたいで残す
- サブ LLM の要約の数字・名前を、もとの記録と照合する（無いものを含む行は除く・多すぎれば使わない）
"""
from __future__ import annotations

import asyncio
import types

from codeagent import compaction_facts as CF
from codeagent.agent import LoopState


def _hist():
    return [
        {"role": "user", "content": "今月の USDJPY の市場コンセンサスに変化があったか確認して"},
        {"role": "assistant", "content": "", "tool_calls": [
            {"id": "a1", "name": "fetch_url", "args": {"url": "https://example.com/fx/usdjpy"}},
            {"id": "a2", "name": "write_file", "args": {"path": "notes/consensus.md", "content": "x"}}]},
        {"role": "tool", "tool_call_id": "a1", "name": "fetch_url", "content": "USDJPY 予想 152.40 (前回 149.80) 回答 27 社"},
        {"role": "tool", "tool_call_id": "a2", "name": "write_file", "content": "notes/consensus.md を書きました"},
        {"role": "assistant", "content": "", "tool_calls": [{"id": "a3", "name": "run_command", "args": {"command": "python check.py"}}]},
        {"role": "tool", "tool_call_id": "a3", "name": "run_command", "content": "ok\n(exit 0)"},
        {"role": "assistant", "content": "", "tool_calls": [{"id": "a4", "name": "read_file", "args": {"path": "nope.txt"}}]},
        {"role": "tool", "tool_call_id": "a4", "name": "read_file", "content": "エラー: nope.txt が見つかりません"},
    ]


def test_extract_merge_render():
    f = CF.extract(_hist())
    assert f["requests"] == ["今月の USDJPY の市場コンセンサスに変化があったか確認して"]
    assert f["files"] == ["notes/consensus.md"] and f["urls"] == ["https://example.com/fx/usdjpy"]
    assert f["commands"] == ["python check.py → exit 0"] and f["errors"][0].startswith("read_file: エラー")
    m = CF.merge(f, {"files": ["notes/consensus.md", "b.py"], "requests": [f"r{i}" for i in range(10)]})
    assert m["files"] == ["notes/consensus.md", "b.py"]                      # 重複を除く
    assert len(m["requests"]) == CF.CAPS["requests"] and m["requests"][-1] == "r9"   # 新しい方から上限まで
    r = CF.render(m)
    assert "## 記録" in r and "- b.py" in r and "### 変更したファイル" in r
    assert CF.render({k: [] for k in CF.CAPS}) == ""
    # 以前の要約のメッセージは取り出しの対象にしない
    assert CF.extract([{"role": "user", "kind": "summary", "content": "要約"}])["requests"] == []


def test_verify_removes_invented_facts():
    src = "USDJPY 予想 152.40 (前回 149.80) 回答 27 社。notes/consensus.md に保存。https://example.com/fx/usdjpy"
    summary = "\n".join(["- 予想は 152.40 に上がった（前回 149.80）",
                         "- notes/consensus.md に保存した",
                         "- 回答は 35% の機関が円安",                       # 35% は記録に無い
                         "- report_2026.csv にまとめた",                    # 記録に無いファイル
                         "- 出典 https://example.com/fx/usdjpy",
                         "- 作業を続ける"])
    clean, missing, removed = CF.verify(summary, src)
    assert removed == 2 and "35%" in missing and "report_2026.csv" in missing
    assert "152.40" in clean and "consensus.md" in clean and "35%" not in clean and "作業を続ける" in clean
    assert CF.verify("1,234 件", "合計 1234 件")[2] == 0                      # 桁区切りは無視して照合


def test_estimate_counts_trimmed_tool_outputs(h):
    agent, *_ = h.make([], h.project(with_test=False))
    big = "x" * 50_000
    msgs = [{"role": "tool", "content": big} for _ in range(10)]
    est = agent._estimate_tokens(msgs)
    cpt = float(agent.cfg.get("compaction.chars_per_token", 2.5))
    assert est == int((4 * 1510 + 6 * 50_000) / cpt)                         # 直近 6 件だけ全文、古いものは縮めた量


def _state(msgs):
    return LoopState(messages=msgs, system="", tool_names=None, ctx=types.SimpleNamespace(depth=0))


def _long_hist():
    msgs = []
    for i in range(12):
        msgs += [{"role": "user", "content": f"指示 {i} " + "あ" * 3000},
                 {"role": "assistant", "content": f"了解 {i}", "tool_calls": []}]
    return msgs


def _bg_agent(h, summary_text, events):
    agent, llm, store, s = h.make([], h.project(with_test=False), {"compaction.background": True})
    agent._helper_model = lambda: "sub-model"

    async def opts(model, n):
        return {}

    async def summ(transcript, budget, model=None, options=None):
        return summary_text if model == "sub-model" else "メイン LLM の要約: 指示 0 から 11 を進めた"
    agent._helper_options = opts
    agent._summarize_chunked = summ

    async def emit(ev):
        events.append(ev)
    return agent, s, emit


def test_background_summary_rejected_when_invented(h):
    events: list = []
    bad = "\n".join([f"- 売上は {1000 + i}% 増えた" for i in range(5)] + ["- 指示 3 を進めた"])
    agent, s, emit = _bg_agent(h, bad, events)
    st = _state(_long_hist())

    async def go():
        await agent._start_bg_compact(st, s, emit)
        await asyncio.sleep(0)
        await agent._compact(st, s, emit, force=True)
    asyncio.run(go())
    failed = [e for e in events if e.get("type") == "bg" and e.get("state") == "failed"]
    assert failed and "メイン LLM で要約します" in failed[0]["text"] and "もとの記録に無い" in failed[0]["text"]
    comp = [e for e in events if e.get("type") == "compacted"][0]
    assert comp["by"] is None and comp["summary"].startswith("メイン LLM の要約")


def test_background_summary_used_and_facts_carried(h):
    events: list = []
    ok = "- 指示 0 から 9 を進めた\n- 指示 3 で確認した\n- 指示 5 を終えた\n- 合計 9999 件を処理した"
    agent, s, emit = _bg_agent(h, ok, events)
    msgs = _long_hist()
    msgs.insert(2, {"role": "assistant", "content": "", "tool_calls": [{"id": "w1", "name": "write_file", "args": {"path": "ea/main.mq5"}}]})
    msgs.insert(3, {"role": "tool", "tool_call_id": "w1", "name": "write_file", "content": "書きました"})
    st = _state(msgs)

    async def go():
        await agent._start_bg_compact(st, s, emit)
        await asyncio.sleep(0)
        await agent._compact(st, s, emit, force=True)
    asyncio.run(go())
    comp = [e for e in events if e.get("type") == "compacted"][0]
    assert comp["by"] == "sub-model" and "9999" not in comp["summary"] and "指示 5 を終えた" in comp["summary"]
    head = st.messages[0]
    assert head["kind"] == "summary" and "ea/main.mq5" in head["content"] and head["facts"]["files"] == ["ea/main.mq5"]
    reqs = head["facts"]["requests"]
    assert len(reqs) == CF.CAPS["requests"] and reqs[0].startswith("指示 2")       # 指示は新しい方から上限まで（9999 の行だけ除く: 1/4）
    # 2 回目の圧縮: 以前の記録が引き継がれる
    st.messages += _long_hist()
    st.compacted_len = -1
    agent._helper_model = lambda: None
    asyncio.run(agent._compact(st, s, emit, force=True))
    assert "ea/main.mq5" in st.messages[0]["facts"]["files"]
    # LLM へ送る履歴には facts を含めない
    assert all("facts" not in m for m in agent._history(st.messages)) if hasattr(agent, "_history") else True
