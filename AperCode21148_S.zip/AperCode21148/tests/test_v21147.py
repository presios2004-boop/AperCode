"""v2.11.47 の回帰テスト: 本文に XML 形式（Qwen3 系）で書かれたツール呼び出しを解析して実行する。"""
from __future__ import annotations

from codeagent.llm import LLMClient

XML = """ユーザーの回答を踏まえて修正します。まず現状を確認します。

<tool_call>
<function=run_command>
<parameter=command>
cd /tmp && sed -n '89,160p' a.md
</parameter>
</function>
</tool_call>"""


def test_extract_qwen_xml_tool_call():
    calls = LLMClient.extract_text_tool_calls(XML, {"run_command", "read_file"},
                                              {"run_command": {"command": {"type": "string"}}})
    assert len(calls) == 1 and calls[0]["name"] == "run_command"
    assert calls[0]["args"] == {"command": "cd /tmp && sed -n '89,160p' a.md"}


def test_xml_values_typed_by_schema_and_unknown_tools_ignored():
    text = ("<tool_call>\n<function=web_search>\n<parameter=query>\n123\n</parameter>\n<parameter=max_results>\n3\n</parameter>\n"
            "</function>\n</tool_call>\n<tool_call><function=rm_everything><parameter=x>1</parameter></function></tool_call>")
    props = {"web_search": {"query": {"type": "string"}, "max_results": {"type": "integer"}}}
    calls = LLMClient.extract_text_tool_calls(text, {"web_search"}, props)
    assert calls and calls[0]["args"] == {"query": "123", "max_results": 3}
    assert len(calls) == 1                                   # 使えないツールは実行しない
    # 文字列の引数は、複数行・前後の空白もそのまま
    t2 = "<tool_call>\n<function=write_file>\n<parameter=path>\na.py\n</parameter>\n<parameter=content>\n  x = 1\n\ny = 2\n</parameter>\n</function>\n</tool_call>"
    c2 = LLMClient.extract_text_tool_calls(t2, {"write_file"}, {"write_file": {"path": {"type": "string"}, "content": {"type": "string"}}})
    assert c2[0]["args"] == {"path": "a.py", "content": "  x = 1\n\ny = 2"}


def test_agent_runs_xml_tool_call_from_text(h):
    proj = h.project(with_test=False, files={"note.md": "hello\n"})
    text = "確認します。\n<tool_call>\n<function=read_file>\n<parameter=path>\nnote.md\n</parameter>\n</function>\n</tool_call>"
    agent, llm, store, s = h.make([("text", text), ("text", "完了しました")], proj, {"phases.enabled": False})
    h.run(agent, s, "note.md を読んで")
    assert [e for e in h.of("tool_result") if e.get("name") == "read_file"]
    assert any("本文に書かれたツール呼び出し" in (e.get("text") or "") for e in h.of("info"))


def test_xml_removed_from_history(h):
    proj = h.project(with_test=False, files={"note.md": "hello\n"})
    text = "確認します。\n<tool_call>\n<function=read_file>\n<parameter=path>\nnote.md\n</parameter>\n</function>\n</tool_call>"
    agent, llm, store, s = h.make([("text", text), ("text", "完了しました")], proj, {"phases.enabled": False})
    h.run(agent, s, "note.md を読んで")
    msgs = [m for m in store.load(s.id).messages if m.get("role") == "assistant" and m.get("tool_calls")]
    assert msgs and msgs[0]["content"] == "確認します。" and msgs[0]["tool_calls"][0]["name"] == "read_file"
