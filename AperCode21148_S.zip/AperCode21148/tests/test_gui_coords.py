"""v2.11.26 の回帰テスト: クリック座標の形式（Qwen3 系の 0〜1000）と、送れていない送信の検出。"""
from __future__ import annotations

import asyncio

from PIL import Image

from codeagent import agent as A
from codeagent import gui as G
from codeagent.tools import gui_tools as GT


class _Cfg:
    def __init__(self, d):
        self.d = d

    def get(self, k, default=None):
        return self.d.get(k, default)


def test_coord_mode():
    assert GT.coord_mode(_Cfg({"llm.model": "qwen3.8:27b"})) == "norm1000"
    assert GT.coord_mode(_Cfg({"llm.model": "orcarouter/Qwen3.8-27B"})) == "norm1000"
    assert GT.coord_mode(_Cfg({"llm.model": "qwen2.5vl:7b"})) == "pixel"
    assert GT.coord_mode(_Cfg({"llm.model": "qwen3.8:27b", "gui.click_coords": "pixel"})) == "pixel"
    assert GT.coord_mode(_Cfg({"llm.model": "llama3", "gui.click_coords": "norm1000"})) == "norm1000"


def test_to_screen_norm1000():
    win = G.Window(id="0xA", title="Firefox", x=5, y=29, w=1180, h=1376)
    G._SHOTS["s1"] = {"0xA": {"scale": 1.0, "w": 1180, "h": 1376, "coords": "norm1000"}}
    assert G._to_screen("s1", win, 640, 930) == (5 + 755, 29 + 1280)      # ログの例: 入力欄（y≈1279）に当たる
    G._SHOTS["s1"]["0xA"]["coords"] = "pixel"
    assert G._to_screen("s1", win, 640, 930) == (645, 959)                 # 以前の扱い（回答文の途中をクリックしていた）
    assert "0〜1000" in G.coord_hint("norm1000") and "ピクセル" in G.coord_hint("pixel")


def test_changed_ratio():
    a = Image.new("L", (400, 400), 30)
    b = a.copy()
    assert G.changed_ratio(a, b) == 0.0
    b.paste(200, (0, 300, 400, 400))
    assert G.changed_ratio(a, b) > 0.2
    assert G.changed_ratio(None, b) == 1.0


def test_gui_input_reports_unsent(monkeypatch):
    img = Image.new("L", (300, 300), 40)

    async def grab(window):
        return img.copy()

    async def gi(*a, **k):
        return ["前面に出した", "貼り付け: 10 文字", "キー: Return"]
    monkeypatch.setattr(G, "grab", grab)
    monkeypatch.setattr(G, "gui_input", gi)

    class Ctx:
        cfg = _Cfg({"gui.reply_wait": 0})
        session_id = "s"
    out = asyncio.run(GT.gui_input(Ctx(), {"window": "Firefox", "text": "こんにちは", "keys": ["Return"], "wait_after": 0}))
    assert GT.NOT_SENT_MARK in out
    changed = iter([img.copy(), Image.new("L", (300, 300), 200)])

    async def grab2(window):
        return next(changed)
    monkeypatch.setattr(G, "grab", grab2)
    out = asyncio.run(GT.gui_input(Ctx(), {"window": "Firefox", "text": "こんにちは", "keys": ["Return"], "wait_after": 0}))
    assert GT.NOT_SENT_MARK not in out


def test_is_send_and_unsent_not_counted():
    assert A.Agent._is_send("gui_input", {"text": "こんにちは、質問です"})
    for url in ("https://grok.com", "grok.com", "www.google.com", "/home/x/a.txt"):
        assert not A.Agent._is_send("gui_input", {"text": url}), url
    from codeagent import phases as PH

    class St:
        phase = PH.PhaseState(active=True, phase="implement", kind="converse")
        iter_bonus = 0
    ag = A.Agent.__new__(A.Agent)
    ag.cfg = _Cfg({})
    st = St()
    ag._phase_note_tool(st, {"name": "gui_input", "args": {"text": "質問です", "keys": ["Return"]}}, GT.NOT_SENT_MARK + "（変化 0.00%）")
    assert st.phase.sent_count == 0 and st.phase.sent_ts == 0
    ag._phase_note_tool(st, {"name": "gui_input", "args": {"text": "質問です", "keys": ["Return"]}}, "キー: Return")
    assert st.phase.sent_count == 1
