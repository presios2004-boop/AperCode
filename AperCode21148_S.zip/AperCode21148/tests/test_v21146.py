"""v2.11.46 の回帰テスト: 起動時の Ollama の用意は、ホストの ollama serve より先に Docker のコンテナを起動する。"""
from __future__ import annotations

import importlib.util
import subprocess
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def _app():
    spec = importlib.util.spec_from_file_location("apercode_app", ROOT / "app.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


class Cfg:
    def __init__(self, data: dict, state: dict):
        self.data, self._state = data, state

    def get(self, key, default=None):
        return self.data.get(key, default)

    def state(self):
        return self._state


def _fake_env(app, monkeypatch, containers: dict, served: list):
    """containers: {名前: 起動中か}。docker start で起動すると Ollama が応答する。served: ホストの ollama serve の記録。"""
    up = {"v": False}
    calls = []

    def run(cmd, **k):
        calls.append(cmd[1:])
        name = cmd[-1]
        if cmd[1] == "inspect":
            if name not in containers:
                return SimpleNamespace(returncode=1, stdout="", stderr="No such object")
            return SimpleNamespace(returncode=0, stdout="true\n" if containers[name] else "false\n", stderr="")
        if cmd[1] == "start":
            containers[name] = True
            up["v"] = True
            return SimpleNamespace(returncode=0, stdout=name, stderr="")
        raise AssertionError(cmd)
    monkeypatch.setattr(app.shutil, "which", lambda x: f"/usr/bin/{x}")
    monkeypatch.setattr(app.subprocess, "run", run)
    monkeypatch.setattr(app.subprocess, "Popen", lambda cmd, **k: served.append(cmd))
    monkeypatch.setattr(app, "ollama_running", lambda url: up["v"])
    monkeypatch.setattr(app.time, "sleep", lambda s: None)
    return calls


def test_container_name_follows_main_model():
    app = _app()
    assert app.ollama_container(Cfg({}, {"endpoint": "strata"})) == "ollama-embed"      # Strata など → 埋め込み用
    assert app.ollama_container(Cfg({}, {})) == "ollama"                                # ローカルの Ollama → メイン用
    c = Cfg({"llm.ollama_docker": {"main": "o-gpu", "embed": "o-cpu"}}, {"endpoint": "x"})
    assert app.ollama_container(c) == "o-cpu"


def test_starts_docker_container_instead_of_host_serve(monkeypatch):
    app = _app()
    served = []
    containers = {"ollama": False, "ollama-embed": False}
    calls = _fake_env(app, monkeypatch, containers, served)
    assert app.try_start_ollama("http://localhost:11434", Cfg({}, {"endpoint": "strata"})) is True
    assert ["start", "ollama-embed"] in calls and containers["ollama"] is False and not served


def test_host_serve_only_without_container(monkeypatch):
    app = _app()
    served = []
    _fake_env(app, monkeypatch, {}, served)                          # コンテナが無い → 従来どおりホストの ollama serve
    app.try_start_ollama("http://localhost:11434", Cfg({}, {}))
    assert served and served[0][-1] == "serve"
    served.clear()
    app.try_start_ollama("http://localhost:11434", Cfg({"llm.ollama_host_serve": False}, {}))
    assert not served


def test_failed_container_start_does_not_fall_back_to_host(monkeypatch):
    app = _app()
    served = []
    _fake_env(app, monkeypatch, {"ollama-embed": False}, served)

    def run(cmd, **k):
        if cmd[1] == "inspect":
            return SimpleNamespace(returncode=0, stdout="false\n", stderr="")
        return SimpleNamespace(returncode=1, stdout="", stderr="port is already allocated")
    monkeypatch.setattr(app.subprocess, "run", run)
    assert app.try_start_ollama("http://localhost:11434", Cfg({}, {"endpoint": "strata"})) is False
    assert not served
