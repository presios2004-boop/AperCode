"""v2.11.41 の回帰テスト: 起動・入力の軽さと、ウィンドウを 2 つ開かないこと。"""
from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _app():
    spec = importlib.util.spec_from_file_location("apercode_app", ROOT / "app.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_top_screen_has_no_heavy_effects():
    html = (ROOT / "codeagent" / "server" / "static" / "index.html").read_text(encoding="utf-8")
    home = "\n".join(ln for ln in html.splitlines() if ln.startswith("#home"))
    # 動き続けるぼかし・背景のぼかしは、GPU を使わない WebKitGTK で CPU を使い続け、入力が鈍くなる
    assert "backdrop-filter" not in home and "filter:blur" not in home and "animation:" not in home
    assert "@keyframes hdrift" not in html and "@keyframes hspin" not in html


def test_window_opens_before_server_and_only_once(tmp_path, monkeypatch):
    app = _app()
    assert "起動しています" in app.LOADING_HTML
    monkeypatch.setattr(app, "LOG_DIR", tmp_path)
    app._LOCK.clear()
    assert app.take_window_lock() is True
    assert app.window_running() is True                                     # 2 つ目の AperCode は開かない
    src = (ROOT / "app.py").read_text(encoding="utf-8")
    assert 'background_color="#0f1115"' in src and "win.events.closing += lambda: _hide_now(win)" in src
    assert "open_webview(url, bring_up)" in src                              # ウィンドウを先に開き、その間にサーバーを起動
