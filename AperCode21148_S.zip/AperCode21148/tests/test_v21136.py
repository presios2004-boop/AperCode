"""v2.11.36 の回帰テスト:
- edit_skill でスキルの説明（先頭の YAML の description）を変えられる
- 2 回目以降のスキルのレビューは、前回の指摘が直ったかの確認＋新しい high だけ。LLM が見ていないときは前回の判定を引き継ぐ
- 同じツールが続けて失敗したら、クラウド AI → Web 検索 → 自分で の順に自動で助けを求める
"""
from __future__ import annotations

import asyncio
import json
import uuid

from codeagent import skill_review as SR
from codeagent import skills as SK
from codeagent import tools as T

BODY = "# 投稿\n\n## 手順\n1. 本文を作る\n2. ユーザーに見せて OK をもらう\n3. 投稿する\n"


class _Cfg:
    def __init__(self, d):
        self.data = {"skills": {"dir": str(d), "review": {"enabled": True, "llm": True}}, "cloud": {"enabled": False}}

    def get(self, k, default=None):
        cur = self.data
        for x in k.split("."):
            if not isinstance(cur, dict) or x not in cur:
                return default
            cur = cur[x]
        return cur


def _md(cfg, name):
    return (SK.skills_dir(cfg) / name / "SKILL.md").read_text(encoding="utf-8")


def test_edit_skill_changes_description(tmp_path):
    cfg = _Cfg(tmp_path / "skills")
    long_desc = "X に考察ポストを投稿する全手順。" + "とても長い説明文を書いて YAML の折り返しが起きるようにする。" * 4
    SK.save(cfg, "x-post", long_desc, BODY)
    assert "\n  " not in _md(cfg, "x-post").split("---")[1]           # 長い説明でも YAML を折り返さない
    SK.edit(cfg, "x-post", description="X に技術トピックの考察を投稿する。投稿前にユーザーの承認を得る")
    meta, body = SK._parse(_md(cfg, "x-post"))
    assert meta["description"].startswith("X に技術トピック") and "## 手順" in body and meta.get("updated")
    # old_string が YAML の部分にあっても置き換えられる
    SK.edit(cfg, "x-post", old="技術トピックの考察", new="技術の考察")
    assert SK._parse(_md(cfg, "x-post"))[0]["description"].startswith("X に技術の考察")
    # content の先頭の YAML の description も使う
    SK.edit(cfg, "x-post", content="---\nname: x-post\ndescription: 新しい説明。投稿の前に必ず確認する\n---\n\n# 投稿\n本文\n")
    meta, body = SK._parse(_md(cfg, "x-post"))
    assert meta["description"] == "新しい説明。投稿の前に必ず確認する" and body.strip().startswith("# 投稿") and meta["author"] == "AperCode"
    try:
        SK.edit(cfg, "x-post", description="短い")
        raise AssertionError
    except SK.SkillError:
        pass


def _prev(cfg, name):
    SK.set_review(cfg, name, {"status": "needs_fix", "lint": [], "ts": __import__("time").time(), "sha": "x",
                              "llm": {"verdict": "fix", "by": "クラウド", "summary": "",
                                      "issues": [{"severity": "high", "where": "description", "problem": "説明が古い", "fix": "", "by": "llm"},
                                                 {"severity": "medium", "where": "手順 3", "problem": "失敗時の対処がない", "fix": "", "by": "llm"}]}})


def test_followup_review_checks_previous_findings(tmp_path):
    cfg = _Cfg(tmp_path / "skills")
    SK.save(cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    _prev(cfg, "x-post")
    seen = []

    async def complete(system, text):
        seen.append((system, text))
        return json.dumps({"verdict": "fix", "summary": "説明は直った", "previous": [{"n": 1, "fixed": True}, {"n": 2, "fixed": False, "note": "まだ無い"}],
                           "issues": []}, ensure_ascii=False)
    r = asyncio.run(SR.review(cfg, "x-post", complete=complete))
    assert "前回の指摘" in seen[0][1] and "説明が古い" in seen[0][1] and "直っているか" in seen[0][0]
    llm = r["llm"]
    assert llm["followup"] and len(llm["fixed"]) == 1 and [i["followup"] for i in llm["issues"]] == ["unresolved"]
    assert r["status"] == "ok"                                              # 残りは medium だけ → 使える
    out = SR.format_result("x-post", r)
    assert "前回の指摘 2 件のうち 1 件は直っていることを確かめました" in out and "［前回の指摘・未解決］" in out and "任意" in out
    sk = [s for s in SK.list_skills(cfg) if s["name"] == "x-post"][0]
    assert sk["review"]["fixed_count"] == 1
    # full=True なら一からレビュー
    asyncio.run(SR.review(cfg, "x-post", complete=complete, full=True))
    assert "前回の指摘" not in seen[-1][1]


def test_review_without_llm_keeps_previous_verdict(tmp_path):
    cfg = _Cfg(tmp_path / "skills")
    SK.save(cfg, "x-post", "X に考察ポストを投稿するスキル。投稿前に確認する", BODY)
    _prev(cfg, "x-post")
    r = asyncio.run(SR.review(cfg, "x-post", complete=None, use_llm=False))
    assert r["status"] == "needs_fix" and r["llm"]["carried"]             # 上限で LLM が見ていない → 「使える」に戻さない
    out = SR.format_result("x-post", r)
    assert "今回は行っていません" in out and "前回の判定を引き継ぎます" in out and "指摘なし" not in out
    # LLM が失敗しても同じ
    async def broken(system, text):
        raise RuntimeError("down")
    r = asyncio.run(SR.review(cfg, "x-post", complete=broken))
    assert r["status"] == "needs_fix" and "失敗" in r["llm"]["skipped"]


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def _fails(n=3):
    return [("tools", [call("read_file", path=f"nope{i}.txt")]) for i in range(n)]


def test_same_tool_failures_consult_cloud_first(h, monkeypatch):
    T.load_builtin()
    asked = []

    async def fake_cloud(ctx, a):
        asked.append(a)
        return "助言: パスを list_dir で確かめてから読む"
    monkeypatch.setattr(T.get("ask_cloud"), "handler", fake_cloud)
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make(_fails() + [("text", "やめます")], proj,
                                  {"phases.enabled": False, "brief.enabled": False, "cloud.enabled": True, "permissions.ask_cloud": "allow"})
    monkeypatch.setattr(agent, "_cloud_ready", lambda: True)
    h.run(agent, s, "ファイルを読んで")
    assert asked and "read_file" in asked[0]["tried"] and asked[0]["goal"]
    nudge = [m for m in store.load(s.id).messages if m.get("kind") == "nudge"][-1]["content"]
    assert "【クラウド AI への自動相談の結果" in nudge and "list_dir で確かめて" in nudge
    assert [e for e in h.of("tool_call") if e["name"] == "ask_cloud"]       # 画面にはクラウド相談のカードが出る


def test_same_tool_failures_fall_back_to_web_then_local(h, monkeypatch):
    T.load_builtin()
    queries = []

    async def fake_web(ctx, a):
        queries.append(a["query"])
        return "検索: ...\n1. 解決策のページ"

    async def failing_cmd(ctx, a):
        return "$ python x.py\n(exit 1)\nTraceback (most recent call last):\nModuleNotFoundError: No module named 'foo'"
    monkeypatch.setattr(T.get("web_search"), "handler", fake_web)
    monkeypatch.setattr(T.get("run_command"), "handler", failing_cmd)
    proj = h.project(with_test=False)
    script = [("tools", [call("run_command", command=f"python x.py {i}")]) for i in range(3)] + [("text", "やめます")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "brief.enabled": False, "cloud.enabled": False,
                                                 "permissions.run_command": "allow", "permissions.web_search": "allow"})
    h.run(agent, s, "x.py を動かして")
    assert queries and "ModuleNotFoundError" in queries[0]
    nudge = [m for m in store.load(s.id).messages if m.get("kind") == "nudge"][-1]["content"]
    assert "【エラー文の Web 検索の結果" in nudge
    # AperCode のツール自身のエラー（Web で調べても無駄）→ 自分で考え直す
    h.events.clear()
    agent2, llm2, store2, s2 = h.make(_fails() + [("text", "やめます")], proj,
                                      {"phases.enabled": False, "brief.enabled": False, "cloud.enabled": False})
    h.run(agent2, s2, "ファイルを読んで")
    nudge = [m for m in store2.load(s2.id).messages if m.get("kind") == "nudge"][-1]["content"]
    assert "クラウド AI と Web 検索は使えません" in nudge and "read_file の説明" in nudge
