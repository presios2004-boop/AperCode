"""set_plan / step_done ツール（v1.9.0）: 作業フェーズの切り替えを AperCode に知らせる。

実際のフェーズの進行（検証・チェックポイント・次の手順の指示）は、ツールの実行後に agent が行う。
"""
from __future__ import annotations

import re

from . import Tool, ToolContext, ToolError, register


async def set_plan(ctx: ToolContext, a: dict) -> str:
    ph = ctx.phase
    if ph is None or not ph.active or ph.phase not in ("plan", "done_check"):
        raise ToolError("set_plan は計画フェーズ・完了確認フェーズでだけ使えます")
    steps = a.get("steps") or []
    if isinstance(steps, str):
        steps = [re.sub(r"^\s*(\d+[.)．、:]|[-*])\s*", "", ln) for ln in steps.splitlines()]
    steps = [str(s).strip() for s in steps if str(s).strip()]
    if not steps:
        raise ToolError("steps に手順を 1 つ以上指定してください")
    ph.signal = ("set_plan", steps)
    return f"計画を登録しました（{len(steps)} 手順）"


async def step_done(ctx: ToolContext, a: dict) -> str:
    ph = ctx.phase
    if ph is None or not ph.active or ph.phase not in ("implement", "fix"):
        raise ToolError("step_done は実装フェーズ・修正フェーズでだけ使えます")
    ph.signal = ("step_done", str(a.get("summary") or ""))
    return "手順の完了を受け付けました。AperCode が検証します"


register(Tool("set_plan",
              "作業を手順に分けて登録する（計画フェーズ）。各手順は 1 回の実装＋検証で終わる大きさにし、何をどのファイルで行うかを具体的に書く。"
              "完了確認フェーズで足りない点が見つかったときは、追加の手順を登録する。",
              {"type": "object", "properties": {
                  "steps": {"type": "array", "items": {"type": "string"}, "description": "手順（3〜7 個が目安。実行順）"}},
               "required": ["steps"]}, set_plan, lambda a: f"{len(a.get('steps') or [])} 手順"))

register(Tool("step_done",
              "今の手順の実装（または修正）が終わったら呼ぶ。AperCode が自動検証・テストを行い、通れば次の手順に進む。",
              {"type": "object", "properties": {
                  "summary": {"type": "string", "description": "この手順でやったこと（1〜2 行）"}},
               "required": ["summary"]}, step_done, lambda a: str(a.get("summary", ""))[:60]))
