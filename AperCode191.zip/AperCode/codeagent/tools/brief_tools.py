"""finish_brief ツール（v1.8.0）: 作業の指示書の目的を達成したら、指示書を片付ける。"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register
from .. import brief as BR


async def finish_brief(ctx: ToolContext, a: dict) -> str:
    p = BR.path_for(ctx.project_dir, ctx.session_id)
    if not p.exists():
        return "指示書はありません（既に片付け済み）"
    vs = ctx.verify
    if vs is not None:
        failing = []
        if vs.tests is not None and vs.tests.detected and not vs.tests.ok:
            failing.append("テストが失敗したまま")
        ng = [f for f, n in (vs.check_failures or {}).items() if n]
        if ng:
            failing.append("自動検証 NG が残っている: " + ", ".join(ng[:5]))
        if failing:
            raise ToolError("まだ指示書を片付けられません（" + "、".join(failing) + "）。直してから呼んでください")
    summary = str(a.get("summary") or "").strip()
    try:
        p.unlink()
    except OSError as e:
        raise ToolError(f"指示書を削除できませんでした: {e}")
    return "指示書の目的を達成したため、指示書を削除しました（" + BR.rel(ctx.project_dir, p) + "）。" + \
        (f"\n達成内容: {summary}" if summary else "") + "\nこのあとユーザーに完了報告をしてください。"


register(Tool("finish_brief",
              "作業の指示書（システムプロンプトの「作業の指示書」）の目的・完了条件をすべて満たし、検証も通ったときに呼ぶ。"
              "指示書を削除して作業を締めくくる。まだ終わっていない項目があるときは呼ばない。",
              {"type": "object", "properties": {
                  "summary": {"type": "string", "description": "達成した内容の要約（1〜3 行）"}},
               "required": ["summary"]}, finish_brief, lambda a: str(a.get("summary", ""))[:60]))
