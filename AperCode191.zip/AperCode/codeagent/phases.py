"""作業フェーズ（v1.9.0）: 計画 → 実装 → 検証 → 修正 → 調査 → 完了確認 を AperCode 側で管理する。

LLM に「次に何をするか」を毎回決めさせるのではなく、今のフェーズと手順を AperCode が持ち、
フェーズごとに短い指示と使えるツールを切り替える。フェーズを進めるのは LLM ではなく AperCode:
  - 計画: 読み取り系ツールだけで調べ、set_plan で手順（3〜7 個）を登録 → 実装へ
  - 実装: 手順 1 つだけを実装し step_done → AperCode が検証
  - 検証: AperCode が自動検証 NG とテストを確認（LLM は呼ばない）。通ればチェックポイントを保存して次の手順へ
  - 修正: 検証のエラーだけを直して step_done → 再検証。上限回数を超えたら直前のチェックポイントへ巻き戻して調査へ
  - 調査: 読み取り・検索・クラウド相談だけで原因を調べ、別の方針を書く → その方針で実装をやり直す
  - 完了確認: 指示書の完了条件を確認して finish_brief、足りなければ set_plan で手順を追加
  - 報告: 方針を変えても通らなかった。ツール無しで状況を報告（「続けて」でこの手順から再開）
状態はセッション JSON（session.phase）に保存され、「続けて」で途中から再開できる。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict

PHASES = ("plan", "implement", "verify", "fix", "investigate", "done_check", "report")
LABEL_JA = {"plan": "計画", "implement": "実装", "verify": "検証", "fix": "修正", "investigate": "調査",
            "done_check": "完了確認", "report": "報告"}
LABEL_EN = {"plan": "Plan", "implement": "Implement", "verify": "Verify", "fix": "Fix", "investigate": "Investigate",
            "done_check": "Done check", "report": "Report"}

# フェーズごとに LLM に見せるツール（None = 全ツールから除外リストだけ引く）
PHASE_ONLY_TOOLS = {"set_plan", "step_done"}
INVESTIGATE_EXTRA = ["ask_cloud"]
DONE_EXTRA = ["run_tests", "run_command", "finish_brief", "set_plan"]

# ユーザーへの質問・依頼で止まったかの判定（応答の末尾に出る表現）。v1.9.1
ASK_RE = re.compile(r"[？?]|ください|下さい|いただけ(ます|ません)か|もらえ(ます|ません)か|よい(です)?か|よろしい(です)?か|でしょうか|"
                    r"教えて|お知らせ|指示を|ご確認|\b(please|could you|can you|would you|let me know|confirm|which)\b", re.I)
STEP_RE = re.compile(r"^\s*(?:\d{1,2}\s*[.)．、:]|[-*]\s*\[\s?\])\s*(.+?)\s*$")


def _en() -> bool:
    from .prompts import prompt_language
    return prompt_language() == "en"


def L(ja: str, en: str) -> str:
    return en if _en() else ja


def label(phase: str) -> str:
    return (LABEL_EN if _en() else LABEL_JA).get(phase, phase)


@dataclass
class PhaseState:
    active: bool = False
    phase: str = "plan"
    steps: list[dict] = field(default_factory=list)   # {"text": str, "status": "todo" | "done"}
    idx: int = 0                                       # 今の手順（0 始まり）
    fix_rounds: int = 0                                # この手順で修正に差し戻した回数
    investigations: int = 0                            # この手順で巻き戻して調査した回数
    last_error: str = ""                               # 直近の検証エラー
    failures: list[str] = field(default_factory=list)  # この手順で失敗した方針の記録
    approach: str = ""                                 # 調査で決めた新しい方針
    replan: bool = False                               # ユーザーの追加指示で計画を出し直す
    signal: tuple | None = None                        # ツールからの通知（set_plan / step_done）。保存しない

    # ---------------------------------------------------------------- 永続化
    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("signal", None)
        return d

    @classmethod
    def from_dict(cls, d: dict | None) -> "PhaseState":
        d = dict(d or {})
        known = set(cls.__dataclass_fields__) - {"signal"}
        ps = cls(**{k: v for k, v in d.items() if k in known})
        if ps.phase not in PHASES:
            ps.phase = "plan"
        return ps

    # ---------------------------------------------------------------- 操作
    @property
    def n(self) -> int:
        return len(self.steps)

    def current(self) -> str:
        return self.steps[self.idx]["text"] if 0 <= self.idx < self.n else ""

    def reset_step(self) -> None:
        self.fix_rounds = 0
        self.investigations = 0
        self.last_error = ""
        self.failures = []
        self.approach = ""

    def set_steps(self, steps: list[str]) -> None:
        """計画を登録する。出し直しなら完了済みの手順は残して、残りを置き換える。"""
        steps = [s.strip() for s in steps if s and s.strip()][:12]
        done = [s for s in self.steps if s.get("status") == "done"] if self.replan else []
        self.steps = done + [{"text": s, "status": "todo"} for s in steps]
        self.idx = len(done)
        self.replan = False
        self.reset_step()

    def add_steps(self, steps: list[str]) -> None:
        """完了確認で足りない点が見つかったときの手順追加。"""
        steps = [s.strip() for s in steps if s and s.strip()][:8]
        self.idx = self.n
        self.steps += [{"text": s, "status": "todo"} for s in steps]
        self.reset_step()

    def view(self) -> dict:
        """UI 表示用。"""
        return {"active": self.active, "phase": self.phase, "label": label(self.phase),
                "idx": self.idx, "n": self.n, "steps": self.steps, "fix_rounds": self.fix_rounds,
                "investigations": self.investigations}


def parse_steps(text: str) -> list[str]:
    """本文に番号付きの手順が書かれていれば取り出す（set_plan を呼ばないモデル向け）。"""
    out = []
    for ln in (text or "").splitlines():
        m = STEP_RE.match(ln)
        if m and len(m.group(1)) >= 3:
            out.append(re.sub(r"\*\*(.+?)\*\*", r"\1", m.group(1)))
    return out if len(out) >= 2 else []


def asks_user(text: str, tail: int = 400) -> bool:
    """応答がユーザーへの質問・依頼で終わっているか（計画フェーズで止まったときに、フェーズを終わらせないため）。"""
    t = re.sub(r"```.*?```", "", text or "", flags=re.S).strip()
    return bool(ASK_RE.search(t[-tail:]))


def plan_list(ps: PhaseState, max_chars: int = 1500) -> str:
    lines = []
    for i, s in enumerate(ps.steps):
        mark = "✓" if s.get("status") == "done" else ("▶" if i == ps.idx else " ")
        lines.append(f"{mark} {i + 1}. {s['text']}")
    txt = "\n".join(lines)
    return txt if len(txt) <= max_chars else txt[:max_chars] + "\n…"


# ------------------------------------------------------------------ システムプロンプトに添えるブロック
def block(ps: PhaseState, *, max_fix: int, cloud: bool, brief: bool, checkpoint: str = "") -> str:
    p, i, n = ps.phase, ps.idx + 1, ps.n
    en = _en()
    if p == "plan":
        if en:
            b = ("## Current phase: Plan\n- Read what you need (read-only tools only), then split the work into 3-7 steps and register them with set_plan\n"
                 "- Each step must be small enough for one implement + verify round; say concretely what to do in which file\n"
                 "- If the request needs no code change (a question or an explanation), just answer without set_plan\n"
                 "- If you lack information needed to plan (a file you cannot read, a choice only the user can make), ask the user and stop. Planning continues after the reply\n")
            if ps.replan and ps.steps:
                b += "- The user gave an additional / changed instruction. Taking the steps below into account, register the remaining steps again with set_plan\n\n" + plan_list(ps)
        else:
            b = ("## 現在のフェーズ: 計画\n- 必要なファイルを読み（読み取り系ツールのみ使用可）、作業を 3〜7 個の手順に分けて set_plan で登録する\n"
                 "- 各手順は「1 回の実装＋検証」で終わる大きさにし、何をどのファイルで行うかを具体的に書く\n"
                 "- コードの変更が不要な質問・説明の依頼なら、set_plan を呼ばずにそのまま回答してよい\n"
                 "- 計画に必要な情報が足りない（ファイルが読めない・方針が決められない）ときは、ユーザーに質問して止まってよい。返事の後も計画フェーズから続く\n")
            if ps.replan and ps.steps:
                b += "- ユーザーから追加・変更の指示があった。下の計画（✓ は完了済み）を踏まえて、残りの手順を set_plan で出し直す\n\n" + plan_list(ps)
        return "\n\n" + b
    if p == "implement":
        if en:
            b = (f"## Current phase: Implement (step {i}/{n})\nDo now: {ps.current()}\n"
                 "- Do only this step. Do not touch the other steps\n"
                 "- When done, call step_done (AperCode verifies automatically and moves to the next step if it passes)\n")
            if ps.approach:
                b += "\nApproaches that failed for this step:\n- " + "\n- ".join(ps.failures[-3:]) + f"\nNew approach (use this): {ps.approach}\n"
            b += "\nPlan:\n" + plan_list(ps)
        else:
            b = (f"## 現在のフェーズ: 実装（手順 {i}/{n}）\n今やること: {ps.current()}\n"
                 "- この手順だけを行う。ほかの手順には手を付けない\n"
                 "- 終わったら step_done を呼ぶ（検証は AperCode が自動で行い、通れば次の手順に進む）\n")
            if ps.approach:
                b += "\nこの手順で失敗した方針:\n- " + "\n- ".join(ps.failures[-3:]) + f"\n新しい方針（これで行う）: {ps.approach}\n"
            b += "\n計画:\n" + plan_list(ps)
        return "\n\n" + b
    if p == "fix":
        err = ps.last_error[:3000]
        if en:
            return (f"\n\n## Current phase: Fix (step {i}/{n}, fix {ps.fix_rounds}/{max_fix})\nFix only this error:\n```\n{err}\n```\n"
                    "- Fix the implementation (do not weaken the tests)\n- When fixed, call step_done (AperCode verifies again)\n"
                    f"\nStep: {ps.current()}\n")
        return (f"\n\n## 現在のフェーズ: 修正（手順 {i}/{n}、修正 {ps.fix_rounds}/{max_fix} 回目）\n次のエラーだけを直す:\n```\n{err}\n```\n"
                "- 実装側を直す（テストを弱めない）\n- 直したら step_done を呼ぶ（AperCode が再検証する）\n"
                f"\n手順: {ps.current()}\n")
    if p == "investigate":
        fails = "\n- ".join(ps.failures[-3:]) or "-"
        if en:
            return (f"\n\n## Current phase: Investigate (step {i}/{n})\nFixing did not make this step pass, so the files were rolled back to {checkpoint}.\n"
                    f"Failure record:\n- {fails}\n"
                    "- Find the cause with read-only tools, web_search, fetch_url, search_memory" + (" and ask_cloud" if cloud else "") + ". You cannot change files\n"
                    "- Then write a different approach in at most 5 lines and stop (no code). The next implement phase retries the step with it\n"
                    f"\nStep: {ps.current()}\n")
        return (f"\n\n## 現在のフェーズ: 調査（手順 {i}/{n}）\nこの手順は修正を重ねても検証が通らなかったため、ファイルを {checkpoint} の状態に戻した。\n"
                f"失敗の記録:\n- {fails}\n"
                "- 読み取り系ツール・web_search・fetch_url・search_memory" + ("・ask_cloud" if cloud else "") + " で原因を調べる。ファイルは変更できない\n"
                "- 調べ終えたら、前回と違う方針を 5 行以内で書いて終える（コードは書かない）。次の実装フェーズでその方針でやり直す\n"
                f"\n手順: {ps.current()}\n")
    if p == "done_check":
        if en:
            return ("\n\n## Current phase: Done check\nAll steps are implemented and verified. Check the done-conditions of the task brief"
                    + (" " if brief else " (or the user's request)") + " one by one\n"
                    + ("- If satisfied, call finish_brief and write the completion report to the user\n" if brief else "- If satisfied, write the completion report to the user\n")
                    + "- If something is missing, register additional steps with set_plan (implementation resumes from them)\n\nPlan:\n" + plan_list(ps))
        return ("\n\n## 現在のフェーズ: 完了確認\n全手順の実装と検証が済んだ。" + ("指示書の完了条件" if brief else "ユーザーの依頼") + "を 1 つずつ確認する\n"
                + ("- 満たしていれば finish_brief を呼び、ユーザーに完了報告を書く\n" if brief else "- 満たしていれば、ユーザーに完了報告を書く\n")
                + "- 足りない点があれば set_plan で追加の手順を登録する（追加分から実装を再開する）\n\n計画:\n" + plan_list(ps))
    if p == "report":
        fails = "\n- ".join(ps.failures[-3:]) or "-"
        if en:
            return (f"\n\n## Current phase: Report\nStep {i}/{n} did not pass even after changing the approach. The files are back at {checkpoint}, the last verified state.\n"
                    f"Failure record:\n- {fails}\n"
                    "Without tools, report to the user: finished steps, the failing step and the approaches tried, the key error, and what to try next. "
                    "If the user sends \"continue\", work resumes from this step.\n\nPlan:\n" + plan_list(ps))
        return (f"\n\n## 現在のフェーズ: 報告\n手順 {i}/{n} は方針を変えても検証が通らなかった。ファイルは最後に検証が通った {checkpoint} の状態に戻してある。\n"
                f"失敗の記録:\n- {fails}\n"
                "ツールは使わずに、完了した手順・失敗した手順と試した方針・エラーの要点・次に試すべきことをユーザーに報告する。"
                "ユーザーが「続けて」と送るとこの手順から再開する。\n\n計画:\n" + plan_list(ps))
    return ""


# ------------------------------------------------------------------ フェーズ切り替え時に履歴へ入れる指示
def msg_start(ps: PhaseState) -> str:
    return L(f"【システム】計画を登録しました（{ps.n} 手順）。手順 {ps.idx + 1}/{ps.n}: {ps.current()}\nこの手順だけを実装し、終わったら step_done を呼んでください。",
             f"[System] Plan registered ({ps.n} steps). Step {ps.idx + 1}/{ps.n}: {ps.current()}\nImplement only this step and call step_done when finished.")


def msg_next(ps: PhaseState, cp_label: str) -> str:
    return L(f"【システム】手順 {ps.idx}/{ps.n} の検証が通りました（{cp_label} を保存）。次は手順 {ps.idx + 1}/{ps.n}: {ps.current()}\n"
             "この手順だけを実装し、終わったら step_done を呼んでください。",
             f"[System] Step {ps.idx}/{ps.n} passed verification ({cp_label} saved). Next, step {ps.idx + 1}/{ps.n}: {ps.current()}\n"
             "Implement only this step and call step_done when finished.")


def msg_fix(ps: PhaseState, max_fix: int) -> str:
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n} の検証で問題が見つかりました（修正 {ps.fix_rounds}/{max_fix} 回目）。\n```\n{ps.last_error[:3000]}\n```\n"
             "このエラーだけを直して step_done を呼んでください。",
             f"[System] Verification of step {ps.idx + 1}/{ps.n} found problems (fix {ps.fix_rounds}/{max_fix}).\n```\n{ps.last_error[:3000]}\n```\n"
             "Fix only this error and call step_done.")


def msg_investigate(ps: PhaseState, cp_label: str, why: str, dropped: int) -> str:
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n}: {why}。ファイルを {cp_label} の状態に戻し、その後の試行 {dropped} 件を履歴から外しました。"
             "原因を調べ、前回と違う方針を 5 行以内で書いてください（ファイルの変更はできません）。",
             f"[System] Step {ps.idx + 1}/{ps.n}: {why}. The files were rolled back to {cp_label} and the {dropped} later messages were removed from the history. "
             "Investigate the cause and write a different approach in at most 5 lines (you cannot change files).")


def msg_retry(ps: PhaseState) -> str:
    return L(f"【システム】新しい方針で手順 {ps.idx + 1}/{ps.n} をやり直してください: {ps.approach[:800]}\n終わったら step_done を呼んでください。",
             f"[System] Retry step {ps.idx + 1}/{ps.n} with the new approach: {ps.approach[:800]}\nCall step_done when finished.")


def msg_done_check(ps: PhaseState, brief: bool) -> str:
    return L(f"【システム】全 {ps.n} 手順の検証が通りました。" + ("指示書の完了条件" if brief else "ユーザーの依頼") + "を満たしているか確認してください。",
             f"[System] All {ps.n} steps passed verification. Check that the " + ("done-conditions of the task brief are" if brief else "user's request is") + " satisfied.")


def msg_report(ps: PhaseState, cp_label: str, dropped: int) -> str:
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n} は方針を変えても検証が通りませんでした。ファイルを {cp_label} の状態に戻し、その後の試行 {dropped} 件を履歴から外しました。"
             "ツールは使わずに、状況をユーザーに報告してください。",
             f"[System] Step {ps.idx + 1}/{ps.n} did not pass even with a new approach. The files were rolled back to {cp_label} and the {dropped} later messages were removed from the history. "
             "Report the situation to the user without using tools.")
