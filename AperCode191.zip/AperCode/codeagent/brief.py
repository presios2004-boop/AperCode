"""作業の指示書（v1.8.0）: ユーザーが最初に指示した目的を md ファイルに清書し、LLM の毎回のリクエストに自動で添える。

ローカル LLM は長い作業の途中で最初の目的を忘れやすい。会話履歴は圧縮で要約されていくので、目的は履歴とは別に
ファイルとして保持し、AperCode（ハーネス）が LLM を呼ぶたびにファイルを読み直してシステムプロンプトに入れる。
LLM に「読みに行かせる」のではないので、読み忘れが起きない。ユーザーがファイルを直接編集すれば次の呼び出しから反映される。

置き場所: <プロジェクト>/.apercode/briefs/<セッションID>.md
- 最初の指示で作成（LLM が清書。失敗したら原文のまま）
- 以降のユーザーの指示は「追加・変更の指示」として追記（「続けて」などの短い返事は追記しない）
- 目的を達成したら LLM が finish_brief ツールで削除（テスト失敗・自動検証 NG が残っていれば拒否）。画面からも削除できる
"""
from __future__ import annotations

import re
import time
from pathlib import Path

BRIEF_PROMPT = """あなたはユーザーの依頼を「作業の指示書」に清書する係です。
以下のユーザーの依頼文を読み、コーディングエージェントが作業の最後まで目的を見失わないための指示書を Markdown で書いてください。

形式（この見出しだけを使う。該当が無い見出しは省略）:
# 目的
（何を実現したいのかを 1〜3 行で）
## 要件
- （ユーザーが求めていること。箇条書き）
## 制約・注意
- （使う言語・ライブラリ・触ってはいけないもの・方針など、ユーザーが指定したこと）
## 完了条件
- [ ] （何ができたら完了か。確認できる形で）

規則:
- ユーザーが書いていないことを付け足さない（推測で要件を増やさない）。曖昧な点は「（未指定）」と書く
- ファイル名・パス・数値・固有名詞はそのまま残す
- 40 行以内。前置きや説明は書かず、指示書だけを出力する
"""

BRIEF_PROMPT_EN = """You turn the user's request into a "task brief".
Read the request below and write, in Markdown, a brief that keeps a coding agent on target until the end of the work.

Format (use only these headings; omit a heading that has nothing):
# Goal
(what the user wants to achieve, 1-3 lines)
## Requirements
- (what the user asked for, as bullets)
## Constraints
- (languages, libraries, things not to touch, policies the user specified)
## Done when
- [ ] (what must be true for the task to be finished, in a checkable form)

Rules:
- Do not add anything the user did not say (no guessed requirements). Write "(unspecified)" for unclear points
- Keep file names, paths, numbers and proper nouns verbatim
- At most 40 lines. Output only the brief, no preamble
"""

CONTINUE_WORDS = re.compile(r"^(続けて|つづけて|続行|はい|いいえ|ok|okay|yes|no|go|continue|進めて|お願いします|おねがいします|よろしく|了解|りょうかい|どうぞ|やって)[。．!！\s]*$",
                            re.I)


def path_for(project: Path, session_id: str) -> Path:
    return project / ".apercode" / "briefs" / f"{session_id}.md"


def rel(project: Path, p: Path) -> str:
    try:
        return str(p.relative_to(project))
    except ValueError:
        return str(p)


def read(p: Path, max_chars: int = 4000) -> str:
    try:
        s = p.read_text("utf-8", errors="replace").strip()
    except (FileNotFoundError, OSError):
        return ""
    return s if len(s) <= max_chars else s[:max_chars] + "\n…（長いため省略）"


def is_meaningful(text: str, min_chars: int) -> bool:
    t = (text or "").strip()
    return len(t) >= min_chars and not CONTINUE_WORDS.match(t)


def is_followup(text: str) -> bool:
    t = (text or "").strip()
    return len(t) >= 6 and not CONTINUE_WORDS.match(t)


def header(created: float) -> str:
    return f"<!-- AperCode 作業の指示書（{time.strftime('%Y-%m-%d %H:%M', time.localtime(created))} 作成）。編集すると次の LLM 呼び出しから反映されます。目的を達成すると自動で削除されます -->\n"


def write_new(p: Path, body: str, original: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    body = body.strip()
    orig = original.strip()
    if len(orig) > 3000:
        orig = orig[:3000] + "…"
    quoted = "\n".join("> " + ln for ln in orig.splitlines())
    p.write_text(header(time.time()) + body + "\n\n## ユーザーの原文\n" + quoted + "\n", encoding="utf-8")


def append_instruction(p: Path, text: str) -> None:
    t = text.strip()
    if len(t) > 1500:
        t = t[:1500] + "…"
    stamp = time.strftime("%m/%d %H:%M")
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"\n## 追加・変更の指示（{stamp}）\n" + "\n".join("> " + ln for ln in t.splitlines()) + "\n")


def clean_llm_output(raw: str) -> str:
    s = (raw or "").strip()
    s = re.sub(r"^```(?:markdown|md)?\s*\n", "", s)
    s = re.sub(r"\n```\s*$", "", s)
    s = re.sub(r"<think>.*?</think>", "", s, flags=re.S).strip()
    return s
