"""v2.5.0 の回帰テスト: コマンドのサンドボックス（bubblewrap）と、AperCode 自身の保護。"""
from __future__ import annotations

import asyncio
import os
import shutil
import sys
import uuid
from pathlib import Path

import pytest

from conftest import tc
from codeagent import sandbox
from codeagent.tools.shell import run_shell

needs_bwrap = pytest.mark.skipif(not sandbox.available(), reason="bubblewrap が使えない環境")


def _sh(cmd: str, proj: Path) -> tuple[int, str]:
    return asyncio.run(run_shell(cmd, str(proj), 30, root=str(proj)))


@pytest.fixture
def sb(h):
    """Agent を作って sandbox を設定させる（データディレクトリ = テスト用のセッション置き場）。"""
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, {"sandbox.mode": "auto"})
    return h, agent, store, s, proj


@needs_bwrap
def test_sandbox_allows_project_and_blocks_elsewhere(sb):
    h, agent, store, s, proj = sb
    outside = Path.home() / f".apercode_sbtest_{uuid.uuid4().hex[:6]}"
    outside.mkdir()
    try:
        code, out = _sh(f"echo hi > {proj}/a.txt && echo hi > {outside}/b.txt", proj)
        assert (proj / "a.txt").read_text().strip() == "hi"            # 作業ディレクトリには書ける
        assert code != 0 and not (outside / "b.txt").exists()           # ほかには書けない
    finally:
        shutil.rmtree(outside, ignore_errors=True)


@needs_bwrap
def test_sandbox_protects_apercode_itself(sb):
    h, agent, store, s, proj = sb
    target = sandbox.APP_ROOT / f"sbtest_{uuid.uuid4().hex[:6]}.txt"
    code, out = _sh(f"echo x > {target}", proj)
    assert code != 0 and not target.exists()
    secret = Path(store.root) / "secret.txt"                          # データディレクトリは中から見えない
    secret.write_text("KEY")
    code, out = _sh(f"cat {secret}", proj)
    assert code != 0 and "KEY" not in out


@needs_bwrap
def test_project_venv_is_on_path(sb):
    h, agent, store, s, proj = sb
    b = proj / ".venv" / "bin"
    b.mkdir(parents=True)
    os.symlink(sys.executable, b / "python")
    code, out = _sh("command -v python; echo $VIRTUAL_ENV", proj)
    assert code == 0 and str(b / "python") in out and str(proj / ".venv") in out


def test_sandbox_on_but_unavailable_refuses(sb, monkeypatch):
    h, agent, store, s, proj = sb
    agent.cfg.data.setdefault("sandbox", {})["mode"] = "on"
    monkeypatch.setattr(sandbox, "_avail", False)
    code, out = _sh("echo hi > x.txt", proj)
    assert code == 126 and "sandbox.mode: on" in out and not (proj / "x.txt").exists()


def test_write_to_apercode_itself_is_denied(h):
    proj = h.project(with_test=False)
    target = sandbox.APP_ROOT / f"sbtest_{uuid.uuid4().hex[:6]}.py"
    script = [("tools", [tc("write_file", path=str(target), content="x = 1\n")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "permissions.outside_project": "allow"})
    h.run(agent, s, "AperCode のファイルを書き換えて")
    assert not target.exists()
    outs = [e["output"] for e in h.of("tool_result") if e.get("name") == "write_file"]
    assert outs and "変更できません" in outs[0]


def test_self_protect_rules(h, monkeypatch):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj)
    from codeagent import tools as T
    ctx = T.ToolContext(cfg=agent.cfg, project_dir=proj)
    assert agent._self_protect(ctx, "write_file", {"path": "a.py"}) is None
    assert agent._self_protect(ctx, "edit_file", {"path": str(sandbox.APP_ROOT / "x.py")})[0] == "deny"
    assert agent._self_protect(ctx, "write_file", {"path": str(Path(store.root) / "c.yaml")})[0] == "deny"
    agent.cfg.data.setdefault("sandbox", {})["mode"] = "off"          # サンドボックスなし → 自身に触れそうなコマンドは確認
    assert agent._self_protect(ctx, "run_command", {"command": f"rm {sandbox.APP_ROOT}/x"})[0] == "ask"
    assert agent._self_protect(ctx, "run_command", {"command": "ls"}) is None


# ------------------------------------------------------------------ v2.6.0: 作業ディレクトリの用意と画面表示
def test_workdir_issues(tmp_path):
    assert sandbox.workdir_issues(tmp_path / "nope") == ["missing"]
    assert sandbox.workdir_issues(tmp_path) == ["no_venv"]
    (tmp_path / ".venv" / "bin").mkdir(parents=True)
    (tmp_path / ".venv" / "bin" / "python").write_text("")
    assert sandbox.workdir_issues(tmp_path) == []


def _client(tmp_path, workdir):
    from fastapi.testclient import TestClient
    from codeagent.config import Config
    from codeagent.server.app import create_app
    root = Path(__file__).resolve().parents[1]
    cfg = Config.load(root / "config.yaml" if (root / "config.yaml").exists() else root / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(workdir),
                 ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    return TestClient(create_app(cfg))


def test_health_warns_and_workdir_setup_creates_venv(tmp_path):
    wd = tmp_path / "Aper_work"
    c = _client(tmp_path, wd)
    h = c.get("/api/health?refresh=1").json()
    assert h["sandbox"]["state"] in ("on", "off", "unavailable") and h["workdir"] == str(wd)
    assert any(w.get("action") == "workdir_setup" for w in h["warnings"])
    r = c.post("/api/workdir/setup")
    assert r.status_code == 200, r.text
    assert (wd / ".venv" / "bin" / "python").exists()
    h = c.get("/api/health?refresh=1").json()
    assert not any(w.get("action") == "workdir_setup" for w in h["warnings"])


def test_workdir_setup_refuses_apercode_itself(tmp_path):
    c = _client(tmp_path, sandbox.APP_ROOT / "work")
    assert c.post("/api/workdir/setup").status_code == 400
    assert not (sandbox.APP_ROOT / "work").exists()
