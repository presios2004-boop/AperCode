"""AperCode ハーネスの回帰テスト用の共通部品（v1.10.0）。

本物の LLM の代わりに、台本どおりに応答する FakeLLM を使ってエージェントループを動かす。
LLM の出来に左右されずに「フェーズの進み方・ツール制限・検証・巻き戻し」がハーネスとして正しく動くかを確かめる。
ユーザーのデータ（~/.apercode）には触れないよう、データフォルダは一時ディレクトリにする。
"""
from __future__ import annotations

import asyncio
import os
import sys
import tempfile
import uuid
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="apercode_test_"))
os.environ["APERCODE_DATA_DIR"] = str(_TMP / "data")          # codeagent.config を import する前に設定する
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import pytest  # noqa: E402

from codeagent.config import Config  # noqa: E402
from codeagent.llm import LLMClient  # noqa: E402
from codeagent.session import Session, SessionStore  # noqa: E402
from codeagent.agent import Agent  # noqa: E402

GOOD = "def add(a, b):\n    return a + b\n"
BAD = "def add(a, b):\n    return a - b\n"
TEST = "from calc import add\n\n\ndef test_add():\n    assert add(2, 3) == 5\n"
TASK = "calc.py に add 関数を実装してテストを通してください"


def tc(name: str, **args) -> dict:
    """ツール呼び出し 1 件（台本用）。"""
    return {"id": uuid.uuid4().hex[:8], "name": name, "args": args}


class FakeLLM(LLMClient):
    """台本（[("tools", [tc(...)]) | ("text", "...")]）を順に返す LLM。受け取ったシステムプロンプトとツール一覧を記録する。"""

    def __init__(self, cfg, script):
        super().__init__(cfg)
        self.script = list(script)
        self.systems: list[str] = []
        self.toolsets: list[list[str]] = []
        self.thinks: list = []                      # 各呼び出しの think 引数（思考の打ち切り後は "off"）
        self.clarify = "OK"                         # v2.0.0: 指示書の不足点検への応答

    async def chat(self, system, messages, tools, model=None, options=None, think=None, *a, **k):
        self.systems.append(system)
        self.toolsets.append([t["function"]["name"] for t in tools])
        self.thinks.append(think)
        kind, data = self.script.pop(0) if self.script else ("text", "（台本終了）")
        if kind == "think":                         # data 文字ぶん考え続ける（思考のループ）
            for _ in range(int(data) // 1000):
                yield ("thinking", "考" * 1000)
            yield ("text", "（思考の後の本文）")
        elif kind == "text":
            yield ("text", data)
        else:
            for c in data:
                yield ("tool_call", c)
        yield ("done", {"prompt_tokens": 100, "completion_tokens": 10})

    async def complete(self, system, text, model=None, options=None, *a, **k):
        if "点検" in (system or "") or "gaps" in (system or ""):
            return self.clarify
        return "# 目的\nadd を実装する\n## 完了条件\n- [ ] テストが通る"


class Harness:
    def __init__(self, root: Path):
        self.root = root
        self.events: list[dict] = []

    async def emit(self, ev: dict) -> None:
        self.events.append(ev)

    async def approve(self, req: dict) -> str:
        return "allow"

    def project(self, with_test: bool = True, files: dict[str, str] | None = None) -> Path:
        p = self.root / ("proj_" + uuid.uuid4().hex[:6])
        p.mkdir(parents=True)
        if with_test:
            (p / "tests").mkdir()
            (p / "tests" / "test_calc.py").write_text(TEST)
            (p / "conftest.py").write_text("import sys, os\nsys.path.insert(0, os.path.dirname(__file__))\n")
        for k, v in (files or {}).items():
            (p / k).parent.mkdir(parents=True, exist_ok=True)
            (p / k).write_text(v)
        return p

    def make(self, script, proj: Path, overrides: dict | None = None, store: SessionStore | None = None, mode: str = "work"):
        cfg = Config.load(ROOT / "config.yaml" if (ROOT / "config.yaml").exists() else ROOT / "config.example.yaml")
        base = {"memory.enabled": False, "browser.enabled": False, "verify.review.enabled": False,
                "compaction.background": False, "workspace.root": str(self.root), "verify.coverage": "off",
                "verify.types": "off"}
        for k, v in {**base, **(overrides or {})}.items():
            cur = cfg.data
            ks = k.split(".")
            for x in ks[:-1]:
                cur = cur.setdefault(x, {})
            cur[ks[-1]] = v
        llm = FakeLLM(cfg, script)
        store = store or SessionStore(self.root / "sessions")
        agent = Agent(cfg, llm, store)
        s = Session.new(str(proj))
        s.mode = mode                      # v2.1.0: 既存のテストは「作業モード」で動かす（auto の切り替えは専用のテストで確かめる）
        store.save(s)
        return agent, llm, store, s

    def run(self, agent, session, text: str):
        asyncio.run(agent.run(session, text, self.emit, self.approve))

    def of(self, kind: str) -> list[dict]:
        return [e for e in self.events if e.get("type") == kind]


@pytest.fixture
def h(tmp_path) -> Harness:
    return Harness(tmp_path)
