"""v2.11.0 の回帰テスト: 相場分析（research_note / research_summary / market_stats / research_scenarios / market_data）。"""
from __future__ import annotations

import math
import shutil
import stat
import uuid
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from codeagent import research as R
from codeagent import sandbox
from codeagent import tools as T

needs_bwrap = pytest.mark.skipif(not sandbox.available(), reason="bubblewrap が使えない環境")
PAGE = ("URL: https://www.example-bank.jp/fx/usdjpy-oct\nタイトル: ドル円見通し 10月\n\n"
        "日米金利差の縮小が続く中でも、ドル円は当面155〜160円のレンジで推移すると予想します。"
        "日銀の追加利上げは円高要因ですが、160円超では介入への警戒が強まります。")


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def _note(stance, inst, pub, targets=(), drivers=(), conv="medium", stype="bank", url=None):
    return {"topic": "USDJPY", "source": {"institution": inst, "url": url or f"https://{inst}.example/r", "published": pub, "type": stype},
            "stance": stance, "conviction": conv, "targets": [{"level": t} for t in targets],
            "drivers": [{"factor": f, "effect": e} for f, e in drivers], "quotes": ["引用"],
            "events": [{"date": "2026-10-30", "name": "日銀会合"}]}


def test_note_quotes_are_checked_against_what_was_read(h, monkeypatch):
    async def handler(ctx, a):
        return PAGE
    T.load_builtin()
    monkeypatch.setattr(T.get("fetch_url"), "handler", handler)
    proj = h.project(with_test=False)
    note = {"topic": "USDJPY", "source": {"institution": "Example Bank", "url": "https://www.example-bank.jp/fx/usdjpy-oct",
                                          "published": "2026-10-01", "type": "bank"},
            "stance": "range", "targets": [{"level": 155, "kind": "support"}, {"level": 160, "kind": "resistance"}],
            "drivers": [{"factor": "日米金利差", "effect": "down"}, {"factor": "介入警戒", "effect": "down"}],
            "quotes": ["ドル円は当面155〜160円のレンジで推移すると予想します", "ドル円は170円を目指す"]}
    script = [("tools", [call("fetch_url", url="https://www.example-bank.jp/fx/usdjpy-oct")]),
              ("tools", [call("research_note", **note)]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "security.ask_on_injection": False})
    h.run(agent, s, "資料を読んでノートにして")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "research_note"][0]
    assert "引用 1/2 件を本文で確認" in out and "見つかりません" in out
    saved = R.load_notes(proj, "USDJPY")[0]
    assert saved["quotes"][0]["found"] and not saved["quotes"][1]["found"]


def test_note_requires_source_and_quotes(tmp_path):
    with pytest.raises(R.ResearchError, match="quotes"):
        R.save_note(tmp_path, {**_note("up", "A", "2026-10-01"), "quotes": []})
    with pytest.raises(R.ResearchError, match="stance"):
        R.save_note(tmp_path, {**_note("up", "A", "2026-10-01"), "stance": "sideways"})


def test_summary_aggregates_and_finds_conflicts(tmp_path):
    now = datetime(2026, 10, 7)
    R.save_note(tmp_path, _note("up", "BankA", "2026-10-01", (160, 162), [("日米金利差", "up")], "high"))
    R.save_note(tmp_path, _note("up", "BankB", "2026-09-28", (158,), [("日米金利差", "up")]))
    R.save_note(tmp_path, _note("down", "BankC", "2026-10-03", (150,), [("日銀の利上げ", "down"), ("日米金利差", "down")]))
    R.save_note(tmp_path, _note("up", "Old", "2026-01-01", (170,)))
    data, md = R.summarize(tmp_path, "USDJPY", now=now)
    assert data["tally"]["up"] == 2 and data["tally"]["down"] == 1 and data["stale"] == ["Old_20260101"]
    assert data["lean"] == "up" and data["targets"]["median"] == 159.0
    assert any("割れています" in c for c in data["conflicts"])
    assert data["drivers"][0]["factor"] == "日米金利差" and data["drivers"][0]["count"] == 3
    assert (tmp_path / "research" / "USDJPY" / "summary.md").exists() and "重み付きの合意" in md


def _write_csv(path: Path, n_trend=744, n_range=672):   # 1 月はトレンドだけ、2 月はレンジだけ
    t = datetime(2026, 1, 1)
    rows = ["time,open,high,low,close,tick_volume,spread"]
    p = 150.0
    for i in range(n_trend + n_range):
        if i < n_trend:
            p += 0.02 + 0.03 * math.sin(i / 3)
        else:
            p = 158 + 1.5 * math.sin(i / 12)
        o, c = p - 0.01, p
        rows.append(f"{(t + timedelta(hours=i)).strftime('%Y.%m.%d %H:%M')},{o:.3f},{max(o, c) + 0.05:.3f},{min(o, c) - 0.05:.3f},{c:.3f},100,5")
    path.write_text("\n".join(rows) + "\n")


def test_market_stats_regimes_levels_and_targets(tmp_path):
    R.save_note(tmp_path, _note("up", "BankA", "2026-10-01", (162,)))
    R.summarize(tmp_path, "USDJPY", now=datetime(2026, 10, 7))
    csvp = tmp_path / "market_data" / "USDJPY_H1.csv"
    csvp.parent.mkdir()
    _write_csv(csvp)
    data, md = R.market_stats(csvp, "USDJPY", tmp_path)
    regs = {r["regime"] for r in data["regimes"]}
    assert data["timeframe"] == "H1" and data["bars"] == 1416
    assert "trend_up" in regs and "range" in regs
    assert data["levels"] and data["target_check"]["median"]["level"] == 162
    assert "月ごとの相場の型" in md and Path(data["report"]).exists()


def test_load_rates_mt5_gui_export(tmp_path):
    p = tmp_path / "x.csv"
    lines = ["<DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>\t<VOL>\t<SPREAD>"]
    for i in range(40):
        lines.append(f"2026.09.{1 + i // 24:02d}\t{i % 24:02d}:00:00\t150.0\t150.2\t149.9\t150.1\t10\t0\t3")
    p.write_text("\n".join(lines))
    rows = R.load_rates(p)
    assert len(rows) == 40 and rows[0]["t"] == datetime(2026, 9, 1, 0, 0)


def test_scenarios_are_validated(tmp_path):
    path, data, _ = R.save_note(tmp_path, _note("up", "BankA", "2026-10-01"))
    with pytest.raises(R.ResearchError, match="invalidation"):
        R.save_scenarios(tmp_path, "USDJPY", [{"role": "main", "premise": "x", "triggers": "y", "regime": "range", "strategy": "z"}])
    p, md, warns = R.save_scenarios(tmp_path, "USDJPY", [
        {"role": "main", "name": "レンジ継続", "premise": "155〜160 のレンジ", "triggers": ["155 付近で反発"],
         "invalidation": ["160 を上抜けて定着"], "regime": "range", "strategy": "逆張り", "evidence": [data["id"]]},
        {"role": "risk", "name": "介入で急落", "premise": "160 超で介入", "triggers": "160 超え; 当局の発言",
         "invalidation": "158 を回復", "regime": "high_volatility", "strategy": "ロット縮小", "evidence": ["nope"]}])
    assert p.exists() and "メイン: レンジ継続" in md and "リスク: 介入で急落" in md
    assert any("nope" in w for w in warns)


@needs_bwrap
def test_market_data_exports_prices_via_mt5(h, monkeypatch, tmp_path):
    import os
    prefix = Path.home() / f".apercode_mt5test_{uuid.uuid4().hex[:6]}"
    term = prefix / "drive_c" / "Program Files" / "MT5"
    (term / "MQL5" / "Files").mkdir(parents=True)
    (term / "terminal64.exe").write_text("")
    (term / "MetaEditor64.exe").write_text("")
    bindir = tmp_path / "bin"
    bindir.mkdir()
    wine = bindir / "wine"                         # 偽の MT5: MetaEditor はスクリプトの .ex5 を作り、terminal は依頼どおり CSV を書く
    wine.write_text("#!/usr/bin/env python3\nimport os, sys\n"
                    "if sys.argv[1].startswith('MetaEditor'):\n"
                    "    src = next(a[9:] for a in sys.argv if a.startswith('/compile:')).replace('\\\\', '/')\n"
                    "    open(os.path.splitext(src)[0] + '.ex5', 'wb').write(b'EX5')\n"
                    "    open(os.path.splitext(src)[0] + '.log', 'wb').write('Result: 0 errors, 0 warnings'.encode('utf-16'))\n"
                    "    sys.exit(0)\n"
                    "cfg = next(a[8:] for a in sys.argv if a.startswith('/config:'))\n"
                    "assert ' ' not in cfg and '/portable' in sys.argv\n"
                    "req = dict(l.split('=', 1) for l in open('MQL5/Files/apercode_export_request.txt').read().split())\n"
                    "rows = ['time,open,high,low,close,tick_volume,spread'] + "
                    "[f'2026.09.01 {i:02d}:00,150.0,150.2,149.9,150.1,10,3' for i in range(24)]\n"
                    "open('MQL5/Files/' + req['out'], 'w').write('\\n'.join(rows) + '\\n')\n"
                    "open('MQL5/Files/apercode_export_done.txt', 'w').write('ok 24')\n")
    wine.chmod(wine.stat().st_mode | stat.S_IEXEC)
    monkeypatch.setenv("PATH", f"{bindir}:{os.environ['PATH']}")
    try:
        proj = h.project(with_test=False)
        over = {"autonomy.enabled": True, "sandbox.mode": "auto", "phases.enabled": False, "mt5.wine_prefix": str(prefix),
                "mt5.terminal_dir": "drive_c/Program Files/MT5", "mt5.mql5_dir": "drive_c/Program Files/MT5/MQL5"}
        reqs = []

        async def approve(req):
            reqs.append(req)
            return "deny"
        h.approve = approve
        script = [("tools", [call("market_data", symbol="USDJPY", period="H1", bars=24)]), ("text", "done")]
        agent, llm, store, s = h.make(script, proj, over)
        h.run(agent, s, "価格を書き出して")
        out = [e["output"] for e in h.of("tool_result") if e.get("name") == "market_data"][0]
        assert not reqs                                                  # 自律モードでは確認なし
        assert "24 本" in out and (proj / "market_data" / "USDJPY_H1.csv").exists(), out
        assert (term / "MQL5" / "Scripts" / "AperCode" / "AperCode_ExportRates.mq5").exists()
        assert "symbol=USDJPY" in (term / "MQL5" / "Files" / "apercode_export_request.txt").read_text()
    finally:
        shutil.rmtree(prefix, ignore_errors=True)
