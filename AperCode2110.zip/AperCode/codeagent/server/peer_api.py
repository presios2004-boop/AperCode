"""ピア API（v2.0.0）: LAN 上の別の AperCode から作業の依頼・会話・確認を受け付ける。

画面用のサーバー（127.0.0.1）とは別のポートで待ち受け、ピア用のエンドポイントだけを公開する。
- すべてのリクエストに `Authorization: Bearer <peer.token>` が必要（token が空なら起動しない）
- 依頼はこの AperCode の LLM・ツール・権限設定で実行する。承認が必要な操作は peer.on_approval に従う
  （deny = 拒否 / allow_edit = 編集・実行は許可、危険な操作・プロジェクト外・GUI は拒否 / allow = すべて許可）
- 依頼されたセッションは画面のセッション一覧にも出る（何をされたかを人が後から確認できる）
- 任意のコマンドは受け付けない。テストはプロジェクトから自動検出したコマンドだけを実行する

エンドポイント（すべて /peer 以下）:
  GET  /peer/info                       名前・バージョン・モデル・受け付けるプロジェクト・実行中の依頼数
  POST /peer/tasks                      依頼を始める {text, project, mode: code|explore, sender, files: {name: content}}
  POST /peer/tasks/{id}/message         同じ依頼に返事・追加の指示を送る {text, files}
  GET  /peer/tasks/{id}?wait=秒          状態と最後の応答（wait 秒まで完了を待つ）
  POST /peer/tasks/{id}/cancel          中止
  GET  /peer/files?project=&path=        ファイルの読み取り（ディレクトリなら一覧）
  POST /peer/verify {project}            テストを実行して結果を返す
"""
from __future__ import annotations

import asyncio
import hmac
import socket
import time
from collections import deque
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

from .. import __version__
from .. import tools as T
from ..config import expand
from ..session import Session

PEER_TOOLS = {"ask_peer", "peer_reply", "peer_status", "peer_read_file", "peer_verify", "peer_list", "cloud_chat"}
GUI_TOOLS = {"gui_launch", "gui_activate", "gui_input", "gui_windows", "screenshot"}
# ピアからの依頼では、ローカルの権限設定が allow でも承認方針（peer.on_approval）に通すツール
FORCE_ASK = {"run_command", "process_start", "process_stop", "repl", "mt5_compile", "mt5_backtest", "make_icon", "restore_backup",
             "fetch_url", "browser_open", "browser_read", "browser_click", "browser_type", "browser_press", "browser_scroll",
             "browser_eval", "browser_screenshot", "browser_console", "browser_close", "ask_cloud", "save_memory"} | GUI_TOOLS
EVENT_TYPES = {"info", "verify", "phase", "checkpoint", "rollback", "brief", "error", "tool_call"}
MAX_FILE = 200_000


class TaskIn(BaseModel):
    text: str
    project: str = ""
    mode: str = "code"
    sender: str = ""
    files: dict[str, str] = {}


class MessageIn(BaseModel):
    text: str
    files: dict[str, str] = {}


class VerifyIn(BaseModel):
    project: str = ""


def peer_name(cfg) -> str:
    return str(cfg.get("peer.name") or "") or socket.gethostname()


def create_peer_app(cfg, agent, store, running: dict) -> FastAPI:
    app = FastAPI(title="AperCode peer", version=__version__)
    token = str(cfg.get("peer.token") or "")
    tasks: dict[str, dict] = {}
    # 受け付けるプロジェクトは明示が必要（空ならピア API は起動しない。serve_peer で確認）
    roots = [expand(p).resolve() for p in (cfg.get("peer.projects") or []) if str(p).strip()]
    from ..config import ensure_data_dir
    data_dirs = {Path(ensure_data_dir()).resolve(), Path(store.root).resolve(), (Path.home() / ".apercode").resolve()}

    def _auth(request: Request) -> None:
        got = request.headers.get("authorization", "")
        if not token or not hmac.compare_digest(got.encode(), f"Bearer {token}".encode()):
            raise HTTPException(401, "unauthorized")

    def _roots() -> list[Path]:
        return roots

    def _forbidden(p: Path, base: Path) -> bool:
        """AperCode のデータ（設定・API キー・セッション）と、base より下のドットで始まるフォルダ・ファイル（.ssh・.env など）は対象にしない。"""
        if any(p == d or d in p.parents for d in data_dirs):
            return True
        try:
            rel = p.relative_to(base).parts
        except ValueError:
            return True
        return any(part.startswith(".") for part in rel)

    def _project(path: str) -> Path:
        p = expand(path) if path else roots[0]
        p = p.resolve()
        base = next((r for r in roots if p == r or r in p.parents), None)
        if base is None or not cfg.in_workspace(p) or _forbidden(p, base):
            raise HTTPException(403, f"このプロジェクトは受け付けていません: {p}")
        if not p.is_dir():
            raise HTTPException(404, f"ディレクトリがありません: {p}")
        return p

    def _busy() -> int:
        return sum(1 for r in tasks.values() if r["task"] is not None and not r["task"].done())

    def _tool_names(mode: str) -> list[str]:
        names = [t.name for t in T.all_tools() if t.name not in PEER_TOOLS]
        if mode == "explore":
            ro = set(T.READ_ONLY_TOOLS) | {"set_plan"}
            names = [n for n in names if n in ro]
        return names

    def _save_files(project: Path, tid: str, files: dict[str, str]) -> list[str]:
        """依頼側から届いたファイルは、プロジェクトのファイルを上書きせず受け取り用フォルダに置く。"""
        if not files:
            return []
        box = project / ".apercode" / "inbox" / tid
        box.mkdir(parents=True, exist_ok=True)
        out = []
        for i, (name, content) in enumerate(list(files.items())[:10]):
            safe = Path(str(name).replace("\\", "/")).name
            if safe in ("", ".", "..") or safe.startswith("."):
                safe = f"file{i}.txt"
            data = str(content)[:MAX_FILE]
            (box / safe).write_text(data, encoding="utf-8")
            out.append(str((box / safe).relative_to(project)))
        return out

    async def _approve(rec: dict, req: dict) -> str:
        mode = str(cfg.get("peer.on_approval", "deny")).lower()
        name = str(req.get("name") or "")
        decision = "deny"
        if mode == "allow":
            decision = "allow"
        elif mode == "allow_edit" and not req.get("reason") and name not in GUI_TOOLS:
            decision = "allow"         # 危険な操作・プロジェクト外・テスト変更（理由付きの確認）と GUI 操作は拒否
        rec["events"].append({"ts": time.time(), "type": "approval", "text": f"{name}: {'許可' if decision == 'allow' else '拒否'}"
                              + (f"（{req.get('reason')}）" if req.get("reason") else "")})
        return decision

    def _start(rec: dict, session: Session, text: str) -> None:
        async def emit(ev: dict):
            typ = ev.get("type")
            if typ in EVENT_TYPES:
                e = {"ts": time.time(), "type": typ}
                for k in ("text", "name", "summary", "phase", "idx", "n", "ok", "kind"):
                    if k in ev and isinstance(ev[k], (str, int, float, bool)):
                        e[k] = ev[k] if not isinstance(ev[k], str) else ev[k][:400]
                if typ == "phase":
                    rec["phase"] = {k: ev.get(k) for k in ("active", "phase", "idx", "n", "kind") if k in ev}
                rec["events"].append(e)
            elif typ == "verify_summary":
                rec["summary"] = {k: ev.get(k) for k in ("files", "lines", "checks", "tests", "tests_ok")}

        async def _run():
            try:
                await agent.run(session, text, emit, lambda req: _approve(rec, req), tool_names=rec["tools"],
                                force_ask=FORCE_ASK)
                rec["status"] = "cancelled" if rec.get("cancel_requested") else "done"
            except asyncio.CancelledError:
                rec["status"] = "cancelled"
                raise
            except Exception as e:  # noqa: BLE001
                rec["status"] = "error"
                rec["error"] = str(e)[:1000]
            finally:
                rec["finished"] = time.time()

        rec.update(status="running", started=time.time(), finished=0.0, error="", summary=None, cancel_requested=False)
        rec["run_ts"] = time.time()          # 圧縮で履歴が縮んでも、この実行の応答を時刻で見つける
        rec["task"] = asyncio.create_task(_run())
        running[session.id] = rec["task"]

    def _view(tid: str) -> dict:
        rec = tasks[tid]
        s = store.load(tid)
        reply = ""
        if s is not None:
            for m in reversed(s.messages):
                if float(m.get("ts") or 0) < rec.get("run_ts", 0):
                    break
                if m.get("role") == "assistant" and (m.get("content") or "").strip():
                    reply = m["content"]
                    break
        return {"id": tid, "status": rec["status"], "peer": peer_name(cfg), "project": rec["project"], "mode": rec["mode"],
                "reply": reply[-8000:], "error": rec.get("error", ""), "phase": rec.get("phase"),
                "events": list(rec["events"])[-40:], "summary": rec.get("summary"), "received_files": rec.get("received", []),
                "started": rec.get("started"), "finished": rec.get("finished")}

    @app.get("/peer/info")
    async def info(request: Request):
        _auth(request)
        return {"name": peer_name(cfg), "version": __version__, "model": agent.llm.model,
                "projects": [str(r) for r in _roots()], "busy": _busy(),
                "max_tasks": int(cfg.get("peer.max_tasks", 1)), "on_approval": str(cfg.get("peer.on_approval", "deny"))}

    @app.post("/peer/tasks")
    async def new_task(body: TaskIn, request: Request):
        _auth(request)
        if _busy() >= int(cfg.get("peer.max_tasks", 1)):
            raise HTTPException(429, "ほかの依頼を実行中です。終わってから依頼してください")
        mode = body.mode if body.mode in ("code", "explore") else "code"
        project = _project(body.project)
        s = Session.new(str(project))
        s.mode = "work"                   # ピアからの依頼は作業として受ける
        who = (body.sender or "peer")[:40]
        s.title = f"[{who}] " + (body.text.strip().splitlines() or [""])[0][:40]
        store.save(s)
        rec = {"task": None, "events": deque(maxlen=300), "project": str(project), "mode": mode, "sender": who,
               "tools": _tool_names(mode), "status": "queued"}
        tasks[s.id] = rec
        rec["received"] = _save_files(project, s.id, body.files)
        text = body.text
        if rec["received"]:
            text += "\n\n（依頼元から受け取ったファイル。プロジェクトのファイルは上書きされていない: " + ", ".join(rec["received"]) + "）"
        _start(rec, s, f"[{who} からの依頼]\n{text}")
        return {"id": s.id, "status": "running"}

    @app.post("/peer/tasks/{tid}/message")
    async def message(tid: str, body: MessageIn, request: Request):
        _auth(request)
        rec = tasks.get(tid)
        s = store.load(tid)
        if rec is None or s is None:
            raise HTTPException(404, "依頼がありません")
        busy_here = running.get(tid)
        if (rec["task"] is not None and not rec["task"].done()) or (busy_here is not None and not busy_here.done()):
            raise HTTPException(409, "まだ実行中です。終わってから送ってください")
        if _busy() >= int(cfg.get("peer.max_tasks", 1)):
            raise HTTPException(429, "ほかの依頼を実行中です。終わってから送ってください")
        got = _save_files(Path(rec["project"]), tid, body.files)
        rec["received"] = rec.get("received", []) + got
        text = body.text + (("\n\n（受け取ったファイル: " + ", ".join(got) + "）") if got else "")
        _start(rec, s, f"[{rec['sender']} からの返事]\n{text}")
        return {"id": tid, "status": "running"}

    @app.get("/peer/tasks/{tid}")
    async def status(tid: str, request: Request, wait: float = 0):
        _auth(request)
        rec = tasks.get(tid)
        if rec is None:
            raise HTTPException(404, "依頼がありません")
        deadline = time.time() + max(0.0, min(wait, 120.0))
        while rec["task"] is not None and not rec["task"].done() and time.time() < deadline:
            await asyncio.sleep(0.5)
        return _view(tid)

    @app.post("/peer/tasks/{tid}/cancel")
    async def cancel(tid: str, request: Request):
        _auth(request)
        rec = tasks.get(tid)
        if rec is None:
            raise HTTPException(404, "依頼がありません")
        if rec["task"] is not None and not rec["task"].done():
            rec["cancel_requested"] = True
            agent.cancel(tid)
        return {"id": tid, "status": "cancelling" if rec.get("cancel_requested") else rec["status"]}

    @app.get("/peer/files")
    async def files(request: Request, project: str = "", path: str = ""):
        _auth(request)
        root = _project(project)
        p = (root / path).resolve() if path else root
        if (p != root and root not in p.parents) or _forbidden(p, root):
            raise HTTPException(403, "このファイルは読めません（プロジェクトの外・ドットで始まるフォルダ／ファイル）")
        if p.is_dir():
            items = []
            for c in sorted(p.iterdir(), key=lambda c: c.name.lower())[:500]:
                if c.name.startswith(".") or c.name in ("__pycache__", "node_modules"):
                    continue
                items.append(c.name + ("/" if c.is_dir() else ""))
            return {"path": str(p.relative_to(root)) if p != root else ".", "entries": items}
        if not p.is_file():
            raise HTTPException(404, "ファイルがありません")
        data = p.read_bytes()[:MAX_FILE]
        return {"path": str(p.relative_to(root)), "size": p.stat().st_size, "truncated": p.stat().st_size > MAX_FILE,
                "content": data.decode("utf-8", errors="replace")}

    @app.post("/peer/verify")
    async def verify(body: VerifyIn, request: Request):
        _auth(request)
        from .. import verify as V
        root = _project(body.project)
        r = await V.run_tests(root, None, timeout=int(cfg.get("peer.test_timeout", 900)))
        return {"detected": r.detected, "command": r.command, "ok": r.ok, "passed": r.passed, "failed": r.failed,
                "output": r.output[-6000:]}

    return app


async def serve_peer(cfg, agent, store, running: dict):
    """画面用サーバーと同じイベントループで、ピア API を別ポートで待ち受ける。停止用の Server を返す。"""
    import contextlib
    import uvicorn

    class _Server(uvicorn.Server):
        def install_signal_handlers(self):  # 画面用サーバーのシグナル処理に任せる
            pass

        @contextlib.contextmanager
        def capture_signals(self):
            yield

    host = str(cfg.get("peer.host", "0.0.0.0"))
    port = int(cfg.get("peer.port", 8766))
    server = _Server(uvicorn.Config(create_peer_app(cfg, agent, store, running), host=host, port=port, log_level="warning"))

    async def _serve():
        # uvicorn は待ち受けに失敗すると SystemExit を投げる。画面用サーバーまで止めないよう、ここで受け止める
        try:
            await server.serve()
        except (SystemExit, OSError) as e:
            print(f"AperCode: ピア API を {host}:{port} で起動できませんでした（{e!r}）。ポートが使用中でないか確認してください")
    return server, asyncio.create_task(_serve())


def peer_ready(cfg) -> str:
    """ピア API を起動できる設定か。問題があれば理由（空文字 = 起動できる）。"""
    if not str(cfg.get("peer.token") or ""):
        return "peer.enabled ですが peer.token が空のため、ピア API は起動しません"
    if not [p for p in (cfg.get("peer.projects") or []) if str(p).strip()]:
        return "peer.enabled ですが peer.projects（依頼を受け付けるプロジェクト）が空のため、ピア API は起動しません"
    return ""
