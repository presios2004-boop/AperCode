"""スキル（v2.10.0）: AperCode が作り、必要なときに読み込んで使う「手順書＋スクリプト」の置き場。

Claude などの Agent Skills と同じ形にする。
  <作業ディレクトリ>/skills/<名前>/SKILL.md     … 先頭に YAML（name・description）、本文に手順
  <作業ディレクトリ>/skills/<名前>/<そのほか>    … スクリプト（.py / .sh / .js）・データ（.json / .csv など）・参考資料
使い方は 3 段階（必要になるまで中身を読まない）:
  1. システムプロンプトには、スキルの名前と説明（いつ使うか）の一覧だけを入れる
  2. 作業に合うスキルがあれば、LLM が use_skill で SKILL.md の本文を読み、その手順に従う
  3. スクリプトは run_skill でサンドボックスの中で実行する（スキルのフォルダは読み取り専用）
安全のため:
  - スキルの作成・更新は save_skill だけ（write_file / edit_file / コマンドではスキルのフォルダを変更できない）
  - 外部の内容を読んだ後（汚染あり）に作ったスキルは「未確認」になり、ユーザーが画面で確認するまで一覧に出さず、読めず、実行できない
  - 上書き・削除の前の版は ~/.apercode/skills_history/ に残す
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
from pathlib import Path

NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")
ALLOWED_EXT = {".md", ".txt", ".json", ".yaml", ".yml", ".csv", ".tsv", ".py", ".sh", ".js", ".mjs", ".html", ".css", ".sql", ".toml",
               ".ini", ".xml", ".j2", ".tmpl"}
RUN_EXT = {".py": "python", ".sh": "bash", ".js": "node", ".mjs": "node"}
MAX_FILE = 200_000
MAX_FILES = 30


class SkillError(ValueError):
    pass


def skills_dir(cfg) -> Path:
    """スキルの置き場（skills.dir。空なら AperCode の作業ディレクトリの skills）。"""
    from .config import expand
    v = str(cfg.get("skills.dir", "") or "").strip()
    return expand(v) if v else Path(cfg.default_project) / "skills"


def ensure_dir(cfg) -> Path:
    d = skills_dir(cfg)
    d.mkdir(parents=True, exist_ok=True)
    readme = d / "README.md"
    if not readme.exists():
        readme.write_text("# AperCode のスキル\n\n1 つのフォルダが 1 つのスキルです（`<名前>/SKILL.md` ＋ スクリプト・データ）。\n"
                          "AperCode が save_skill で作り、作業に合うときに use_skill で読み込み、run_skill でスクリプトを実行します。\n"
                          "手で置いたスキルも使えます。画面の「スキル」で一覧・確認・削除ができます。\n", encoding="utf-8")
    return d


def is_inside(cfg, p: Path) -> bool:
    try:
        d = skills_dir(cfg).resolve()
        q = Path(p).expanduser().resolve()
    except (OSError, RuntimeError):
        return False
    return q == d or d in q.parents


# ------------------------------------------------------------------ 登録簿（未確認の印。サンドボックスから見えない場所）
def _registry_path() -> Path:
    from . import sandbox
    from .config import DATA_DIR
    return Path(sandbox._data_dir or DATA_DIR) / "skills.json"


def _registry() -> dict:
    try:
        return json.loads(_registry_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save_registry(reg: dict) -> None:
    p = _registry_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(reg, ensure_ascii=False, indent=1), encoding="utf-8")


def _key(cfg, name: str) -> str:
    return f"{skills_dir(cfg).resolve()}::{name}"


def _digest(folder: Path) -> str:
    h = hashlib.sha256()
    for f in sorted(p for p in folder.rglob("*") if p.is_file()):
        h.update(str(f.relative_to(folder)).encode())
        h.update(f.read_bytes())
    return h.hexdigest()


# ------------------------------------------------------------------ 読み込み
_FM = re.compile(r"^\s*---\s*\n(.*?)\n---\s*(?:\n|$)", re.S)


def strip_frontmatter(text: str) -> str:
    """先頭の YAML（--- で囲む）を取り除く（v2.10.2: 何重に付いていても全部）。"""
    t = text or ""
    while True:
        m = _FM.match(t)
        if not m:
            return t.lstrip("\n")
        t = t[m.end():]


def _parse(md: str) -> tuple[dict, str]:
    """SKILL.md の先頭の YAML（--- で囲む）と本文。本文の先頭に重なった YAML は取り除く。"""
    meta: dict = {}
    body = md
    m = _FM.match(md)
    if m:
        try:
            import yaml
            meta = yaml.safe_load(m.group(1)) or {}
        except Exception:  # noqa: BLE001
            meta = {}
        body = strip_frontmatter(md[m.end():])
    return (meta if isinstance(meta, dict) else {}), body


def list_skills(cfg) -> list[dict]:
    d = skills_dir(cfg)
    out: list[dict] = []
    if not d.is_dir():
        return out
    reg = _registry()
    for sk in sorted(p for p in d.iterdir() if p.is_dir() and not p.name.startswith(".")):
        f = sk / "SKILL.md"
        if not f.is_file():
            continue
        try:
            meta, body = _parse(f.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            continue
        r = reg.get(_key(cfg, sk.name)) or {}
        status = "ok"
        if r.get("status") == "untrusted":
            status = "untrusted"
        files = sorted(str(p.relative_to(sk)) for p in sk.rglob("*") if p.is_file() and p.name != "SKILL.md")
        out.append({"name": sk.name, "description": str(meta.get("description") or "").strip()[:500],
                    "title": str(meta.get("name") or sk.name), "status": status, "files": files,
                    "scripts": [x for x in files if Path(x).suffix in RUN_EXT],
                    "created": r.get("created") or f.stat().st_mtime, "updated": f.stat().st_mtime,
                    "author": str(meta.get("author") or ("AperCode" if r else "")), "uses": int(r.get("uses", 0))})
    return out


def get(cfg, name: str) -> dict:
    """使ってよいスキルの本文（未確認なら SkillError）。"""
    if not NAME_RE.match(name or ""):
        raise SkillError(f"スキル名が不正です: {name}")
    sk = next((s for s in list_skills(cfg) if s["name"] == name), None)
    if sk is None:
        raise SkillError(f"スキル {name} がありません（list_skills で一覧を確認）")
    if sk["status"] != "ok":
        raise SkillError(f"スキル {name} は未確認です（外部の内容を読んだ後に作られたため）。ユーザーが画面の「スキル」で確認するまで使えません")
    folder = skills_dir(cfg) / name
    meta, body = _parse((folder / "SKILL.md").read_text(encoding="utf-8", errors="replace"))
    reg = _registry()
    r = reg.setdefault(_key(cfg, name), {})
    r["uses"] = int(r.get("uses", 0)) + 1
    r["last_used"] = time.time()
    _save_registry(reg)
    return {**sk, "body": body.strip(), "path": str(folder)}


def prompt_block(cfg, lang: str = "ja", limit: int = 40) -> str:
    """システムプロンプトに入れる一覧（確認済みのスキルの名前と説明だけ）。"""
    sks = [s for s in list_skills(cfg) if s["status"] == "ok"][:limit]
    d = skills_dir(cfg)
    if lang == "en":
        head = (f"\n\n## Skills (folder: {d})\nSaved procedures and scripts. When a task matches a skill's description, call use_skill "
                "to read it and follow it; run its scripts with run_skill. When you finish a procedure that is likely to be reused "
                "(a repeatable workflow, a useful script), save it with save_skill (name, when to use it, the steps, and any scripts). "
                "Fix an existing skill with edit_skill, sending only the part that changes.\n")
        rows = "".join(f"- {s['name']}: {s['description'] or '(no description)'}\n" for s in sks) or "- (no skills yet)\n"
    else:
        head = (f"\n\n## スキル（置き場: {d}）\n保存済みの手順書とスクリプト。作業が説明に当てはまるスキルがあれば、use_skill で読んで"
                "その手順に従う。スクリプトは run_skill で実行する。繰り返し使えそうな手順・便利なスクリプトができたら、save_skill で保存してよい"
                "（名前・いつ使うか・手順・スクリプト）。既にあるスキルの修正は edit_skill で、変える部分だけを送る（全部を送り直さない）。\n")
        rows = "".join(f"- {s['name']}: {s['description'] or '（説明なし）'}\n" for s in sks) or "- （まだありません）\n"
    return head + rows


# ------------------------------------------------------------------ 作成・削除
def _history(cfg, name: str, folder: Path, why: str) -> str:
    from . import sandbox
    from .config import DATA_DIR
    base = Path(sandbox._data_dir or DATA_DIR) / "skills_history" / name / (time.strftime("%Y%m%d-%H%M%S") + "_" + why)
    dst, i = base, 0
    while dst.exists():                        # v2.10.2: 同じ秒に何度変えても前の版を上書きしない
        i += 1
        dst = base.with_name(f"{base.name}_{i}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(folder, dst)
    return str(dst)


def save(cfg, name: str, description: str, instructions: str, files: dict | None = None, overwrite: bool = False,
         tainted: bool = False, session_id: str = "") -> dict:
    """スキルを作る・更新する。tainted なら未確認にする。"""
    name = (name or "").strip().lower()
    if not NAME_RE.match(name):
        raise SkillError("name は英小文字・数字・- _ で 63 文字まで（例: csv-cleanup）")
    description = " ".join(str(description or "").split())
    if len(description) < 10:
        raise SkillError("description に「何をするスキルか・いつ使うか」を書いてください（10 文字以上）")
    instructions = strip_frontmatter(str(instructions or ""))   # v2.10.2: LLM が本文にも YAML を書いても 2 重にしない
    if not instructions.strip():
        raise SkillError("instructions（手順）が空です")
    files = dict(files or {})
    if len(files) > MAX_FILES:
        raise SkillError(f"ファイルは {MAX_FILES} 個まで")
    for rel, content in files.items():
        p = Path(str(rel))
        if p.is_absolute() or ".." in p.parts or str(rel).startswith(".") or p.name == "SKILL.md":
            raise SkillError(f"ファイル名が不正です: {rel}（スキルのフォルダからの相対パス。SKILL.md は instructions に書く）")
        if p.suffix.lower() not in ALLOWED_EXT:
            raise SkillError(f"使えない拡張子です: {rel}（使えるもの: {' '.join(sorted(ALLOWED_EXT))}）")
        if len(str(content)) > MAX_FILE:
            raise SkillError(f"ファイルが大きすぎます: {rel}（{MAX_FILE} 文字まで）")
    root = ensure_dir(cfg)
    folder = root / name
    old = ""
    if folder.exists():
        if not overwrite:
            raise SkillError(f"スキル {name} は既にあります。更新するなら overwrite: true（前の版は履歴に残ります）")
        old = _history(cfg, name, folder, "before_update")
        shutil.rmtree(folder)
    folder.mkdir(parents=True)
    meta = {"name": name, "description": description, "author": "AperCode", "created": time.strftime("%Y-%m-%d %H:%M")}
    import yaml
    (folder / "SKILL.md").write_text("---\n" + yaml.safe_dump(meta, allow_unicode=True, sort_keys=False) + "---\n\n"
                                     + str(instructions).strip() + "\n", encoding="utf-8")
    for rel, content in files.items():
        f = folder / str(rel)
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(str(content), encoding="utf-8")
        if f.suffix in (".sh", ".py"):
            f.chmod(0o755)
    reg = _registry()
    reg[_key(cfg, name)] = {"status": "untrusted" if tainted else "ok", "created": time.time(), "session": session_id,
                            "sha": _digest(folder), "uses": int((reg.get(_key(cfg, name)) or {}).get("uses", 0))}
    _save_registry(reg)
    return {"name": name, "path": str(folder), "files": sorted(files), "status": "untrusted" if tainted else "ok", "previous": old}


def edit(cfg, name: str, file: str = "SKILL.md", old: str | None = None, new: str | None = None,
         content: str | None = None, replace_all: bool = False, delete: bool = False,
         tainted: bool = False, session_id: str = "") -> dict:
    """v2.10.2: スキルの 1 ファイルだけを変える（全部を送り直さずに済む）。
    old/new = 一部の置き換え、content = そのファイルを丸ごと書く（無ければ作る）、delete = そのファイルを消す。"""
    if not NAME_RE.match(name or ""):
        raise SkillError(f"スキル名が不正です: {name}")
    folder = skills_dir(cfg) / name
    if not (folder / "SKILL.md").is_file():
        raise SkillError(f"スキル {name} がありません（新しく作るなら save_skill）")
    rel = Path(str(file or "SKILL.md"))
    if rel.is_absolute() or ".." in rel.parts or str(rel).startswith("."):
        raise SkillError(f"ファイル名が不正です: {file}（スキルのフォルダからの相対パス）")
    if rel.suffix.lower() not in ALLOWED_EXT:
        raise SkillError(f"使えない拡張子です: {file}")
    f = folder / rel
    is_md = str(rel) == "SKILL.md"
    if delete:
        if is_md:
            raise SkillError("SKILL.md は消せません（スキルごと消すなら画面の「スキル」から）")
        if not f.is_file():
            raise SkillError(f"{file} がありません")
        prev = _history(cfg, name, folder, "before_edit")
        f.unlink()
        action = "削除"
    else:
        if content is None and old is None:
            raise SkillError("old_string と new_string（一部の置き換え）か、content（丸ごと）を指定してください")
        cur = f.read_text(encoding="utf-8", errors="replace") if f.is_file() else None
        if is_md:
            meta, body = _parse(cur or "")
            cur_body = body
        else:
            cur_body = cur
        if content is not None:
            text = strip_frontmatter(content) if is_md else str(content)
            action = "書き換え" if cur is not None else "作成"
        else:
            if cur_body is None:
                raise SkillError(f"{file} がありません（新しく作るなら content を指定）")
            n = cur_body.count(str(old))
            if n == 0:
                raise SkillError(f"old_string が {file} に見つかりません。read_file で今の内容を確認してください")
            if n > 1 and not replace_all:
                raise SkillError(f"old_string が {file} に {n} か所あります。前後も含めて一意にするか replace_all: true")
            text = cur_body.replace(str(old), str(new or ""), -1 if replace_all else 1)
            action = "置き換え"
        if len(text) > MAX_FILE:
            raise SkillError(f"ファイルが大きすぎます（{MAX_FILE} 文字まで）")
        prev = _history(cfg, name, folder, "before_edit")
        if is_md:
            import yaml
            meta = dict(meta)
            meta["updated"] = time.strftime("%Y-%m-%d %H:%M")
            text = "---\n" + yaml.safe_dump(meta, allow_unicode=True, sort_keys=False) + "---\n\n" + text.strip() + "\n"
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(text, encoding="utf-8")
        if f.suffix in (".sh", ".py"):
            f.chmod(0o755)
    reg = _registry()
    r = reg.setdefault(_key(cfg, name), {"created": time.time()})
    if tainted:
        r["status"] = "untrusted"                  # 外部の内容を読んだ後に変えたら、確認し直すまで使わない
    r["sha"] = _digest(folder)
    r["session"] = session_id or r.get("session", "")
    _save_registry(reg)
    return {"name": name, "file": str(rel), "action": action, "previous": prev, "status": r.get("status", "ok")}


def confirm(cfg, name: str) -> None:
    reg = _registry()
    r = reg.setdefault(_key(cfg, name), {})
    r["status"] = "ok"
    folder = skills_dir(cfg) / name
    if folder.is_dir():
        r["sha"] = _digest(folder)
    _save_registry(reg)


def delete(cfg, name: str) -> str:
    if not NAME_RE.match(name or ""):
        raise SkillError("スキル名が不正です")
    folder = skills_dir(cfg) / name
    if not folder.is_dir():
        raise SkillError(f"スキル {name} がありません")
    kept = _history(cfg, name, folder, "deleted")
    shutil.rmtree(folder)
    reg = _registry()
    reg.pop(_key(cfg, name), None)
    _save_registry(reg)
    return kept


def script_argv(cfg, name: str, script: str, args: list | None, project: Path) -> list[str]:
    """run_skill で実行するコマンド（サンドボックスで包む前）。"""
    sk = get(cfg, name)
    p = Path(str(script or ""))
    if p.is_absolute() or ".." in p.parts:
        raise SkillError("script はスキルのフォルダからの相対パスで指定してください")
    f = Path(sk["path"]) / p
    if not f.is_file():
        raise SkillError(f"スクリプト {script} がありません（あるもの: {', '.join(sk['scripts']) or 'なし'}）")
    kind = RUN_EXT.get(f.suffix.lower())
    if not kind:
        raise SkillError(f"{script} は実行できる種類ではありません（.py / .sh / .js）")
    from . import sandbox
    if kind == "python":
        env = sandbox.env_for(project)
        exe = shutil.which("python3", path=env.get("PATH")) or "python3"
    elif kind == "node":
        exe = shutil.which("node") or "node"
    else:
        exe = "/bin/bash"
    return [exe, str(f)] + [str(a) for a in (args or [])][:50]
