"""自律モード（v2.8.0）: 人が画面を見ていなくても作業が止まらないようにする。

前提はコマンドのサンドボックス（bubblewrap）が有効であること。無効なら自律モードは働かない。
  - サンドボックスの中からホームを見えなくする（見えるのは作業ディレクトリ・sandbox.readable / writable だけ）。
    ほかのプロセスも見えない（--unshare-pid）。持ち出せるのは作業ディレクトリの中身だけになる
  - 作業ディレクトリの中の操作（コマンド・ファイルの変更・パッケージのインストール）は自動で許可する
  - ターンごとに作業ディレクトリのスナップショットを ~/.apercode/snapshots に取る（壊れても戻せる。サンドボックスからは見えない）
  - 外部の内容を読んだ後（汚染あり）でも、サンドボックスの中の操作・作業ディレクトリ内のファイル変更・LAN のピアへの送信・
    許可したウィンドウ（autonomy.gui_windows）への入力は止めない。AI への指示に見える文言が見つかったときだけ、人の確認を待つ
  - 自動で許可したもの・人が判断したものは、すべて監査ログ（~/.apercode/audit/日付.jsonl）に説明付きで残す
"""
from __future__ import annotations

import hashlib
import json
import os
import tarfile
import time
from pathlib import Path

from . import sandbox

EXCLUDE_DIRS = {".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
                ".tox", "dist", "build", ".cache", "target"}
SAFE_GUI_KEYS = {"return", "enter", "ctrl+return", "ctrl+enter", "shift+return", "tab", "escape", "backspace",
                 "ctrl+a", "ctrl+v", "ctrl+c", "up", "down", "left", "right", "page_up", "page_down", "home", "end"}


def enabled(cfg) -> bool:
    return bool(cfg.get("autonomy.enabled", False))


def active(cfg) -> bool:
    """自律モードが働いているか（設定でオン、かつサンドボックスが使える）。"""
    return enabled(cfg) and sandbox.enabled()


def status(cfg) -> dict:
    if not enabled(cfg):
        return {"enabled": False, "active": False, "reason": ""}
    if not sandbox.enabled():
        return {"enabled": True, "active": False,
                "reason": "コマンドのサンドボックスが使えないため、自律モードは働いていません（sandbox.mode と bubblewrap を確認）"}
    return {"enabled": True, "active": True, "reason": ""}


def gui_allowed(cfg, name: str, args: dict) -> bool:
    """許可したウィンドウ（タイトルの一部）への、送信程度のキー操作か。"""
    if name not in ("gui_input", "gui_activate"):
        return False
    win = str(args.get("window") or "").lower()
    allow = [str(w).lower() for w in (cfg.get("autonomy.gui_windows", ["AperCode"]) or []) if str(w).strip()]
    if not win or not any(w in win for w in allow):
        return False
    keys = [str(k).lower().replace(" ", "") for k in (args.get("keys") or [])]
    return all(k in SAFE_GUI_KEYS for k in keys)


# ------------------------------------------------------------------ 監査ログ
def _data_root() -> Path:
    d = sandbox._data_dir
    if d is None:
        from .config import DATA_DIR
        d = DATA_DIR
    return Path(d)


def audit(entry: dict) -> None:
    """監査ログに 1 件追記する（失敗しても作業は止めない）。"""
    try:
        d = _data_root() / "audit"
        d.mkdir(parents=True, exist_ok=True)
        e = {"ts": time.time(), **entry}
        with open(d / time.strftime("%Y-%m-%d.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")
    except Exception:  # noqa: BLE001
        pass


def read_audit(limit: int = 200, session_id: str | None = None) -> list[dict]:
    """新しい順に返す。"""
    d = _data_root() / "audit"
    out: list[dict] = []
    if not d.is_dir():
        return out
    for f in sorted(d.glob("*.jsonl"), reverse=True):
        try:
            lines = f.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for ln in reversed(lines):
            try:
                e = json.loads(ln)
            except ValueError:
                continue
            if session_id and e.get("session") != session_id:
                continue
            out.append(e)
            if len(out) >= limit:
                return out
    return out


# ------------------------------------------------------------------ スナップショット
def _snap_dir(project: Path) -> Path:
    h = hashlib.sha1(str(Path(project).resolve()).encode()).hexdigest()[:12]
    return _data_root() / "snapshots" / h


def _files(project: Path) -> list[Path]:
    out = []
    for root, dirs, files in os.walk(project):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not (Path(root) / d).is_symlink()]
        for fn in files:
            p = Path(root) / fn
            if p.is_file() and not p.is_symlink():
                out.append(p)
    return out


def snapshot(project: Path, note: str = "", session_id: str = "", keep: int = 20, max_mb: float = 300) -> dict:
    """作業ディレクトリをまるごと保存する（.venv・node_modules などは除く）。結果のメタ情報（skipped なら理由付き）。"""
    project = Path(project).resolve()
    if not project.is_dir() or sandbox.is_protected(project):
        return {"skipped": "作業ディレクトリがありません"}
    files = _files(project)
    total = sum(p.stat().st_size for p in files)
    if total > max_mb * 1024 * 1024:
        return {"skipped": f"大きすぎるため保存しませんでした（{total / 1048576:.0f} MB > autonomy.snapshot_max_mb {max_mb:g} MB）"}
    d = _snap_dir(project)
    d.mkdir(parents=True, exist_ok=True)
    base = time.strftime("%Y%m%d-%H%M%S") + f"-{int(time.time() * 1000) % 1000:03d}"
    sid, n = base, 0
    while (d / f"{sid}.tar.gz").exists():       # v2.10.1: 同じミリ秒に 2 回保存しても上書きしない（復元前の保存が元の版を消していた）
        n += 1
        sid = f"{base}-{n}"
    with tarfile.open(d / f"{sid}.tar.gz", "w:gz") as tf:
        for p in files:
            tf.add(p, arcname=str(p.relative_to(project)))
    meta = {"id": sid, "project": str(project), "ts": time.time(), "files": len(files), "bytes": total,
            "note": note, "session": session_id}
    (d / f"{sid}.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    snaps = sorted(d.glob("*.tar.gz"))
    for old in snaps[:-max(1, keep)]:
        old.unlink(missing_ok=True)
        old.with_name(old.name.replace(".tar.gz", ".json")).unlink(missing_ok=True)
    return meta


def list_snapshots(project: Path) -> list[dict]:
    d = _snap_dir(project)
    out = []
    for m in sorted(d.glob("*.json"), reverse=True) if d.is_dir() else []:
        try:
            out.append(json.loads(m.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            continue
    return out


def restore(project: Path, sid: str) -> dict:
    """スナップショットの状態に戻す。今の状態は先に別のスナップショットとして保存する。"""
    project = Path(project).resolve()
    if sandbox.is_protected(project):
        raise ValueError("AperCode 自身の中には戻せません")
    if not sid.replace("-", "").isdigit():
        raise ValueError("スナップショットの名前が不正です")
    tar = _snap_dir(project) / f"{sid}.tar.gz"
    if not tar.is_file():
        raise ValueError(f"スナップショット {sid} がありません")
    before = snapshot(project, note=f"{sid} に戻す前の状態", keep=10 ** 6, max_mb=10 ** 6)
    with tarfile.open(tar, "r:gz") as tf:
        members = [m for m in tf.getmembers() if m.isfile() and not m.name.startswith(("/", "..")) and ".." not in Path(m.name).parts]
        keepset = {m.name for m in members}
        for p in _files(project):
            if str(p.relative_to(project)) not in keepset:
                p.unlink()
        for m in members:
            tf.extract(m, project, filter="data") if hasattr(tarfile, "data_filter") else tf.extract(m, project)
    return {"restored": sid, "files": len(members), "saved_before": before.get("id", "")}
