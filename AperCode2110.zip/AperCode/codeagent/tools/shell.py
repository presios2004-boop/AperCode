"""シェルコマンド実行ツール"""
from __future__ import annotations

import asyncio
import os  # noqa: F401
from pathlib import Path

from .. import sandbox

from . import Tool, ToolContext, ToolError, register

MAX_OUT = 30_000


async def run_shell(cmd: str, cwd: str, timeout: int = 120, env: dict | None = None,
                    root: str | None = None, sandboxed: bool = True) -> tuple[int, str]:
    """v2.5.0: サンドボックス（bubblewrap）の中で実行する。root = 書き込みを許す作業ディレクトリ（省略時は cwd）
    sandboxed=False は AperCode 自身が決めたコマンド（MT5 のコンパイルなど、設定された場所の道具）だけに使う。LLM のコマンドには使わない"""
    if sandboxed:
        try:
            argv = sandbox.shell(cmd, Path(cwd), Path(root) if root else None)
        except sandbox.SandboxError as e:
            return 126, str(e)
        base_env = sandbox.env_for(Path(root or cwd))
    else:
        argv, base_env = ["/bin/bash", "-c", cmd], dict(os.environ)
    proc = await asyncio.create_subprocess_exec(
        *argv, cwd=cwd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        start_new_session=not sandboxed, env={**base_env, **(env or {})})
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        _kill(proc, sandboxed)
        return -1, f"(タイムアウト {timeout}s)"
    except asyncio.CancelledError:          # v2.9.0: 強制停止 → コマンドも止める
        _kill(proc, sandboxed)
        raise
    text = out.decode("utf-8", errors="replace")
    if len(text) > MAX_OUT:
        text = text[:MAX_OUT // 2] + "\n... (中略) ...\n" + text[-MAX_OUT // 2:]
    return proc.returncode or 0, text


def _kill(proc, sandboxed: bool) -> None:
    """止める。サンドボックスの外で動かしたもの（wine など子を残すもの）はプロセスグループごと止める。"""
    try:
        if not sandboxed:
            import signal
            os.killpg(proc.pid, signal.SIGKILL)
        else:
            proc.kill()
    except (ProcessLookupError, PermissionError):
        pass


async def run_command(ctx: ToolContext, a: dict) -> str:
    cmd = a["command"]
    cwd = ctx.resolve(a.get("cwd", ".")) if a.get("cwd") else ctx.project_dir
    if not cwd.is_dir():
        raise ToolError(f"cwd がありません: {cwd}")
    timeout = int(a.get("timeout", 120))
    code, out = await run_shell(cmd, str(cwd), timeout, root=str(ctx.project_dir))
    return f"$ {cmd}\n(exit {code})\n{out}"


register(Tool("run_command",
              "シェルコマンドを実行する（bash）。ビルド・テスト・git 操作などに使う。長時間かかるものは timeout を指定。",
              {"type": "object", "properties": {
                  "command": {"type": "string"},
                  "cwd": {"type": "string", "description": "作業ディレクトリ（省略時はプロジェクト）"},
                  "timeout": {"type": "integer", "description": "秒（既定 120）"}},
               "required": ["command"]}, run_command, lambda a: a.get("command", "")))
