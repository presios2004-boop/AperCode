"""相場分析のツール（v2.11.0）: research_note / research_summary / market_stats / research_scenarios。"""
from __future__ import annotations

from pathlib import Path

from . import Tool, ToolContext, ToolError, register
from .. import research as R


async def research_note(ctx: ToolContext, a: dict) -> str:
    try:
        path, data, warns = R.save_note(ctx.project_dir, a, getattr(ctx, "fetched", None) or {})
    except R.ResearchError as e:
        raise ToolError(str(e))
    q = data["quotes"]
    out = [f"ノートを保存しました: {path}（ID: {data['id']}）",
           f"見通し: {R.STANCE_JA[data['stance']]}／確信度 {data['conviction']}／目標水準 {len(data['targets'])} 件／要因 {len(data['drivers'])} 件／"
           f"イベント {len(data['events'])} 件／引用 {data['quotes_verified']}/{len(q)} 件を本文で確認"]
    out += [f"⚠ {w}" for w in warns]
    out.append("資料を全部書き出したら research_summary で集計する")
    return "\n".join(out)


async def research_summary(ctx: ToolContext, a: dict) -> str:
    try:
        data, md = R.summarize(ctx.project_dir, str(a.get("topic") or ""), max_age_days=int(a.get("max_age_days") or 120))
    except R.ResearchError as e:
        raise ToolError(str(e))
    return f"（保存: {R.topic_dir(ctx.project_dir, data['topic']) / 'summary.md'}）\n\n" + md


async def market_stats(ctx: ToolContext, a: dict) -> str:
    p = ctx.resolve(str(a.get("path") or ""))
    if not p.is_file():
        raise ToolError(f"ファイルがありません: {p}（MT5 からは market_data で書き出せる）")
    try:
        data, md = R.market_stats(p, str(a.get("topic") or ""), ctx.project_dir)
    except R.ResearchError as e:
        raise ToolError(str(e))
    return f"（保存: {data['report']}）\n\n" + md


async def research_scenarios(ctx: ToolContext, a: dict) -> str:
    try:
        path, md, warns = R.save_scenarios(ctx.project_dir, str(a.get("topic") or ""), a.get("scenarios") or [])
    except R.ResearchError as e:
        raise ToolError(str(e))
    return f"シナリオを保存しました: {path}\n" + "".join(f"⚠ {w}\n" for w in warns) + "\n" + md


_NOTE_SCHEMA = {
    "type": "object", "properties": {
        "topic": {"type": "string", "description": "分析のテーマ（例: USDJPY）。同じテーマのノートがまとめて集計される"},
        "source": {"type": "object", "description": "資料の出どころ", "properties": {
            "institution": {"type": "string", "description": "発行元（例: 日本銀行, MUFG, OANDA）"},
            "title": {"type": "string"}, "author": {"type": "string"},
            "url": {"type": "string", "description": "読んだ URL（fetch_url / browser で読んだもの）"},
            "path": {"type": "string", "description": "ファイルなら read_document で読んだパス"},
            "published": {"type": "string", "description": "発行日 YYYY-MM-DD"},
            "type": {"type": "string", "description": "official（中央銀行・政府）/ bank / analyst / broker / media / blog"}}},
        "stance": {"type": "string", "description": "topic の価格の見通し: up / down / range / neutral"},
        "horizon": {"type": "string", "description": "見通しの期間（例: 1か月, 2026年末）"},
        "conviction": {"type": "string", "description": "資料の確信度: high / medium / low"},
        "targets": {"type": "array", "description": "資料が挙げた水準 [{level, by, kind: target|support|resistance}]",
                    "items": {"type": "object"}},
        "drivers": {"type": "array", "description": "根拠の要因 [{factor, effect: up|down|range, note}]（例: 日米金利差, 日銀の利上げ, 介入警戒）",
                    "items": {"type": "object"}},
        "events": {"type": "array", "description": "注目イベント [{date, name, impact}]", "items": {"type": "object"}},
        "quotes": {"type": "array", "items": {"type": "string"},
                   "description": "見通しの根拠になる原文の引用（1〜5 個、資料の文をそのまま。言い換えない）"},
        "summary": {"type": "string", "description": "資料の要点（3 行程度）"}},
    "required": ["topic", "source", "stance", "quotes"]}

register(Tool("research_note",
              "読んだ資料（レポート・記事・中央銀行の発表など）1 本を、決まった形のノートに書き出す。資料を 1 本読むたびに使う。"
              "引用は本文にあるかを AperCode が確かめる。",
              _NOTE_SCHEMA, research_note,
              lambda a: f"{a.get('topic', '')}: {(a.get('source') or {}).get('institution', '')} {a.get('stance', '')}"))
register(Tool("research_summary",
              "テーマのノートを集計する（見通しの票と重み付きの合意、目標水準の中央値・ばらつき、よく挙がる要因、イベントの日程、"
              "資料どうしの食い違い）。計算は AperCode が行う。シナリオを考える前に使う。",
              {"type": "object", "properties": {
                  "topic": {"type": "string"},
                  "max_age_days": {"type": "integer", "description": "これより古い資料は除く（既定 120 日）"}},
               "required": ["topic"]}, research_summary, lambda a: a.get("topic", "")))
register(Tool("market_stats",
              "価格データ（CSV）を分析する: 期間ごとの値動きと値幅、ATR、ボラティリティ、トレンドの強さ（効率比）、月ごとの相場の型、"
              "よく止まった水準、資料の目標水準までの距離。資料の主張を数字で確かめるときに使う。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": "CSV のパス（market_data で書き出したもの、または MT5 から書き出したもの）"},
                  "topic": {"type": "string", "description": "research のテーマ（指定すると目標水準までの距離も出す）"}},
               "required": ["path"]}, market_stats, lambda a: a.get("path", "")))
register(Tool("research_scenarios",
              "メインとリスクのシナリオを決まった型で保存する。各シナリオ: role（main / risk）, name, premise（前提）, "
              "triggers（発動条件）, invalidation（否定される条件）, regime（trend_up / trend_down / range / high_volatility）, "
              "horizon, strategy, ea_params（EA の設定の目安）, evidence（根拠のノート ID）, probability（任意）。EA を作る前に使う。",
              {"type": "object", "properties": {
                  "topic": {"type": "string"},
                  "scenarios": {"type": "array", "items": {"type": "object"}}},
               "required": ["topic", "scenarios"]}, research_scenarios,
              lambda a: f"{a.get('topic', '')}: {len(a.get('scenarios') or [])} 件"))
