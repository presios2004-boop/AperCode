"""MT5 (wine) 向けツール: mt5_compile / mt5_backtest

前提: WINEPREFIX 配下に MetaTrader 5 がインストールされ、MetaEditor64.exe / terminal64.exe が存在すること。
"""
from __future__ import annotations

import re
import shutil
import time
from pathlib import Path

from ..config import expand
from . import Tool, ToolContext, ToolError, register
from .shell import run_shell


def _mt5_paths(ctx: ToolContext) -> dict[str, Path]:
    cfg = ctx.cfg
    prefix = expand(cfg.get("mt5.wine_prefix", "~/.wine_mt5"))
    terminal_dir = prefix / cfg.get("mt5.terminal_dir")
    mql5_dir = prefix / cfg.get("mt5.mql5_dir")
    return {"prefix": prefix, "terminal_dir": terminal_dir, "mql5_dir": mql5_dir,
            "metaeditor": terminal_dir / "MetaEditor64.exe", "terminal": terminal_dir / "terminal64.exe"}


def _to_win(prefix: Path, p: Path) -> str:
    """WINEPREFIX/drive_c/... を C:\\... に変換する。"""
    rel = p.resolve().relative_to((prefix / "drive_c").resolve())
    return "C:\\" + str(rel).replace("/", "\\")


def _read_win_text(p: Path) -> str:
    raw = p.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):          # MetaEditor のログは UTF-16（BOM 付き）
        return raw.decode("utf-16", errors="replace")
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig", errors="replace")
    for enc in ("utf-8", "cp932", "utf-16"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def _place_source(ctx: ToolContext, src: Path, mql5_dir: Path) -> Path:
    """ソースが MQL5 フォルダ外なら MQL5/Experts/AperCode/ にコピーして、その先のパスを返す。"""
    if mql5_dir.resolve() in src.resolve().parents:
        return src
    dest_dir = mql5_dir / "Experts" / "AperCode"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / src.name
    shutil.copy2(src, dest)
    # 同階層の .mqh も一緒にコピー（インクルード用）
    for inc in src.parent.glob("*.mqh"):
        shutil.copy2(inc, dest_dir / inc.name)
    return dest


def _portable(ctx: ToolContext, paths: dict) -> bool:
    """MT5 がポータブル（データフォルダがインストール先の中）か。mt5.portable で明示も可（既定は自動判定）。"""
    v = ctx.cfg.get("mt5.portable", "auto")
    if isinstance(v, bool):
        return v
    try:
        return paths["terminal_dir"].resolve() in paths["mql5_dir"].resolve().parents
    except OSError:
        return False


def _running_metaeditor(prefix: Path) -> list[str]:
    """この WINEPREFIX で動いている MetaEditor（起動中の画面があると、コンパイルの依頼がそちらに渡って何もしないことがある）。"""
    import os
    out = []
    for d in Path("/proc").iterdir() if Path("/proc").is_dir() else []:
        if not d.name.isdigit():
            continue
        try:
            cmd = (d / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            if "metaeditor64.exe" not in cmd.lower():
                continue
            env = (d / "environ").read_bytes()
            if f"WINEPREFIX={prefix}".encode() in env or b"WINEPREFIX=" not in env:
                out.append(d.name)
        except OSError:
            continue
    return out


async def _compile_placed(ctx: ToolContext, paths: dict, placed: Path, timeout: int) -> tuple[bool, str, int, str, bool]:
    """MT5 フォルダの中に置いた .mq5 をコンパイルする。(成功, ログ, 終了コード, 出力, MetaEditor が既に起動中)"""
    log = placed.with_suffix(".log")
    ex5 = placed.with_suffix(".ex5")
    for f in (log, ex5):
        if f.exists():
            f.unlink()
    if _portable(ctx, paths):
        target = str(placed.resolve().relative_to(paths["terminal_dir"].resolve())).replace("/", "\\")
        cmd = f'wine MetaEditor64.exe /portable /compile:"{target}" /log'
    else:
        cmd = f'wine MetaEditor64.exe /compile:"{_to_win(paths["prefix"], placed)}" /log'
    env = {"WINEPREFIX": str(paths["prefix"]), "WINEDEBUG": "-all"}
    busy = bool(_running_metaeditor(paths["prefix"]))
    t0 = time.time()
    # v2.10.5: wine は WINEPREFIX 全体を使うので、サンドボックスの外で動かす（コマンドは AperCode が組み立てたもの）
    code, out = await run_shell(cmd, str(paths["terminal_dir"]), timeout=timeout, env=env, sandboxed=False)
    for _ in range(20):                          # 書き出しを少し待つ
        if log.exists() or ex5.exists():
            break
        await _sleep(0.5)
    text = _read_win_text(log).strip() if log.exists() else ""
    errs = re.findall(r"(\d+)\s+errors?", text)
    made = ex5.exists() and ex5.stat().st_mtime >= t0 - 2
    return made and (not errs or errs[-1] == "0"), text, code, out, busy


async def mt5_compile(ctx: ToolContext, a: dict) -> str:
    """v2.10.6: これまで動いていた方法（/portable・MT5 フォルダからの相対パス・/log で .mq5 の隣にログ）に合わせた。
    以前は絶対パスと /log:"パス" で呼んでいて、ポータブル版の MT5 では画面が開いたまま終わらず、ログも作られなかった。"""
    paths = _mt5_paths(ctx)
    if not paths["metaeditor"].exists():
        raise ToolError(f"MetaEditor64.exe が見つかりません: {paths['metaeditor']}（config.yaml の mt5 設定を確認）")
    src = ctx.resolve(a["path"])
    if src.suffix.lower() not in (".mq5", ".mq4"):
        raise ToolError("拡張子は .mq5 である必要があります")
    if not src.exists():
        raise ToolError(f"ファイルがありません: {src}")
    placed = _place_source(ctx, src, paths["mql5_dir"])
    ex5 = placed.with_suffix(".ex5")
    ok, text, code, out, busy = await _compile_placed(ctx, paths, placed, int(a.get("timeout", 180)))
    made = ex5.exists()
    errs = re.findall(r"(\d+)\s+errors?", text)
    warns = re.findall(r"(\d+)\s+warnings?", text)
    head = f"[{'成功' if ok else '失敗'}] errors={errs[-1] if errs else ('0' if made else '?')} " \
           f"warnings={warns[-1] if warns else '?'}（MetaEditor の終了コード {code}）"
    result = [head]
    if text:
        result.append(text[-6000:])
    elif code == -1:
        result.append(f"MetaEditor が終わりませんでした（タイムアウト）。{out[-500:]}")
    else:
        result.append("MetaEditor のコンパイルログがありません。" + (out[-1000:] if out.strip() else ""))
    if not made and busy:
        result.append("⚠ MetaEditor が既に起動しています。起動中の MetaEditor を閉じてから、もう一度 mt5_compile を実行してください"
                      "（MT5・wine の再インストールや設定変更はしないこと）")
    if made:
        result.append(f"出力: {ex5}")
        if placed != src:
            shutil.copy2(ex5, src.with_suffix(".ex5"))
            result.append(f"コピー: {src.with_suffix('.ex5')}")
    return "\n".join(result)


# ------------------------------------------------------------------ v2.11.0: 価格データの書き出し
EXPORT_SCRIPT = r"""//+------------------------------------------------------------------+
//| AperCode_ExportRates.mq5 （AperCode が自動で置くスクリプト）        |
//| MQL5/Files/apercode_export_request.txt の指定で価格を CSV に書き出し、 |
//| 終わったらターミナルを閉じる                                        |
//+------------------------------------------------------------------+
#property script_show_inputs false

ENUM_TIMEFRAMES TfFrom(string s)
  {
   if(s=="M1") return PERIOD_M1;   if(s=="M5") return PERIOD_M5;   if(s=="M15") return PERIOD_M15;
   if(s=="M30") return PERIOD_M30; if(s=="H1") return PERIOD_H1;   if(s=="H4") return PERIOD_H4;
   if(s=="D1") return PERIOD_D1;   if(s=="W1") return PERIOD_W1;   if(s=="MN1") return PERIOD_MN1;
   return PERIOD_H1;
  }

void Done(string status)
  {
   int h=FileOpen("apercode_export_done.txt",FILE_WRITE|FILE_TXT|FILE_ANSI);
   if(h!=INVALID_HANDLE) { FileWriteString(h,status); FileClose(h); }
  }

void OnStart()
  {
   string sym=_Symbol, out="apercode_rates.csv";
   ENUM_TIMEFRAMES tf=PERIOD_H1;
   int bars=3000;
   datetime from=0, to=0;
   int h=FileOpen("apercode_export_request.txt",FILE_READ|FILE_TXT|FILE_ANSI);
   if(h!=INVALID_HANDLE)
     {
      while(!FileIsEnding(h))
        {
         string ln=FileReadString(h);
         int p=StringFind(ln,"=");
         if(p<0) continue;
         string k=StringSubstr(ln,0,p), v=StringSubstr(ln,p+1);
         StringTrimLeft(v); StringTrimRight(v);
         if(k=="symbol") sym=v;
         else if(k=="period") tf=TfFrom(v);
         else if(k=="bars") bars=(int)StringToInteger(v);
         else if(k=="from") from=StringToTime(v);
         else if(k=="to") to=StringToTime(v);
         else if(k=="out") out=v;
        }
      FileClose(h);
     }
   SymbolSelect(sym,true);
   MqlRates r[];
   ArraySetAsSeries(r,false);
   int got=-1;
   for(int i=0;i<60;i++)                      // 履歴の読み込みを待つ（最大 60 秒）
     {
      if(from>0) got=CopyRates(sym,tf,from,(to>0?to:TimeCurrent()),r);
      else got=CopyRates(sym,tf,0,bars,r);
      if(got>0 && (from>0 || got>=bars)) break;
      Sleep(1000);
     }
   if(got<=0)
     {
      Done("error "+IntegerToString(GetLastError())+" "+sym);
      TerminalClose(0);
      return;
     }
   int digits=(int)SymbolInfoInteger(sym,SYMBOL_DIGITS);
   int f=FileOpen(out,FILE_WRITE|FILE_TXT|FILE_ANSI);
   if(f==INVALID_HANDLE) { Done("error open "+out); TerminalClose(0); return; }
   FileWriteString(f,"time,open,high,low,close,tick_volume,spread
");
   for(int i=0;i<got;i++)
      FileWriteString(f,TimeToString(r[i].time,TIME_DATE|TIME_MINUTES)+","+DoubleToString(r[i].open,digits)+","+
                      DoubleToString(r[i].high,digits)+","+DoubleToString(r[i].low,digits)+","+DoubleToString(r[i].close,digits)+","+
                      IntegerToString(r[i].tick_volume)+","+IntegerToString(r[i].spread)+"
");
   FileClose(f);
   Done("ok "+IntegerToString(got));
   TerminalClose(0);
  }
"""
TIMEFRAMES = ("M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN1")


async def market_data(ctx: ToolContext, a: dict) -> str:
    """MT5 から価格（OHLC）を CSV に書き出し、作業ディレクトリの market_data/ に置く。"""
    paths = _mt5_paths(ctx)
    if not paths["terminal"].exists():
        raise ToolError(f"terminal64.exe が見つかりません: {paths['terminal']}（config.yaml の mt5 設定を確認）")
    sym = re.sub(r"[^\w.#-]", "", str(a.get("symbol") or ctx.cfg.get("mt5.tester.symbol", "USDJPY")))
    tf = str(a.get("period") or "H1").upper()
    if tf not in TIMEFRAMES:
        raise ToolError(f"period は {' / '.join(TIMEFRAMES)} のどれか")
    bars = max(50, min(int(a.get("bars") or 3000), 200000))
    frm, to = str(a.get("from_date") or "").strip(), str(a.get("to_date") or "").strip()
    for v in (frm, to):
        if v and not re.fullmatch(r"\d{4}\.\d{2}\.\d{2}", v):
            raise ToolError("from_date / to_date は YYYY.MM.DD")
    scripts = paths["mql5_dir"] / "Scripts" / "AperCode"
    scripts.mkdir(parents=True, exist_ok=True)
    src = scripts / "AperCode_ExportRates.mq5"
    notes = []
    if not src.exists() or src.read_text(encoding="utf-8", errors="replace") != EXPORT_SCRIPT or not src.with_suffix(".ex5").exists():
        src.write_text(EXPORT_SCRIPT, encoding="utf-8")
        ok, text, code, out, busy = await _compile_placed(ctx, paths, src, 180)
        if not ok:
            raise ToolError("書き出し用スクリプトのコンパイルに失敗しました（MT5・wine の再インストールや設定変更はしないこと）\n"
                            + (text[-1500:] or out[-800:]) + ("\n起動中の MetaEditor を閉じてから再実行してください" if busy else ""))
        notes.append("書き出し用スクリプトを準備しました")
    files = paths["mql5_dir"] / "Files"
    files.mkdir(parents=True, exist_ok=True)
    out_name = f"apercode_{sym}_{tf}.csv"
    for f in (files / out_name, files / "apercode_export_done.txt"):
        if f.exists():
            f.unlink()
    req = [f"symbol={sym}", f"period={tf}", f"bars={bars}", f"out={out_name}"]
    if frm:
        req.append(f"from={frm}")
    if to:
        req.append(f"to={to}")
    (files / "apercode_export_request.txt").write_text("\n".join(req) + "\n", encoding="ascii")
    ini_dir = paths["prefix"] / "drive_c" / "apercode"           # 空白を含まない場所（v2.10.8）
    ini_dir.mkdir(parents=True, exist_ok=True)
    ini = ini_dir / "apercode_export.ini"
    ini.write_text("\n".join(["[StartUp]", "Script=AperCode\\AperCode_ExportRates", f"Symbol={sym}", f"Period={tf}",
                              "ShutdownTerminal=1", ""]), encoding="utf-8")
    cmd = f'wine terminal64.exe{" /portable" if _portable(ctx, paths) else ""} /config:"{_to_win(paths["prefix"], ini)}"'
    env = {"WINEPREFIX": str(paths["prefix"]), "WINEDEBUG": "-all"}
    t0 = time.time()
    code, out = await run_shell(cmd, str(paths["terminal_dir"]), timeout=int(a.get("timeout", 300)), env=env, sandboxed=False)
    csv_src = files / out_name
    done = files / "apercode_export_done.txt"
    status = done.read_text(errors="replace").strip() if done.exists() else ""
    if not csv_src.exists():
        hint = _terminal_log_hint(paths["terminal_dir"], t0)
        raise ToolError(f"価格データを書き出せませんでした（終了コード {code}、状態: {status or '不明'}）\n"
                        + (f"MT5 のログ（今回の分）:\n{hint}\n" if hint else "")
                        + "MT5・wine の再インストールや設定変更はせず、この内容をユーザーに報告すること")
    dest = ctx.project_dir / "market_data"
    dest.mkdir(parents=True, exist_ok=True)
    target = dest / f"{sym}_{tf}.csv"
    shutil.copy2(csv_src, target)
    lines = target.read_text(errors="replace").splitlines()
    rng = f"{lines[1].split(',')[0]} 〜 {lines[-1].split(',')[0]}" if len(lines) > 2 else ""
    return "\n".join(notes + [f"価格データを書き出しました: {target}（{max(len(lines) - 1, 0)} 本、{rng}）",
                               "分析は market_stats（path に上のファイル）で行う"])


async def _sleep(sec: float) -> None:
    import asyncio
    await asyncio.sleep(sec)


def _parse_report(html: str) -> str:
    """v2.10.7: ストラテジーテスターのレポートから「項目: 値」をすべて抜き出す（日本語・英語どちらの MT5 でも）。
    取引の一覧（注文・約定の表）の手前までを読む。"""
    cut = len(html)
    for mark in ("<b>注文</b>", "<b>Orders</b>", ">注文<", ">Orders<"):
        i = html.find(mark)
        if i != -1:
            cut = min(cut, i)
    text = re.sub(r"<[^>]+>", "\n", html[:cut])
    lines = [ln.strip().replace("\xa0", " ") for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]
    rows, i = [], 0
    while i < len(lines):
        ln = lines[i]
        if ln.endswith(":") and len(ln) <= 60 and i + 1 < len(lines) and not lines[i + 1].endswith(":"):
            val = lines[i + 1]
            j = i + 2                              # パラメータのように値が何行も続くもの
            if ln.rstrip(":") in ("パラメータ", "Inputs", "Parameters"):
                while j < len(lines) and not lines[j].endswith(":") and "=" in lines[j]:
                    val += ", " + lines[j]
                    j += 1
            rows.append(f"{ln} {val}")
            i = j
            continue
        i += 1
    return "\n".join(rows) if rows else "(指標を抽出できませんでした。レポートを直接確認してください)"


def _terminal_log_hint(terminal_dir: Path, since: float) -> str:
    """今回の実行で MT5 が書いたログのうち、設定・テスターに関係する行（エラーの手がかり）。"""
    logs = sorted((terminal_dir / "logs").glob("2*.log"))
    if not logs:
        return ""
    try:
        text = _read_win_text(logs[-1])
    except OSError:
        return ""
    since_hms = time.strftime("%H:%M:%S", time.localtime(since - 2))
    rows = []
    for ln in text.splitlines():
        parts = ln.split("\t")
        hms = parts[2][:8] if len(parts) > 3 else ""
        if hms and hms >= since_hms and re.search(r"config|Tester|cannot|error|failed|LiveUpdate|launched", ln, re.I):
            rows.append("\t".join(parts[2:]))
    return "\n".join(rows[-15:])


def _copy_report(ctx: ToolContext, report: Path) -> Path:
    """v2.10.7: レポート（.htm と画像）を作業ディレクトリの bt_reports/ にコピーする。
    MT5 のフォルダはサンドボックスや read_file から見えないので、LLM が読めるようにする。"""
    dest = ctx.project_dir / "bt_reports"
    dest.mkdir(parents=True, exist_ok=True)
    for f in report.parent.glob(report.stem + "*"):
        if f.is_file() and f.suffix.lower() in (".htm", ".html", ".xml", ".png"):
            shutil.copy2(f, dest / f.name)
    return dest / report.name


async def mt5_backtest(ctx: ToolContext, a: dict) -> str:
    paths = _mt5_paths(ctx)
    if not paths["terminal"].exists():
        raise ToolError(f"terminal64.exe が見つかりません: {paths['terminal']}")
    t = ctx.cfg.get("mt5.tester", {})
    src = ctx.resolve(a["path"])
    ex5 = src if src.suffix == ".ex5" else src.with_suffix(".ex5")
    placed = _place_source(ctx, src if src.suffix == ".mq5" else src.with_suffix(".mq5"), paths["mql5_dir"]) \
        if src.with_suffix(".mq5").exists() else None
    placed_ex5 = (placed.with_suffix(".ex5") if placed else ex5)
    if ex5.exists() and placed and not placed_ex5.exists():
        shutil.copy2(ex5, placed_ex5)
    if not placed_ex5.exists():
        raise ToolError(f"コンパイル済み .ex5 がありません: {placed_ex5}。先に mt5_compile を実行してください")
    experts_dir = paths["mql5_dir"] / "Experts"
    expert_rel = str(placed_ex5.relative_to(experts_dir)).replace("/", "\\")
    report_name = f"AperCode_{placed_ex5.stem}_{int(time.time())}"
    # v2.10.8: 設定ファイルは空白を含まない場所（C:\apercode\）に置く。"Program Files" のように空白があると、wine が引数全体を
    # 引用符で囲み、MT5 が /config: のパスの最後に " が付いたものとして読んで「cannot load config」になっていた
    ini_dir = paths["prefix"] / "drive_c" / "apercode"
    ini_dir.mkdir(parents=True, exist_ok=True)
    ini = ini_dir / "apercode_tester.ini"
    ini_text = "\n".join([
        "[Tester]",
        f"Expert={expert_rel}",
        f"Symbol={a.get('symbol', t.get('symbol', 'USDJPY'))}",
        f"Period={a.get('period', t.get('period', 'H1'))}",
        f"Model={a.get('model', t.get('model', 1))}",
        f"FromDate={a.get('from_date', t.get('from', '2024.01.01'))}",
        f"ToDate={a.get('to_date', t.get('to', '2024.12.31'))}",
        f"Deposit={t.get('deposit', 1000000)}",
        f"Leverage={t.get('leverage', 25)}",
        "Optimization=0",
        "Visual=0",
        f"Report={report_name}",
        "ReplaceReport=1",
        "ShutdownTerminal=1",
        "",
    ])
    if a.get("set_file"):
        ini_text += f"ExpertParameters={a['set_file']}\n"
    ini.write_text(ini_text, encoding="utf-8")
    cmd = f'wine terminal64.exe{" /portable" if _portable(ctx, paths) else ""} /config:"{_to_win(paths["prefix"], ini)}"'
    env = {"WINEPREFIX": str(paths["prefix"]), "WINEDEBUG": "-all"}
    t0 = time.time()
    code, out = await run_shell(cmd, str(paths["terminal_dir"]), timeout=int(a.get("timeout", 1800)), env=env, sandboxed=False)
    report = next((paths["terminal_dir"] / f"{report_name}{ext}" for ext in (".htm", ".html", ".xml")
                   if (paths["terminal_dir"] / f"{report_name}{ext}").exists()), paths["terminal_dir"] / f"{report_name}.htm")
    if not report.exists():
        hint = _terminal_log_hint(paths["terminal_dir"], t0)
        return (f"バックテストのレポートが見つかりません (exit {code})。\n"
                f"ini: {ini}\n" + (f"MT5 のログ（今回の分）:\n{hint}\n" if hint else
                                    f"ログ: {paths['terminal_dir']}/logs/ および Tester/logs/ を確認してください\n") +
                "MT5・wine の再インストールや設定変更はせず、この内容をユーザーに報告すること\n" + out[-800:])
    summary = _parse_report(_read_win_text(report))
    copied = _copy_report(ctx, report)
    md = copied.with_suffix(".md")
    md.write_text(f"# バックテスト結果: {placed_ex5.stem}\n\n元のレポート: {report}\n\n" +
                  "\n".join(f"- {r}" for r in summary.splitlines()) + "\n", encoding="utf-8")
    pngs = sorted(p.name for p in copied.parent.glob(copied.stem + "*.png"))
    return (f"レポート（作業ディレクトリにコピー済み。read_file / read_document で読める）:\n"
            f"- 指標の一覧: {md}\n- レポート本体: {copied}\n" +
            (f"- グラフ画像: {', '.join(pngs)}\n" if pngs else "") +
            f"\n## 指標\n{summary}")


register(Tool("mt5_compile",
              "MQL5 ソース (.mq5) を MetaEditor (wine) でコンパイルし、エラー/警告を返す。EA を書いたら必ず実行して確認する。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": ".mq5 ファイルのパス"},
                  "timeout": {"type": "integer"}},
               "required": ["path"]}, mt5_compile, lambda a: a.get("path", "")))

register(Tool("market_data",
              "MT5 から価格データ（始値・高値・安値・終値）を CSV に書き出し、作業ディレクトリの market_data/ に置く。"
              "相場の分析（market_stats）や、資料の主張の確認に使う。",
              {"type": "object", "properties": {
                  "symbol": {"type": "string", "description": "銘柄（既定は mt5.tester.symbol）"},
                  "period": {"type": "string", "description": "M1/M5/M15/M30/H1/H4/D1/W1/MN1（既定 H1）"},
                  "bars": {"type": "integer", "description": "本数（既定 3000。from_date を指定したときは使わない）"},
                  "from_date": {"type": "string", "description": "YYYY.MM.DD（任意）"},
                  "to_date": {"type": "string", "description": "YYYY.MM.DD（任意）"},
                  "timeout": {"type": "integer"}}},
              market_data, lambda a: f"{a.get('symbol', '')} {a.get('period', 'H1')} {a.get('bars') or a.get('from_date') or ''}"))

register(Tool("mt5_backtest",
              "コンパイル済み EA をストラテジーテスターでバックテストし、主要指標（純利益・PF・DD 等）を返す。時間がかかる。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": ".mq5 または .ex5 のパス"},
                  "symbol": {"type": "string"}, "period": {"type": "string", "description": "M1/M5/M15/H1/H4/D1"},
                  "from_date": {"type": "string", "description": "YYYY.MM.DD"},
                  "to_date": {"type": "string", "description": "YYYY.MM.DD"},
                  "model": {"type": "integer", "description": "0=every tick,1=1min OHLC,2=open only,4=real ticks"},
                  "set_file": {"type": "string", "description": "パラメータ .set ファイル名（任意）"},
                  "timeout": {"type": "integer"}},
               "required": ["path"]}, mt5_backtest, lambda a: a.get("path", "")))
