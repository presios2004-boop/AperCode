"""set_plan / step_done ツール（v1.9.0）: 作業フェーズの切り替えを AperCode に知らせる。

実際のフェーズの進行（検証・チェックポイント・次の手順の指示）は、ツールの実行後に agent が行う。
"""
from __future__ import annotations

import re

from . import Tool, ToolContext, ToolError, register


async def set_plan(ctx: ToolContext, a: dict) -> str:
    ph = ctx.phase
    if ph is None or not ph.active or ph.phase not in ("plan", "done_check", "implement", "fix"):
        raise ToolError("set_plan は計画・実装・修正・完了確認のフェーズで使えます")
    steps = a.get("steps") or []
    if isinstance(steps, str):
        steps = [re.sub(r"^\s*(\d+[.)．、:]|[-*])\s*", "", ln) for ln in steps.splitlines()]
    steps = [str(s).strip() for s in steps if str(s).strip()]
    if not steps:
        raise ToolError("steps に手順を 1 つ以上指定してください")
    kind = str(a.get("kind") or "").strip().lower()
    if kind in ("code", "operate", "converse"):
        ph.kind = kind
    try:
        r = int(a.get("rounds") or 0)
    except (TypeError, ValueError):
        r = 0
    if r > 0:
        ph.rounds = min(r, 100)          # v2.3.0: 送信回数の目安（超えるときはユーザーに許可を求める）
    ph.signal = ("set_plan", steps)
    return f"計画を登録しました（{len(steps)} 手順）"


async def step_done(ctx: ToolContext, a: dict) -> str:
    ph = ctx.phase
    if ph is None or not ph.active or ph.phase not in ("implement", "fix"):
        raise ToolError("step_done は実装フェーズ・修正フェーズでだけ使えます")
    ph.signal = ("step_done", {"summary": str(a.get("summary") or ""), "evidence": str(a.get("evidence") or "")})
    return "手順の完了を受け付けました。AperCode が検証します"


def _items(v) -> list[str]:
    if isinstance(v, str):
        v = [re.sub(r"^\s*(\d+[.)．、:]|[-*・])\s*", "", ln) for ln in v.splitlines()]
    return [str(x).strip() for x in (v or []) if str(x).strip()]


async def digest(ctx: ToolContext, a: dict) -> str:
    """v2.0.0: 相手の返事を送信前に整理する。知見は経験メモリに保存する。"""
    points, questions, insights = _items(a.get("points")), _items(a.get("questions")), _items(a.get("insights"))
    plan = str(a.get("reply_plan") or "").strip()
    if not plan:
        raise ToolError("reply_plan（返信で何をどう答えるか）は必須です")
    if not points and not questions:
        raise ToolError("points（相手の言いたいこと・助言・指摘）か questions（相手の質問）の少なくとも一方を書いてください。"
                        "相手が挨拶だけなら points に「挨拶のみ」と書く")
    import time as _t
    ph = ctx.phase
    if ph is not None and ph.digest_ts and ph.inbox_ts <= ph.digest_ts and questions == ph.open_questions:
        # v2.0.1: 同じ返事をもう一度整理しようとした（新しい返事は来ていない）→ やり直さず、返信へ進ませる
        return ("この返事は整理済みです（新しい返事はまだ来ていません）。digest を繰り返さず、整理した内容で返信を送ってください。"
                + (" 答える質問: " + " ／ ".join(questions) if questions else ""))
    state = str(a.get("partner_state") or "").strip().lower()
    state = state if state in ("replied", "replying", "waiting_approval", "error") else ("unknown" if state else "")
    if ph is not None:
        ph.digest_ts = _t.time()
        ph.open_questions = questions[:10]
        ph.reply_plan = plan[:500]
        ph.partner_state = state
    saved, dups = [], 0
    store = getattr(ctx, "memory", None)
    if store is not None and ctx.cfg.get("memory.enabled", True):
        who = str(a.get("partner") or "").strip()
        untrusted = ["untrusted"] if (getattr(ctx, "taint", None) or {}).get("active") else []
        for ins in insights[:5]:
            try:
                m, dup = await store.add(lesson=ins, situation=("会話: " + who) if who else "会話で得た知見", action="",
                                         outcome="info", tags=["conversation"] + ([who] if who else []) + untrusted,
                                         project=str(ctx.project_dir), source="conversation",
                                         dedup_threshold=float(ctx.cfg.get("memory.dedup_threshold", 0.92)))
                if dup:
                    dups += 1
                else:
                    saved.append(f"#{m.id}")
            except Exception:  # noqa: BLE001  メモリの失敗で会話を止めない
                continue
    if state == "replying":
        return "相手はまだ返事を書いている途中です。送らずに、少し待って（run_command の sleep）から screenshot で確かめてください。"
    if state == "waiting_approval":
        return ("相手は、相手側のユーザーの承認（許可・拒否）を待っています。これは「実行できない」という意味ではありません。"
                "送らずに、少し待ってから screenshot で確かめてください。相手の許可ボタンを自分で押さないこと。"
                "長く変わらなければ、ユーザーに「相手の画面で許可が必要」と伝えてください。")
    out = ["整理しました。返信で必ず扱うこと:"]
    for i, q in enumerate(questions, 1):
        out.append(f"  質問{i}: {q}")
    for pnt in points:
        out.append(f"  - {pnt}（受け入れる／理由付きで反論する、のどちらかを書く）")
    out.append(f"返信の方針: {plan}")
    out.append("次は、この内容で返信を送る（digest は返事 1 通につき 1 回）。")
    if insights:
        out.append(f"知見: 保存 {len(saved)} 件" + (f"（{', '.join(saved)}）" if saved else "") + (f"、既存と重複 {dups} 件" if dups else "")
                   + ("" if store is not None else "（経験メモリが無効のため保存していません）"))
    return "\n".join(out)


register(Tool("set_plan",
              "作業を手順に分けて登録する（計画フェーズ）。各手順は 1 回の実装＋検証で終わる大きさにし、何をどのファイルで行うかを具体的に書く。"
              "実装中にユーザーの追加指示などで残りの手順が合わなくなったら出し直す（完了済みの手順は残る）。"
              "完了確認フェーズで足りない点が見つかったときは、追加の手順を登録する。",
              {"type": "object", "properties": {
                  "steps": {"type": "array", "items": {"type": "string"}, "description": "手順（3〜7 個が目安。実行順）"},
                  "rounds": {"type": "integer", "description": "converse のとき、ユーザーが指定した送信回数（目安。指定が無ければ省略）"},
                  "kind": {"type": "string", "enum": ["code", "operate", "converse"],
                           "description": "code = コードを書く作業 / operate = アプリの操作・環境設定などコードを書かない作業 / "
                                          "converse = ほかの AI や人との会話（チャットアプリ・別の AperCode・クラウド AI）"}},
               "required": ["steps"]}, set_plan, lambda a: f"{len(a.get('steps') or [])} 手順"))

register(Tool("step_done",
              "今の手順の実装（または修正）が終わったら呼ぶ。AperCode が自動検証・テストを行い、通れば次の手順に進む。"
              "コマンド実行や GUI 操作などテストで確かめられない手順は、結果を観察してから evidence に何を見て成功と判断したかを書く。",
              {"type": "object", "properties": {
                  "summary": {"type": "string", "description": "この手順でやったこと（1〜2 行）"},
                  "evidence": {"type": "string", "description": "成功を確かめた証拠（例: 全体スクリーンショットで送信したメッセージが画面上部に表示され、入力欄が空になった）"}},
               "required": ["summary"]}, step_done, lambda a: str(a.get("summary", ""))[:60]))

register(Tool("digest",
              "会話の相手（チャットアプリの AI・別の AperCode・クラウド AI・人）の返事を読んだら、返信を送る前に呼ぶ。"
              "質問だけでなく、助言・訂正・自分の答えへの指摘・雑談の中の情報も拾って整理する。insights は経験メモリに保存される。",
              {"type": "object", "properties": {
                  "points": {"type": "array", "items": {"type": "string"},
                             "description": "相手の言いたいこと・助言・訂正・自分への指摘（質問以外。1 項目 1 文）"},
                  "questions": {"type": "array", "items": {"type": "string"},
                                "description": "相手の質問すべて（前の返事で答えていないものも含む）"},
                  "reply_plan": {"type": "string", "description": "返信で何をどう答えるか（指摘を受け入れるか・反論するかも）"},
                  "insights": {"type": "array", "items": {"type": "string"},
                               "description": "今後の作業にも役立つ知見（具体的に 1 文ずつ。無ければ空）"},
                  "partner": {"type": "string", "description": "相手の名前（例: Claude, 分家 AperCode）"},
                  "partner_state": {"type": "string", "enum": ["replied", "replying", "waiting_approval", "error", "unknown"],
                                    "description": "相手の状態: replied=返事を書き終えた / replying=考え中・生成中 / "
                                                   "waiting_approval=相手の画面に承認（許可・拒否）や「作業を始めますか？」が出ている / error"}},
               "required": ["reply_plan"]}, digest, lambda a: f"質問 {len(_items(a.get('questions')))} / 知見 {len(_items(a.get('insights')))}"))
