"""v2.11.51: 画面の「スキル」「設定」を開くときのユーザー認証（AperCode 自身に操作させないため）。

AperCode は画面操作（gui_input・ブラウザ）ができるので、自分のウィンドウの「スキル」でスキルを確認済みにしたり、
「設定」で権限や接続先を変えたりできてしまう。そこで、これらの変更はユーザーのパスワードを入れたときだけ受け付ける。

- パスワード: 既定は PC のログインパスワード（unix_chkpwd で確かめる。AperCode はパスワードを保存しない）。
  unix_chkpwd が無い環境では、AperCode 用のパスワード（初回に作る。~/.apercode/admin.json に PBKDF2 のハッシュだけを保存）
- 通れば、短い時間だけ有効な合言葉（トークン）を画面のメモリにだけ渡す。画面を閉じると無効にする
- パスワードはログ・履歴・LLM に渡さない。AperCode（LLM）は隔離環境から ~/.apercode を見られない
- 続けて間違えたら、しばらく受け付けない（総当たり対策）
"""
from __future__ import annotations

import getpass
import hashlib
import hmac
import json
import os
import secrets
import shutil
import subprocess
import threading
import time
from pathlib import Path

CHKPWD_PATHS = ("/usr/sbin/unix_chkpwd", "/sbin/unix_chkpwd", "/usr/bin/unix_chkpwd")
HASH_ITER = 300_000
MAX_FAILS = 5                   # これだけ続けて間違えたら
LOCK_SECONDS = 300              # この秒数は受け付けない
HEADER = "x-apercode-admin"


class AdminAuth:
    def __init__(self, cfg, data_dir: Path | None = None):
        self.cfg = cfg
        from .config import USER_CONFIG_PATH
        self.path = (data_dir or USER_CONFIG_PATH.parent) / "admin.json"
        self._tokens: dict[str, float] = {}
        self._fails = 0
        self._locked_until = 0.0
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ 設定
    def enabled(self) -> bool:
        return bool(self.cfg.get("security.admin_lock", True))

    def ttl(self) -> float:
        try:
            return max(1.0, float(self.cfg.get("security.admin_ttl_minutes", 10))) * 60
        except (TypeError, ValueError):
            return 600.0

    @staticmethod
    def chkpwd() -> str | None:
        for p in CHKPWD_PATHS:
            if os.path.exists(p) and os.access(p, os.X_OK):
                return p
        return shutil.which("unix_chkpwd")

    def method(self) -> str:
        """os（PC のログインパスワード）/ apercode（AperCode 用のパスワード）/ setup（AperCode 用のパスワードをまだ作っていない）。"""
        want = str(self.cfg.get("security.admin_auth", "auto") or "auto").lower()
        if want in ("auto", "os") and self.chkpwd():
            return "os"
        return "apercode" if self._hash() else "setup"

    def status(self) -> dict:
        left = max(0, int(self._locked_until - time.time()))
        return {"enabled": self.enabled(), "method": self.method(), "locked_seconds": left,
                "user": getpass.getuser() if self.method() == "os" else ""}

    # ------------------------------------------------------------------ パスワード
    def _hash(self) -> dict | None:
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            return d if d.get("hash") and d.get("salt") else None
        except (OSError, ValueError):
            return None

    def setup(self, password: str) -> None:
        """AperCode 用のパスワードを作る（unix_chkpwd が無く、まだ作っていないときだけ）。"""
        if self.method() != "setup":
            raise PermissionError("パスワードは作成済みです")
        if len(password or "") < 6:
            raise ValueError("パスワードは 6 文字以上にしてください")
        salt = secrets.token_bytes(16)
        h = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, HASH_ITER)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps({"algo": "pbkdf2_sha256", "iter": HASH_ITER, "salt": salt.hex(), "hash": h.hex()}),
                             encoding="utf-8")
        try:
            self.path.chmod(0o600)
        except OSError:
            pass

    def _check_os(self, password: str) -> bool:
        exe = self.chkpwd()
        if not exe:
            return False
        try:
            r = subprocess.run([exe, getpass.getuser(), "nullok"], input=password.encode("utf-8") + b"\0",
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
            return r.returncode == 0
        except (OSError, subprocess.SubprocessError):
            return False

    def _check_hash(self, password: str) -> bool:
        d = self._hash()
        if not d:
            return False
        h = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(d["salt"]), int(d.get("iter") or HASH_ITER))
        return hmac.compare_digest(h.hex(), d["hash"])

    def verify(self, password: str) -> bool:
        if not password:
            return False
        return self._check_os(password) if self.method() == "os" else self._check_hash(password)

    # ------------------------------------------------------------------ トークン
    def unlock(self, password: str) -> str:
        """パスワードが合えばトークンを返す。違えば PermissionError（続けて間違えたら一定時間受け付けない）。"""
        with self._lock:
            now = time.time()
            if now < self._locked_until:
                raise PermissionError(f"パスワードを続けて間違えたため、{int(self._locked_until - now)} 秒後まで受け付けません")
        ok = self.verify(password)
        with self._lock:
            if not ok:
                self._fails += 1
                if self._fails >= MAX_FAILS:
                    self._fails = 0
                    self._locked_until = time.time() + LOCK_SECONDS
                raise PermissionError("パスワードが違います")
            self._fails = 0
            tok = secrets.token_urlsafe(32)
            self._purge()
            self._tokens[tok] = time.time() + self.ttl()
            return tok

    def lock(self, token: str | None = None) -> None:
        with self._lock:
            if token:
                self._tokens.pop(token, None)
            else:
                self._tokens.clear()

    def _purge(self) -> None:
        now = time.time()
        for k in [k for k, v in self._tokens.items() if v < now]:
            self._tokens.pop(k, None)

    def check(self, token: str | None) -> bool:
        if not self.enabled():
            return True
        if not token:
            return False
        with self._lock:
            self._purge()
            return any(hmac.compare_digest(token, k) for k in self._tokens)
