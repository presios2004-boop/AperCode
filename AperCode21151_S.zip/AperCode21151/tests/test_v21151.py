"""v2.11.51 の回帰テスト: 画面の「スキル」「設定」はパスワードを入れてから開く（AperCode に自分のスキルや設定を変えさせない）。"""
from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from codeagent import admin_auth as AA
from codeagent import endpoints as EP

ROOT = Path(__file__).resolve().parents[1]


def _client(tmp_path, monkeypatch, auth="apercode"):
    from fastapi.testclient import TestClient
    from codeagent.config import Config
    from codeagent.server import app as APP
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    monkeypatch.setattr(EP, "PATH_GETTER", lambda: tmp_path / "user.yaml")
    cfg = Config.load(ROOT / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("workspace", "root"): str(tmp_path), ("llm", "base_url"): "http://127.0.0.1:9",
                 ("skills", "dir"): str(tmp_path / "skills"), ("security", "admin_auth"): auth}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    monkeypatch.setattr(type(cfg), "state", lambda self: dict(getattr(self, "_st", {})), raising=False)
    monkeypatch.setattr(type(cfg), "save_state", lambda self, st: setattr(self, "_st", dict(st)), raising=False)
    (tmp_path / "w").mkdir(exist_ok=True)
    app = APP.create_app(cfg)
    app.state.admin.path = tmp_path / "admin.json"
    return TestClient(app), app


PROTECTED = [("post", "/api/settings", {"values": {"llm.temperature": 0.3}}),
             ("post", "/api/cloud", {"model": "claude-sonnet-5-5", "api_key": "sk-x"}),
             ("post", "/api/cloud/test", None),
             ("post", "/api/endpoints", {"name": "x", "type": "openai", "url": "http://127.0.0.1:9/v1"}),
             ("post", "/api/endpoints/test", {"name": "x", "type": "openai", "url": "http://127.0.0.1:9/v1"}),
             ("delete", "/api/endpoints/x", None),
             ("post", "/api/skills/any/confirm", None),
             ("post", "/api/skills/any/review", None),
             ("delete", "/api/skills/any", None)]


def test_changes_need_password_and_token(tmp_path, monkeypatch):
    c, app = _client(tmp_path, monkeypatch)
    for m, path, body in PROTECTED:                                       # パスワードで開いていなければ受け付けない
        r = getattr(c, m)(path, json=body) if body is not None else getattr(c, m)(path)
        assert r.status_code == 403 and "admin_required" in r.text, path
    # 左のパネルの表示言語・クラウド AI のオン・オフは、これまでどおりパスワードなしで使える
    assert c.post("/api/settings", json={"prompt_language": "ja"}).status_code == 200
    assert c.post("/api/cloud", json={"enabled": False}).status_code == 200
    # 初回: AperCode 用のパスワードを作る（ハッシュだけを本人だけが読める権限で保存）
    assert c.get("/api/admin/status").json()["method"] == "setup"
    assert c.post("/api/admin/setup", json={"password": "abc"}).status_code == 400          # 短すぎる
    assert c.post("/api/admin/setup", json={"password": "s3cret-pass"}).json()["method"] == "apercode"
    saved = (tmp_path / "admin.json").read_text()
    assert "s3cret-pass" not in saved and stat.S_IMODE((tmp_path / "admin.json").stat().st_mode) == 0o600
    assert c.post("/api/admin/setup", json={"password": "other-pass"}).status_code == 400   # 作成済みは上書きできない
    assert c.post("/api/admin/unlock", json={"password": "wrong-pass"}).status_code == 401
    tok = c.post("/api/admin/unlock", json={"password": "s3cret-pass"}).json()["token"]
    h = {AA.HEADER: tok}
    assert c.post("/api/settings", json={"values": {"llm.temperature": 0.3}}, headers=h).status_code == 200
    # 画面を閉じたら（lock）無効
    c.post("/api/admin/lock", headers=h)
    assert c.post("/api/settings", json={"values": {"llm.temperature": 0.3}}, headers=h).status_code == 403


def test_lockout_after_repeated_failures(tmp_path, monkeypatch):
    c, app = _client(tmp_path, monkeypatch)
    c.post("/api/admin/setup", json={"password": "s3cret-pass"})
    for _ in range(AA.MAX_FAILS):
        assert c.post("/api/admin/unlock", json={"password": "nope-nope"}).status_code == 401
    r = c.post("/api/admin/unlock", json={"password": "s3cret-pass"})          # 正しくても、しばらく受け付けない
    assert r.status_code == 401 and c.get("/api/admin/status").json()["locked_seconds"] > 0


def test_token_expires(tmp_path, monkeypatch):
    c, app = _client(tmp_path, monkeypatch)
    c.post("/api/admin/setup", json={"password": "s3cret-pass"})
    tok = c.post("/api/admin/unlock", json={"password": "s3cret-pass"}).json()["token"]
    adm = app.state.admin
    adm._tokens[tok] = 0                                                       # 有効時間を過ぎた
    assert c.post("/api/settings", json={"values": {"llm.temperature": 0.3}}, headers={AA.HEADER: tok}).status_code == 403


@pytest.mark.skipif(os.name != "posix", reason="unix_chkpwd は Linux のみ")
def test_os_password_via_unix_chkpwd(tmp_path, monkeypatch):
    fake = tmp_path / "unix_chkpwd"                                             # 標準入力（NUL まで）が合っていれば 0 を返す偽物
    fake.write_text("#!/bin/sh\npw=$(head -c 64 | tr -d '\\000')\n[ \"$pw\" = \"login-pass\" ]\n")
    fake.chmod(0o755)
    monkeypatch.setattr(AA, "CHKPWD_PATHS", (str(fake),))
    c, app = _client(tmp_path, monkeypatch, auth="auto")
    st = c.get("/api/admin/status").json()
    assert st["method"] == "os" and st["user"]
    assert c.post("/api/admin/unlock", json={"password": "bad"}).status_code == 401
    assert c.post("/api/admin/unlock", json={"password": "login-pass"}).status_code == 200
    assert not (tmp_path / "admin.json").exists()                              # PC のパスワードは保存しない


def test_screen_asks_password_before_opening():
    html = (ROOT / "codeagent" / "server" / "static" / "index.html").read_text(encoding="utf-8")
    assert "$('#setopen').onclick=()=>adminOpen(setOpen)" in html
    assert "$('#skillopen').onclick=()=>adminOpen(skOpen)" in html
    assert 'id="adm-pw" type="password"' in html and "X-AperCode-Admin" in html
    assert "localStorage" not in html.split("let ADM=null")[1].split("function adminLockSoon")[0]   # 合言葉はメモリにだけ持つ
