"""v2.11.50 の回帰テスト: 計画の前にユーザーへ確認する番号付きの質問を、手順と取り違えて作業を進めない。"""
from __future__ import annotations

from codeagent import phases as PH

CONFIRM = """計画を立てる前に、撤廃の範囲を確認させてください。

| # | 項目 | 現在の値 |
|---|---|---|
| A | 1 バッチの処理対象 | 5 件 |

**確認したい点**

1. **D（1 通知あたり最大 3 件）も撤廃しますか?** 種別の上限は残す想定ですが、よいかご判断ください。
2. **E・F（待機 20〜40 秒 / 6 時間間隔）は維持**でよいですか? 維持を推奨します。
3. **既存テストの扱い** — 撤廃後に失敗します。**「これらのテストを新仕様に合わせて更新してよい」と明示的にご承認ください**。

**変更予定のファイル（承認後）**
- `skills/x-notifications/SKILL.md`
"""

PLAN = "計画:\n1. SKILL.md のレート制限節を書き換える\n2. テストの期待値を新仕様に合わせる\n3. pytest で全テストを確かめる"


def test_confirmation_questions_are_not_steps():
    steps = PH.parse_steps(CONFIRM)
    assert len(steps) == 3 and PH.asks_confirmation(CONFIRM, steps)
    assert not PH.asks_confirmation(PLAN, PH.parse_steps(PLAN))
    # 前置きの「確認させてください」と質問が 1 つでもあれば確認とみなす
    t = "確認させてください。\n1. 対象は src だけでよいですか?\n2. README も更新する\n3. CHANGELOG を書く"
    assert PH.asks_confirmation(t, PH.parse_steps(t))


def test_agent_waits_for_answer_instead_of_planning_questions(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", CONFIRM), ("text", "（ここまで進んではいけない）")], proj,
                                  {"verify.create_missing_tests": False})
    h.run(agent, s, "通知処理の回数制限をなしにしてください。未処理のアカウントはすべて実行する")
    assert any("計画の前にユーザーに確認しています" in (e.get("text") or "") for e in h.of("info"))
    assert not any("計画を登録しました" in (e.get("text") or "") for e in h.of("info"))
    assert llm.script == [("text", "（ここまで進んではいけない）")]           # 返事を待って止まる
    ph = store.load(s.id).phase
    assert ph.get("active") and ph.get("phase") == "plan" and not ph.get("steps")
