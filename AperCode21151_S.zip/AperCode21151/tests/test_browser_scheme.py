"""v2.11.21 の回帰テスト: 内蔵ブラウザのライト / ダークの切り替え。"""
from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from codeagent import browser as B
from codeagent.config import Config


ROOT = Path(__file__).resolve().parents[1]


def _base():
    return Config.load(ROOT / "config.yaml" if (ROOT / "config.yaml").exists() else ROOT / "config.example.yaml")


def _cfg(scheme=None):
    c = _base()
    c.data.setdefault("browser", {})
    c.data["browser"].update({"mode": "headless", "cdp_url": "", "channel": "chromium"})
    if scheme is not None:
        c.data["browser"]["color_scheme"] = scheme
    else:
        c.data["browser"].pop("color_scheme", None)
    return c


def test_color_scheme_default_and_invalid():
    assert B.Browser(_cfg()).color_scheme() == "light"
    assert B.Browser(_cfg("dark")).color_scheme() == "dark"
    assert B.Browser(_cfg("purple")).color_scheme() == "light"


@pytest.mark.skipif(not B.is_available(), reason="Playwright が無い")
def test_switch_scheme_live():
    async def run():
        b = B.Browser(_cfg("light"))
        try:
            pg = await b.page()
            await pg.set_content("<html><body>x</body></html>")
            q = "matchMedia('(prefers-color-scheme: dark)').matches"
            assert await pg.evaluate(q) is False
            assert await b.set_color_scheme("dark") == "dark"
            assert await pg.evaluate(q) is True                      # 再読み込みなしで反映
            assert b.cfg.get("browser.color_scheme") == "dark"
            await b.set_color_scheme("light")
            assert await pg.evaluate(q) is False
        finally:
            await b.close()
    try:
        asyncio.run(run())
    except Exception as e:  # noqa: BLE001
        if "Executable doesn't exist" in str(e) or "launch" in str(e).lower() and "browser" in str(e).lower():
            pytest.skip(f"ブラウザを起動できない: {str(e)[:100]}")
        raise


def test_scheme_api_saves_and_applies(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from codeagent import agent as A
    from codeagent.server import app as APP
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    applied = []

    class FakeBrowser:
        _page = None

        def __init__(self, cfg):
            self.cfg = cfg

        async def set_color_scheme(self, s):
            applied.append(s)
            return s

        async def close(self):
            pass
    monkeypatch.setattr(A.B, "Browser", FakeBrowser)
    monkeypatch.setattr(A.B, "is_available", lambda: True)
    cfg = _base()
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): True, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    cfg.data.setdefault("security", {})["admin_lock"] = False      # v2.11.51: パスワードの確認はこのテストの対象外（test_v21151 で確かめる）
    c = TestClient(APP.create_app(cfg))
    r = c.post("/api/browser/scheme", json={"scheme": "dark"}).json()
    assert r["color_scheme"] == "dark" and applied == ["dark"]
    assert "color_scheme: dark" in (tmp_path / "user.yaml").read_text(encoding="utf-8")
    assert c.get("/api/browser").json()["color_scheme"] == "dark"
    r = c.post("/api/settings", json={"values": {"browser.color_scheme": "light", "verify.review.followup": False}}).json()
    assert applied[-1] == "light" and r["values"]["browser.color_scheme"] == "light"
    assert r["values"]["verify.review.followup"] is False                   # v2.11.20 の設定が保存されること
