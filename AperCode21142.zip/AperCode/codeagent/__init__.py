"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "2.11.42"
__app_name__ = "AperCode"
