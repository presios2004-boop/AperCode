# Changelog

## 1.2.0 (2026-09-21)

- 生成コードの検証レイヤー（`verify.*`）
  - write_file / edit_file 直後の自動チェック（構文・lint・型。Python/JS/TS/Go/Rust/シェル/C/JSON/YAML。外部ツールは入っていれば使う）。NG は LLM に差し戻し
  - `run_tests` ツールと、完了報告前のテスト自動実行（pytest/unittest/npm test/go test/cargo test/make test を自動判定、`backup/` は除外）。失敗は差し戻し（上限 `max_fix_rounds`）。テストが無ければ作成を促す
  - 変更行数が閾値以上のとき、読み取り専用の子エージェントが diff をレビューし、high/medium の指摘を親に戻す（最大 `review.max_rounds` 回）
  - 画面に検証イベント（✓/✗）と完了時の「検証結果」サマリを表示。`verifying` ステータス追加
- システムプロンプトに「検証」節を追加。requirements.txt に `ruff` と `pytest` を追加

## 1.1.8 (2026-09-21)

- コンテキストサイズの自動調整: 起動時・モデル切替時に空き VRAM（無ければ RAM）とモデル構造から KV キャッシュに載るトークン数を見積もり、`llm.num_ctx` を上限に `num_ctx` を自動決定（`llm.auto_ctx.*`）。画面と `/api/config` に根拠を表示
- `/api/ctx/recalc` で再計算可能
- 複数 GPU 環境では全 GPU の空き VRAM を合算して見積もる（以前は 1 枚分のみ）

## 1.1.7 (2026-09-21)

- 教訓抽出（振り返り）を応答完了後のバックグラウンド処理に変更（タイムアウト付き、失敗しても会話に影響しない）。記録を 24k 文字に制限
- Ollama: チャットモデルの `keep_alive`（既定 30m）を送信、埋め込みは `keep_alive: 2m` + truncate で VRAM の奪い合いを軽減
- Ollama が一時的に応答しない場合の自動再試行（`llm.connect_retries`）。切断時のエラーメッセージを明確化

## 1.1.6 (2026-09-20)

- 行き詰まり検知: 同じツール呼び出しの 3 回以上の繰り返し、または 3 回連続の失敗を検知したら、Web 検索など別アプローチを促す指示を履歴に差し込む（1 ターン最大 3 回）
- ツール呼び出し上限到達時に黙って止まらず、状況報告（完了・未完了・問題・次の手順）を生成。「続けて」で再開可能

## 1.1.5 (2026-09-20)

- 「このセッションでは編集・実行を常に許可」: 一度押せばコード生成・編集・テスト実行（write_file / edit_file / run_command / mt5_* / make_icon）を確認なしで継続。セッションに保存され再起動後も有効
- 取り返しのつかない操作（rm, git reset --hard, sudo, dd, kill, drop table, pip uninstall, curl|sh, restore_backup など）は常時許可の対象外で毎回確認。`permissions.dangerous_commands` で調整可能

## 1.1.4 (2026-09-20)

- 作業ディレクトリの外に触れるツール呼び出し（絶対パス・`~/`・`../`・run_command 内の `cd` や絶対パス）は、読み取り専用ツールでもユーザーの承認を求めるように。`permissions.outside_project`（ask / allow / deny）を追加
- 承認ダイアログに理由（⚠ 作業ディレクトリの外へのアクセス: パス）を表示

## 1.1.3 (2026-09-20)

- 作業ディレクトリの取り違え対策: システムプロンプト先頭で現在の作業ディレクトリを明示し、経験メモリ由来の別プロジェクトのパスに従わないよう指示
- app.py: 起動時に既存サーバーのバージョンを確認し、古いサーバーが残っていれば停止して起動し直す（/api/shutdown を追加）
- 作業ディレクトリ欄を変更して送信すると自動で新しいセッションを開始。セッション未選択時の送信でも自動作成
- 経験メモリの自動注入を厳格化（類似度の正規化、閾値 0.40、上位 3 件、短い入力は対象外）。「参照した経験」を折りたたみ表示

## 1.1.2 (2026-09-20)

- 変更前ファイルの自動バックアップ: write_file / edit_file の直前に `backup/<日時>/` へ退避。list_backups / restore_backup ツール、保持日数による自動整理
- make_icon ツール / CLI（Pillow）: PNG 一式・.ico・.svg のアプリアイコン生成
- GTK 専用ウィンドウでモデル選択プルダウンが白く塗りつぶされる問題を修正（select を独自描画）
- 依存に pillow を追加

## 1.1.0 (2026-09-20)

- web_search / fetch_url ツール（DuckDuckGo / SearXNG）と「行き詰まったときの手順」をシステムプロンプトに追加
- save_memory に出典 URL を付けられるように。振り返りでも Web 由来の解決策に URL を含める
- 専用ウィンドウを GTK バックエンド優先に変更（OS の日本語入力が使える）。setup_linux_window.sh を追加
- IME 変換確定の Enter で送信されてしまう問題を修正
- ディレクトリ選択ダイアログ、存在しないディレクトリの作成確認

## 1.0.0 (2026-09-20)

初回リリース。

- Ollama（ローカル LLM）/ Anthropic API 対応のコーディングエージェント
- ツール: read_file / write_file / edit_file / list_dir / glob / grep / run_command
- MT5 (wine) 向けツール: mt5_compile / mt5_backtest
- Web UI（承認ダイアログ、ツール実行の可視化、状態表示、画像・テキスト添付、右クリックメニュー）
- コンテキスト自動圧縮（要約による置き換え）
- サブエージェント（explore / code モード）
- 経験メモリ（SQLite FTS5 + 埋め込みベクトルのハイブリッド検索、自動抽出、管理画面）
- デスクトップ起動（app.py / install_desktop.sh）
- 作業ディレクトリ選択ダイアログ、存在しない場合の作成確認
