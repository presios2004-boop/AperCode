"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "1.2.0"
__app_name__ = "AperCode"
