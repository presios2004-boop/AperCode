"""変更行のカバレッジ（v1.10.0）: テストは通ったが、今回変更した行が一度も実行されていない状態を見つける。

pytest で実行するテストだけが対象（Python）。プロジェクトの Python に coverage が入っていれば
  COVERAGE_FILE=… <python> -m coverage run -m pytest …
でテストを実行し、coverage json の executed_lines / missing_lines と、今回の変更で追加・変更した行を突き合わせる。
coverage が無ければ何もしない（通常の run_tests に任せる）。
"""
from __future__ import annotations

import json
import re
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from . import pycheck

PYTEST_RE = re.compile(r"^(?P<py>\S+)\s+-m\s+pytest(?P<rest>.*)$")


@dataclass
class CoverageReport:
    uncovered: dict[str, list[int]] = field(default_factory=dict)   # ファイル -> テストで一度も実行されなかった変更行
    never_imported: list[str] = field(default_factory=list)         # テストから一度も読み込まれなかった変更ファイル
    checked: int = 0                                                # 調べた変更行（実行可能な行）の数

    @property
    def n_uncovered(self) -> int:
        return sum(len(v) for v in self.uncovered.values())

    def summary(self, max_files: int = 8) -> str:
        parts = []
        for f, lines in list(self.uncovered.items())[:max_files]:
            parts.append(f"{f}: {ranges(lines)}")
        for f in self.never_imported[:max_files]:
            parts.append(f"{f}: テストから一度も読み込まれていません")
        return "\n".join(parts)


def ranges(lines: list[int]) -> str:
    """[3,4,5,9] -> '3-5, 9'"""
    out, start, prev = [], None, None
    for n in sorted(lines):
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            out.append(f"{start}-{prev}" if start != prev else str(start))
            start = prev = n
    if start is not None:
        out.append(f"{start}-{prev}" if start != prev else str(start))
    return ", ".join(out)


def coverage_available(py: str) -> bool:
    try:
        return subprocess.run([py, "-c", "import coverage"], capture_output=True, timeout=20).returncode == 0
    except Exception:  # noqa: BLE001
        return False


def wrap_command(cmd: str) -> str | None:
    """pytest のコマンドを coverage run 付きに書き換える（データの置き場所は環境変数 COVERAGE_FILE）。pytest でなければ None。"""
    m = PYTEST_RE.match(cmd.strip())
    if not m:
        return None
    return f"{m.group('py')} -m coverage run -m pytest{m.group('rest')}"


def _main_guard_lines(src: str) -> set[int]:
    """if __name__ == "__main__": の中の行（テストからは普通実行されないので対象外）。"""
    import ast
    out: set[int] = set()
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return out
    for st in tree.body:
        if isinstance(st, ast.If) and "__main__" in ast.unparse(st.test):
            out.update(range(st.lineno, (st.end_lineno or st.lineno) + 1))
    return out


def analyze(cov: dict, project: Path, changes: dict[str, dict], is_test) -> CoverageReport:
    """coverage json（dict）と変更（rel -> {before, after}）から、実行されなかった変更行を求める。"""
    rep = CoverageReport()
    files = {}
    for fname, data in (cov.get("files") or {}).items():
        p = Path(fname)
        if not p.is_absolute():
            p = project / p
        try:
            files[p.resolve().relative_to(project.resolve()).as_posix()] = data
        except (ValueError, OSError):
            continue
    for rel, ch in changes.items():
        rel = Path(rel).as_posix()
        if not rel.endswith(".py") or is_test(rel) or Path(rel).name == "conftest.py":
            continue
        if rel.split("/")[0] in (".apercode", "backup", ".venv", "venv"):
            continue
        after = ch.get("after") or ""
        added = pycheck.added_lines(ch.get("before"), after) - _main_guard_lines(after)
        if not added:
            continue
        data = files.get(rel)
        if data is None:
            # 実行可能な行が追加されているのに、テストから読み込まれていない
            code_lines = [n for n in added if (after.splitlines()[n - 1].strip() if n <= len(after.splitlines()) else "")
                          and not after.splitlines()[n - 1].strip().startswith("#")]
            if code_lines:
                rep.never_imported.append(rel)
                rep.checked += len(code_lines)
            continue
        executable = set(data.get("executed_lines") or []) | set(data.get("missing_lines") or [])
        target = added & executable
        rep.checked += len(target)
        miss = sorted(target & set(data.get("missing_lines") or []))
        if miss:
            rep.uncovered[rel] = miss
    return rep


def load_json(project: Path, py: str, data_file: Path) -> dict | None:
    out = Path(tempfile.mkdtemp(prefix="apercode_cov_")) / "cov.json"
    try:
        import os
        r = subprocess.run([py, "-m", "coverage", "json", "-o", str(out), "-q", f"--include={project.resolve()}/*"],
                           cwd=str(project), capture_output=True, timeout=120,
                           env={**os.environ, "COVERAGE_FILE": str(data_file)})
        if r.returncode != 0 or not out.exists():
            return None
        return json.loads(out.read_text("utf-8"))
    except Exception:  # noqa: BLE001
        return None
    finally:
        try:
            out.unlink(missing_ok=True)
            out.parent.rmdir()
        except OSError:
            pass
