"""チェックポイント（v1.9.0）: 手順の検証が通るたびにファイルの状態を保存し、失敗したらその時点へ巻き戻す。

置き場所: <プロジェクト>/.apercode/checkpoints/<セッションID>/
  manifest.json  … baseline（各ファイルの「AperCode が最初に変更する前」の内容）と、チェックポイントの一覧
  blobs/<sha1>   … ファイル内容（同じ内容は 1 つだけ保存）

追跡するのは AperCode が write_file / edit_file で変更したファイル（子エージェント分を含む）。
run_command（sed・npm install など）でのファイル変更は追跡しない。
各チェックポイントは、その時点で追跡中の全ファイルの内容を記録する。チェックポイント k へ戻すときは:
  - k に記録があるファイル → その内容に戻す
  - k の後で初めて変更したファイル → baseline（変更前）に戻す。変更前に無かったファイルは削除（削除前に backup/ へ退避）
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path


class CheckpointStore:
    def __init__(self, project: Path, session_id: str, keep: int = 30, max_file_mb: float = 20):
        self.project = project.resolve()
        self.root = self.project / ".apercode" / "checkpoints" / session_id
        self.keep = max(3, int(keep))
        self.max_bytes = int(max_file_mb * 1024 * 1024)
        self._data: dict | None = None

    # ---------------------------------------------------------------- 保存形式
    def _load(self) -> dict:
        if self._data is None:
            try:
                self._data = json.loads((self.root / "manifest.json").read_text("utf-8"))
            except (FileNotFoundError, OSError, ValueError):
                self._data = {"baseline": {}, "items": [], "next_id": 1}
        return self._data

    def _flush(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        gi = self.project / ".apercode" / ".gitignore"
        if not gi.exists():
            try:
                gi.write_text("# AperCode の作業ファイル（指示書・チェックポイント）\n*\n", encoding="utf-8")
            except OSError:
                pass
        tmp = self.root / "manifest.json.tmp"
        tmp.write_text(json.dumps(self._load(), ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(self.root / "manifest.json")

    def _put(self, data: bytes) -> str:
        h = hashlib.sha1(data).hexdigest()
        p = self.root / "blobs" / h
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
        return h

    def _get(self, h: str) -> bytes:
        return (self.root / "blobs" / h).read_bytes()

    def rel(self, path: Path) -> str | None:
        try:
            r = path.resolve().relative_to(self.project)
        except (ValueError, OSError):
            return None
        if r.parts and r.parts[0] in (".apercode", ".git"):
            return None
        return r.as_posix()

    # ---------------------------------------------------------------- 追跡
    def track(self, path: Path) -> None:
        """変更の直前に呼ぶ。初めて変更するファイルなら、変更前の内容を baseline に保存する。"""
        rel = self.rel(path)
        if rel is None:
            return
        d = self._load()
        if rel in d["baseline"]:
            return
        try:
            if path.is_file():
                if path.stat().st_size > self.max_bytes:
                    d["baseline"][rel] = {"skip": True}
                else:
                    d["baseline"][rel] = {"blob": self._put(path.read_bytes())}
            else:
                d["baseline"][rel] = {"blob": None}      # 変更前は存在しなかった
            self._flush()
        except OSError:
            pass

    def tracked(self) -> list[str]:
        return [r for r, v in self._load()["baseline"].items() if not v.get("skip")]

    # ---------------------------------------------------------------- チェックポイント
    def save(self, label: str, anchor_ts: float | None, phase: dict | None) -> dict:
        d = self._load()
        files: dict[str, str | None] = {}
        for rel in self.tracked():
            p = self.project / rel
            try:
                if p.is_file():
                    if p.stat().st_size > self.max_bytes:
                        continue
                    files[rel] = self._put(p.read_bytes())
                else:
                    files[rel] = None
            except OSError:
                continue
        item = {"id": d["next_id"], "label": label, "ts": time.time(), "anchor_ts": anchor_ts,
                "files": files, "phase": phase or {}}
        d["next_id"] += 1
        d["items"].append(item)
        if len(d["items"]) > self.keep:
            d["items"] = d["items"][-self.keep:]
            self._gc()
        self._flush()
        return item

    def list(self) -> list[dict]:
        return [{"id": it["id"], "label": it["label"], "ts": it["ts"], "files": len(it["files"]),
                 "step": (it.get("phase") or {}).get("idx"), "phase": (it.get("phase") or {}).get("phase")}
                for it in self._load()["items"]]

    def get(self, cid: int) -> dict | None:
        for it in self._load()["items"]:
            if it["id"] == cid:
                return it
        return None

    def last(self) -> dict | None:
        items = self._load()["items"]
        return items[-1] if items else None

    def restore(self, cid: int, backup=None) -> dict:
        """チェックポイント cid の状態にファイルを戻す。{"written": [...], "deleted": [...]} を返す。"""
        it = self.get(cid)
        if it is None:
            raise KeyError(f"チェックポイント #{cid} がありません")
        d = self._load()
        written, deleted = [], []
        for rel in self.tracked():
            if rel in it["files"]:
                h = it["files"][rel]
            else:
                h = d["baseline"][rel].get("blob")
            p = self.project / rel
            try:
                cur = p.read_bytes() if p.is_file() else None
            except OSError:
                cur = None
            if h is None:
                if cur is not None:
                    if backup is not None:
                        backup.save(p)
                    p.unlink(missing_ok=True)
                    deleted.append(rel)
                continue
            data = self._get(h)
            if cur == data:
                continue
            if backup is not None and cur is not None:
                backup.save(p)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
            written.append(rel)
        # このチェックポイントより後のものは無効になる（やり直した先で新しく作る）
        d["items"] = [x for x in d["items"] if x["id"] <= cid]
        self._gc()
        self._flush()
        return {"written": written, "deleted": deleted}

    def _gc(self) -> None:
        d = self._load()
        used = {v.get("blob") for v in d["baseline"].values()}
        for it in d["items"]:
            used.update(it["files"].values())
        bdir = self.root / "blobs"
        if bdir.is_dir():
            for p in bdir.iterdir():
                if p.name not in used:
                    p.unlink(missing_ok=True)

    def clear(self) -> None:
        import shutil
        shutil.rmtree(self.root, ignore_errors=True)
        self._data = None


def label_of(item: dict) -> str:
    return f"#{item['id']}（{item['label']}）"
