"""デスクトップ GUI 操作（v1.11.0、Linux / X11）: ウィンドウの一覧・起動・アクティブ化、スクリーンショット、クリック・貼り付け・キー入力。

LLM がその場でシェルや Python を組み立てると、同じ操作でも毎回書き方が変わって失敗しやすい（起動コマンドの書き誤り、
クリップボードの扱い、座標のずれ、xprop が -root 無しで固まる など）。ここで決まった手順として実装し、ツールから呼ぶ。

- スクリーンショットは画面全体を撮ってからウィンドウの位置で切り出す（Electron のウィンドウは単体で撮ると壁紙になることがある）
- 座標はそのウィンドウの直近のスクリーンショット上のピクセル座標で受け取り、撮影時の縮小率と「いまの」ウィンドウ位置で画面座標に直す
  （ウィンドウが動いても、前回と違う場所に開いても同じ座標で押せる）
- 入力は xdotool → xte → python-xlib(XTest) の順に使えるものを使う。日本語はクリップボード経由で貼り付ける（IME を通さない）
"""
from __future__ import annotations

import asyncio
import os
import re
import shutil
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path


class GuiError(Exception):
    pass


@dataclass
class Window:
    id: str            # 0x03e00003
    title: str
    x: int = 0
    y: int = 0
    w: int = 0
    h: int = 0
    active: bool = False

    def line(self) -> str:
        return f"{self.id}  {self.w}x{self.h}+{self.x}+{self.y}  {'★アクティブ ' if self.active else ''}{self.title}"


# セッション ID -> ウィンドウ ID -> 直近のスクリーンショットの縮小率（画像の 1px = 画面の 1/scale px）
_SHOTS: dict[str, dict[str, float]] = {}


async def _run(args: list[str] | str, timeout: float = 10, stdin: bytes | None = None, env: dict | None = None) -> tuple[int, str]:
    try:
        if isinstance(args, str):
            p = await asyncio.create_subprocess_shell(args, stdin=asyncio.subprocess.PIPE if stdin is not None else None,
                                                      stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
                                                      env={**os.environ, **(env or {})})
        else:
            p = await asyncio.create_subprocess_exec(*args, stdin=asyncio.subprocess.PIPE if stdin is not None else None,
                                                     stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
                                                     env={**os.environ, **(env or {})})
    except FileNotFoundError:
        return 127, ""
    try:
        out, _ = await asyncio.wait_for(p.communicate(stdin), timeout)
    except asyncio.TimeoutError:
        try:
            p.kill()
        except ProcessLookupError:
            pass
        return -1, f"(タイムアウト {timeout}s)"
    return p.returncode or 0, out.decode("utf-8", "replace")


def check_env() -> None:
    if not os.environ.get("DISPLAY"):
        if os.environ.get("WAYLAND_DISPLAY"):
            raise GuiError("Wayland のみの環境では GUI 操作ツールは使えません（X11 セッションで AperCode を起動してください）")
        raise GuiError("DISPLAY が設定されていません（デスクトップのセッションで AperCode を起動してください）")
    if not shutil.which("wmctrl") or not shutil.which("xprop") or not shutil.which("xwininfo"):
        raise GuiError("wmctrl / xprop / xwininfo が必要です: sudo apt install wmctrl x11-utils")


# ------------------------------------------------------------------ ウィンドウ
async def active_id() -> str | None:
    code, out = await _run(["xprop", "-root", "_NET_ACTIVE_WINDOW"], 3)      # -root を付けないとクリック待ちで固まる
    m = re.search(r"window id # (0x[0-9a-fA-F]+)", out)
    return _norm(m.group(1)) if m and code == 0 else None


def _norm(wid: str) -> str:
    try:
        return f"0x{int(wid, 16):08x}"
    except ValueError:
        return wid


async def geometry(wid: str) -> tuple[int, int, int, int] | None:
    code, out = await _run(["xwininfo", "-id", wid], 3)
    if code != 0:
        return None
    g = {}
    for key, pat in (("x", r"Absolute upper-left X:\s+(-?\d+)"), ("y", r"Absolute upper-left Y:\s+(-?\d+)"),
                     ("w", r"Width:\s+(\d+)"), ("h", r"Height:\s+(\d+)")):
        m = re.search(pat, out)
        if not m:
            return None
        g[key] = int(m.group(1))
    return g["x"], g["y"], g["w"], g["h"]


async def list_windows() -> list[Window]:
    check_env()
    code, out = await _run(["wmctrl", "-l"], 5)
    act = await active_id()
    wins = []
    for ln in out.splitlines():
        parts = ln.split(None, 3)
        if len(parts) < 3 or not parts[0].startswith("0x"):
            continue
        title = parts[3] if len(parts) > 3 else ""
        if parts[1] == "-1":
            continue                                  # パネル・デスクトップ
        wid = _norm(parts[0])
        g = await geometry(wid) or (0, 0, 0, 0)
        wins.append(Window(wid, title, *g, active=(wid == act)))
    return wins


async def find(query: str) -> Window:
    """ウィンドウ ID（0x…）またはタイトルの一部（大文字小文字を区別しない）でウィンドウを探す。"""
    q = (query or "").strip()
    if not q:
        raise GuiError("window（タイトルの一部または 0x で始まる ID）を指定してください")
    wins = await list_windows()
    if q.lower().startswith("0x"):
        for w in wins:
            if w.id == _norm(q):
                return w
        g = await geometry(q)
        if g:
            return Window(_norm(q), "", *g)
        raise GuiError(f"ウィンドウ {q} がありません")
    hits = [w for w in wins if q.lower() in w.title.lower()]
    if not hits:
        raise GuiError(f"タイトルに「{q}」を含むウィンドウがありません。gui_windows で一覧を確認し、起動していなければ gui_launch で起動してください")
    exact = [w for w in hits if w.title.strip().lower() == q.lower()]
    pool = exact or hits
    return max(pool, key=lambda w: w.w * w.h)


async def activate(win: Window, tries: int = 3) -> bool:
    for i in range(tries):
        await _run(["wmctrl", "-i", "-a", win.id], 3)
        await asyncio.sleep(0.4 + 0.3 * i)
        if await active_id() == win.id:
            return True
        if await _xdotool_ok():
            await _run(["xdotool", "windowactivate", "--sync", win.id], 3)
            await asyncio.sleep(0.3)
            if await active_id() == win.id:
                return True
    return False


async def launch(command: str, title: str, timeout: float = 40) -> tuple[Window, bool]:
    """アプリを起動し、タイトルに title を含むウィンドウが出るまで待つ。既に開いていれば起動しない。(ウィンドウ, 新規起動したか)"""
    check_env()
    try:
        return await find(title), False
    except GuiError:
        pass
    log = Path(tempfile.gettempdir()) / f"apercode_launch_{re.sub(r'[^A-Za-z0-9]+', '_', title)[:30]}.log"
    # シェルに 1 つの文字列として渡す（リストで渡すとリダイレクトが引数扱いになり起動しない）
    await asyncio.create_subprocess_exec("setsid", "sh", "-c", f"{command} >{log} 2>&1 </dev/null &",
                                         stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
    t0 = time.time()
    while time.time() - t0 < timeout:
        await asyncio.sleep(1)
        try:
            w = await find(title)
            if w.w > 50 and w.h > 50:
                await asyncio.sleep(1.5)                  # 中身の描画を待つ
                return await find(title), True
        except GuiError:
            continue
    tail = ""
    try:
        tail = log.read_text("utf-8", "replace")[-800:]
    except OSError:
        pass
    raise GuiError(f"{timeout:.0f} 秒待っても「{title}」のウィンドウが現れませんでした。起動コマンド: {command}"
                   + (f"\n起動ログ（{log}）:\n{tail}" if tail.strip() else ""))


# ------------------------------------------------------------------ スクリーンショット
async def _capture_root(path: Path) -> str:
    """画面全体を path に PNG で保存し、使ったツール名を返す。"""
    cands: list[tuple[str, list[str]]] = []
    if shutil.which("import"):
        cands.append(("import", ["import", "-silent", "-window", "root", str(path)]))
    if shutil.which("xfce4-screenshooter"):
        cands.append(("xfce4-screenshooter", ["xfce4-screenshooter", "-f", "-s", str(path)]))
    if shutil.which("scrot"):
        cands.append(("scrot", ["scrot", "-o", str(path)]))
    if shutil.which("gnome-screenshot"):
        cands.append(("gnome-screenshot", ["gnome-screenshot", "-f", str(path)]))
    for name, cmd in cands:
        path.unlink(missing_ok=True)
        code, out = await _run(cmd, 20)
        for _ in range(20):                               # 非同期に書き出すツールがある
            if path.exists() and path.stat().st_size > 0:
                return name
            await asyncio.sleep(0.2)
    raise GuiError("スクリーンショットを撮れるツールがありません: sudo apt install imagemagick（または scrot / xfce4-screenshooter）")


async def screenshot(dest_dir: Path, session_id: str, window: str | None = None, activate_first: bool = True,
                     max_width: int = 1600) -> tuple[str, str]:
    """スクリーンショットを dest_dir に保存する。(ファイル名, 説明文)"""
    check_env()
    from PIL import Image
    win = None
    if window:
        win = await find(window)
        if activate_first and not await activate(win):
            raise GuiError(f"ウィンドウ {win.id}（{win.title}）を前面に出せませんでした")
        await asyncio.sleep(0.3)
        g = await geometry(win.id)
        if g:
            win.x, win.y, win.w, win.h = g
    with tempfile.TemporaryDirectory() as td:
        raw = Path(td) / "root.png"
        tool = await _capture_root(raw)
        img = Image.open(raw).convert("RGB")
    sw, sh = img.size
    if win is not None:
        box = (max(0, win.x), max(0, win.y), min(sw, win.x + win.w), min(sh, win.y + win.h))
        if box[2] - box[0] < 10 or box[3] - box[1] < 10:
            raise GuiError(f"ウィンドウ {win.id} が画面の外にあります（{win.w}x{win.h}+{win.x}+{win.y}）")
        img = img.crop(box)
    scale = 1.0
    if img.width > max_width:
        scale = max_width / img.width
        img = img.resize((max_width, int(img.height * scale)))
    dest_dir.mkdir(parents=True, exist_ok=True)
    fname = f"screen_{int(time.time() * 1000)}.png"
    img.save(dest_dir / fname)
    key = win.id if win is not None else "root"
    _SHOTS.setdefault(session_id, {})[key] = scale
    what = f"ウィンドウ {win.id}「{win.title}」（画面上の位置 {win.w}x{win.h}+{win.x}+{win.y}）" if win else f"画面全体（{sw}x{sh}）"
    desc = (f"{what} を撮影しました（{tool}、画像 {img.width}x{img.height}px"
            + (f"、{scale:.2f} 倍に縮小" if scale != 1.0 else "") + "）。"
            "gui_input の click には、この画像上のピクセル座標（左上が 0,0）をそのまま指定する。")
    return fname, desc


def _to_screen(session_id: str, win: Window | None, x: float, y: float) -> tuple[int, int]:
    key = win.id if win is not None else "root"
    scale = _SHOTS.get(session_id, {}).get(key, 1.0)
    ox, oy = (max(0, win.x), max(0, win.y)) if win is not None else (0, 0)
    return int(round(ox + x / scale)), int(round(oy + y / scale))


# ------------------------------------------------------------------ 入力
_XDOTOOL: bool | None = None


async def _xdotool_ok() -> bool:
    global _XDOTOOL
    if _XDOTOOL is None:
        _XDOTOOL = bool(shutil.which("xdotool")) and (await _run(["xdotool", "version"], 3))[0] == 0
    return _XDOTOOL


def _xlib_script(body: str) -> str:
    return ("import sys, time\nfrom Xlib import X, XK, display\nfrom Xlib.ext import xtest\nd = display.Display()\n"
            "def kc(name):\n    return d.keysym_to_keycode(XK.string_to_keysym(name))\n" + body + "\nd.sync()\n")


def _system_python() -> str | None:
    for p in ("/usr/bin/python3", shutil.which("python3") or ""):
        if p and Path(p).exists():
            return p
    return None


async def _xlib(body: str) -> tuple[int, str]:
    py = _system_python()
    if not py:
        return 127, ""
    return await _run([py, "-c", _xlib_script(body)], 10)


KEY_ALIASES = {"enter": "Return", "return": "Return", "tab": "Tab", "esc": "Escape", "escape": "Escape",
               "backspace": "BackSpace", "delete": "Delete", "space": "space", "up": "Up", "down": "Down",
               "left": "Left", "right": "Right", "home": "Home", "end": "End", "pageup": "Prior", "pagedown": "Next"}
MOD_ALIASES = {"ctrl": "Control_L", "control": "Control_L", "shift": "Shift_L", "alt": "Alt_L", "super": "Super_L", "meta": "Super_L"}


def _parse_combo(combo: str) -> tuple[list[str], str]:
    parts = [p.strip() for p in combo.replace(" ", "").split("+") if p.strip()]
    if not parts:
        raise GuiError(f"キーの指定が空です: {combo!r}")
    *mods, key = parts
    mods_x = [MOD_ALIASES.get(m.lower(), m) for m in mods]
    key_x = KEY_ALIASES.get(key.lower(), key if len(key) > 1 else key.lower())
    return mods_x, key_x


async def key(combo: str) -> str:
    mods, k = _parse_combo(combo)
    if await _xdotool_ok():
        xd = "+".join([m.split("_")[0].lower().replace("control", "ctrl") for m in mods] + [k])
        code, out = await _run(["xdotool", "key", "--clearmodifiers", xd], 5)
        if code == 0:
            return "xdotool"
    if shutil.which("xte"):
        cmds = [f"keydown {m}" for m in mods] + [f"key {k}"] + [f"keyup {m}" for m in reversed(mods)]
        code, out = await _run(["xte", *cmds], 5)
        if code == 0:
            return "xte"
    body = "".join(f"xtest.fake_input(d, X.KeyPress, kc({m!r}))\n" for m in mods)
    body += f"xtest.fake_input(d, X.KeyPress, kc({k!r})); xtest.fake_input(d, X.KeyRelease, kc({k!r}))\n"
    body += "".join(f"xtest.fake_input(d, X.KeyRelease, kc({m!r}))\n" for m in reversed(mods))
    code, out = await _xlib(body)
    if code == 0:
        return "python-xlib"
    raise GuiError("キー入力に使えるツールがありません: sudo apt install xdotool（または xautomation / python3-xlib）\n" + out[-300:])


async def click_at(sx: int, sy: int, button: int = 1) -> str:
    if await _xdotool_ok():
        code, _ = await _run(["xdotool", "mousemove", "--sync", str(sx), str(sy), "click", str(button)], 5)
        if code == 0:
            return "xdotool"
    if shutil.which("xte"):
        code, _ = await _run(["xte", f"mousemove {sx} {sy}", "usleep 100000", f"mouseclick {button}"], 5)
        if code == 0:
            return "xte"
    code, out = await _xlib(f"xtest.fake_input(d, X.MotionNotify, x={sx}, y={sy}); d.sync(); time.sleep(0.1)\n"
                            f"xtest.fake_input(d, X.ButtonPress, {button}); xtest.fake_input(d, X.ButtonRelease, {button})")
    if code == 0:
        return "python-xlib"
    raise GuiError("クリックに使えるツールがありません: sudo apt install xdotool（または xautomation / python3-xlib）\n" + out[-300:])


_CLIP_PROCS: list[asyncio.subprocess.Process] = []


async def set_clipboard(text: str) -> None:
    """クリップボードに text を入れる。xclip はクリップボードの持ち主として残す（すぐ終了させると貼り付けできない）。"""
    for p in _CLIP_PROCS:
        if p.returncode is None:
            try:
                p.kill()
            except ProcessLookupError:
                pass
    _CLIP_PROCS.clear()
    if shutil.which("xclip"):
        p = await asyncio.create_subprocess_exec("xclip", "-selection", "clipboard", "-i", stdin=asyncio.subprocess.PIPE,
                                                 stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
        assert p.stdin is not None
        p.stdin.write(text.encode("utf-8"))
        await p.stdin.drain()
        p.stdin.close()
        _CLIP_PROCS.append(p)
    elif shutil.which("xsel"):
        code, out = await _run(["xsel", "--clipboard", "--input"], 5, stdin=text.encode("utf-8"))
        if code != 0:
            raise GuiError("xsel でクリップボードに入れられませんでした: " + out[-200:])
    else:
        raise GuiError("クリップボードの操作に xclip が必要です: sudo apt install xclip")
    await asyncio.sleep(0.3)
    if shutil.which("xclip"):
        code, out = await _run(["xclip", "-selection", "clipboard", "-o"], 3)
        if code == 0 and out != text:
            raise GuiError("クリップボードに文章を入れられませんでした（読み出した内容が一致しません）")


async def gui_input(session_id: str, window: str, click: list | None = None, text: str | None = None,
                    keys: list[str] | None = None, button: int = 1) -> list[str]:
    """ウィンドウを前面に出し、（あれば）クリック → 文章の貼り付け → キー入力 の順に行う。行ったことの一覧を返す。"""
    check_env()
    win = await find(window)
    done: list[str] = []
    if not await activate(win):
        raise GuiError(f"ウィンドウ {win.id}（{win.title}）を前面に出せませんでした。入力は行っていません")
    done.append(f"前面に出した: {win.id}「{win.title}」")
    g = await geometry(win.id)
    if g:
        win.x, win.y, win.w, win.h = g
    if click is not None:
        if not (isinstance(click, (list, tuple)) and len(click) == 2):
            raise GuiError("click は [x, y]（直近のスクリーンショット上のピクセル座標）で指定してください")
        if win.id not in _SHOTS.get(session_id, {}):
            raise GuiError("このウィンドウのスクリーンショットがまだありません。先に screenshot(window=…) で撮り、画像上の座標を指定してください")
        sx, sy = _to_screen(session_id, win, float(click[0]), float(click[1]))
        if not (win.x <= sx < win.x + win.w and win.y <= sy < win.y + win.h):
            raise GuiError(f"クリック位置 {click} はウィンドウの外になります（画面座標 {sx},{sy}）")
        tool = await click_at(sx, sy, button)
        done.append(f"クリック: 画像上 ({click[0]}, {click[1]}) → 画面 ({sx}, {sy})（{tool}）")
        await asyncio.sleep(0.3)
    if text:
        await set_clipboard(text)
        if await active_id() != win.id and not await activate(win):
            raise GuiError("クリップボードに入れている間にウィンドウが前面から外れました。貼り付けは行っていません")
        tool = await key("ctrl+v")
        done.append(f"貼り付け: {len(text)} 文字（{tool}）")
        await asyncio.sleep(0.4)
    for k in keys or []:
        if await active_id() != win.id and not await activate(win):
            raise GuiError(f"キー {k} を送る前にウィンドウが前面から外れました")
        tool = await key(str(k))
        done.append(f"キー: {k}（{tool}）")
        await asyncio.sleep(0.2)
    return done
