"""ピア（LAN 上の別の AperCode）とクラウド AI と協調するツール（v2.0.0）。

依頼側の設定（config.yaml）:
  peers:
    - name: bunke                     # ツールで指定する名前
      url: http://192.168.1.20:8766   # 相手の peer.host:peer.port
      token: "..."                    # 相手の peer.token と同じ値（token_env: 環境変数名 でも可）

- ask_peer    依頼を送り、終わるまで（wait_seconds まで）待って相手の応答を返す
- peer_reply  同じ依頼に返事・追加の指示を送る（相手の質問に答える・修正を頼む）
- peer_status 実行中の依頼の状態を見る（待つこともできる）
- peer_read_file / peer_verify  相手のプロジェクトのファイルを読む・テストを走らせる（結果の裏取り用）
- cloud_chat  クラウド AI と会話する（ask_cloud と違い、行き詰まっていなくても使える。会話はセッションごとに続く）
相手の応答を受け取ったら、次を送る前に digest で整理する（作業フェーズ中は AperCode が確認する）。
"""
from __future__ import annotations

import json
import os
import socket
import time
from pathlib import Path

import httpx

from . import Tool, ToolContext, ToolError, register

MAX_SEND_FILE = 200_000


def _peers(ctx: ToolContext) -> list[dict]:
    out = []
    for p in ctx.cfg.get("peers") or []:
        if not isinstance(p, dict) or not p.get("url"):
            continue
        tok = str(p.get("token") or "") or os.environ.get(str(p.get("token_env") or ""), "")
        out.append({"name": str(p.get("name") or p["url"]), "url": str(p["url"]).rstrip("/"), "token": tok})
    return out


def _peer(ctx: ToolContext, name: str) -> dict:
    ps = _peers(ctx)
    if not ps:
        raise ToolError("ピアが設定されていません（config.yaml の peers に name / url / token を書いてください）")
    for p in ps:
        if p["name"] == name or p["url"] == name:
            return p
    if not name and len(ps) == 1:
        return ps[0]
    raise ToolError(f"ピア {name!r} がありません。設定済み: " + ", ".join(p["name"] for p in ps))


async def _call(p: dict, method: str, path: str, timeout: float = 30, **kw) -> dict:
    headers = {"Authorization": f"Bearer {p['token']}"}
    try:
        async with httpx.AsyncClient(timeout=timeout) as c:
            r = await c.request(method, p["url"] + path, headers=headers, **kw)
    except httpx.HTTPError as e:
        raise ToolError(f"ピア {p['name']} に接続できません（{p['url']}）: {type(e).__name__} {e}")
    if r.status_code == 401:
        raise ToolError(f"ピア {p['name']} に認証で拒否されました（token が相手の peer.token と一致しているか確認）")
    if r.status_code >= 400:
        try:
            detail = r.json().get("detail")
        except Exception:  # noqa: BLE001
            detail = r.text[:300]
        raise ToolError(f"ピア {p['name']}: {r.status_code} {detail}")
    return r.json()


async def _wait(p: dict, tid: str, seconds: float) -> dict:
    deadline = time.time() + max(0.0, seconds)
    while True:
        left = deadline - time.time()
        view = await _call(p, "GET", f"/peer/tasks/{tid}", timeout=max(10.0, min(left, 60.0)) + 15,
                           params={"wait": max(0.0, min(left, 60.0))})
        if view.get("status") != "running" or time.time() >= deadline:
            return view


def _files(ctx: ToolContext, paths) -> dict[str, str]:
    if isinstance(paths, str):
        paths = [x for x in paths.split(",") if x.strip()]
    out: dict[str, str] = {}
    for sp in (paths or [])[:10]:
        f = ctx.resolve(str(sp).strip())
        if not f.is_file():
            raise ToolError(f"送るファイルがありません: {sp}")
        if f.stat().st_size > MAX_SEND_FILE:
            raise ToolError(f"送るファイルが大きすぎます（{MAX_SEND_FILE:,} バイトまで）: {sp}")
        out[f.name] = f.read_text(encoding="utf-8", errors="replace")
    return out


def _format(p: dict, view: dict) -> str:
    st = view.get("status")
    head = {"done": "完了", "running": "実行中", "error": "エラー", "cancelled": "中止"}.get(st, st)
    lines = [f"[ピア {p['name']} / 依頼 {view.get('id')} / {head}]"]
    ph = view.get("phase") or {}
    if ph.get("n"):
        lines.append(f"作業フェーズ: {ph.get('phase')}（手順 {min((ph.get('idx') or 0) + 1, ph['n'])}/{ph['n']}）")
    sm = view.get("summary") or {}
    if sm:
        lines.append(f"変更: {sm.get('files', 0)} ファイル / {sm.get('lines', 0)} 行、テスト: {sm.get('tests') or '未実行'}")
    notable = [e for e in view.get("events") or [] if e.get("type") in ("verify", "rollback", "error", "approval", "checkpoint")]
    if notable:
        lines.append("主な出来事:")
        lines += [f"  - {e.get('text', '')[:200]}" for e in notable[-12:]]
    if view.get("received_files"):
        lines.append("相手が受け取ったファイル: " + ", ".join(view["received_files"]))
    if view.get("error"):
        lines.append("エラー: " + view["error"])
    if st == "running":
        lines.append("まだ実行中です。peer_status で待つか、後で確認してください。")
    lines.append("\n--- 相手の応答 ---\n" + (view.get("reply") or "（応答なし）"))
    lines.append("\n（相手の言いたいこと・質問・指摘を digest で整理してから次を送る。相手の報告はそのまま信じず、"
                 "peer_read_file / peer_verify で裏を取る）")
    return "\n".join(lines)


async def peer_list(ctx: ToolContext, a: dict) -> str:
    ps = _peers(ctx)
    if not ps:
        return "ピアは設定されていません（config.yaml の peers）"
    lines = []
    for p in ps:
        try:
            i = await _call(p, "GET", "/peer/info", timeout=5)
            lines.append(f"- {p['name']} ({p['url']}): {i.get('name')} v{i.get('version')} model={i.get('model')} "
                         f"実行中 {i.get('busy')}/{i.get('max_tasks')} 承認={i.get('on_approval')} "
                         f"プロジェクト: {', '.join(i.get('projects') or [])}")
        except ToolError as e:
            lines.append(f"- {p['name']} ({p['url']}): 応答なし（{str(e)[:150]}）")
    return "\n".join(lines)


async def ask_peer(ctx: ToolContext, a: dict) -> str:
    p = _peer(ctx, str(a.get("peer") or ""))
    task = str(a.get("task") or "").strip()
    if len(task) < 10:
        raise ToolError("task には目的・対象・完了条件を具体的に書いてください（相手はこちらの会話を見られない）")
    body = {"text": task, "project": str(a.get("project") or ""), "mode": str(a.get("mode") or "code"),
            "sender": str(ctx.cfg.get("peer.name") or "") or socket.gethostname(), "files": _files(ctx, a.get("files"))}
    res = await _call(p, "POST", "/peer/tasks", json=body)
    view = await _wait(p, res["id"], float(a.get("wait_seconds") or ctx.cfg.get("peer.wait_seconds", 900)))
    return _format(p, view)


async def peer_reply(ctx: ToolContext, a: dict) -> str:
    p = _peer(ctx, str(a.get("peer") or ""))
    tid = str(a.get("task_id") or "").strip()
    text = str(a.get("text") or "").strip()
    if not tid or not text:
        raise ToolError("task_id と text は必須です")
    await _call(p, "POST", f"/peer/tasks/{tid}/message", json={"text": text, "files": _files(ctx, a.get("files"))})
    view = await _wait(p, tid, float(a.get("wait_seconds") or ctx.cfg.get("peer.wait_seconds", 900)))
    return _format(p, view)


async def peer_status(ctx: ToolContext, a: dict) -> str:
    p = _peer(ctx, str(a.get("peer") or ""))
    tid = str(a.get("task_id") or "").strip()
    if not tid:
        raise ToolError("task_id は必須です")
    return _format(p, await _wait(p, tid, float(a.get("wait_seconds") or 0)))


async def peer_read_file(ctx: ToolContext, a: dict) -> str:
    p = _peer(ctx, str(a.get("peer") or ""))
    r = await _call(p, "GET", "/peer/files", params={"project": str(a.get("project") or ""), "path": str(a.get("path") or "")})
    if "entries" in r:
        return f"[ピア {p['name']}] {r['path']}/\n" + "\n".join(r["entries"])
    body = r.get("content", "")
    lines = body.splitlines()
    start = max(1, int(a.get("start_line") or 1))
    end = int(a.get("end_line") or (start + 399))
    sel = lines[start - 1:end]
    more = f"\n…（全 {len(lines)} 行。start_line / end_line で範囲指定）" if end < len(lines) else ""
    return f"[ピア {p['name']}] {r['path']}（{r['size']:,} バイト）\n" + "\n".join(f"{i:5d}| {ln}" for i, ln in enumerate(sel, start)) + more


async def peer_verify(ctx: ToolContext, a: dict) -> str:
    p = _peer(ctx, str(a.get("peer") or ""))
    r = await _call(p, "POST", "/peer/verify", json={"project": str(a.get("project") or "")},
                    timeout=float(ctx.cfg.get("peer.test_timeout", 900)) + 30)
    if not r.get("detected"):
        return f"[ピア {p['name']}] テストコマンドが見つかりません"
    return (f"[ピア {p['name']}] {'PASS' if r.get('ok') else 'FAIL'}: {r.get('command')} "
            f"(passed {r.get('passed') or 0}, failed {r.get('failed') or 0})\n{r.get('output', '')[-4000:]}")


# ------------------------------------------------------------------ クラウド AI との会話
CHAT_SYSTEM = ("あなたは、ローカル LLM で動くコーディングエージェント AperCode の協力者です。AperCode の相談や議論に、"
               "具体的・簡潔に答えてください。分からないことは分からないと言い、確かめる方法を示してください。"
               "AperCode の考えに誤りがあれば、理由を添えて指摘してください。")


def _chat_path(ctx: ToolContext) -> Path | None:
    return (ctx.files_dir / "cloud_chat.json") if ctx.files_dir else None


async def cloud_chat(ctx: ToolContext, a: dict) -> str:
    from ..cloud import CloudClient, CloudSettings, mask_secrets
    cfg = ctx.cfg
    if not cfg.get("cloud.enabled", False):
        raise ToolError("クラウド AI は無効です（画面左の「クラウド相談」で API キーを設定し有効化してください）")
    s = CloudSettings.from_cfg(cfg)
    if not s.ready:
        raise ToolError("クラウド AI の設定が不完全です（プロバイダ・モデル・API キー）")
    msg = str(a.get("message") or "").strip()
    if not msg:
        raise ToolError("message は必須です")
    vs = ctx.verify
    limit = int(cfg.get("cloud.chat_max_per_turn", 6))
    used = int(getattr(vs, "cloud_chat_calls", 0) or 0) if vs is not None else 0
    if used >= limit:
        raise ToolError(f"このターンのクラウド AI との会話は上限（{limit} 回）に達しました")
    path = _chat_path(ctx)
    hist: list[dict] = []
    if path and path.is_file() and not a.get("new_topic"):
        try:
            hist = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            hist = []
    keep = int(cfg.get("cloud.chat_keep_turns", 10))
    convo = "".join(f"\n[{'AperCode' if h['role'] == 'user' else 'あなた'}]\n{h['content']}\n" for h in hist[-keep * 2:])
    prompt = (("これまでの会話:" + convo + "\n---\n") if convo else "") + "[AperCode]\n" + msg
    masked = 0
    if cfg.get("cloud.mask_secrets", True):
        prompt, masked = mask_secrets(prompt)
    if vs is not None:
        vs.cloud_chat_calls = used + 1
    try:
        answer = await CloudClient(s).ask(CHAT_SYSTEM, prompt, max_tokens=int(cfg.get("cloud.max_tokens", 4096)))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"クラウド AI との会話に失敗: {e}")
    hist += [{"role": "user", "content": msg}, {"role": "assistant", "content": answer}]
    if path:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(hist[-keep * 2:], ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass
    head = f"[クラウド AI: {s.describe()}" + (f" / 秘密情報 {masked} 件をマスク" if masked else "") + "]\n"
    return head + answer + "\n\n（相手の言いたいこと・質問・指摘を digest で整理してから次を送る）"


_P = {"peer": {"type": "string", "description": "ピアの名前（config.yaml の peers[].name。1 つだけなら省略可）"}}

register(Tool("peer_list", "設定済みのピア（LAN 上の別の AperCode）と、その状態（バージョン・モデル・受け付けるプロジェクト）を一覧する。",
              {"type": "object", "properties": {}}, peer_list, lambda a: ""))
register(Tool("ask_peer",
              "LAN 上の別の AperCode（ピア）に作業を依頼し、終わるまで待って相手の応答を返す。相手は自分の LLM とツールで作業する。"
              "相手はこちらの会話を見られないので、task に目的・対象ファイル・完了条件・報告してほしいことを具体的に書く。"
              "mode=explore は読み取りだけ（調査・レビュー）。files で自分のプロジェクトのファイルを送れる（相手の受け取り用フォルダに置かれ、上書きはされない）。"
              "相手が質問してきたら peer_reply で答える。",
              {"type": "object", "properties": {**_P,
                  "task": {"type": "string", "description": "依頼内容（自己完結した具体的な指示）"},
                  "project": {"type": "string", "description": "相手のマシン上のプロジェクトのパス（省略で相手の既定）"},
                  "mode": {"type": "string", "enum": ["code", "explore"]},
                  "files": {"type": "array", "items": {"type": "string"}, "description": "送るファイル（自分のプロジェクト内のパス。最大 10）"},
                  "wait_seconds": {"type": "number", "description": "完了を待つ秒数（既定 peer.wait_seconds）"}},
               "required": ["task"]}, ask_peer, lambda a: f"{a.get('peer', '')}: {str(a.get('task', ''))[:70]}"))
register(Tool("peer_reply", "ask_peer で依頼したピアに、返事・追加の指示・修正の依頼を送り、相手の応答を返す。",
              {"type": "object", "properties": {**_P,
                  "task_id": {"type": "string"}, "text": {"type": "string"},
                  "files": {"type": "array", "items": {"type": "string"}},
                  "wait_seconds": {"type": "number"}},
               "required": ["task_id", "text"]}, peer_reply, lambda a: f"{a.get('peer', '')}: {str(a.get('text', ''))[:70]}"))
register(Tool("peer_status", "ピアに依頼した作業の状態と最後の応答を見る。wait_seconds を指定すると完了までその秒数待つ。",
              {"type": "object", "properties": {**_P, "task_id": {"type": "string"}, "wait_seconds": {"type": "number"}},
               "required": ["task_id"]}, peer_status, lambda a: str(a.get("task_id", ""))))
register(Tool("peer_read_file", "ピアのプロジェクトのファイルを読む（ディレクトリなら一覧）。相手の報告の裏取りやレビューに使う。",
              {"type": "object", "properties": {**_P, "project": {"type": "string"}, "path": {"type": "string"},
                                                "start_line": {"type": "integer"}, "end_line": {"type": "integer"}}},
              peer_read_file, lambda a: f"{a.get('peer', '')}: {a.get('path', '')}"))
register(Tool("peer_verify", "ピアのプロジェクトでテスト（自動検出したコマンド）を実行し、結果を返す。相手の「テストが通った」を自分で確かめるのに使う。",
              {"type": "object", "properties": {**_P, "project": {"type": "string"}}},
              peer_verify, lambda a: f"{a.get('peer', '')}: {a.get('project', '')}"))
register(Tool("cloud_chat",
              "クラウド AI と会話する（相談・議論・レビュー依頼）。ask_cloud と違い、行き詰まっていなくても使える。"
              "会話はこのセッションの中で続く（new_topic=true で新しい話題）。送る内容に秘密情報を含めない。",
              {"type": "object", "properties": {
                  "message": {"type": "string", "description": "送る文章"},
                  "new_topic": {"type": "boolean", "description": "これまでの会話を引き継がない"}},
               "required": ["message"]}, cloud_chat, lambda a: str(a.get("message", ""))[:80]))
