"""デスクトップ GUI 操作ツール（v1.11.0）: gui_windows / gui_launch / gui_activate / screenshot / gui_input。

run_command でその場限りのスクリプトを組み立てる代わりに、決まった手順で確実に動く操作を提供する。
スクリーンショットは画像として LLM に直接渡る（ブラウザで開き直す必要はない）。
"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register
from .. import gui as G

GUI_TOOLS = {"gui_windows", "gui_launch", "gui_activate", "screenshot", "gui_input"}


def _err(e: Exception) -> ToolError:
    return ToolError(str(e))


async def gui_windows(ctx: ToolContext, a: dict) -> str:
    try:
        wins = await G.list_windows()
    except G.GuiError as e:
        raise _err(e)
    q = str(a.get("filter") or "").lower()
    wins = [w for w in wins if not q or q in w.title.lower()]
    if not wins:
        return "該当するウィンドウはありません" + ("（起動していなければ gui_launch で起動する）" if q else "")
    return "ウィンドウ一覧（ID  幅x高さ+X+Y  タイトル）:\n" + "\n".join(w.line() for w in wins)


async def gui_launch(ctx: ToolContext, a: dict) -> str:
    cmd = str(a.get("command") or "").strip()
    title = str(a.get("title") or "").strip()
    if not cmd or not title:
        raise ToolError("command（起動コマンド）と title（ウィンドウのタイトルの一部）を指定してください")
    try:
        w, started = await G.launch(cmd, title, float(a.get("timeout") or 40))
    except G.GuiError as e:
        raise _err(e)
    return ("起動しました" if started else "既に開いています（起動はしていません）") + f": {w.line()}\n次は screenshot(window=\"{title}\") で画面を確認する。"


async def gui_activate(ctx: ToolContext, a: dict) -> str:
    try:
        w = await G.find(str(a.get("window") or ""))
        ok = await G.activate(w)
    except G.GuiError as e:
        raise _err(e)
    if not ok:
        raise ToolError(f"ウィンドウ {w.id}（{w.title}）を前面に出せませんでした（最小化・別のワークスペースの可能性）")
    return f"前面に出しました: {w.line()}"


async def screenshot(ctx: ToolContext, a: dict) -> str:
    if ctx.files_dir is None:
        raise ToolError("スクリーンショットの保存先がありません")
    try:
        fname, desc = await G.screenshot(ctx.files_dir, ctx.session_id, window=str(a.get("window") or "") or None,
                                         activate_first=a.get("activate", True) is not False)
    except G.GuiError as e:
        raise _err(e)
    return f"{desc}\n[[screenshot:{fname}]]"


async def gui_input(ctx: ToolContext, a: dict) -> str:
    text = a.get("text")
    keys = a.get("keys") or []
    if isinstance(keys, str):
        keys = [keys]
    if a.get("click") is None and not text and not keys:
        raise ToolError("click・text・keys のどれかを指定してください")
    try:
        done = await G.gui_input(ctx.session_id, str(a.get("window") or ""), click=a.get("click"),
                                 text=str(text) if text else None, keys=[str(k) for k in keys], button=int(a.get("button") or 1))
    except G.GuiError as e:
        raise _err(e)
    return "\n".join(done) + "\n結果はまだ確認していません。screenshot でウィンドウ全体を撮って、意図どおりになったかを確かめること。"


def _win_desc() -> str:
    return "ウィンドウのタイトルの一部（例: Claude）または 0x で始まるウィンドウ ID"


register(Tool("gui_windows", "デスクトップに開いているウィンドウ（ID・位置・大きさ・タイトル・アクティブか）を一覧する。",
              {"type": "object", "properties": {"filter": {"type": "string", "description": "タイトルで絞り込む文字列（任意）"}}},
              gui_windows, lambda a: a.get("filter", "")))

register(Tool("gui_launch",
              "デスクトップアプリを起動し、ウィンドウが現れるまで待つ。既に開いていれば起動せずにそのウィンドウを返す。",
              {"type": "object", "properties": {
                  "command": {"type": "string", "description": "起動コマンド（例: claude-desktop）"},
                  "title": {"type": "string", "description": "待つウィンドウのタイトルの一部（例: Claude）"},
                  "timeout": {"type": "integer", "description": "待つ秒数（既定 40）"}},
               "required": ["command", "title"]}, gui_launch, lambda a: f"{a.get('command', '')} → {a.get('title', '')}"))

register(Tool("gui_activate", "ウィンドウを前面に出してアクティブにし、本当にアクティブになったかを確かめる。",
              {"type": "object", "properties": {"window": {"type": "string", "description": _win_desc()}}, "required": ["window"]},
              gui_activate, lambda a: a.get("window", "")))

register(Tool("screenshot",
              "スクリーンショットを撮り、画像として見る（画像が読めるモデル向け）。window を指定するとそのウィンドウを前面に出して、"
              "その部分だけを撮る（文字が大きく読みやすい）。gui_input の click はこの画像上の座標で指定する。",
              {"type": "object", "properties": {
                  "window": {"type": "string", "description": _win_desc() + "。省略で画面全体"},
                  "activate": {"type": "boolean", "description": "撮る前に前面に出す（既定 true）"}}},
              screenshot, lambda a: a.get("window") or "画面全体"))

register(Tool("gui_input",
              "ウィンドウを前面に出してから、クリック → 文章の貼り付け → キー入力 の順に操作する（指定したものだけ）。"
              "文章はクリップボード経由で貼り付けるので日本語も崩れない。click は直前の screenshot の画像上のピクセル座標。"
              "操作の後は必ず screenshot で結果を確かめる。",
              {"type": "object", "properties": {
                  "window": {"type": "string", "description": _win_desc()},
                  "click": {"type": "array", "items": {"type": "number"}, "description": "[x, y] クリックする位置（直前の screenshot 上の座標）"},
                  "text": {"type": "string", "description": "貼り付ける文章"},
                  "keys": {"type": "array", "items": {"type": "string"}, "description": "最後に押すキー（例: [\"Return\"], [\"ctrl+Return\"]）"},
                  "button": {"type": "integer", "description": "マウスボタン（1=左 既定, 3=右）"}},
               "required": ["window"]},
              gui_input, lambda a: f"{a.get('window', '')}: " + ", ".join(
                  x for x in (f"click {a.get('click')}" if a.get("click") else "", f"貼り付け {len(str(a.get('text') or ''))} 文字" if a.get("text") else "",
                              f"keys {a.get('keys')}" if a.get("keys") else "") if x)))
