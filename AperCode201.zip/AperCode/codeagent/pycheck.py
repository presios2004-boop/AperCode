"""Python の構造チェック（v1.10.0）: 追加のツール無しで「存在しないもの」を呼んでいるバグを見つける。

py_compile・ruff・既存テストをすり抜けるが、実行すると AttributeError / TypeError で落ちる種類の誤りを、AST だけで検出する:
  - self.xxx の参照先が、そのクラスのどこにも定義されていない（メソッド・クラス変数・self.xxx = への代入・dataclass フィールド）
  - 同じクラスのメソッド self.m(...) / 同じファイルの関数 f(...) の呼び出しで、引数の数やキーワード名が定義と合わない

誤検出を避けるため、継承しているクラス（object 以外の基底）・__getattr__ / __slots__ / setattr を使うクラスは調べない。
既存コードの問題で毎回 NG にならないよう、変更前（before）にも同じ問題があったものは報告しない（今回の変更で増えた問題だけ）。
"""
from __future__ import annotations

import ast
import builtins
from dataclasses import dataclass


@dataclass(frozen=True)
class Problem:
    line: int
    key: str        # 行番号を含まない識別子（変更前との比較用）
    message: str

    def format(self, path: str) -> str:
        return f"{path}:{self.line}: {self.message}"


# ------------------------------------------------------------------ 関数の引数仕様
@dataclass
class _Sig:
    name: str
    pos: list[str]          # 位置引数として渡せる名前（self/cls は除く）
    required_pos: int       # デフォルト無しの位置引数の数
    kwonly: list[str]
    kwonly_required: list[str]
    vararg: bool
    kwarg: bool


def _sig(fn: ast.FunctionDef | ast.AsyncFunctionDef, drop_first: bool) -> _Sig:
    a = fn.args
    pos = [x.arg for x in a.posonlyargs + a.args]
    if drop_first and pos:
        pos = pos[1:]
    n_def = len(a.defaults)
    total = len(a.posonlyargs) + len(a.args) - (1 if drop_first and (a.posonlyargs or a.args) else 0)
    required = max(0, total - n_def)
    kwonly = [x.arg for x in a.kwonlyargs]
    kwreq = [x.arg for x, d in zip(a.kwonlyargs, a.kw_defaults) if d is None]
    return _Sig(fn.name, pos, required, kwonly, kwreq, a.vararg is not None, a.kwarg is not None)


def _decorators(fn) -> set[str]:
    out = set()
    for d in fn.decorator_list:
        if isinstance(d, ast.Name):
            out.add(d.id)
        elif isinstance(d, ast.Attribute):
            out.add(d.attr)
        elif isinstance(d, ast.Call):
            f = d.func
            out.add(f.id if isinstance(f, ast.Name) else f.attr if isinstance(f, ast.Attribute) else "")
    return out


def _check_call(call: ast.Call, sig: _Sig, label: str) -> str | None:
    if any(isinstance(a, ast.Starred) for a in call.args) or any(k.arg is None for k in call.keywords):
        return None                                     # *args / **kw 展開は数えられない
    n = len(call.args)
    if n > len(sig.pos) and not sig.vararg:
        return f"{label} は位置引数を最大 {len(sig.pos)} 個取りますが、{n} 個渡しています"
    given = set(sig.pos[:n])
    for k in call.keywords:
        if k.arg in given:
            return f"{label} の引数 {k.arg} が位置とキーワードの両方で渡されています"
        if k.arg not in sig.pos and k.arg not in sig.kwonly and not sig.kwarg:
            return f"{label} に存在しないキーワード引数 {k.arg} を渡しています"
        given.add(k.arg)
    missing = [p for p in sig.pos[:sig.required_pos] if p not in given] + [k for k in sig.kwonly_required if k not in given]
    if missing:
        return f"{label} の必須引数 {', '.join(missing)} が渡されていません"
    return None


# ------------------------------------------------------------------ 本体
class _ClassInfo:
    def __init__(self, node: ast.ClassDef):
        self.node = node
        self.names: set[str] = set()
        self.methods: dict[str, _Sig] = {}
        self.skip = False
        bases = [b for b in node.bases if not (isinstance(b, ast.Name) and b.id == "object")]
        if bases or any(k.arg == "metaclass" for k in node.keywords):
            self.skip = True                            # 継承先の属性は分からない
        if set(_decorators(node)) - {"dataclass", "total_ordering", "final"}:
            self.skip = True                            # クラスデコレータは属性を足しうる（enum など）
        for st in _class_level(node.body):
            if isinstance(st, (ast.Import, ast.ImportFrom)):
                self.names.update((a.asname or a.name).split(".")[0] for a in st.names)
            elif isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.names.add(st.name)
                decs = _decorators(st)
                if "staticmethod" in decs:
                    self.methods[st.name] = _sig(st, drop_first=False)
                elif "property" in decs or any(d.endswith(("setter", "getter", "deleter")) for d in decs):
                    pass
                elif decs - {"classmethod", "abstractmethod", "override", "wraps", "cache", "lru_cache", "cached_property"}:
                    pass                                # 未知のデコレータはシグネチャを変えうる
                else:
                    self.methods[st.name] = _sig(st, drop_first=True)
                if st.name in ("__getattr__", "__getattribute__", "__setattr__"):
                    self.skip = True
            elif isinstance(st, ast.Assign):
                for t in st.targets:
                    for n in ast.walk(t):
                        if isinstance(n, ast.Name):
                            self.names.add(n.id)
                            if n.id == "__slots__":
                                self.skip = True
            elif isinstance(st, ast.AnnAssign) and isinstance(st.target, ast.Name):
                self.names.add(st.target.id)
            elif isinstance(st, ast.ClassDef):
                self.names.add(st.name)
        # self.xxx = ... / self.xxx += ... / for self.xxx in / with ... as self.xxx
        for n in ast.walk(node):
            if isinstance(n, ast.Attribute) and isinstance(n.ctx, (ast.Store, ast.Del)) and _is_self(n.value):
                self.names.add(n.attr)
            elif isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ("setattr", "delattr", "vars") \
                    and n.args and _is_self(n.args[0]):
                self.skip = True
            elif isinstance(n, ast.Attribute) and n.attr == "__dict__" and _is_self(n.value):
                self.skip = True


def _class_level(body: list) -> list:
    """クラス本体の文（if / try / with の中も含む。関数やネストしたクラスの中は含まない）。"""
    out = []
    for st in body:
        out.append(st)
        for fld in ("body", "orelse", "finalbody"):
            if isinstance(st, (ast.If, ast.Try, ast.With, ast.For, ast.While)) and getattr(st, fld, None):
                out += _class_level(getattr(st, fld))
        if isinstance(st, ast.Try):
            for h in st.handlers:
                out += _class_level(h.body)
    return out


def _is_self(node: ast.AST) -> bool:
    return isinstance(node, ast.Name) and node.id in ("self", "cls")


def analyze(src: str) -> list[Problem]:
    """ソースを解析して問題の一覧を返す（構文エラーなら空。構文は py_compile が見る）。"""
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return []
    probs: list[Problem] = []

    # モジュール直下の関数（同名の再定義・import・代入で上書きされるものは除外）
    funcs: dict[str, _Sig] = {}
    shadow: set[str] = set()
    for st in tree.body:
        if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if st.name in funcs or _decorators(st):
                shadow.add(st.name)
            funcs[st.name] = _sig(st, drop_first=False)
        elif isinstance(st, (ast.Import, ast.ImportFrom)):
            shadow.update((a.asname or a.name).split(".")[0] for a in st.names)
        elif isinstance(st, ast.Assign):
            for t in st.targets:
                for n in ast.walk(t):
                    if isinstance(n, ast.Name):
                        shadow.add(n.id)
    funcs = {k: v for k, v in funcs.items() if k not in shadow and not hasattr(builtins, k)}

    classes = [_ClassInfo(n) for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
    # ミックスイン（他クラスと多重継承されて使われる前提のクラス）は、足りない属性を相手のクラスが持つので調べない
    multi_bases: set[str] = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.ClassDef) and len(n.bases) >= 2:
            multi_bases.update(b.id for b in n.bases if isinstance(b, ast.Name))
    # クラスの外で足される属性（Cls.attr = ...）と、同じファイルのサブクラスが定義する属性（基底側で使う抽象的な属性）
    by_name = {ci.node.name: ci for ci in classes}
    for n in ast.walk(tree):
        if isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Store) and isinstance(n.value, ast.Name) and n.value.id in by_name:
            by_name[n.value.id].names.add(n.attr)
    for ci in classes:
        for b in ci.node.bases:
            if isinstance(b, ast.Name) and b.id in by_name:
                by_name[b.id].names |= ci.names
    for ci in classes:
        nm = ci.node.name
        if ci.skip or nm in multi_bases or nm.endswith(("Mixin", "Base", "Protocol", "Interface")) or nm.startswith(("Base", "Abstract")):
            continue
        undefined = {n.attr for fn in ci.node.body if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef))
                     for n in ast.walk(fn) if isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Load)
                     and _is_self(n.value) and n.attr not in ci.names and not (n.attr.startswith("__") and n.attr.endswith("__"))}
        if len(undefined) > 2:
            continue                                    # 未定義が 3 種類以上 = ミックスインの可能性が高い（書き損じは普通 1〜2 個）
        for fn in ci.node.body:
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if "staticmethod" in _decorators(fn):
                continue
            for n in ast.walk(fn):
                if isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Load) and _is_self(n.value):
                    a = n.attr
                    if a.startswith("__") and a.endswith("__"):
                        continue
                    if a not in ci.names:
                        probs.append(Problem(n.lineno, f"attr:{ci.node.name}.{a}",
                                             f"self.{a} はクラス {ci.node.name} のどこにも定義されていません（実行すると AttributeError）"))
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and _is_self(n.func.value):
                    sig = ci.methods.get(n.func.attr)
                    if sig is not None:
                        msg = _check_call(n, sig, f"{ci.node.name}.{sig.name}()")
                        if msg:
                            probs.append(Problem(n.lineno, f"call:{ci.node.name}.{sig.name}:{msg}", msg + "（実行すると TypeError）"))
    # モジュール関数の呼び出し（関数内で同名のローカル変数・引数があるものは除外しない簡易版: 名前が Load のときだけ）
    local_names: set[str] = set()
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            for a in n.args.posonlyargs + n.args.args + n.args.kwonlyargs:
                local_names.add(a.arg)
        elif isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
            local_names.add(n.id)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            local_names.update((a.asname or a.name).split(".")[0] for a in n.names)
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in funcs and n.func.id not in local_names:
            sig = funcs[n.func.id]
            msg = _check_call(n, sig, f"{sig.name}()")
            if msg:
                probs.append(Problem(n.lineno, f"call:{sig.name}:{msg}", msg + "（実行すると TypeError）"))
    # 同じ行・同じ内容の重複を除く
    seen, out = set(), []
    for p in sorted(probs, key=lambda p: p.line):
        if (p.line, p.key) not in seen:
            seen.add((p.line, p.key))
            out.append(p)
    return out


def new_problems(after: str, before: str | None) -> list[Problem]:
    """変更後にあって変更前には無かった問題だけを返す（既存の問題で毎回 NG にしない）。"""
    now = analyze(after)
    if not before:
        return now
    old_keys = {p.key for p in analyze(before)}
    return [p for p in now if p.key not in old_keys]


def added_lines(before: str | None, after: str) -> set[int]:
    """変更後のファイルで、追加・変更された行番号（1 始まり）。"""
    import difflib
    a = (before or "").splitlines()
    b = after.splitlines()
    if before is None:
        return set(range(1, len(b) + 1))
    out: set[int] = set()
    for tag, _i1, _i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag in ("replace", "insert"):
            out.update(range(j1 + 1, j2 + 1))
    return out
