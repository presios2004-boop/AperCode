"""作業の指示書（v1.8.0）: ユーザーが最初に指示した目的を md ファイルに清書し、LLM の毎回のリクエストに自動で添える。

ローカル LLM は長い作業の途中で最初の目的を忘れやすい。会話履歴は圧縮で要約されていくので、目的は履歴とは別に
ファイルとして保持し、AperCode（ハーネス）が LLM を呼ぶたびにファイルを読み直してシステムプロンプトに入れる。
LLM に「読みに行かせる」のではないので、読み忘れが起きない。ユーザーがファイルを直接編集すれば次の呼び出しから反映される。

置き場所: <プロジェクト>/.apercode/briefs/<セッションID>.md
- 最初の指示で作成（LLM が清書。失敗したら原文のまま）
- 以降のユーザーの指示は「追加・変更の指示」として追記（「続けて」などの短い返事は追記しない）
- 目的を達成したら LLM が finish_brief ツールで削除（テスト失敗・自動検証 NG が残っていれば拒否）。画面からも削除できる
"""
from __future__ import annotations

import re
import time
from pathlib import Path

BRIEF_PROMPT = """あなたはユーザーの依頼を「作業の指示書」に清書する係です。
以下のユーザーの依頼文を読み、コーディングエージェントが作業の最後まで目的を見失わないための指示書を Markdown で書いてください。

形式（この見出しだけを使う。該当が無い見出しは省略）:
# 目的
（何を実現したいのかを 1〜3 行で）
## 要件
- （ユーザーが求めていること。箇条書き）
## 制約・注意
- （使う言語・ライブラリ・触ってはいけないもの・方針など、ユーザーが指定したこと）
## 完了条件
- [ ] （何ができたら完了か。確認できる形で）

規則:
- ユーザーが書いていないことを付け足さない（推測で要件を増やさない）。曖昧な点は「（未指定）」と書く
- ファイル名・パス・数値・固有名詞はそのまま残す
- 40 行以内。前置きや説明は書かず、指示書だけを出力する
"""

BRIEF_PROMPT_EN = """You turn the user's request into a "task brief".
Read the request below and write, in Markdown, a brief that keeps a coding agent on target until the end of the work.

Format (use only these headings; omit a heading that has nothing):
# Goal
(what the user wants to achieve, 1-3 lines)
## Requirements
- (what the user asked for, as bullets)
## Constraints
- (languages, libraries, things not to touch, policies the user specified)
## Done when
- [ ] (what must be true for the task to be finished, in a checkable form)

Rules:
- Do not add anything the user did not say (no guessed requirements). Write "(unspecified)" for unclear points
- Keep file names, paths, numbers and proper nouns verbatim
- At most 40 lines. Output only the brief, no preamble
"""

# v2.0.0: 指示書の不足点検。ユーザーが指示書を正確に書くとは限らないので、作業を始める前に足りない点を洗い出す
CLARIFY_PROMPT = """あなたはコーディングエージェント AperCode の作業前点検係です。
以下の「作業の指示書」を読み、このまま作業を始めると困る不足がないかを点検してください。

点検する観点:
1. 完了条件: 何ができたら終わりかが確認できる形か。会話・繰り返し・監視などの作業では「いつ終えるか（終了条件）」があるか
2. 対象: 作業するファイル・フォルダ・アプリ・相手・場所が特定できるか
3. 取り返しのつかない操作: 削除・上書き・送信・公開・購入などがある場合、その範囲が決まっているか
4. 成果物: 形式や置き場所が結果を大きく左右するのに、決まっていないか

出力の形式（この形式の行だけを書く。前置き・説明は書かない）:
QUESTION: （作業前にユーザーへ聞くべき質問。AperCode が自分で決めると大きな手戻りや損害になるものだけ。最大 3 つ）
ASSUME: （AperCode が妥当に決められる点。「〜とする」の形で仮定を書く。最大 5 つ）
不足が無ければ OK とだけ書く。

規則:
- 指示書に書いてあることを質問しない。細かい好みは質問せず ASSUME にする
- やり方・手段（アプリの起動方法・使うツール・作業の手順など）は AperCode が決めることなので、質問せず ASSUME にする
- 終了条件が相手の行動（「相手が終了を告げたら」など）だけに頼っている場合は、それが来なかったときの上限（往復数・時間）を ASSUME に書く
- 質問は 1 つ 1 文で、ユーザーが短く答えられる形にする（選択肢があれば示す）
"""

CLARIFY_PROMPT_EN = """You check a task brief for the coding agent AperCode before the work starts.
Read the brief below and find gaps that would cause trouble if the work started as is.

Check:
1. Done condition: can "finished" be checked? For conversations, repeated work or monitoring: is there a stop condition?
2. Target: are the files, folders, apps, counterpart or place identifiable?
3. Irreversible operations: if there is deleting, overwriting, sending, publishing or buying, is its scope decided?
4. Deliverable: is a format or location that matters a lot left undecided?

Output format (only lines in this format, no preamble):
QUESTION: (a question to ask the user before starting — only where AperCode deciding alone could cause big rework or damage; at most 3)
ASSUME: (a point AperCode can reasonably decide, written as an assumption; at most 5)
If nothing is missing, write only OK.

Rules:
- Do not ask about what the brief already says. Put minor preferences under ASSUME
- Methods and means (how to launch an app, which tools, the order of work) are AperCode's decision: put them under ASSUME, never ask
- If the stop condition depends only on someone else's action ("until they say goodbye"), add a fallback limit (rounds or time) under ASSUME
- One sentence per question, answerable briefly (offer choices when possible)
"""


def parse_clarify(raw: str) -> tuple[list[str], list[str]]:
    """点検結果から（質問, 仮定）を取り出す。形式に合わない行は無視する。"""
    qs: list[str] = []
    ass: list[str] = []
    for ln in clean_llm_output(raw).splitlines():
        m = re.match(r"^\s*[-*]?\s*(QUESTION|ASSUME|質問|仮定)\s*[:：]\s*(.+?)\s*$", ln, re.I)
        if not m:
            continue
        body = m.group(2).strip()
        if len(body) < 4 or body.upper() == "OK":
            continue
        (qs if m.group(1).upper() in ("QUESTION", "質問") else ass).append(body)
    return qs[:3], ass[:5]


def append_assumptions(p: Path, assumptions: list[str]) -> None:
    if not assumptions:
        return
    with open(p, "a", encoding="utf-8") as f:
        f.write("\n## AperCode の仮定（違っていれば指示してください）\n" + "\n".join(f"- {a}" for a in assumptions) + "\n")


def append_answer(p: Path, text: str) -> None:
    t = text.strip()[:1500]
    stamp = time.strftime("%m/%d %H:%M")
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"\n## 作業前の確認への回答（{stamp}）\n" + "\n".join("> " + ln for ln in t.splitlines()) + "\n")


CONTINUE_WORDS = re.compile(r"^(続けて|つづけて|続行|はい|いいえ|ok|okay|yes|no|go|continue|進めて|お願いします|おねがいします|よろしく|了解|りょうかい|どうぞ|やって)[。．!！\s]*$",
                            re.I)


def path_for(project: Path, session_id: str) -> Path:
    return project / ".apercode" / "briefs" / f"{session_id}.md"


def rel(project: Path, p: Path) -> str:
    try:
        return str(p.relative_to(project))
    except ValueError:
        return str(p)


def read(p: Path, max_chars: int = 4000) -> str:
    try:
        s = p.read_text("utf-8", errors="replace").strip()
    except (FileNotFoundError, OSError):
        return ""
    return s if len(s) <= max_chars else s[:max_chars] + "\n…（長いため省略）"


def is_meaningful(text: str, min_chars: int) -> bool:
    t = (text or "").strip()
    return len(t) >= min_chars and not CONTINUE_WORDS.match(t)


def is_followup(text: str) -> bool:
    t = (text or "").strip()
    return len(t) >= 6 and not CONTINUE_WORDS.match(t)


def header(created: float) -> str:
    return f"<!-- AperCode 作業の指示書（{time.strftime('%Y-%m-%d %H:%M', time.localtime(created))} 作成）。編集すると次の LLM 呼び出しから反映されます。目的を達成すると自動で削除されます -->\n"


def write_new(p: Path, body: str, original: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    body = body.strip()
    orig = original.strip()
    if len(orig) > 3000:
        orig = orig[:3000] + "…"
    quoted = "\n".join("> " + ln for ln in orig.splitlines())
    p.write_text(header(time.time()) + body + "\n\n## ユーザーの原文\n" + quoted + "\n", encoding="utf-8")


def append_instruction(p: Path, text: str) -> None:
    t = text.strip()
    if len(t) > 1500:
        t = t[:1500] + "…"
    stamp = time.strftime("%m/%d %H:%M")
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"\n## 追加・変更の指示（{stamp}）\n" + "\n".join("> " + ln for ln in t.splitlines()) + "\n")


def clean_llm_output(raw: str) -> str:
    s = (raw or "").strip()
    s = re.sub(r"^```(?:markdown|md)?\s*\n", "", s)
    s = re.sub(r"\n```\s*$", "", s)
    s = re.sub(r"<think>.*?</think>", "", s, flags=re.S).strip()
    return s
