"""AperCode ベンチマーク（v1.10.0）: 実際の LLM に小さな課題を解かせ、ハーネスの性能を数字で記録する。

使い方（AperCode のフォルダで）:
    python bench/run_bench.py                     # 全課題を 1 回ずつ（モデルは画面で選んだもの）
    python bench/run_bench.py --tasks 01,05       # 課題を選ぶ（番号の先頭一致）
    python bench/run_bench.py --model qwen3:8b --repeat 3 --label 実験A
    python bench/run_bench.py --phases off        # 作業フェーズを切った場合と比べる
    python bench/run_bench.py --list              # 課題の一覧
    python bench/run_bench.py --history           # 過去の結果の集計

各課題は bench/tasks/<名前>/ にある:
    task.md   … LLM に送る指示（ユーザーの入力と同じ扱い）
    files/    … 作業フォルダの初期状態（一時フォルダにコピーして作業させる）
    check.py  … 隠し受け入れテスト（LLM には見せない）。作業後に python check.py <作業フォルダ> を実行し、終了コード 0 で合格

結果は bench/results.jsonl に 1 課題 1 行で追記される（成功・時間・ツール呼び出し回数・巻き戻し回数・トークンなど）。
ハーネスを変更したら同じモデルで実行し、前回の結果と比べて性能が落ちていないかを確かめる。

注意:
  - ツールの実行はすべて自動で許可する（作業フォルダの外に触れる操作だけは拒否）。作業は一時フォルダの中だけで行われる
  - 設定はふだんの AperCode と同じ（config.yaml + ~/.apercode/config.yaml）。ただし経験メモリ・ブラウザ・クラウド相談は切る
    （ベンチマークの教訓がふだんの記憶に混ざらないように。結果が外部 AI の力に左右されないように）
  - コンテキストサイズは設定値（llm.num_ctx）を使う。画面の自動調整とそろえたいときは --num-ctx で指定する
"""
from __future__ import annotations

import argparse
import asyncio
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BENCH = ROOT / "bench"
TASKS = BENCH / "tasks"
RESULTS = BENCH / "results.jsonl"
sys.path.insert(0, str(ROOT))


def list_tasks(sel: str | None) -> list[Path]:
    tasks = sorted(p for p in TASKS.iterdir() if (p / "task.md").exists())
    if sel:
        keys = [s.strip() for s in sel.split(",") if s.strip()]
        tasks = [t for t in tasks if any(t.name.startswith(k) for k in keys)]
    return tasks


def set_cfg(cfg, dotted: str, value) -> None:
    cur = cfg.data
    ks = dotted.split(".")
    for k in ks[:-1]:
        cur = cur.setdefault(k, {})
    cur[ks[-1]] = value


class Recorder:
    """エージェントのイベントを数えて、進み具合を 1 行ずつ表示する。"""

    def __init__(self, verbose: bool):
        self.events: list[dict] = []
        self.verbose = verbose
        self._last_phase = ""

    async def emit(self, ev: dict) -> None:
        self.events.append(ev)
        t = ev.get("type")
        if not self.verbose:
            return
        if t == "tool_call":
            print(f"    · {ev.get('name')} {str(ev.get('summary') or '')[:70]}", flush=True)
        elif t == "phase":
            line = f"    ▶ フェーズ: {ev.get('label')}" + (f" {min(ev.get('idx', 0) + 1, ev['n'])}/{ev['n']}" if ev.get("n") else "")
            if line != self._last_phase:
                print(line, flush=True)
            self._last_phase = line
        elif t == "checkpoint":
            print(f"    💾 {str(ev.get('text'))[:120]}", flush=True)
        elif t in ("rollback", "error") or (t == "verify" and ev.get("ok") is False):
            print(f"    ! {t}: {str(ev.get('text'))[:120]}", flush=True)

    async def approve(self, req: dict) -> str:
        return "deny" if "作業ディレクトリの外" in str(req.get("reason", "")) else "allow"

    def count(self, t: str, **kw) -> int:
        return sum(1 for e in self.events if e.get("type") == t and all(e.get(k) == v for k, v in kw.items()))


async def run_one(task: Path, cfg, model: str | None, run_dir: Path, timeout: float, verbose: bool) -> dict:
    from codeagent.agent import Agent
    from codeagent.llm import LLMClient
    from codeagent.session import Session, SessionStore

    work = run_dir / task.name
    shutil.copytree(task / "files", work)
    llm = LLMClient(cfg)
    if model:
        llm.model = model
    store = SessionStore(run_dir / "sessions")
    agent = Agent(cfg, llm, store)
    session = Session.new(str(work))
    store.save(session)
    rec = Recorder(verbose)
    prompt = (task / "task.md").read_text(encoding="utf-8").strip()
    t0 = time.time()
    status = "done"
    try:
        await asyncio.wait_for(agent.run(session, prompt, rec.emit, rec.approve), timeout=timeout)
    except asyncio.TimeoutError:
        agent.cancel(session.id)
        status = "timeout"
    except Exception as e:  # noqa: BLE001
        status = f"crash: {type(e).__name__}: {e}"
    secs = time.time() - t0
    try:
        await llm.close()
    except Exception:  # noqa: BLE001
        pass
    chk = subprocess.run([sys.executable, str(task / "check.py"), str(work)], capture_output=True, text=True, timeout=600)
    s = store.load(session.id) or session
    ph = s.phase or {}
    msg = (chk.stdout + chk.stderr).strip().splitlines()
    return {
        "task": task.name, "success": chk.returncode == 0, "status": status, "check": msg[-1][:200] if msg else "",
        "seconds": round(secs, 1), "tool_calls": rec.count("tool_call"),
        "tool_errors": sum(1 for e in rec.events if e.get("type") == "tool_result" and e.get("error")),
        "llm_errors": rec.count("error"), "verify_ng": rec.count("verify", ok=False),
        "rollbacks": rec.count("rollback"), "checkpoints": rec.count("checkpoint"),
        "fix_phases": sum(1 for e in rec.events if e.get("type") == "phase" and e.get("phase") == "fix"),
        "limit_hit": any("上限" in str(e.get("text", "")) for e in rec.events if e.get("type") == "info"),
        "phase_end": (ph.get("phase") if ph.get("active") else ("done" if ph.get("steps") else "none")),
        "steps": len(ph.get("steps") or []), "prompt_tokens": s.usage.get("prompt_tokens", 0),
        "completion_tokens": s.usage.get("completion_tokens", 0),
    }


def summarize(rows: list[dict]) -> dict:
    n = len(rows) or 1
    return {"runs": len(rows), "success": sum(r["success"] for r in rows), "rate": round(100 * sum(r["success"] for r in rows) / n, 1),
            "avg_seconds": round(sum(r["seconds"] for r in rows) / n, 1),
            "avg_tool_calls": round(sum(r["tool_calls"] for r in rows) / n, 1),
            "rollbacks": sum(r["rollbacks"] for r in rows), "crashes": sum(str(r["status"]).startswith("crash") for r in rows),
            "timeouts": sum(r["status"] == "timeout" for r in rows)}


def load_history() -> list[dict]:
    if not RESULTS.exists():
        return []
    out = []
    for ln in RESULTS.read_text(encoding="utf-8").splitlines():
        try:
            out.append(json.loads(ln))
        except ValueError:
            continue
    return out


def print_history() -> None:
    rows = load_history()
    if not rows:
        print("まだ結果がありません")
        return
    groups: dict[str, list[dict]] = {}
    for r in rows:
        groups.setdefault(r["run_id"], []).append(r)
    print(f"{'実行 ID':20} {'版':8} {'モデル':22} {'フェーズ':6} {'ラベル':12} {'成功':>7} {'率':>6} {'平均秒':>7} {'平均ツール':>8} {'巻戻し':>5}")
    for rid, rs in groups.items():
        s = summarize(rs)
        r0 = rs[0]
        print(f"{rid:20} {r0['version']:8} {r0['model'][:22]:22} {r0['phases']:6} {str(r0.get('label') or '')[:12]:12} "
              f"{s['success']:>3}/{s['runs']:<3} {s['rate']:>5}% {s['avg_seconds']:>7} {s['avg_tool_calls']:>8} {s['rollbacks']:>5}")


def main() -> None:
    ap = argparse.ArgumentParser(description="AperCode ベンチマーク")
    ap.add_argument("--tasks", help="課題の番号・名前（カンマ区切り、先頭一致）")
    ap.add_argument("--model", help="メインモデル（省略時は画面で選んだもの）")
    ap.add_argument("--repeat", type=int, default=1, help="各課題の実行回数（LLM の出来のばらつきを均す）")
    ap.add_argument("--timeout", type=float, default=1200, help="1 課題の制限秒数（既定 1200）")
    ap.add_argument("--phases", choices=["on", "off"], help="作業フェーズを強制的にオン / オフ")
    ap.add_argument("--num-ctx", type=int, help="コンテキストサイズ（tokens）")
    ap.add_argument("--label", default="", help="結果に付ける名前（比較用）")
    ap.add_argument("--keep", action="store_true", help="作業フォルダを消さずに残す（失敗の原因調査用）")
    ap.add_argument("--quiet", action="store_true", help="進み具合を表示しない")
    ap.add_argument("--list", action="store_true", help="課題の一覧を表示して終了")
    ap.add_argument("--history", action="store_true", help="過去の結果の集計を表示して終了")
    a = ap.parse_args()

    if a.list:
        for t in list_tasks(None):
            print(f"{t.name:20} {(t / 'task.md').read_text(encoding='utf-8').strip()[:90]}")
        return
    if a.history:
        print_history()
        return

    from codeagent import __version__
    from codeagent.config import Config
    cfg = Config.load()
    for k, v in {"memory.enabled": False, "browser.enabled": False, "cloud.enabled": False}.items():
        set_cfg(cfg, k, v)
    if a.phases:
        set_cfg(cfg, "phases.enabled", a.phases == "on")
    if a.num_ctx:
        set_cfg(cfg, "llm.num_ctx", a.num_ctx)
    model = a.model or cfg.state().get("model") or cfg.get("llm.model")
    tasks = list_tasks(a.tasks)
    if not tasks:
        print("課題がありません")
        return
    run_id = time.strftime("%Y%m%d-%H%M%S")
    base = Path(tempfile.mkdtemp(prefix="apercode_bench_"))
    set_cfg(cfg, "workspace.root", str(base))
    phases = "on" if cfg.get("phases.enabled", True) else "off"
    print(f"AperCode v{__version__} ベンチマーク {run_id}: モデル {model} / フェーズ {phases} / 課題 {len(tasks)} × {a.repeat} 回")
    print(f"作業フォルダ: {base}")
    rows = []
    for rep in range(a.repeat):
        for task in tasks:
            run_dir = base / f"r{rep + 1}"
            run_dir.mkdir(exist_ok=True)
            print(f"\n[{task.name}] ({rep + 1}/{a.repeat})", flush=True)
            r = asyncio.run(run_one(task, cfg, model, run_dir, a.timeout, not a.quiet))
            r.update({"run_id": run_id, "version": __version__, "model": model, "sub_model": cfg.state().get("sub_model") or "",
                      "phases": phases, "label": a.label, "repeat": rep + 1, "ts": time.time()})
            rows.append(r)
            with open(RESULTS, "a", encoding="utf-8") as f:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
            mark = "✓ 合格" if r["success"] else "✗ 不合格"
            print(f"  {mark}  {r['seconds']}s  ツール {r['tool_calls']} 回  巻き戻し {r['rollbacks']}  {r['status']}  {r['check']}")

    print("\n=== 結果 ===")
    for r in rows:
        print(f"{'✓' if r['success'] else '✗'} {r['task']:20} {r['seconds']:>7}s ツール {r['tool_calls']:>3} 修正 {r['fix_phases']:>2} 巻戻し {r['rollbacks']} "
              f"{'' if r['status'] == 'done' else r['status']}")
    s = summarize(rows)
    print(f"成功 {s['success']}/{s['runs']}（{s['rate']}%） 平均 {s['avg_seconds']}s  平均ツール {s['avg_tool_calls']} 回  "
          f"巻き戻し {s['rollbacks']}  落ちた {s['crashes']}  時間切れ {s['timeouts']}")
    # 同じモデルの前回の実行と比べる（同じ課題だけ）
    prev = [r for r in load_history() if r["run_id"] != run_id and r["model"] == model]
    if prev:
        last_id = max(r["run_id"] for r in prev)
        names = {r["task"] for r in rows}
        p = summarize([r for r in prev if r["run_id"] == last_id and r["task"] in names])
        if p["runs"]:
            print(f"前回（{last_id}, v{next(r['version'] for r in prev if r['run_id'] == last_id)}）: 成功 {p['success']}/{p['runs']}（{p['rate']}%） "
                  f"平均 {p['avg_seconds']}s  平均ツール {p['avg_tool_calls']} 回 → 成功率の差 {round(s['rate'] - p['rate'], 1):+}%")
    if not a.keep:
        shutil.rmtree(base, ignore_errors=True)
    else:
        print(f"作業フォルダを残しました: {base}")


if __name__ == "__main__":
    main()
