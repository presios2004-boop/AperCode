"""ベンチマーク課題の検査（課題を追加・変更したときに実行する）: python bench/validate_tasks.py

各課題の check.py が「最初の状態では不合格」「正しい解答では合格」になることを確かめる。
正しい解答（参照解）はこのファイルの SOL に書く。ここは作業フォルダにコピーされないので、LLM からは見えない。
"""
import shutil, subprocess, sys, tempfile, textwrap
from pathlib import Path
S = Path(tempfile.mkdtemp(prefix="apercode_bench_validate_")); T = Path(__file__).resolve().parent / "tasks"
def fresh(name, tag):
    d = S / f"{name}_{tag}"; shutil.copytree(T / name / "files", d); return d
def check(name, d):
    r = subprocess.run([sys.executable, str((T / name / "check.py").resolve()), str(d)], capture_output=True, text=True, timeout=300)
    out = (r.stdout + r.stderr).strip()
    return r.returncode, out.splitlines()[-1][:160] if out else ""
def w(d, rel, src): (d / rel).parent.mkdir(parents=True, exist_ok=True); (d / rel).write_text(textwrap.dedent(src).lstrip("\n"), encoding="utf-8")
def sub(d, rel, a, b):
    s = (d / rel).read_text(encoding="utf-8"); assert a in s, (rel, a); (d / rel).write_text(s.replace(a, b), encoding="utf-8")
SOL = {}
def sol(name):
    def deco(f): SOL[name] = f; return f
    return deco
@sol("01_slugify")
def _(d): sub(d, "text_utils.py", "    raise NotImplementedError", '    import re\n    s = re.sub(r"[\\s_]+", "-", text.lower())\n    s = re.sub(r"[^a-z0-9-]", "", s)\n    s = re.sub(r"-+", "-", s)\n    return s.strip("-")')
@sol("02_paginate_bug")
def _(d):
    sub(d, "pager.py", "start = page * per_page", "start = (page - 1) * per_page"); sub(d, "pager.py", "return total // per_page", "return -(-total // per_page)")
@sol("03_cli_options")
def _(d):
    sub(d, "cli.py", '    args = parser.parse_args(argv)', '    parser.add_argument("--limit", type=int)\n    parser.add_argument("--upper", action="store_true")\n    args = parser.parse_args(argv)\n    shown = 0')
    sub(d, "cli.py", '        if line.strip():\n            print(line.strip())', '        if line.strip():\n            if args.limit is not None and shown >= args.limit:\n                break\n            print(line.strip().upper() if args.upper else line.strip())\n            shown += 1')
@sol("04_csv_stats")
def _(d): w(d, "stats.py", 'import csv, json\ntot = {}\nwith open("sales.csv", encoding="utf-8") as f:\n    for r in csv.DictReader(f):\n        tot[r["region"]] = tot.get(r["region"], 0) + float(r["amount"])\nout = {k: round(v, 2) for k, v in tot.items()}\nout["_total"] = round(sum(tot.values()), 2)\njson.dump(out, open("out.json", "w"), indent=1)\n')
@sol("05_rename")
def _(d):
    for f in d.glob("*.py"): f.write_text(f.read_text(encoding="utf-8").replace("calc_total", "compute_total"), encoding="utf-8")
@sol("06_write_tests")
def _(d): w(d, "tests/test_inventory.py", '''
    import os, sys, pytest
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from inventory import Inventory
    def test_add_and_count():
        i = Inventory(); i.add("a", 2); i.add("a"); assert i.count("a") == 3 and i.count("x") == 0
    def test_add_nonpositive():
        with pytest.raises(ValueError):
            Inventory().add("a", 0)
    def test_remove_partial_and_all():
        i = Inventory(); i.add("a", 3); i.remove("a", 2); assert i.count("a") == 1
        i.remove("a"); assert i.count("a") == 0 and i.items() == []
    def test_remove_too_many():
        i = Inventory(); i.add("a", 1)
        with pytest.raises(ValueError):
            i.remove("a", 2)
    def test_items_sorted():
        i = Inventory(); i.add("b"); i.add("a"); assert i.items() == ["a", "b"]
''')
@sol("07_class_methods")
def _(d): sub(d, "shapes.py", "    def __repr__(self):", "    def perimeter(self):\n        return 2 * (self.width + self.height)\n\n    def scale(self, factor):\n        return Rectangle(self.width * factor, self.height * factor)\n\n    def __eq__(self, other):\n        return isinstance(other, Rectangle) and (self.width, self.height) == (other.width, other.height)\n\n    def __repr__(self):")
@sol("08_js_counter")
def _(d): sub(d, "app.js", 'getElementById("increment")', 'getElementById("inc")')
@sol("09_deep_merge")
def _(d):
    sub(d, "config_utils.py", "    raise NotImplementedError", "    import copy\n    out = copy.deepcopy(base)\n    for k, v in override.items():\n        if v is None:\n            out.pop(k, None)\n        elif isinstance(v, dict) and isinstance(out.get(k), dict):\n            out[k] = deep_merge(out[k], v)\n        else:\n            out[k] = copy.deepcopy(v)\n    return out")
    w(d, "tests/test_cu.py", 'import os, sys\nsys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))\nfrom config_utils import deep_merge\ndef test_basic():\n    assert deep_merge({"a": {"b": 1}}, {"a": {"c": 2}}) == {"a": {"b": 1, "c": 2}}\n')
@sol("10_todo_priority")
def _(d):
    sub(d, "todo.py", "    done: bool = False", "    done: bool = False\n    priority: int = 3")
    sub(d, "cli.py", '    a.add_argument("title")', '    a.add_argument("title")\n    a.add_argument("--priority", type=int, default=3)')
    sub(d, "cli.py", "todos.append(Todo(args.title))", "todos.append(Todo(args.title, priority=args.priority))")
    sub(d, "cli.py", "        for t in todos:", "        for t in sorted(todos, key=lambda t: (t.priority, t.title)):")
bad = 0
for name in sorted(p.name for p in T.iterdir() if p.name in SOL):
    rc0, m0 = check(name, fresh(name, "orig"))
    d = fresh(name, "sol"); SOL[name](d); rc1, m1 = check(name, d)
    good = rc0 != 0 and rc1 == 0; bad += not good
    print(f"{name:18} shipped:{'FAIL(ok)' if rc0 else 'PASS(!!)':9} solved:{'PASS(ok)' if rc1 == 0 else 'FAIL(!!)':9} | {m1}")
print("すべて有効" if not bad else f"{bad} 件が無効")
shutil.rmtree(S, ignore_errors=True)
missing = sorted(p.name for p in T.iterdir() if p.is_dir() and p.name not in SOL)
if missing:
    print("参照解が無い課題:", ", ".join(missing))
sys.exit(1 if bad or missing else 0)
