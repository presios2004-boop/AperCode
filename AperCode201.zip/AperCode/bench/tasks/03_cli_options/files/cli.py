import argparse
from pathlib import Path


def main(argv=None):
    parser = argparse.ArgumentParser(description="names.txt の名前を表示する")
    parser.add_argument("file", nargs="?", default="names.txt")
    args = parser.parse_args(argv)
    for line in Path(args.file).read_text(encoding="utf-8").splitlines():
        if line.strip():
            print(line.strip())


if __name__ == "__main__":
    main()
