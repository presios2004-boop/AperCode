"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


def out(*a):
    r = run("cli.py", *a)
    ok(r.returncode == 0, f"cli.py {' '.join(a)} が失敗: {r.stderr[-300:]}")
    return r.stdout.split()
ok(out() == ["alice", "bob", "carol", "dave"], "オプションなし")
ok(out("--limit", "2") == ["alice", "bob"], "--limit 2")
ok(out("--upper") == ["ALICE", "BOB", "CAROL", "DAVE"], "--upper")
ok(out("--limit", "3", "--upper") == ["ALICE", "BOB", "CAROL"], "--limit 3 --upper")
ok(out("--upper", "--limit", "1") == ["ALICE"], "順序を変えても使える")
print("OK")
