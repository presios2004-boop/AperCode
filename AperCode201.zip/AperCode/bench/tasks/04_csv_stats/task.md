sales.csv を読み、地域（region）ごとの amount の合計を out.json に書き出す stats.py を作ってください。out.json は {"地域名": 合計, ...} の形で、合計は小数第 2 位に丸めた数値、さらに "_total" に全体の合計を入れてください。python stats.py で実行できるように。
