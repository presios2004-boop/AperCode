"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


(W / "out.json").unlink(missing_ok=True)
r = run("stats.py")
ok(r.returncode == 0, "stats.py が失敗: " + r.stderr[-300:])
ok((W / "out.json").exists(), "out.json が無い")
d = json.loads((W / "out.json").read_text(encoding="utf-8"))
exp = {"east": 140.76, "west": 80.1, "north": 300.0, "_total": 520.86}
for k, v in exp.items():
    ok(k in d and abs(float(d[k]) - v) < 0.011, f"{k}: {d.get(k)} 期待 {v}")
ok(set(d) == set(exp), f"余分なキー: {set(d) - set(exp)}")
print("OK")
