import argparse

import store
from todo import Todo


def main(argv=None):
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add")
    a.add_argument("title")
    sub.add_parser("list")
    args = p.parse_args(argv)
    todos = store.load()
    if args.cmd == "add":
        todos.append(Todo(args.title))
        store.save(todos)
    else:
        for t in todos:
            print(("[x] " if t.done else "[ ] ") + t.title)


if __name__ == "__main__":
    main()
