import json
from pathlib import Path

from todo import Todo

PATH = Path(__file__).with_name("todos.json")


def load(path=PATH):
    if not Path(path).exists():
        return []
    return [Todo(**d) for d in json.loads(Path(path).read_text(encoding="utf-8"))]


def save(todos, path=PATH):
    Path(path).write_text(json.dumps([t.__dict__ for t in todos], ensure_ascii=False, indent=1), encoding="utf-8")
