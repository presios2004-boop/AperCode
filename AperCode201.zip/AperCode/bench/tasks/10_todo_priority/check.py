"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


old = (W / "todos.json").read_text(encoding="utf-8")
try:
    r = run("cli.py", "list")
    ok(r.returncode == 0, "古い todos.json の list が失敗: " + r.stderr[-300:])
    ok([l.strip() for l in r.stdout.splitlines() if l.strip()][:2] == ["[x] buy milk", "[ ] write report"], "既定 3 同士はタイトル順: " + r.stdout)
    for args in (["add", "urgent", "--priority", "1"], ["add", "later", "--priority", "5"], ["add", "normal"]):
        r = run("cli.py", *args)
        ok(r.returncode == 0, f"cli.py {' '.join(args)} が失敗: " + r.stderr[-300:])
    lines = [l.strip() for l in run("cli.py", "list").stdout.splitlines() if l.strip()]
    titles = [l.split("] ", 1)[-1].split()[0] for l in lines]
    ok(titles == ["urgent", "buy", "normal", "write", "later"], f"並び順: {lines}")
    data = json.loads((W / "todos.json").read_text(encoding="utf-8"))
    pr = {d["title"]: d.get("priority") for d in data}
    ok(pr.get("urgent") == 1 and pr.get("later") == 5 and pr.get("normal") == 3, f"保存された priority: {pr}")
finally:
    (W / "todos.json").write_text(old, encoding="utf-8")
print("OK")
