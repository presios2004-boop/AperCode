def slugify(text):
    """文字列を URL 用のスラッグに変換する。

    仕様:
    - 英字は小文字にする
    - 空白とアンダースコアはハイフンにする
    - 英小文字・数字・ハイフン以外の文字は取り除く
    - 連続するハイフンは 1 つにまとめる
    - 先頭と末尾のハイフンは取り除く

    例:
        slugify("Hello World") == "hello-world"
        slugify("  Rock & Roll__2024 ") == "rock-roll-2024"
        slugify("--Already--Slugged--") == "already-slugged"
    """
    raise NotImplementedError
