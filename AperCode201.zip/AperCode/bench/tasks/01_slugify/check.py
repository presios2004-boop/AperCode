"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


m = load("text_utils")
cases = {"Hello World": "hello-world", "  Rock & Roll__2024 ": "rock-roll-2024", "--Already--Slugged--": "already-slugged",
         "Café Déjà Vu": "caf-dj-vu", "a___b   c": "a-b-c", "!!!": "", "Python3 Is Fun": "python3-is-fun"}
for k, v in cases.items():
    got = m.slugify(k)
    ok(got == v, f"slugify({k!r}) = {got!r}, 期待 {v!r}")
print("OK")
