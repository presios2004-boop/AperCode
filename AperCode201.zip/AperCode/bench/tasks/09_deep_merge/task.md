config_utils.py の deep_merge を docstring の仕様どおりに実装し、tests/ にテストも書いてください。
