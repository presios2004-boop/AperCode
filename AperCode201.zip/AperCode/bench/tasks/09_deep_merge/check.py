"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


import copy
m = load("config_utils")
b = {"a": 1, "n": {"x": 1, "y": {"p": 1}}, "l": [1, 2], "gone": 5}
o = {"n": {"y": {"q": 2}, "z": 3}, "l": [9], "gone": None, "new": {"k": 1}}
b0, o0 = copy.deepcopy(b), copy.deepcopy(o)
r = m.deep_merge(b, o)
ok(r == {"a": 1, "n": {"x": 1, "y": {"p": 1, "q": 2}, "z": 3}, "l": [9], "new": {"k": 1}}, f"結果: {r}")
ok(b == b0 and o == o0, "入力が変更されている")
r["n"]["x"] = 99
r["new"]["k"] = 99
ok(b["n"]["x"] == 1 and o["new"]["k"] == 1, "結果の dict が入力と共有されている")
ok(m.deep_merge({}, {}) == {}, "空")
ok(list(W.glob("tests/test_*.py")), "tests/ にテストが無い")
t = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"], cwd=W, capture_output=True, text=True, timeout=120)
ok(t.returncode == 0, "テストが通らない: " + t.stdout[-400:])
print("OK")
