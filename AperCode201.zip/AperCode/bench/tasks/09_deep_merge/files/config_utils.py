def deep_merge(base, override):
    """2 つの設定 dict を再帰的にマージした新しい dict を返す。

    - 両方に dict があるキーは再帰的にマージする
    - それ以外は override の値が優先（リストは連結せず置き換える）
    - override の値が None のキーは、結果から取り除く
    - base / override 自体は変更しない（結果の中の dict も元と共有しない）
    """
    raise NotImplementedError
