class Rectangle:
    def __init__(self, width, height):
        if width < 0 or height < 0:
            raise ValueError("negative size")
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def __repr__(self):
        return f"Rectangle({self.width}, {self.height})"
