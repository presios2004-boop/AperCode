"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


m = load("shapes")
R = m.Rectangle
r = R(3, 4)
ok(r.area() == 12 and repr(r) == "Rectangle(3, 4)", "既存の動作")
ok(r.perimeter() == 14, "perimeter")
s = r.scale(2)
ok(isinstance(s, R) and (s.width, s.height) == (6, 8) and (r.width, r.height) == (3, 4), "scale（元は変えない）")
ok(R(1, 2) == R(1, 2) and R(1, 2) != R(2, 1) and R(1, 2) != "x", "==")
try:
    R(-1, 1)
    ok(False, "負の大きさで ValueError にならない")
except ValueError:
    pass
print("OK")
