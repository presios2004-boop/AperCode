shapes.py の Rectangle クラスに次を追加してください: perimeter()（周の長さ）、scale(factor)（幅と高さを factor 倍した新しい Rectangle を返す。元は変えない）、== で幅と高さが同じなら等しいと判定できるようにする。既存の area() と repr はそのまま。
