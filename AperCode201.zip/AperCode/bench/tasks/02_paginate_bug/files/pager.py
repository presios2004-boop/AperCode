def paginate(items, page, per_page=10):
    """items を per_page 件ずつに分けたときの page ページ目（1 始まり）を返す。範囲外なら空リスト。"""
    if page < 1 or per_page < 1:
        return []
    start = page * per_page
    return items[start:start + per_page]


def page_count(total, per_page=10):
    """全ページ数。"""
    return total // per_page
