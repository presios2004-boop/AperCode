import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pager import paginate, page_count


def test_first_page():
    assert paginate(list(range(25)), 1) == list(range(10))


def test_last_page():
    assert paginate(list(range(25)), 3) == [20, 21, 22, 23, 24]


def test_page_count():
    assert page_count(25) == 3
    assert page_count(20) == 2
    assert page_count(0) == 0
