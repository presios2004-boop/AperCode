inventory.py の Inventory クラスに対するテストを tests/test_inventory.py に書いてください。追加・取り出し・在庫不足のエラー・個数の確認など、主要な振る舞いを確かめること。inventory.py 自体は変更しないでください。
