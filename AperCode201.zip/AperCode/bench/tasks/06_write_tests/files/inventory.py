class Inventory:
    """商品の在庫。"""

    def __init__(self):
        self._stock = {}

    def add(self, item, qty=1):
        if qty <= 0:
            raise ValueError("qty must be positive")
        self._stock[item] = self._stock.get(item, 0) + qty

    def remove(self, item, qty=1):
        have = self._stock.get(item, 0)
        if qty > have:
            raise ValueError(f"not enough {item}: have {have}, need {qty}")
        if qty == have:
            del self._stock[item]
        else:
            self._stock[item] = have - qty

    def count(self, item):
        return self._stock.get(item, 0)

    def items(self):
        return sorted(self._stock)
