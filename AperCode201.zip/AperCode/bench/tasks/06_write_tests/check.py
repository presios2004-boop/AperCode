"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


import shutil, tempfile, hashlib
SRC = (W / "inventory.py").read_text(encoding="utf-8")
ORIG = """d65f5f59d9f5efb87bb73ac6d6daebf04879a59e"""
ok(hashlib.sha1(SRC.encode()).hexdigest() == ORIG, "inventory.py が変更されています")
ok((W / "tests/test_inventory.py").exists(), "tests/test_inventory.py が無い")
def pytest_in(d):
    return subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests/test_inventory.py"],
                          cwd=d, capture_output=True, text=True, timeout=120)
r = pytest_in(W)
ok(r.returncode == 0, "テストが通らない: " + r.stdout[-500:])
# 変異テスト: 実装を壊したらテストが失敗するか
mutants = [SRC.replace("if qty > have:", "if qty > have + 1:"),
           SRC.replace("if qty <= 0:", "if qty < 0:"),
           SRC.replace("self._stock[item] = have - qty", "self._stock[item] = have"),
           SRC.replace("return sorted(self._stock)", "return list(self._stock)[:1]")]
killed = 0
for mu in mutants:
    d = Path(tempfile.mkdtemp())
    shutil.copytree(W / "tests", d / "tests")
    (d / "inventory.py").write_text(mu, encoding="utf-8")
    for extra in ("conftest.py", "pytest.ini"):
        if (W / extra).exists():
            shutil.copy(W / extra, d / extra)
    if pytest_in(d).returncode != 0:
        killed += 1
    shutil.rmtree(d, ignore_errors=True)
ok(killed >= 3, f"実装を壊してもテストが失敗しない（検出 {killed}/4）")
print(f"OK（変異 {killed}/4 を検出）")
