"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


for f in W.glob("*.py"):
    ok("calc_total" not in f.read_text(encoding="utf-8"), f"{f.name} に calc_total が残っている")
m = load("calc")
ok(m.compute_total([(100, 2), (250, 1)]) == 495.0, "compute_total の値")
r = run("main.py")
o = r.stdout.split()
ok(r.returncode == 0 and len(o) == 4 and o[0] == "合計:" and o[2] == "円" and float(o[1]) == 495.0 and float(o[3]) == 450.0,
   "main.py の出力: " + r.stdout + r.stderr[-300:])
print("OK")
