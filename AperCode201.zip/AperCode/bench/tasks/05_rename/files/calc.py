def calc_total(items, tax=0.1):
    """(価格, 個数) のリストの税込合計。"""
    return round(sum(p * n for p, n in items) * (1 + tax), 2)
