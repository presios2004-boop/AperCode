import calc
from report import report

ITEMS = [(100, 2), (250, 1)]

if __name__ == "__main__":
    print(report(ITEMS))
    print(calc.calc_total(ITEMS, tax=0))
