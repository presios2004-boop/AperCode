from calc import calc_total


def report(items):
    return f"合計: {calc_total(items)} 円"
