"""隠し受け入れテスト。使い方: python check.py <作業フォルダ>。終了コード 0 = 合格。"""
import importlib.util, json, subprocess, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W))


def load(name):
    spec = importlib.util.spec_from_file_location(name, W / f"{name}.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(*args, **kw):
    return subprocess.run([sys.executable, *args], cwd=W, capture_output=True, text=True, timeout=60, **kw)


def ok(cond, msg):
    if not cond:
        print("NG:", msg)
        sys.exit(1)


import re, shutil
html = (W / "index.html").read_text(encoding="utf-8")
ids = set(re.findall(r'id="([^"]+)"', html))
js = (W / "app.js").read_text(encoding="utf-8")
used = set(re.findall(r'getElementById\(\s*["\']([^"\']+)["\']', js))
ok(used <= ids, f"HTML に無い id を参照: {used - ids}")
node = shutil.which("node")
if node:
    harness = """
const fs = require('fs'); const els = {}; const ids = %s;
for (const id of ids) els[id] = {textContent: '0', handlers: {}, addEventListener(t, f) { this.handlers[t] = f; }};
global.document = {getElementById: (id) => els[id] || null, querySelector: () => null};
eval(fs.readFileSync(%s, 'utf8'));
const hit = Object.entries(els).find(([k, e]) => k !== 'reset' && e.handlers.click); if (!hit) { console.log('+1 button has no click handler'); process.exit(1); } const inc = hit[1];
inc.handlers.click(); inc.handlers.click();
if (els['count'].textContent !== '2') { console.log('count=' + els['count'].textContent); process.exit(1); }
els['reset'].handlers.click();
if (els['count'].textContent !== '0') { console.log('reset NG'); process.exit(1); }
""" % (json.dumps(sorted(ids)), json.dumps(str(W / "app.js")))
    r = subprocess.run([node, "-e", harness], capture_output=True, text=True, timeout=30)
    ok(r.returncode == 0, "ボタンを押してもカウントが正しく変わらない: " + (r.stdout + r.stderr)[-300:])
print("OK")
