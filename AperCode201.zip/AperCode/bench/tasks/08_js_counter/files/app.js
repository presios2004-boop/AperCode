let count = 0;
const view = document.getElementById("count");
function render() {
  view.textContent = String(count);
}
document.getElementById("increment").addEventListener("click", () => {
  count += 1;
  render();
});
document.getElementById("reset").addEventListener("click", () => {
  count = 0;
  render();
});
render();
