"""GUI 操作ツールの実機テスト（v1.11.0）。X11 の画面（DISPLAY）と wmctrl・xclip・ImageMagick があるときだけ動く。

入力欄と Enter で送信する簡単な Tk のチャット窓を開き、起動 → 撮影 → クリック → 日本語の貼り付け → 送信 → 撮影 を行い、
アプリが実際に受け取った文章を確かめる。
"""
from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import time
from pathlib import Path

import pytest

from conftest import tc

APP = '''
import sys, tkinter as tk
root = tk.Tk(); root.title(sys.argv[1]); root.geometry("600x400+140+90")
log = tk.Text(root, height=15); log.pack(fill="both", expand=True)
e = tk.Entry(root, font=("DejaVu Sans", 14)); e.pack(fill="x", side="bottom")
def send(ev=None):
    t = e.get(); e.delete(0, "end"); log.insert("end", "YOU: " + t + "\\n")
    open(sys.argv[2], "a", encoding="utf-8").write(t + "\\n")
e.bind("<Return>", send)
root.mainloop()
'''


def _tk_python():
    for p in ("/usr/bin/python3", "/usr/bin/python3.12", "/usr/bin/python3.11", "/usr/bin/python3.13", shutil.which("python3")):
        if p and Path(p).exists() and subprocess.run([p, "-c", "import tkinter"], capture_output=True).returncode == 0:
            return p
    return None


needs_x = pytest.mark.skipif(not os.environ.get("DISPLAY") or not all(shutil.which(t) for t in ("wmctrl", "xprop", "xwininfo", "xclip", "import"))
                             or _tk_python() is None, reason="X11 の画面と wmctrl / xclip / ImageMagick / tkinter が必要")


@pytest.fixture
def chat_app(tmp_path):
    title = f"TestChat{int(time.time() * 1000) % 100000}"
    app = tmp_path / "app.py"
    app.write_text(APP)
    sent = tmp_path / "sent.txt"
    sent.write_text("")
    cmd = f"{_tk_python()} {app} {title} {sent}"
    yield title, cmd, sent
    subprocess.run(["pkill", "-f", str(app)], capture_output=True)


@needs_x
def test_gui_backend_launch_shot_click_paste(chat_app, tmp_path):
    from codeagent import gui as G
    title, cmd, sent = chat_app

    async def go():
        w, started = await G.launch(cmd, title, 20)
        assert started and w.w >= 590
        w2, started2 = await G.launch(cmd, title, 20)
        assert not started2 and w2.id == w.id                           # 開いていれば起動しない
        fname, desc = await G.screenshot(tmp_path, "s", window=title, max_width=300)   # 縮小した画像の座標でも押せる
        subprocess.run(["wmctrl", "-i", "-r", w.id, "-e", "0,500,300,-1,-1"])         # 撮影後に移動しても押せる
        await asyncio.sleep(0.8)
        done = await G.gui_input("s", title, click=[150, 194], text="こんにちは。AperCode です。", keys=["Return"])
        await asyncio.sleep(0.8)
        return done
    done = asyncio.run(go())
    assert sent.read_text(encoding="utf-8") == "こんにちは。AperCode です。\n", done


@needs_x
def test_agent_gui_flow_with_evidence(h, chat_app):
    """エージェントとして: 起動 → 撮影 → 送信 → 撮影して確認 → 証拠付きで完了。スクリーンショットは画像として LLM に渡る。"""
    title, cmd, sent = chat_app
    proj = h.project(with_test=False)
    script = [("tools", [tc("set_plan", steps=["アプリを起動して挨拶を送る"], kind="operate")]),
              ("tools", [tc("gui_launch", command=cmd, title=title)]),
              ("tools", [tc("screenshot", window=title)]),
              ("tools", [tc("gui_input", window=title, click=[300, 388], text="こんにちは。よろしくお願いします。", keys=["Return"])]),
              ("tools", [tc("step_done", summary="送信した")]),                                  # 観察していない → 確認を求められる
              ("tools", [tc("screenshot", window=title)]),
              ("tools", [tc("step_done", summary="送信した", evidence="撮り直した画像で、ログ欄に YOU: こんにちは… が表示され入力欄が空になった")]),
              ("text", "送信できました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, "チャットアプリを起動して挨拶を送ってください")
    assert sent.read_text(encoding="utf-8") == "こんにちは。よろしくお願いします。\n"
    msgs = store.load(s.id).messages
    shots = [m for m in msgs if m.get("kind") == "screenshot"]
    assert len(shots) == 2 and "画面のスクリーンショット" in shots[0]["content"]
    assert [e["ok"] for e in h.of("verify") if e.get("kind") == "evidence"] == [None, True]
    assert store.load(s.id).phase["active"] is False
