"""ハーネスの部品ごとの回帰テスト（チェックポイント・フェーズ・構造チェック・カバレッジ・検証）。"""
from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from codeagent import phases as PH
from codeagent import pycheck
from codeagent.checkpoint import CheckpointStore
from codeagent import coverage_check as CC
from codeagent import verify as V


# ------------------------------------------------------------------ チェックポイント
def test_checkpoint_restore_writes_deletes_and_backs_up(tmp_path):
    (tmp_path / "a.txt").write_text("v1")
    cps = CheckpointStore(tmp_path, "s1")
    cps.track(tmp_path / "a.txt")
    first = cps.save("開始", 1.0, {})
    (tmp_path / "a.txt").write_text("v2")
    cps.track(tmp_path / "new.txt")
    (tmp_path / "new.txt").write_text("created later")
    cps.save("手順 1", 2.0, {})

    class _Backup:
        saved = []

        def save(self, p):
            self.saved.append(p.name)
    b = _Backup()
    res = cps.restore(first["id"], b)
    assert (tmp_path / "a.txt").read_text() == "v1" and not (tmp_path / "new.txt").exists()
    assert res == {"written": ["a.txt"], "deleted": ["new.txt"]} and sorted(b.saved) == ["a.txt", "new.txt"]
    assert [i["id"] for i in cps.list()] == [first["id"]]          # 後のチェックポイントは無効になる
    assert (tmp_path / ".apercode" / ".gitignore").exists()


def test_checkpoint_ignores_outside_and_internal_paths(tmp_path):
    cps = CheckpointStore(tmp_path, "s1")
    cps.track(tmp_path / ".apercode" / "x")
    cps.track(tmp_path.parent / "outside.txt")
    assert cps.tracked() == []


def test_checkpoint_keep_limit_and_gc(tmp_path):
    (tmp_path / "a.txt").write_text("0")
    cps = CheckpointStore(tmp_path, "s1", keep=3)
    cps.track(tmp_path / "a.txt")
    for i in range(6):
        (tmp_path / "a.txt").write_text(str(i))
        cps.save(f"c{i}", float(i), {})
    assert len(cps.list()) == 3
    blobs = list((cps.root / "blobs").iterdir())
    assert len(blobs) == 4                                           # baseline + 残った 3 世代


# ------------------------------------------------------------------ フェーズ
def test_parse_steps_and_asks_user():
    assert PH.parse_steps("計画:\n1. ファイルを読む\n2. **関数を書く**\n3) テストを試す") == ["ファイルを読む", "関数を書く", "テストを試す"]
    assert PH.parse_steps("1. ひとつだけ") == []
    assert PH.asks_user("このパスでよろしいですか")
    assert PH.asks_user("Could you copy the folder into the workspace.")
    assert PH.asks_user("コピーしていただけますか。\n```bash\ncp a b\n```\n")
    assert not PH.asks_user("このプロジェクトは足し算のテストです。")


def test_replan_keeps_done_steps():
    ps = PH.PhaseState(active=True)
    ps.set_steps(["a", "b", "c"])
    ps.steps[0]["status"] = "done"
    ps.idx = 1
    ps.replan = True
    ps.set_steps(["x", "y"])
    assert [s["text"] for s in ps.steps] == ["a", "x", "y"] and ps.idx == 1 and not ps.replan


def test_phase_state_roundtrip_drops_signal():
    ps = PH.PhaseState(active=True, phase="fix", cov_asked=True)
    ps.signal = ("step_done", "x")
    d = ps.to_dict()
    assert "signal" not in d and PH.PhaseState.from_dict(d).cov_asked is True
    assert PH.PhaseState.from_dict({"phase": "bogus"}).phase == "plan"


# ------------------------------------------------------------------ 構造チェック
BUGGY = '''
class Agent:
    def __init__(self):
        self.x = 1

    def run(self, st):
        return self._phase_gate(st)

    def two(self, a, b=1, *, k):
        return a

    def call(self):
        self.two(1, 2, 3, k=1)
        self.two(1, zz=2, k=1)
        self.two(1)


def f(a):
    return a


f(1, 2)
'''


def test_pycheck_finds_missing_attribute_and_bad_calls():
    msgs = [p.message for p in pycheck.analyze(BUGGY)]
    assert any("self._phase_gate" in m for m in msgs)
    assert any("最大 2 個" in m for m in msgs)
    assert any("zz" in m for m in msgs)
    assert any("必須引数 k" in m for m in msgs)
    assert any("f()" in m for m in msgs)


def test_pycheck_reports_only_new_problems():
    before = "class A:\n    def f(self):\n        return self.old_missing\n"
    after = before + "\n    def g(self):\n        return self.new_missing\n"
    assert [p.key for p in pycheck.new_problems(after, before)] == ["attr:A.new_missing"]


@pytest.mark.parametrize("src", [
    "class B(Base):\n    def f(self):\n        return self.inherited\n",                     # 継承
    "class M:\n    def f(self):\n        return self.a + self.b + self.c\n",                  # ミックスイン
    "class C:\n    def __getattr__(self, n):\n        return 1\n    def f(self):\n        return self.any\n",
    "class D:\n    def f(self):\n        return self.late\nD.late = 1\n",                      # クラスの外で追加
    "class E:\n    from os import path\n    def f(self):\n        return self.path\n",         # クラス本体の import
    "class P:\n    def f(self):\n        return self.value_parser\nclass Q(P):\n    value_parser = 1\n",   # サブクラスが定義
    "class S:\n    x: int\n    def f(self):\n        return self.x\n",                          # dataclass 風の注釈
])
def test_pycheck_no_false_positive(src):
    assert pycheck.analyze(src) == []


def test_pycheck_clean_on_apercode_itself():
    root = Path(__file__).resolve().parents[1] / "codeagent"
    bad = {str(f): [p.message for p in pycheck.analyze(f.read_text("utf-8"))] for f in root.rglob("*.py")}
    assert {k: v for k, v in bad.items() if v} == {}


def test_added_lines():
    assert pycheck.added_lines("a\nb\nc\n", "a\nB\nc\nd\n") == {2, 4}
    assert pycheck.added_lines(None, "x\ny\n") == {1, 2}


# ------------------------------------------------------------------ 変更行のカバレッジ
def test_coverage_analyze_reports_uncovered_changed_lines(tmp_path):
    after = "def add(a, b):\n    return a + b\n\n\ndef mul(a, b):\n    return a * b\n\n\nif __name__ == '__main__':\n    print(1)\n"
    cov = {"files": {str(tmp_path / "calc.py"): {"executed_lines": [1, 2, 5, 9], "missing_lines": [6, 10]}}}
    rep = CC.analyze(cov, tmp_path, {"calc.py": {"before": "def add(a, b):\n    return a + b\n", "after": after},
                                     "tests/test_x.py": {"before": None, "after": "x = 1\n"},
                                     "other.py": {"before": None, "after": "def z():\n    return 1\n"}},
                     lambda r: V.is_test_file(r))
    assert rep.uncovered == {"calc.py": [6]}                       # __main__ ブロックの 10 行目は対象外
    assert rep.never_imported == ["other.py"]
    assert "calc.py: 6" in rep.summary() and CC.ranges([1, 2, 3, 7]) == "1-3, 7"


def test_run_tests_cov_end_to_end(tmp_path):
    pytest.importorskip("coverage")
    (tmp_path / "tests").mkdir()
    (tmp_path / "conftest.py").write_text("import sys, os\nsys.path.insert(0, os.path.dirname(__file__))\n")
    (tmp_path / "tests" / "test_calc.py").write_text("from calc import add\n\n\ndef test_add():\n    assert add(1, 2) == 3\n")
    after = "def add(a, b):\n    return a + b\n\n\ndef mul(a, b):\n    r = a * b\n    return r\n"
    (tmp_path / "calc.py").write_text(after)
    res, rep = asyncio.run(V.run_tests_cov(tmp_path, {"calc.py": {"before": None, "after": after}}))
    assert res.ok and res.passed == 1 and "coverage" not in res.command
    assert rep is not None and rep.uncovered == {"calc.py": [6, 7]}


# ------------------------------------------------------------------ 自動検証（構造・型）
def test_check_file_structure_reports_new_problem_only(tmp_path):
    before = "class A:\n    def f(self):\n        return self.old\n"
    after = before + "\n    def g(self):\n        return self.nope\n"
    (tmp_path / "m.py").write_text(after)
    r = asyncio.run(V.check_file(tmp_path / "m.py", tmp_path, lint=False, types=False, before=before))
    assert not r.ok and "structure" in r.tools and "self.nope" in r.output and "self.old" not in r.output


def test_check_file_types_on_changed_lines_only(tmp_path):
    import shutil
    if not (shutil.which("pyright") or shutil.which("mypy")):
        pytest.skip("pyright / mypy が無い")
    before = "import os\n\n\ndef f(x):\n    return os.path.joinn(x)\n"
    after = before + "\n\ndef h(s: str):\n    return s.uper()\n"
    (tmp_path / "m.py").write_text(after)
    r = asyncio.run(V.check_file(tmp_path / "m.py", tmp_path, lint=False, types=True, before=before))
    assert not r.ok and "uper" in r.output and "joinn" not in r.output


def test_done_check_asks_for_unanswered_requests():
    """v1.11.2: 完了確認で、最後に観察した画面・出力に未対応の依頼や質問が残っていないかも確認させる。"""
    ps = PH.PhaseState(active=True)
    ps.set_steps(["メッセージを送信する"])
    ps.phase, ps.idx = "done_check", 1
    text = PH.block(ps, max_fix=3, cloud=False, brief=True)
    msg = PH.msg_done_check(ps, brief=True)
    for t in (text, msg):
        assert "応えていない依頼や質問" in t
