"""作業フェーズとチェックポイントの流れ（FakeLLM によるエージェントループ全体の回帰テスト）。"""
from __future__ import annotations

from conftest import BAD, GOOD, TASK, tc
from codeagent.checkpoint import CheckpointStore


def test_happy_path_plan_implement_verify_done(h):
    proj = h.project()
    script = [
        ("tools", [tc("set_plan", steps=["calc.py に add を実装する", "README を書く"])]),
        ("tools", [tc("write_file", path="calc.py", content=GOOD)]),
        ("tools", [tc("step_done", summary="add 実装")]),
        ("tools", [tc("write_file", path="README.md", content="# calc\n")]),
        ("text", "README を書きました。"),                       # 本文だけの応答も手順の区切り
        ("tools", [tc("finish_brief", summary="完了")]),
        ("text", "完了しました。"),
    ]
    agent, llm, store, s = h.make(script, proj)
    h.run(agent, s, TASK)
    ph = store.load(s.id).phase
    assert (proj / "calc.py").read_text() == GOOD
    assert ph["active"] is False and all(x["status"] == "done" for x in ph["steps"])
    # フェーズごとのツール制限
    assert "set_plan" in llm.toolsets[0] and "write_file" not in llm.toolsets[0]
    assert "step_done" in llm.toolsets[1] and "finish_brief" not in llm.toolsets[1]   # 実装中も set_plan で出し直せる（v1.11.0）
    assert "finish_brief" in llm.toolsets[5] and "write_file" not in llm.toolsets[5]
    assert "現在のフェーズ: 計画" in llm.systems[0]
    assert "現在のフェーズ: 実装（手順 1/2）" in llm.systems[1]
    assert "現在のフェーズ: 完了確認" in llm.systems[5]
    assert [c["label"].split(":")[0] for c in h.of("checkpoint")] == ["開始時点", "手順 1/2 完了", "手順 2/2 完了"]
    assert not (proj / ".apercode" / "briefs" / f"{s.id}.md").exists()


def test_fix_limit_rolls_back_then_investigate_then_retry(h):
    proj = h.project()
    (proj / "calc.py").write_text("# old\n")
    script = [
        ("tools", [tc("set_plan", steps=["calc.py に add を実装する"])]),
        ("tools", [tc("write_file", path="calc.py", content=BAD), tc("write_file", path="helper.py", content="x = 1\n")]),
        ("tools", [tc("step_done", summary="1")]),
        ("tools", [tc("step_done", summary="2")]),                # 変更せずに step_done しても失敗は残る
        ("tools", [tc("step_done", summary="3")]),
        ("tools", [tc("step_done", summary="4")]),                # 上限超え → 巻き戻し → 調査
        ("tools", [tc("write_file", path="calc.py", content=GOOD)]),   # 調査中の書き込みは拒否される
        ("text", "足し算なのに引き算になっていた。return a + b にする。"),
        ("tools", [tc("write_file", path="calc.py", content=GOOD)]),
        ("tools", [tc("step_done", summary="ok")]),
        ("text", "完了しました。"),
    ]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, TASK)
    rb = h.of("rollback")
    assert len(rb) == 1
    assert rb[0]["written"] == ["calc.py"] and rb[0]["deleted"] == ["helper.py"] and rb[0]["dropped"] > 0
    assert not (proj / "helper.py").exists() and (proj / "calc.py").read_text() == GOOD
    denied = [e for e in h.of("tool_result") if e["name"] == "write_file" and e["error"]]
    assert denied and "調査" in denied[0]["output"]
    assert "現在のフェーズ: 調査" in llm.systems[6]
    assert "新しい方針（これで行う）" in llm.systems[8]
    s2 = store.load(s.id)
    assert s2.phase["active"] is False and any(a.get("rolled_back") for a in s2.archive)
    assert not any(t["args"].get("content") == BAD for m in s2.messages for t in (m.get("tool_calls") or []))


def test_restore_checkpoint_from_ui(h):
    proj = h.project()
    (proj / "calc.py").write_text("# old\n")
    script = [("tools", [tc("set_plan", steps=["add"])]), ("tools", [tc("write_file", path="calc.py", content=GOOD)]),
              ("tools", [tc("step_done", summary="ok")]), ("text", "完了")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, TASK)
    first = CheckpointStore(proj, s.id).list()[0]
    n_before = len(store.load(s.id).messages)
    res = agent.restore_checkpoint(store.load(s.id), first["id"])
    s2 = store.load(s.id)
    assert (proj / "calc.py").read_text() == "# old\n"
    assert res["dropped"] > 0 and len(s2.messages) < n_before and s2.messages[-1]["kind"] == "nudge"
    assert s2.phase["phase"] == "plan" and s2.phase["active"]


def test_question_answer_ends_phase_and_short_input_skips_phase(h):
    proj = h.project()
    agent, llm, store, s = h.make([("text", "このプロジェクトは足し算のテストです。")], proj, {"brief.enabled": False})
    h.run(agent, s, "このプロジェクトの構成を説明してください")
    assert store.load(s.id).phase["active"] is False
    agent, llm, store, s = h.make([("text", "はい")], proj, {"brief.enabled": False})
    h.run(agent, s, "こんにちは")
    assert not store.load(s.id).phase.get("active")
    assert "set_plan" not in llm.toolsets[0] and "step_done" not in llm.toolsets[0]


def test_phases_disabled(h):
    proj = h.project()
    agent, llm, store, s = h.make([("text", "ok")], proj, {"phases.enabled": False, "brief.enabled": False})
    h.run(agent, s, TASK)
    assert "現在のフェーズ" not in llm.systems[0] and "write_file" in llm.toolsets[0]


def test_report_then_continue_resumes_same_step(h):
    proj = h.project()
    script = [("tools", [tc("set_plan", steps=["add を実装"])]), ("tools", [tc("write_file", path="calc.py", content=BAD)]),
              ("tools", [tc("step_done", summary="x")]), ("tools", [tc("step_done", summary="x")]),
              ("text", "報告: 通りませんでした。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False, "phases.max_fix_rounds": 1, "phases.max_investigations": 0})
    h.run(agent, s, TASK)
    ph = store.load(s.id).phase
    assert ph["active"] and ph["phase"] == "report" and llm.toolsets[-1] == []
    agent2, llm2, _, _ = h.make([("tools", [tc("write_file", path="calc.py", content=GOOD)]),
                                 ("tools", [tc("step_done", summary="ok")]), ("text", "完了")], proj,
                                {"brief.enabled": False}, store=store)
    h.run(agent2, store.load(s.id), "続けて")
    ph = store.load(s.id).phase
    assert ph["active"] is False and ph["steps"][0]["status"] == "done"
    assert "現在のフェーズ: 実装（手順 1/1）" in llm2.systems[0]


def test_question_during_plan_keeps_phase_and_short_reply_resumes(h):
    """v1.9.1: 計画中にユーザーへ質問して止まってもフェーズは終わらない。短い返事でも計画を続ける。"""
    proj = h.project()
    q = "本家のフォルダが読めません。\nお手数ですが、ワークスペース内へコピーしていただけますか。\n\n```bash\ncp -r a b\n```\n\nコピーの完了を教えてください。"
    agent, llm, store, s = h.make([("text", q)], proj, {"brief.enabled": False})
    h.run(agent, s, TASK)
    ph = store.load(s.id).phase
    assert ph["active"] and ph["phase"] == "plan"
    agent2, llm2, _, _ = h.make([("tools", [tc("set_plan", steps=["add を実装"])]), ("tools", [tc("write_file", path="calc.py", content=GOOD)]),
                                 ("tools", [tc("step_done", summary="ok")]), ("text", "完了しました。")], proj,
                                {"brief.enabled": False}, store=store)
    h.run(agent2, store.load(s.id), "コピー完了。つづけて")
    ph = store.load(s.id).phase
    assert ph["active"] is False and ph["steps"][0]["status"] == "done"
    assert "ユーザーに質問して止まってよい" in llm2.systems[0]


def test_question_during_implement_does_not_crash(h):
    """分家への移植で起きた不具合（存在しないメソッド呼び出し）の再発防止。"""
    proj = h.project()
    agent, llm, store, s = h.make([("tools", [tc("set_plan", steps=["add を実装"])]), ("text", "引数の型は int だけでよいですか？")],
                                  proj, {"brief.enabled": False})
    h.run(agent, s, TASK)
    ph = store.load(s.id).phase
    assert ph["active"] and ph["phase"] == "implement"
    assert not [e for e in h.of("error") if "内部エラー" in e.get("text", "")]


def test_child_agent_changes_are_tracked_by_checkpoints(h):
    proj = h.project()
    (proj / "calc.py").write_text("# old\n")
    agent, llm, store, s = h.make([], proj, {"brief.enabled": False})
    from codeagent.agent import LoopState
    from codeagent import tools as T
    ctx = T.ToolContext(agent.cfg, proj, checkpoints=CheckpointStore(proj, s.id))
    parent = LoopState(messages=[], system="", tool_names=None, ctx=ctx)
    captured = {}
    orig = agent._loop

    async def fake_loop(child, *a, **k):
        captured["ctx"] = child.ctx
        return "done"
    agent._loop = fake_loop
    import asyncio
    asyncio.run(agent._spawn(parent, s, {"task": "x", "mode": "code"}, "p1", h.emit, h.approve, asyncio.Event()))
    agent._loop = orig
    assert captured["ctx"].checkpoints is ctx.checkpoints


def test_verify_step_asks_for_tests_when_changed_lines_are_not_executed(h):
    """v1.10.0: テストは通るが、この手順で追加した関数が一度も実行されていない → テストの追加を 1 回求める。"""
    import pytest
    pytest.importorskip("coverage")
    proj = h.project()
    extra = GOOD + "\n\ndef mul(a, b):\n    r = a * b\n    r = int(r)\n    return r\n"
    mul_test = "from calc import mul\n\n\ndef test_mul():\n    assert mul(2, 3) == 6\n"
    script = [("tools", [tc("set_plan", steps=["add と mul を実装"])]),
              ("tools", [tc("write_file", path="calc.py", content=extra)]),
              ("tools", [tc("step_done", summary="1")]),                  # mul のテストが無い → 追加を求められる
              ("tools", [tc("write_file", path="tests/test_mul.py", content=mul_test)]),
              ("tools", [tc("step_done", summary="2")]),
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False, "verify.coverage": "auto"})
    h.run(agent, s, TASK)
    cov = [e for e in h.of("verify") if e.get("kind") == "coverage"]
    assert cov and cov[0]["ok"] is None and "calc.py" in cov[0]["detail"]
    assert "テストで一度も実行されていません" in llm.systems[3]            # 修正フェーズの指示
    assert cov[-1]["ok"] is True
    assert store.load(s.id).phase["active"] is False


def test_few_uncovered_lines_are_reported_but_not_pushed_back(h):
    """v1.10.0: しきい値未満の未実行行は「すべて実行された」と誤表示せず、報告だけしてテスト追加は求めない。"""
    import pytest
    pytest.importorskip("coverage")
    proj = h.project()
    extra = GOOD + "\n\ndef mul(a, b):\n    r = a * b\n    return r\n"          # 未実行 2 行 < 既定の 3 行
    script = [("tools", [tc("set_plan", steps=["add と mul を実装"])]),
              ("tools", [tc("write_file", path="calc.py", content=extra)]),
              ("tools", [tc("step_done", summary="1")]),
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False, "verify.coverage": "auto"})
    h.run(agent, s, TASK)
    cov = [e for e in h.of("verify") if e.get("kind") == "coverage"]
    assert len(cov) == 1 and cov[0]["ok"] is None and "少ないため" in cov[0]["text"]
    assert not any("現在のフェーズ: 修正" in x for x in llm.systems)
    assert store.load(s.id).phase["active"] is False


def _fake_gui_action(monkeypatch):
    """結果が返らない GUI 操作の代わり（gui_input 相当）。外部に作用するツールとして登録する。"""
    from codeagent import tools as T, phases as PH

    async def fake_click(ctx, a):
        return "クリックしました（結果はまだ確認していません）"
    T.register(T.Tool("fake_click", "テスト用の GUI 操作", {"type": "object", "properties": {}}, fake_click))
    monkeypatch.setattr(PH, "EXTERNAL_TOOLS", PH.EXTERNAL_TOOLS | {"fake_click"})


def test_gui_action_requires_observation_after_it(h, monkeypatch):
    """v1.10.1 / v1.11.1: 結果の返らない操作の後に観察していなければ、証拠を書いても完了にしない（送信失敗の思い込み防止）。"""
    _fake_gui_action(monkeypatch)
    proj = h.project(with_test=False)
    script = [("tools", [tc("set_plan", steps=["メッセージを送信する"], kind="operate")]),
              ("tools", [tc("fake_click")]),
              ("tools", [tc("step_done", summary="送信した", evidence="送信したメッセージが画面上部に表示された")]),   # 操作の後に見ていない → 確認を求める
              ("tools", [tc("step_done", summary="送信した", evidence="送信したメッセージが画面上部に表示された")]),   # まだ見ていない → 差し戻し
              ("tools", [tc("process_status")]),                                                                        # 観察
              ("tools", [tc("step_done", summary="送信した", evidence="撮り直した画面で送信したメッセージが上部に表示された")]),
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, "チャットアプリにメッセージを送信してください")
    ev = [e for e in h.of("verify") if e.get("kind") == "evidence"]
    assert [e["ok"] for e in ev] == [None, False, True], [e["text"] for e in ev]
    assert "結果を実際に観察して" in "".join(m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge")
    assert store.load(s.id).phase["active"] is False


def test_observed_before_step_done_passes_without_reshoot(h, monkeypatch):
    """v1.11.1: 操作 → 観察 → 証拠付きの step_done なら、確認の依頼（撮り直し）なしで 1 回で完了する。"""
    _fake_gui_action(monkeypatch)
    proj = h.project(with_test=False)
    script = [("tools", [tc("set_plan", steps=["メッセージを送信する"], kind="operate")]),
              ("tools", [tc("fake_click")]), ("tools", [tc("process_status")]),
              ("tools", [tc("step_done", summary="送信した", evidence="画面上部に送信したメッセージが表示され、入力欄が空になった")]),
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, "チャットアプリにメッセージを送信してください")
    assert [e["ok"] for e in h.of("verify") if e.get("kind") == "evidence"] == [True]
    assert not any("結果を実際に観察して" in m["content"] or "撮り直さず" in m["content"]
                   for m in store.load(s.id).messages if m.get("kind") == "nudge")
    assert len(llm.systems) == 5 and store.load(s.id).phase["active"] is False


def test_observed_but_no_evidence_asks_to_write_it_without_reshoot(h):
    """コマンドの出力は観察になる。証拠が書かれていなければ、撮り直しではなく evidence を書くことだけを求める。"""
    proj = h.project(with_test=False)
    script = [("tools", [tc("set_plan", steps=["メッセージを送信する"])]),
              ("tools", [tc("run_command", command="echo sent")]),
              ("tools", [tc("step_done", summary="送信した")]),
              ("tools", [tc("step_done", summary="送信した", evidence="コマンドの出力に sent と表示された")]),
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, "チャットアプリにメッセージを送信してください")
    assert [e["ok"] for e in h.of("verify") if e.get("kind") == "evidence"] == [None, True]
    assert "撮り直さずに" in "".join(m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge")


def test_text_reply_can_carry_evidence(h):
    """step_done の evidence を使わず、本文で観察結果を書くモデルでも通る。"""
    proj = h.project(with_test=False)
    script = [("tools", [tc("set_plan", steps=["メッセージを送信する"])]),
              ("tools", [tc("run_command", command="echo hi")]),
              ("text", "送信しました。"),                                                    # 確認を求められる
              ("tools", [tc("run_command", command="echo check")]),
              ("text", "出力に check と表示されたので、送信できたことを確認しました。"),
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, "チャットアプリにメッセージを送信してください")
    assert [e["ok"] for e in h.of("verify") if e.get("kind") == "evidence"] == [None, True]
    assert store.load(s.id).phase["active"] is False


def test_file_only_and_tested_code_steps_need_no_evidence(h):
    proj = h.project()
    script = [("tools", [tc("set_plan", steps=["手順書を書く", "add を実装して動かす"])]),
              ("tools", [tc("write_file", path="notes.md", content="# 手順\n")]),
              ("tools", [tc("step_done", summary="手順書")]),                                   # ファイルの読み書きだけ → 証拠不要
              ("tools", [tc("write_file", path="calc.py", content=GOOD), tc("run_command", command="python3 -c 'print(1)'")]),
              ("tools", [tc("step_done", summary="実装")]),                                     # コード変更 + テスト合格 → 証拠不要
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, TASK)
    assert not [e for e in h.of("verify") if e.get("kind") == "evidence"]
    assert store.load(s.id).phase["active"] is False


def test_evidence_can_be_disabled(h):
    proj = h.project(with_test=False)
    script = [("tools", [tc("set_plan", steps=["送信"])]), ("tools", [tc("run_command", command="echo x")]),
              ("tools", [tc("step_done", summary="送信")]), ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False, "phases.require_evidence": False})
    h.run(agent, s, "チャットアプリにメッセージを送信してください")
    assert store.load(s.id).phase["active"] is False


# ------------------------------------------------------------------ v1.11.0
def test_followup_hint_keeps_current_step(h):
    """作業中のヒントでは計画を立て直さない（計画フェーズに戻ると操作系のツールが使えなくなっていた）。"""
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("tools", [tc("set_plan", steps=["送信する", "返事を読む"], kind="operate")]),
                                   ("text", "送り方が分かりません。どうすればよいですか？")], proj, {"brief.enabled": False})
    h.run(agent, s, "チャットアプリにメッセージを送信してください")
    assert store.load(s.id).phase["phase"] == "implement" and store.load(s.id).phase["kind"] == "operate"
    agent2, llm2, _, _ = h.make([("text", "了解しました。")], proj, {"brief.enabled": False}, store=store)
    h.run(agent2, store.load(s.id), "アクティブ化するとカーソルが入力欄に出るので、そこへ貼り付ければよい")
    assert "現在のフェーズ: 実装（手順 1/2）" in llm2.systems[0] and "run_command" in llm2.toolsets[0]
    assert "追加の指示を受けました" in "".join(e.get("text", "") for e in h.of("info"))


def test_restart_keyword_makes_fresh_plan(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("tools", [tc("set_plan", steps=["a を行う", "b を行う"])]), ("text", "a を行いましたか？")],
                                  proj, {"brief.enabled": False})
    h.run(agent, s, "チャットアプリにメッセージを送信してください")
    agent2, llm2, _, _ = h.make([("text", "計画を考えます。")], proj, {"brief.enabled": False}, store=store)
    h.run(agent2, store.load(s.id), "最初から実行して")
    assert "現在のフェーズ: 計画" in llm2.systems[0]
    assert store.load(s.id).phase["steps"] == []


def test_set_plan_during_implement_replaces_remaining_steps(h):
    proj = h.project(with_test=False)
    script = [("tools", [tc("set_plan", steps=["手順書を書く", "古い手順"])]),
              ("tools", [tc("write_file", path="notes.md", content="x\n")]), ("tools", [tc("step_done", summary="1")]),
              ("tools", [tc("set_plan", steps=["新しい手順 A", "新しい手順 B"])]),
              ("tools", [tc("write_file", path="a.md", content="a\n")]), ("tools", [tc("step_done", summary="A")]),
              ("tools", [tc("write_file", path="b.md", content="b\n")]), ("tools", [tc("step_done", summary="B")]),
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, "手順書と関連ファイルを用意してください")
    ph = store.load(s.id).phase
    assert [x["text"] for x in ph["steps"]] == ["手順書を書く", "新しい手順 A", "新しい手順 B"] and ph["active"] is False


def test_operate_step_failure_retries_without_rollback_or_investigation(h):
    proj = h.project(with_test=False)
    (proj / "keep.txt").write_text("keep")
    script = [("tools", [tc("set_plan", steps=["送信する"], kind="operate")])] + \
             [("tools", [tc("run_command", command="echo try")])] * 3 + \
             [("text", "もう一度試します。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False, "stuck.repeat_calls": 3})
    h.run(agent, s, "チャットアプリにメッセージを送信してください")
    assert not h.of("rollback")
    assert not any("現在のフェーズ: 調査" in x for x in llm.systems)
    assert any("別の方法でこの手順をやり直してください" in m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge")
    assert "run_command" in llm.toolsets[-1]


def test_untested_new_script_must_be_run_before_done(h):
    """書いたツールを一度も動かさずに完了にしない（保存したツールが壊れていた問題の再発防止）。"""
    proj = h.project(with_test=False)
    script = [("tools", [tc("set_plan", steps=["起動ツールを作る"])]),
              ("tools", [tc("write_file", path="launcher.py", content="print('launched')\n")]),
              ("tools", [tc("step_done", summary="作った")]),                               # 動かしていない → 確認を求められる
              ("tools", [tc("run_command", command="python3 launcher.py")]),
              ("tools", [tc("step_done", summary="作った", evidence="python3 launcher.py の出力に launched と表示された")]),
              ("text", "完了しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False})
    h.run(agent, s, "アプリの起動ツールを作ってください")
    ev = [e for e in h.of("verify") if e.get("kind") == "evidence"]
    assert [e["ok"] for e in ev] == [None, True] and "テストで実行されていないコード" in ev[0]["text"]


def test_runaway_thinking_is_cut_and_next_call_has_no_thinking(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("think", 30000), ("text", "結論: 何もする必要はありません。")], proj,
                                  {"brief.enabled": False, "llm.think_limit_chars": 20000})
    h.run(agent, s, "こんにちは")
    assert llm.thinks[:2] == [None, "off"]
    assert any("思考が長すぎるため打ち切りました" in e.get("text", "") for e in h.of("info"))


def test_repeated_screenshots_are_not_stuck(h):
    proj = h.project(with_test=False)
    obs = tc("process_status")
    script = [("tools", [tc("set_plan", steps=["返事を待つ"], kind="operate")])] + [("tools", [dict(obs, id=f"o{i}")]) for i in range(4)] + \
             [("text", "返事が来ました。確認しました。")]
    agent, llm, store, s = h.make(script, proj, {"brief.enabled": False, "stuck.repeat_calls": 3})
    h.run(agent, s, "チャットアプリの返事を待ってください")
    assert not any("繰り返" in e.get("text", "") for e in h.of("info"))


def test_focus_is_restored_after_approval(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("tools", [tc("run_command", command="echo hi")]), ("text", "ok")], proj,
                                  {"brief.enabled": False, "phases.enabled": False})
    calls = []

    async def focused():
        return "0x0000abcd"

    async def restore(wid):
        calls.append(wid)
    agent._focused_window = focused
    agent._restore_focus = restore
    asked = []

    async def approve(req):
        asked.append(req["name"])
        return "allow"
    import asyncio
    asyncio.run(agent.run(s, "echo を実行して", h.emit, approve))
    assert asked == ["run_command"] and calls == ["0x0000abcd"]
