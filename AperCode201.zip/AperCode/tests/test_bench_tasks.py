"""ベンチマーク課題の形式と、隠しテストが「最初の状態では不合格」になることの確認（v1.10.0）。
正しい解答で合格するかは bench/validate_tasks.py で確かめる。"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

import pytest

TASKS = sorted(p for p in (Path(__file__).resolve().parents[1] / "bench" / "tasks").iterdir() if p.is_dir())


@pytest.mark.parametrize("task", TASKS, ids=[t.name for t in TASKS])
def test_task_is_well_formed_and_unsolved_at_start(task, tmp_path):
    assert (task / "task.md").read_text(encoding="utf-8").strip()
    assert (task / "files").is_dir() and (task / "check.py").is_file()
    work = tmp_path / "w"
    shutil.copytree(task / "files", work)
    r = subprocess.run([sys.executable, str(task / "check.py"), str(work)], capture_output=True, text=True, timeout=300)
    assert r.returncode != 0, "最初の状態で合格してしまう（課題になっていない）"
