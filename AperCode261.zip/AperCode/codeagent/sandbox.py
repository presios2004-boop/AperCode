"""コマンド実行のサンドボックス（v2.5.0, Linux の bubblewrap）。

LLM が実行するコマンド（run_command・process_start・repl・テスト・自動検証）を bubblewrap（bwrap）の中で動かす。
  - 書き込めるのは作業ディレクトリ（プロジェクト）・/tmp・sandbox.writable（既定 ~/.cache, ~/.npm）だけ。ほかは読み取り専用
  - AperCode 自身（インストール先）は常に読み取り専用。作業ディレクトリがその中にあっても書き込めない
  - AperCode のデータ（~/.apercode: 設定・API キー・セッション・経験メモリ）は中から見えない（空のフォルダに見える）
  - 作業ディレクトリに .venv があれば、その bin を PATH の先頭に入れる（python3 / pip がその環境を使う）
bubblewrap が無い・使えないときは sandbox.mode が auto なら隔離なしで実行し、on なら実行を断る。
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]          # AperCode のインストール先（codeagent/ の親）
_DEFAULTS: dict = {"mode": "auto", "network": True, "writable": ["~/.cache", "~/.npm"]}
_conf = None                                             # Config（設定画面で変えたら次の実行から反映）
_data_dir: Path | None = None
_avail: bool | None = None
_reason = ""


def configure(cfg, data_dir: Path | None = None) -> None:
    """Config から設定を読む（Agent の初期化時に呼ぶ）。"""
    global _data_dir, _conf
    _conf = cfg
    _data_dir = Path(data_dir).resolve() if data_dir else None


def _get(key: str):
    v = _conf.get("sandbox." + key, _DEFAULTS[key]) if _conf is not None else _DEFAULTS[key]
    if key == "mode":
        v = str(v).lower()
        return "off" if v in ("false", "off", "0", "no") else "on" if v in ("true", "on", "required") else "auto"
    if key == "writable":
        return list(v or [])
    return bool(v)


def protected_roots() -> list[Path]:
    """AperCode のツールから書き換えてはいけない場所（AperCode 自身とデータ）。"""
    roots = [APP_ROOT]
    if _data_dir is not None:
        roots.append(_data_dir)
    return roots


def is_protected(p: Path) -> bool:
    try:
        p = Path(p).expanduser().resolve()
    except (OSError, RuntimeError):
        return False
    return any(p == r or r in p.parents for r in protected_roots())


def available() -> bool:
    """bubblewrap が使えるか（初回に実際に起動して確かめ、結果を覚える）。"""
    global _avail, _reason
    if _avail is not None:
        return _avail
    exe = shutil.which("bwrap")
    if not exe or not sys.platform.startswith("linux"):
        _avail, _reason = False, "bubblewrap（bwrap）がありません（sudo apt install bubblewrap）"
        return False
    try:
        r = subprocess.run([exe, "--ro-bind", "/", "/", "--dev", "/dev", "--proc", "/proc", "--", "/bin/true"],
                           capture_output=True, timeout=10)
        _avail = r.returncode == 0
        _reason = "" if _avail else ("bubblewrap を起動できません: " + r.stderr.decode(errors="replace")[:200])
    except Exception as e:  # noqa: BLE001
        _avail, _reason = False, f"bubblewrap を起動できません: {e}"
    return _avail


def enabled() -> bool:
    return _get("mode") != "off" and available()


def status() -> str:
    if _get("mode") == "off":
        return "off"
    return "on" if available() else f"unavailable ({_reason})"


def recheck() -> None:
    """使えなかったときだけ、次に確かめ直す（起動後に bubblewrap を入れた場合）。"""
    global _avail
    if _avail is False:
        _avail = None


def info() -> dict:
    """画面に出す状態。state: on / off / unavailable"""
    mode = _get("mode")
    st = "off" if mode == "off" else ("on" if available() else "unavailable")
    return {"state": st, "mode": mode, "network": _get("network"), "reason": "" if st != "unavailable" else _reason,
            "linux": sys.platform.startswith("linux")}


def workdir_issues(d: Path) -> list[str]:
    """作業ディレクトリの問題: missing（無い）/ no_venv（Python の仮想環境が無い）"""
    d = Path(d).expanduser()
    if not d.is_dir():
        return ["missing"]
    if not any((d / v / "bin" / "python").exists() or (d / v / "Scripts" / "python.exe").exists() for v in (".venv", "venv")):
        return ["no_venv"]
    return []


class SandboxError(RuntimeError):
    pass


def check_required() -> None:
    """mode: on なのに使えなければ実行を断る。"""
    if _get("mode") == "on" and not available():
        raise SandboxError("サンドボックスが必須（sandbox.mode: on）ですが使えません: " + _reason)


def env_for(root: Path | None, base: dict | None = None) -> dict:
    """作業ディレクトリの .venv を PATH の先頭に入れた環境変数。"""
    env = dict(os.environ if base is None else base)
    if root is not None:
        for v in (".venv", "venv"):
            b = Path(root) / v / "bin"
            if (b / "python").exists():
                env["PATH"] = str(b) + os.pathsep + env.get("PATH", "")
                env["VIRTUAL_ENV"] = str(Path(root) / v)
                env.pop("PYTHONHOME", None)
                break
    return env


def wrap(argv: list[str], cwd: Path, root: Path | None) -> list[str]:
    """argv を bubblewrap で包む（使えない・無効なら argv をそのまま返す）。"""
    check_required()
    if not enabled():
        return argv
    cwd = Path(cwd).resolve()
    root = Path(root).resolve() if root is not None else cwd
    a = ["bwrap", "--ro-bind", "/", "/", "--dev", "/dev", "--proc", "/proc", "--bind", "/tmp", "/tmp", "--die-with-parent"]
    for w in _get("writable"):
        p = Path(str(w)).expanduser()
        if p.is_dir():
            a += ["--bind", str(p), str(p)]
    if root.is_dir():
        a += ["--bind", str(root), str(root)]
    # 後から重ねたものが優先される: AperCode 自身は読み取り専用、データは見えなくする
    a += ["--ro-bind", str(APP_ROOT), str(APP_ROOT)]
    if _data_dir is not None and _data_dir.is_dir():
        a += ["--tmpfs", str(_data_dir)]
    if not _get("network"):
        a += ["--unshare-net"]
    a += ["--chdir", str(cwd), "--"]
    return a + list(argv)


def shell(cmd: str, cwd: Path, root: Path | None) -> list[str]:
    """シェルコマンドを（必要なら bubblewrap の中で）bash で実行する argv。"""
    return wrap(["/bin/bash", "-c", cmd], cwd, root)
