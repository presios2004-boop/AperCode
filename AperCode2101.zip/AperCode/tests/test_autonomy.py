"""v2.8.0 の回帰テスト: 自律モード（確認なしで進める範囲・ホームを隠すサンドボックス・スナップショット・監査ログ）。"""
from __future__ import annotations

import asyncio
import shutil
import uuid
from pathlib import Path

import pytest

from conftest import tc
from codeagent import autonomy as AU
from codeagent import sandbox
from codeagent.tools.shell import run_shell

needs_bwrap = pytest.mark.skipif(not sandbox.available(), reason="bubblewrap が使えない環境")
AUTO = {"autonomy.enabled": True, "sandbox.mode": "auto", "phases.enabled": False}


def _recording(h):
    reqs = []

    async def approve(req):
        reqs.append(req)
        return "deny"
    h.approve = approve
    return reqs


@needs_bwrap
def test_autonomy_runs_commands_without_asking_and_logs(h):
    proj = h.project(with_test=False)
    (proj / "build").mkdir()
    reqs = _recording(h)
    script = [("tools", [tc("run_command", command="rm -rf build && echo ok > done.txt")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, AUTO)
    h.run(agent, s, "build を消して")
    assert not reqs                                              # 危険なコマンドでも、サンドボックスの中なら確認しない
    assert not (proj / "build").exists() and (proj / "done.txt").exists()
    log = AU.read_audit(20, s.id)
    e = next(x for x in log if x.get("tool") == "run_command")
    assert e["decision"] == "auto" and e["result"] == "ok" and any("build を削除" in x for x in e["explain"])


@needs_bwrap
def test_tainted_session_continues_but_suspicious_text_waits(h):
    proj = h.project(with_test=False)
    reqs = _recording(h)
    script = [("tools", [tc("run_command", command="echo a > a.txt")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, AUTO)
    s.taint = {"active": True, "sources": ["fetch_url: https://example.com"], "suspicious": [], "since": 1.0}
    h.run(agent, s, "続けて")
    assert not reqs and (proj / "a.txt").exists()                # 外部の内容を読んだだけなら止めない
    script = [("tools", [tc("run_command", command="echo b > b.txt")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, AUTO)
    s.taint = {"active": True, "sources": ["fetch_url: x"], "suspicious": ["ignore previous instructions"], "since": 1.0}
    h.run(agent, s, "続けて")
    assert reqs and not (proj / "b.txt").exists()                 # AI への指示に見える文言の後は人の確認を待つ


def test_autonomy_inactive_without_sandbox(h, monkeypatch):
    proj = h.project(with_test=False)
    reqs = _recording(h)
    script = [("tools", [tc("run_command", command="echo a > a.txt")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, AUTO)
    monkeypatch.setattr(sandbox, "_avail", False)
    h.run(agent, s, "やって")
    assert reqs and not AU.active(agent.cfg)


def test_outside_file_write_still_asks(h):
    proj = h.project(with_test=False)
    reqs = _recording(h)
    outside = h.root / f"outside_{uuid.uuid4().hex[:6]}.txt"
    script = [("tools", [tc("write_file", path=str(outside), content="x")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, AUTO)
    h.run(agent, s, "書いて")
    if sandbox.available():
        assert reqs and not outside.exists()


def test_gui_allowed():
    class C:
        def get(self, k, d=None):
            return {"autonomy.gui_windows": ["AperCode"]}.get(k, d)
    c = C()
    assert AU.gui_allowed(c, "gui_input", {"window": "AperCode - 同僚", "text": "hi", "keys": ["Return"]})
    assert not AU.gui_allowed(c, "gui_input", {"window": "Terminal", "text": "hi", "keys": ["Return"]})
    assert not AU.gui_allowed(c, "gui_input", {"window": "AperCode", "keys": ["ctrl+alt+t"]})
    assert not AU.gui_allowed(c, "gui_launch", {"command": "x"})


@needs_bwrap
def test_hidden_home_in_autonomy(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, AUTO)
    secret_dir = Path.home() / f".apercode_hidetest_{uuid.uuid4().hex[:6]}"
    secret_dir.mkdir()
    (secret_dir / "key").write_text("SECRET")
    try:
        code, out = asyncio.run(run_shell(f"cat {secret_dir}/key; ls {proj}; ps -e | wc -l", str(proj), 30, root=str(proj)))
        assert "SECRET" not in out and "No such file" in out
        assert int(out.strip().splitlines()[-1]) < 10              # ほかのプロセスは見えない
        assert sandbox.info()["hide_home"]
    finally:
        shutil.rmtree(secret_dir, ignore_errors=True)


def test_snapshot_and_restore(h):
    proj = h.project(with_test=False, files={"a.py": "A\n", "sub/b.txt": "B\n", ".venv/bin/x": "venv\n"})
    agent, llm, store, s = h.make([("text", "ok")], proj, AUTO)       # データの置き場所をテスト用にする
    meta = AU.snapshot(proj, "test", s.id)
    assert meta["files"] == 2                                         # .venv は含めない
    (proj / "a.py").write_text("changed\n")
    (proj / "sub" / "b.txt").unlink()
    (proj / "new.txt").write_text("new\n")
    r = AU.restore(proj, meta["id"])
    assert (proj / "a.py").read_text() == "A\n" and (proj / "sub" / "b.txt").read_text() == "B\n"
    assert not (proj / "new.txt").exists() and (proj / ".venv" / "bin" / "x").exists()
    assert r["saved_before"] and len(AU.list_snapshots(proj)) == 2
    assert Path(store.root) in AU._snap_dir(proj).parents            # サンドボックスから見えない場所に保存


@needs_bwrap
def test_work_turn_takes_snapshot_and_mode_switch_is_automatic(h):
    proj = h.project(with_test=False, files={"x.py": "x = 1\n"})
    reqs = _recording(h)
    script = [("tools", [tc("write_file", path="y.py", content="y = 2\n")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, AUTO, mode="auto")
    h.run(agent, s, "y.py を作って")
    assert not any(r.get("kind") == "mode_switch" for r in reqs)     # 作業への切り替えも確認しない
    assert AU.list_snapshots(proj)


def test_snapshot_ids_never_collide(h, monkeypatch):
    """v2.10.1: 速いマシンで、保存と「復元前の保存」が同じミリ秒になると、元の版が上書きされて復元に失敗していた。"""
    proj = h.project(with_test=False, files={"a.py": "A\n"})
    agent, llm, store, s = h.make([("text", "ok")], proj, AUTO)
    monkeypatch.setattr(AU.time, "time", lambda: 1759600000.123)
    meta = AU.snapshot(proj, "test", s.id)
    (proj / "a.py").write_text("changed\n")
    r = AU.restore(proj, meta["id"])
    assert (proj / "a.py").read_text() == "A\n" and r["saved_before"] != meta["id"]
