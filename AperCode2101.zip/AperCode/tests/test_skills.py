"""v2.10.0 の回帰テスト: スキル（save_skill / list_skills / use_skill / run_skill）。"""
from __future__ import annotations

import pytest

from conftest import tc
from codeagent import skills as SK
from codeagent import sandbox

needs_bwrap = pytest.mark.skipif(not sandbox.available(), reason="bubblewrap が使えない環境")
SCRIPT = "import os, sys\nprint('hello', sys.argv[1:], os.path.basename(os.environ['SKILL_DIR']))\nopen('out.txt','w').write('ok')\n"


def call(tool, **args):
    import uuid
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def _make(h, script, extra=None, project=None):
    proj = project or h.project(with_test=False)
    over = {"phases.enabled": False, "skills.dir": str(h.root / "skills"), "permissions.save_skill": "allow",
            "permissions.run_skill": "allow", **(extra or {})}
    agent, llm, store, s = h.make(script, proj, over)
    return proj, agent, llm, store, s


def _save_call(**kw):
    a = {"name": "greet", "description": "あいさつを表示する例のスキル。テスト用", "instructions": "1. greet.py を実行する",
         "files": {"greet.py": SCRIPT, "data/rules.json": "{\"a\": 1}"}}
    a.update(kw)
    return call("save_skill", **a)


def test_save_list_use_and_prompt(h):
    script = [("tools", [_save_call()]), ("tools", [call("use_skill", name="greet")]), ("text", "done")]
    proj, agent, llm, store, s = _make(h, script)
    h.run(agent, s, "スキルを作って使って")
    d = h.root / "skills" / "greet"
    assert (d / "SKILL.md").read_text().startswith("---\nname: greet") and (d / "data" / "rules.json").exists()
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "use_skill"][0]
    assert "1. greet.py を実行する" in out and "data/rules.json" in out
    assert "greet: あいさつを表示する" in llm.systems[-1]                 # 一覧（名前と説明）がプロンプトに入る
    assert "1. greet.py を実行する" not in llm.systems[-1]                # 中身は use_skill まで読まない
    sk = SK.list_skills(agent.cfg)[0]
    assert sk["status"] == "ok" and sk["uses"] == 1 and "greet.py" in sk["scripts"]


def test_tainted_skill_is_unverified_until_confirmed(h):
    script = [("tools", [_save_call()]), ("tools", [call("use_skill", name="greet")]), ("text", "done")]
    proj, agent, llm, store, s = _make(h, script)
    s.taint = {"active": True, "sources": ["fetch_url: x"], "suspicious": [], "since": 1.0}
    h.run(agent, s, "スキルを作って")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "save_skill"][0]
    assert "未確認" in out
    assert any("未確認" in e["output"] for e in h.of("tool_result") if e.get("name") == "use_skill")
    assert "greet:" not in SK.prompt_block(agent.cfg)
    SK.confirm(agent.cfg, "greet")
    assert SK.get(agent.cfg, "greet")["status"] == "ok" and "greet:" in SK.prompt_block(agent.cfg)


def test_validation_and_overwrite_history(h):
    proj, agent, llm, store, s = _make(h, [("text", "x")])
    with pytest.raises(SK.SkillError):
        SK.save(agent.cfg, "Bad Name", "説明が十分に長い説明です", "x")
    with pytest.raises(SK.SkillError):
        SK.save(agent.cfg, "ok-name", "説明が十分に長い説明です", "x", {"../evil.py": "x"})
    with pytest.raises(SK.SkillError):
        SK.save(agent.cfg, "ok-name", "説明が十分に長い説明です", "x", {"a.exe": "x"})
    SK.save(agent.cfg, "ok-name", "説明が十分に長い説明です", "v1")
    with pytest.raises(SK.SkillError, match="overwrite"):
        SK.save(agent.cfg, "ok-name", "説明が十分に長い説明です", "v2")
    r = SK.save(agent.cfg, "ok-name", "説明が十分に長い説明です", "v2", overwrite=True)
    assert r["previous"] and "v1" in open(r["previous"] + "/SKILL.md").read()
    kept = SK.delete(agent.cfg, "ok-name")
    assert not (h.root / "skills" / "ok-name").exists() and "v2" in open(kept + "/SKILL.md").read()


def test_write_file_into_skills_is_denied(h):
    script = [("tools", [tc("write_file", path=str(h.root / "skills" / "x" / "SKILL.md"), content="x")]), ("text", "done")]
    proj, agent, llm, store, s = _make(h, script, {"permissions.write_file": "allow", "permissions.outside_project": "allow"})
    h.run(agent, s, "書いて")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "write_file"][0]
    assert "save_skill" in out and not (h.root / "skills" / "x").exists()


@needs_bwrap
def test_run_skill_in_sandbox(h):
    script = [("tools", [_save_call(files={"greet.py": SCRIPT + "open(os.environ['SKILL_DIR'] + '/x.txt', 'w')\n"})]),
              ("tools", [call("run_skill", name="greet", script="greet.py", args=["a", "b"])]), ("text", "done")]
    proj, agent, llm, store, s = _make(h, script)
    h.run(agent, s, "実行して")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "run_skill"][0]
    assert "hello ['a', 'b'] greet" in out and (proj / "out.txt").read_text() == "ok"   # 作業ディレクトリで動く
    assert "Read-only file system" in out or "Permission denied" in out                # スキルのフォルダは書き換えられない
    assert not (h.root / "skills" / "greet" / "x.txt").exists()
