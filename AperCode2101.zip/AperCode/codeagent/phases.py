"""作業フェーズ（v1.9.0）: 計画 → 実装 → 検証 → 修正 → 調査 → 完了確認 を AperCode 側で管理する。

LLM に「次に何をするか」を毎回決めさせるのではなく、今のフェーズと手順を AperCode が持ち、
フェーズごとに短い指示と使えるツールを切り替える。フェーズを進めるのは LLM ではなく AperCode:
  - 計画: 読み取り系ツールだけで調べ、set_plan で手順（3〜7 個）を登録 → 実装へ
  - 実装: 手順 1 つだけを実装し step_done → AperCode が検証
  - 検証: AperCode が自動検証 NG とテストを確認（LLM は呼ばない）。通ればチェックポイントを保存して次の手順へ
  - 修正: 検証のエラーだけを直して step_done → 再検証。上限回数を超えたら直前のチェックポイントへ巻き戻して調査へ
  - 調査: 読み取り・検索・クラウド相談だけで原因を調べ、別の方針を書く → その方針で実装をやり直す
  - 完了確認: 指示書の完了条件を確認して finish_brief、足りなければ set_plan で手順を追加
  - 報告: 方針を変えても通らなかった。ツール無しで状況を報告（「続けて」でこの手順から再開）
状態はセッション JSON（session.phase）に保存され、「続けて」で途中から再開できる。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict

PHASES = ("plan", "implement", "verify", "fix", "investigate", "done_check", "report")
LABEL_JA = {"plan": "計画", "implement": "実装", "verify": "検証", "fix": "修正", "investigate": "調査",
            "done_check": "完了確認", "report": "報告"}
LABEL_EN = {"plan": "Plan", "implement": "Implement", "verify": "Verify", "fix": "Fix", "investigate": "Investigate",
            "done_check": "Done check", "report": "Report"}

# フェーズごとに LLM に見せるツール（None = 全ツールから除外リストだけ引く）
PHASE_ONLY_TOOLS = {"set_plan", "step_done"}
INVESTIGATE_EXTRA = ["ask_cloud"]
# v1.10.1: 外部に作用するツール。これを使った手順は、テストで確かめられない限り「結果を観察した証拠」を求める
EXTERNAL_TOOLS = {"run_command", "process_start", "process_stop", "repl", "browser_click", "browser_type", "browser_press",
                  "mt5_backtest", "make_icon", "gui_launch", "gui_activate", "gui_input", "run_skill"}
# v1.11.0: ユーザーが「最初からやり直し」を求めたら、計画を作り直す
RESTART_RE = re.compile(r"最初から|はじめから|初めから|一から|やり直し|start over|from scratch|from the beginning", re.I)
# v1.11.1: 実行結果そのものが出力として返るツール（その出力が観察になる）。GUI の入力のように結果が返らないものは含めない
SELF_REPORTING_TOOLS = {"run_command", "repl", "gui_launch", "gui_activate", "mt5_backtest", "run_skill"}
CODE_EXTS = {".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java", ".kt", ".c", ".cpp", ".h", ".hpp",
             ".cs", ".rb", ".php", ".sh", ".mq5", ".mqh", ".mq4", ".lua", ".swift", ".dart"}
DONE_EXTRA = ["run_tests", "run_command", "finish_brief", "set_plan"]
# v2.0.0: 会話の相手へ送る／相手から受け取るツール。受け取った返事を digest で整理するまで、次の送信を止める
PEER_TALK_TOOLS = {"ask_peer", "peer_reply", "cloud_chat"}       # 送信と受信を 1 回で行う（出力が相手の返事）
KINDS = ("code", "operate", "converse")

# ユーザーへの質問・依頼で止まったかの判定（応答の末尾に出る表現）。v1.9.1
ASK_RE = re.compile(r"[？?]|ください|下さい|いただけ(ます|ません)か|もらえ(ます|ません)か|よい(です)?か|よろしい(です)?か|でしょうか|"
                    r"教えて|お知らせ|指示を|ご確認|\b(please|could you|can you|would you|let me know|confirm|which)\b", re.I)
STEP_RE = re.compile(r"^\s*(?:\d{1,2}\s*[.)．、:]|[-*]\s*\[\s?\])\s*(.+?)\s*$")


def _en() -> bool:
    from .prompts import prompt_language
    return prompt_language() == "en"


def L(ja: str, en: str) -> str:
    return en if _en() else ja


def label(phase: str) -> str:
    return (LABEL_EN if _en() else LABEL_JA).get(phase, phase)


@dataclass
class PhaseState:
    active: bool = False
    phase: str = "plan"
    steps: list[dict] = field(default_factory=list)   # {"text": str, "status": "todo" | "done"}
    idx: int = 0                                       # 今の手順（0 始まり）
    fix_rounds: int = 0                                # この手順で修正に差し戻した回数
    investigations: int = 0                            # この手順で巻き戻して調査した回数
    last_error: str = ""                               # 直近の検証エラー
    failures: list[str] = field(default_factory=list)  # この手順で失敗した方針の記録
    approach: str = ""                                 # 調査で決めた新しい方針
    replan: bool = False                               # ユーザーの追加指示で計画を出し直す
    kind: str = "code"                                 # v1.11.0: code（コードを書く作業）/ operate（アプリ操作・環境設定などコードを書かない作業）
    cov_asked: bool = False                            # v1.10.0: この手順で変更行のカバレッジ不足を指摘したか（1 回だけ）
    step_tools: list[str] = field(default_factory=list)  # v1.10.1: この手順で使ったツール（"code_edit" = コードファイルの変更）
    confirm_ts: float = 0.0                            # v1.10.1: 結果の確認（証拠）を求めた時刻。0 = まだ求めていない
    last_action_ts: float = 0.0                        # v1.11.1: この手順で最後に外部へ作用した（またはコードを書いた）時刻
    last_observe_ts: float = 0.0                       # v1.11.1: この手順で最後に結果を観察した時刻
    # v2.0.0: 会話の状態（手順をまたいで保持する）。受け取った返事を digest で整理してから次を送る
    sent_ts: float = 0.0                               # 最後に相手へ送った時刻
    inbox_ts: float = 0.0                              # 送った後に相手の返事を見た（受け取った）時刻
    digest_ts: float = 0.0                             # 最後に digest で整理した時刻
    open_questions: list[str] = field(default_factory=list)  # 直近の digest で挙げた、まだ答えていない相手の質問
    final_digest_asked: bool = False                   # 完了確認で「最後の返事の整理」を 1 度求めたか
    partner_state: str = ""                            # v2.4.0: 相手の状態（replied / replying / waiting_approval / error / unknown）
    reply_plan: str = ""                               # v2.3.0: 直近の digest の返信の方針（続行の許可を求めるときの理由に使う）
    rounds: int = 0                                    # v2.3.0: ユーザーが指定した送信回数の目安（0 = 指定なし）
    sent_count: int = 0                                # v2.3.0: 相手へ送った回数
    rounds_allowed: int = 0                            # v2.3.0: 目安を超えてユーザーが許可した回数
    rounds_closed: bool = False                        # v2.3.0: ユーザーが「これ以上続けない」を選んだ
    signal: tuple | None = None                        # ツールからの通知（set_plan / step_done）。保存しない

    # ---------------------------------------------------------------- 永続化
    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("signal", None)
        return d

    @classmethod
    def from_dict(cls, d: dict | None) -> "PhaseState":
        d = dict(d or {})
        known = set(cls.__dataclass_fields__) - {"signal"}
        ps = cls(**{k: v for k, v in d.items() if k in known})
        if ps.phase not in PHASES:
            ps.phase = "plan"
        return ps

    # ---------------------------------------------------------------- 操作
    @property
    def n(self) -> int:
        return len(self.steps)

    def current(self) -> str:
        return self.steps[self.idx]["text"] if 0 <= self.idx < self.n else ""

    def reset_step(self) -> None:
        self.fix_rounds = 0
        self.investigations = 0
        self.last_error = ""
        self.failures = []
        self.approach = ""
        self.cov_asked = False
        self.step_tools = []
        self.confirm_ts = 0.0
        self.last_action_ts = 0.0
        self.last_observe_ts = 0.0

    # ---------------------------------------------------------------- v2.0.0: 会話
    def undigested(self) -> bool:
        """相手の返事を受け取った後、まだ digest で整理していないか。"""
        return self.inbox_ts > 0 and self.inbox_ts > self.digest_ts

    def set_steps(self, steps: list[str]) -> None:
        """計画を登録する。出し直しなら完了済みの手順は残して、残りを置き換える。"""
        steps = [s.strip() for s in steps if s and s.strip()][:12]
        done = [s for s in self.steps if s.get("status") == "done"] if self.replan else []
        self.steps = done + [{"text": s, "status": "todo"} for s in steps]
        self.idx = len(done)
        self.replan = False
        self.reset_step()

    def add_steps(self, steps: list[str]) -> None:
        """完了確認で足りない点が見つかったときの手順追加。"""
        steps = [s.strip() for s in steps if s and s.strip()][:8]
        self.idx = self.n
        self.steps += [{"text": s, "status": "todo"} for s in steps]
        self.reset_step()

    def view(self) -> dict:
        """UI 表示用。"""
        return {"active": self.active, "phase": self.phase, "label": label(self.phase),
                "idx": self.idx, "n": self.n, "steps": self.steps, "fix_rounds": self.fix_rounds,
                "investigations": self.investigations}


def parse_steps(text: str) -> list[str]:
    """本文に番号付きの手順が書かれていれば取り出す（set_plan を呼ばないモデル向け）。"""
    out = []
    for ln in (text or "").splitlines():
        m = STEP_RE.match(ln)
        if m and len(m.group(1)) >= 3:
            out.append(re.sub(r"\*\*(.+?)\*\*", r"\1", m.group(1)))
    return out if len(out) >= 2 else []


def asks_user(text: str, tail: int = 400) -> bool:
    """応答がユーザーへの質問・依頼で終わっているか（計画フェーズで止まったときに、フェーズを終わらせないため）。"""
    t = re.sub(r"```.*?```", "", text or "", flags=re.S).strip()
    return bool(ASK_RE.search(t[-tail:]))


def plan_list(ps: PhaseState, max_chars: int = 1500) -> str:
    lines = []
    for i, s in enumerate(ps.steps):
        mark = "✓" if s.get("status") == "done" else ("▶" if i == ps.idx else " ")
        lines.append(f"{mark} {i + 1}. {s['text']}")
    txt = "\n".join(lines)
    return txt if len(txt) <= max_chars else txt[:max_chars] + "\n…"


# ------------------------------------------------------------------ システムプロンプトに添えるブロック
def block(ps: PhaseState, *, max_fix: int, cloud: bool, brief: bool, checkpoint: str = "") -> str:
    p, i, n = ps.phase, ps.idx + 1, ps.n
    en = _en()
    if p == "plan":
        if en:
            b = ("## Current phase: Plan\n- Read what you need (read-only tools only), then split the work into 3-7 steps and register them with set_plan\n"
                 "- Each step must be small enough for one implement + verify round; say concretely what to do in which file\n"
                 "- For work that writes no code (operating apps, configuring the environment) pass kind \"operate\" to set_plan (\"code\" for coding work). "
                 "For a conversation with another AI or person (chat app, another AperCode, a cloud AI) pass \"converse\", "
                 "and if the user gave a number of messages to send, put it in rounds\n"
                 "- If the request needs no code change (a question or an explanation), just answer without set_plan\n"
                 "- If you lack information needed to plan (a file you cannot read, a choice only the user can make), ask the user and stop. Planning continues after the reply\n")
            if ps.replan and ps.steps:
                b += "- The user gave an additional / changed instruction. Taking the steps below into account, register the remaining steps again with set_plan\n\n" + plan_list(ps)
        else:
            b = ("## 現在のフェーズ: 計画\n- 必要なファイルを読み（読み取り系ツールのみ使用可）、作業を 3〜7 個の手順に分けて set_plan で登録する\n"
                 "- 各手順は「1 回の実装＋検証」で終わる大きさにし、何をどのファイルで行うかを具体的に書く\n"
                 "- アプリの操作・環境設定などコードを書かない作業は set_plan の kind に \"operate\" を指定する（コードを書く作業は \"code\"）。"
                 "ほかの AI や人との会話（チャットアプリ・別の AperCode・クラウド AI）は \"converse\"。"
                 "会話でユーザーが送る回数を指定していれば、その回数を rounds に書く\n"
                 "- コードの変更が不要な質問・説明の依頼なら、set_plan を呼ばずにそのまま回答してよい\n"
                 "- 計画に必要な情報が足りない（ファイルが読めない・方針が決められない）ときは、ユーザーに質問して止まってよい。返事の後も計画フェーズから続く\n")
            if ps.replan and ps.steps:
                b += "- ユーザーから追加・変更の指示があった。下の計画（✓ は完了済み）を踏まえて、残りの手順を set_plan で出し直す\n\n" + plan_list(ps)
        return "\n\n" + b
    if p == "implement":
        if en:
            b = (f"## Current phase: Implement (step {i}/{n})\nDo now: {ps.current()}\n"
                 "- Do only this step. Do not touch the other steps\n"
                 "- When done, call step_done (AperCode verifies automatically and moves to the next step if it passes)\n"
                 "- For work tests cannot check (commands, GUI operations), observe the result (screenshot, output, file content) "
                 "and write in step_done's evidence what you saw that shows it worked\n"
                 "- Run any script or function you just wrote at least once and confirm it works before calling step_done\n"
                 "- Follow additional instructions from the user. If the remaining steps no longer fit, re-register them with set_plan\n")
            b += converse_lines(ps, True)
            if ps.approach:
                b += "\nApproaches that failed for this step:\n- " + "\n- ".join(ps.failures[-3:]) + f"\nNew approach (use this): {ps.approach}\n"
            b += "\nPlan:\n" + plan_list(ps)
        else:
            b = (f"## 現在のフェーズ: 実装（手順 {i}/{n}）\n今やること: {ps.current()}\n"
                 "- この手順だけを行う。ほかの手順には手を付けない\n"
                 "- 終わったら step_done を呼ぶ（検証は AperCode が自動で行い、通れば次の手順に進む）\n"
                 "- コマンド実行や GUI 操作など、テストで確かめられない作業は、結果を観察して（スクリーンショット・出力・ファイルの中身）"
                 "成功を確かめてから step_done の evidence に「何を見て成功と判断したか」を書く\n"
                 "- 新しく書いたスクリプト・関数は、一度実際に実行して動くことを確かめてから step_done を呼ぶ\n"
                 "- ユーザーから追加の指示があればそれに従う。残りの手順が合わなくなったら set_plan で出し直してよい\n")
            b += converse_lines(ps, False)
            if ps.approach:
                b += "\nこの手順で失敗した方針:\n- " + "\n- ".join(ps.failures[-3:]) + f"\n新しい方針（これで行う）: {ps.approach}\n"
            b += "\n計画:\n" + plan_list(ps)
        return "\n\n" + b
    if p == "fix":
        err = ps.last_error[:3000]
        if en:
            return (f"\n\n## Current phase: Fix (step {i}/{n}, fix {ps.fix_rounds}/{max_fix})\nFix only this error:\n```\n{err}\n```\n"
                    "- Fix the implementation (do not weaken the tests)\n- When fixed, call step_done (AperCode verifies again)\n"
                    f"\nStep: {ps.current()}\n")
        return (f"\n\n## 現在のフェーズ: 修正（手順 {i}/{n}、修正 {ps.fix_rounds}/{max_fix} 回目）\n次のエラーだけを直す:\n```\n{err}\n```\n"
                "- 実装側を直す（テストを弱めない）\n- 直したら step_done を呼ぶ（AperCode が再検証する）\n"
                f"\n手順: {ps.current()}\n")
    if p == "investigate":
        fails = "\n- ".join(ps.failures[-3:]) or "-"
        if en:
            return (f"\n\n## Current phase: Investigate (step {i}/{n})\nFixing did not make this step pass, so the files were rolled back to {checkpoint}.\n"
                    f"Failure record:\n- {fails}\n"
                    "- Find the cause with read-only tools, web_search, fetch_url, search_memory" + (" and ask_cloud" if cloud else "") + ". You cannot change files\n"
                    "- Then write a different approach in at most 5 lines and stop (no code). The next implement phase retries the step with it\n"
                    f"\nStep: {ps.current()}\n")
        return (f"\n\n## 現在のフェーズ: 調査（手順 {i}/{n}）\nこの手順は修正を重ねても検証が通らなかったため、ファイルを {checkpoint} の状態に戻した。\n"
                f"失敗の記録:\n- {fails}\n"
                "- 読み取り系ツール・web_search・fetch_url・search_memory" + ("・ask_cloud" if cloud else "") + " で原因を調べる。ファイルは変更できない\n"
                "- 調べ終えたら、前回と違う方針を 5 行以内で書いて終える（コードは書かない）。次の実装フェーズでその方針でやり直す\n"
                f"\n手順: {ps.current()}\n")
    if p == "done_check":
        if en:
            return ("\n\n## Current phase: Done check\nAll steps are implemented and verified. Check the done-conditions of the task brief"
                    + (" " if brief else " (or the user's request)") + " one by one\n"
                    + ("- If satisfied, call finish_brief and write the completion report to the user\n" if brief else "- If satisfied, write the completion report to the user\n")
                    + "- Also check the last screen or output you observed (e.g. the other party's reply): if a request or question in it, including an earlier one, is still unanswered, it is not done yet\n"
                    + "- If something is missing, register additional steps with set_plan (implementation resumes from them)\n\nPlan:\n" + plan_list(ps))
        return ("\n\n## 現在のフェーズ: 完了確認\n全手順の実装と検証が済んだ。" + ("指示書の完了条件" if brief else "ユーザーの依頼") + "を 1 つずつ確認する\n"
                + ("- 満たしていれば finish_brief を呼び、ユーザーに完了報告を書く\n" if brief else "- 満たしていれば、ユーザーに完了報告を書く\n")
                + "- 最後に観察した画面や出力（相手の返信など）も確認する。その中に、前からのものも含めて、まだ応えていない依頼や質問が残っていれば完了ではない\n"
                + "- 足りない点があれば set_plan で追加の手順を登録する（追加分から実装を再開する）\n\n計画:\n" + plan_list(ps))
    if p == "report":
        fails = "\n- ".join(ps.failures[-3:]) or "-"
        if en:
            return (f"\n\n## Current phase: Report\nStep {i}/{n} did not pass even after changing the approach. The files are back at {checkpoint}, the last verified state.\n"
                    f"Failure record:\n- {fails}\n"
                    "Without tools, report to the user: finished steps, the failing step and the approaches tried, the key error, and what to try next. "
                    "If the user sends \"continue\", work resumes from this step.\n\nPlan:\n" + plan_list(ps))
        return (f"\n\n## 現在のフェーズ: 報告\n手順 {i}/{n} は方針を変えても検証が通らなかった。ファイルは最後に検証が通った {checkpoint} の状態に戻してある。\n"
                f"失敗の記録:\n- {fails}\n"
                "ツールは使わずに、完了した手順・失敗した手順と試した方針・エラーの要点・次に試すべきことをユーザーに報告する。"
                "ユーザーが「続けて」と送るとこの手順から再開する。\n\n計画:\n" + plan_list(ps))
    return ""


def converse_lines(ps: PhaseState, en: bool) -> str:
    """v2.0.0: 会話の作業で守ること。相手の返事を質問だけ拾って読み飛ばさないように、送信前の整理（digest）を求める。"""
    if ps.kind != "converse" and not ps.inbox_ts:
        return ""
    if en:
        b = ("\nConversation rules:\n"
             "- After reading the other party's reply, call digest BEFORE sending anything. Pick up everything, not only questions: "
             "advice, corrections, criticism of your answers, and facts mentioned in small talk\n"
             "- In your reply, answer every question (including earlier unanswered ones), and for each piece of advice or correction say whether "
             "you accept it or why you disagree. Never jump to the next question while skipping these\n"
             "- Put what will be useful later into digest's insights (saved to experience memory)\n"
             "- Call digest once per reply; right after it, send your reply (do not digest the same reply again)\n"
             "- Tell the other party's state and put it in digest's partner_state: replied / replying (thinking or generating indicator) / "
             "waiting_approval (an \"approval needed\" card with allow/deny buttons or a \"start working?\" card = waiting for ITS user) / error\n"
             "- Waiting for approval does not mean it cannot do the task: its user has not approved yet. Do not send; wait, and never click its approval buttons yourself\n")
        if ps.open_questions:
            b += "- Questions still to answer: " + " / ".join(q[:120] for q in ps.open_questions[:6]) + "\n"
        if ps.rounds:
            b += (f"- Messages sent: {ps.sent_count} / planned {ps.rounds} (a guide, not absolute). Sending more asks the user for "
                  "permission with your reason (from digest); say in the final report if you went beyond it and why\n")
        return b
    b = ("\n会話の作業で守ること:\n"
         "- 相手の返事を読んだら、送信する前に必ず digest で整理する。質問だけでなく、助言・訂正・自分の答えへの指摘・雑談の中の情報も拾う\n"
         "- 返信では、すべての質問（前からの未回答も含む）に答え、助言や指摘には「受け入れる」か「理由付きで反論する」かを書く。"
         "これらを飛ばして次の質問に移らない\n"
         "- 今後に役立つ知見は digest の insights に書く（経験メモリに保存される）\n"
         "- digest は相手の返事 1 通につき 1 回。整理したらすぐに返信を送る（同じ返事を整理し直さない）\n"
         "- 相手の状態を見分けて digest の partner_state に書く: replied（返事を書き終えた）／replying（考え中・生成中の表示がある）／"
         "waiting_approval（相手の画面に「承認が必要」「許可・拒否」のボタンや「作業を始めますか？」のカードが出ている＝相手のユーザーの許可待ち）／error\n"
         "- 承認待ちは「相手は実行できない」ではない。相手のユーザーが許可するのを待っているだけ。送らずに待ち、相手の許可ボタンを自分で押さない\n")
    if ps.open_questions:
        b += "- まだ答えていない質問: " + " ／ ".join(q[:120] for q in ps.open_questions[:6]) + "\n"
    if ps.rounds:
        b += (f"- 送った回数: {ps.sent_count} 回 / 予定 {ps.rounds} 回（目安。絶対ではない）。予定を超えて送るときは、AperCode が digest の内容を理由として"
              "ユーザーに許可を求める。超えた場合は完了報告にその理由を書く\n")
    return b


def rounds_reason(ps: PhaseState) -> str:
    """v2.3.0: 予定の回数を超えて送るときにユーザーへ示す理由（AperCode が digest で整理した内容）。"""
    qs = " ／ ".join(q[:100] for q in ps.open_questions[:3])
    plan = (ps.reply_plan or "").strip()[:200]
    return L(f"予定の {ps.rounds} 回を超えて会話を続けようとしています（{ps.sent_count + 1} 回目）。理由（AperCode の整理）: "
             + (f"相手の質問に答えるため「{qs}」" if qs else "相手の返事に応えるため") + (f" ／ 返信の方針: {plan}" if plan else "")
             + "。続けてよければ「許可」、ここで終えるなら「拒否」",
             f"About to go beyond the planned {ps.rounds} messages (message {ps.sent_count + 1}). Reason (AperCode's digest): "
             + (f"to answer the other party's question: {qs}" if qs else "to respond to the other party's reply") + (f" / reply plan: {plan}" if plan else "")
             + ". Allow to continue, deny to stop here.")


def msg_rounds_closed(ps: PhaseState) -> str:
    return L(f"エラー: ユーザーは予定の {ps.rounds} 回を超えて会話を続けないことを選びました。これ以上送らずに、この手順を終えて"
             "（step_done）、完了報告に「相手から未回答の質問が残っている」ことと内容を書いてください。",
             f"Error: the user chose not to continue beyond the planned {ps.rounds} messages. Do not send more; finish this step "
             "(step_done) and mention in the final report that the other party's question was left unanswered and what it was.")


def msg_partner_busy(ps: PhaseState) -> str:
    """v2.4.0: 相手がまだ返事を書いている／相手のユーザーの承認待ちのときに送ろうとした。"""
    if ps.partner_state == "waiting_approval":
        return L("エラー: 相手は、相手側のユーザーの承認（許可・拒否）を待っています。今は送らずに、少し待ってから screenshot で確かめてください。"
                 "相手の許可ボタンを自分で押さないこと。長く変わらなければ、ユーザーに「相手の画面で許可が必要」と伝えてください。",
                 "Error: the other party is waiting for its user's approval. Do not send now; wait and take a screenshot again. "
                 "Never click its approval buttons yourself. If it stays like this, tell the user that approval is needed on the other screen.")
    return L("エラー: 相手はまだ返事を書いている途中です。送らずに、少し待ってから screenshot で確かめてください。",
             "Error: the other party is still writing its reply. Do not send; wait a little and take another screenshot.")


def msg_digest_first(ps: PhaseState) -> str:
    return L("相手の返事をまだ整理していません。送信する前に digest を呼び、相手の助言・指摘・質問（前からの未回答も含む）と"
             "返信の方針・残す知見を書いてください。",
             "You have not digested the other party's reply yet. Before sending, call digest with their advice, corrections and questions "
             "(including earlier unanswered ones), your reply plan and the insights to keep.")


def msg_final_digest(ps: PhaseState) -> str:
    return L("【システム】相手の最後の返事をまだ digest で整理していません。完了にする前に digest を呼び、"
             "助言・指摘・残す知見を整理してください。未回答の質問が残っていれば、答える手順を set_plan で追加してください。",
             "[System] You have not digested the other party's last reply. Before finishing, call digest to record their advice, "
             "corrections and the insights to keep. If questions are still unanswered, add steps with set_plan to answer them.")


# ------------------------------------------------------------------ フェーズ切り替え時に履歴へ入れる指示
def msg_start(ps: PhaseState) -> str:
    return L(f"【システム】計画を登録しました（{ps.n} 手順）。手順 {ps.idx + 1}/{ps.n}: {ps.current()}\nこの手順だけを実装し、終わったら step_done を呼んでください。",
             f"[System] Plan registered ({ps.n} steps). Step {ps.idx + 1}/{ps.n}: {ps.current()}\nImplement only this step and call step_done when finished.")


def msg_next(ps: PhaseState, cp_label: str) -> str:
    return L(f"【システム】手順 {ps.idx}/{ps.n} の検証が通りました（{cp_label} を保存）。次は手順 {ps.idx + 1}/{ps.n}: {ps.current()}\n"
             "この手順だけを実装し、終わったら step_done を呼んでください。",
             f"[System] Step {ps.idx}/{ps.n} passed verification ({cp_label} saved). Next, step {ps.idx + 1}/{ps.n}: {ps.current()}\n"
             "Implement only this step and call step_done when finished.")


def msg_fix(ps: PhaseState, max_fix: int) -> str:
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n} の検証で問題が見つかりました（修正 {ps.fix_rounds}/{max_fix} 回目）。\n```\n{ps.last_error[:3000]}\n```\n"
             "このエラーだけを直して step_done を呼んでください。",
             f"[System] Verification of step {ps.idx + 1}/{ps.n} found problems (fix {ps.fix_rounds}/{max_fix}).\n```\n{ps.last_error[:3000]}\n```\n"
             "Fix only this error and call step_done.")


def msg_confirm(ps: PhaseState, again: str = "", observed: bool = False) -> str:
    """v1.10.1: テストで確かめられない手順の完了報告に、観察による確認を求める。
    v1.11.1: 最後の操作の後に既に観察していれば、撮り直しは求めず evidence を書くことだけを求める。"""
    if observed and not again:
        return L(f"【システム】手順 {ps.idx + 1}/{ps.n} はテストでは成功を確かめられない作業です。操作の後に観察した結果"
                 "（直前のスクリーンショットや出力）で成功を確かめられているなら、撮り直さずに、step_done の evidence に"
                 "何を見て成功と判断したかを具体的に書いてください。失敗していたら直してから報告してください。",
                 f"[System] Step {ps.idx + 1}/{ps.n} cannot be checked by tests. If what you observed after the action "
                 "(the last screenshot or output) shows it worked, do not take it again: call step_done with evidence describing "
                 "concretely what you saw. If it failed, fix it first.")
    if again:
        return L(f"【システム】手順 {ps.idx + 1}/{ps.n} の完了をまだ認められません（{again}）。"
                 "結果を実際に観察し（GUI ならアプリ全体のスクリーンショット、コマンドなら出力、ファイルなら中身）、"
                 "成功していれば step_done の evidence に何を見てそう判断したかを具体的に書いてください。失敗していたら直してから報告してください。",
                 f"[System] Step {ps.idx + 1}/{ps.n} cannot be accepted yet ({again}). Actually observe the result (a screenshot of the whole app "
                 "for GUI work, the output of a command, the content of a file). If it worked, call step_done with evidence describing concretely "
                 "what you saw. If it failed, fix it first.")
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n} はコマンド実行・GUI 操作など、AperCode のテストでは成功を確かめられない作業です。"
             "「操作した」だけでは完了になりません。結果を実際に観察して確かめてください（GUI ならアプリ全体のスクリーンショット、"
             "コマンドなら出力、ファイルなら中身）。成功していれば step_done の evidence に何を見てそう判断したかを具体的に書き、"
             "失敗していれば直してから報告してください。",
             f"[System] Step {ps.idx + 1}/{ps.n} is work AperCode's tests cannot check (commands, GUI operations). Performing the action "
             "is not enough: actually observe the result (a screenshot of the whole app for GUI work, the output of a command, the content of "
             "a file). If it worked, call step_done with evidence describing concretely what you saw; if it failed, fix it first.")


def msg_investigate(ps: PhaseState, cp_label: str, why: str, dropped: int) -> str:
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n}: {why}。ファイルを {cp_label} の状態に戻し、その後の試行 {dropped} 件を履歴から外しました。"
             "原因を調べ、前回と違う方針を 5 行以内で書いてください（ファイルの変更はできません）。",
             f"[System] Step {ps.idx + 1}/{ps.n}: {why}. The files were rolled back to {cp_label} and the {dropped} later messages were removed from the history. "
             "Investigate the cause and write a different approach in at most 5 lines (you cannot change files).")


def msg_retry_other(ps: PhaseState, why: str) -> str:
    """v1.11.0: ファイルを変えていない手順（アプリ操作など）の失敗。巻き戻しや調査フェーズを挟まず、別のやり方でやり直させる。"""
    fails = "\n- ".join(ps.failures[-3:]) or "-"
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n}: {why}。同じやり方を繰り返さず、別の方法でこの手順をやり直してください。"
             f"まず現在の状態を確認（画面ならスクリーンショット、コマンドなら出力）してから操作すること。\nうまくいかなかったやり方:\n- {fails}",
             f"[System] Step {ps.idx + 1}/{ps.n}: {why}. Do not repeat the same approach; redo this step another way. "
             f"First check the current state (a screenshot, the output of a command), then act.\nApproaches that did not work:\n- {fails}")


def msg_report_plain(ps: PhaseState) -> str:
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n} はやり方を変えても成功しませんでした。ツールは使わずに、状況をユーザーに報告してください。",
             f"[System] Step {ps.idx + 1}/{ps.n} did not succeed even with other approaches. Report the situation to the user without using tools.")


def msg_retry(ps: PhaseState) -> str:
    return L(f"【システム】新しい方針で手順 {ps.idx + 1}/{ps.n} をやり直してください: {ps.approach[:800]}\n終わったら step_done を呼んでください。",
             f"[System] Retry step {ps.idx + 1}/{ps.n} with the new approach: {ps.approach[:800]}\nCall step_done when finished.")


def msg_done_check(ps: PhaseState, brief: bool) -> str:
    """v1.11.2: 最後に観察した画面・出力に未対応の依頼や質問が残っていないかも確認させる（会話の途中で完了にしない）。
    v2.3.0: 予定の回数を超えて会話した場合は、完了報告にその理由を書かせる。"""
    over = ps.rounds and ps.sent_count > ps.rounds
    extra = L(f"予定の {ps.rounds} 回を超えて {ps.sent_count} 回送ったので、完了報告にその理由を書いてください。" if over else "",
              f"You sent {ps.sent_count} messages, more than the planned {ps.rounds}; give the reason in the final report." if over else "")
    return L(f"【システム】全 {ps.n} 手順の検証が通りました。" + ("指示書の完了条件" if brief else "ユーザーの依頼") + "を満たしているか確認してください。"
             "あわせて、最後に観察した画面や出力（相手の返信など）に、まだ応えていない依頼や質問が残っていないか確認し、"
             "残っていれば set_plan で応える手順を追加してください。" + extra,
             f"[System] All {ps.n} steps passed verification. Check that the " + ("done-conditions of the task brief are" if brief else "user's request is") + " satisfied. "
             "Also check the last screen or output you observed (e.g. the other party's reply): if a request or question in it is still unanswered, "
             "add steps with set_plan to answer it. " + extra)


def msg_report(ps: PhaseState, cp_label: str, dropped: int) -> str:
    return L(f"【システム】手順 {ps.idx + 1}/{ps.n} は方針を変えても検証が通りませんでした。ファイルを {cp_label} の状態に戻し、その後の試行 {dropped} 件を履歴から外しました。"
             "ツールは使わずに、状況をユーザーに報告してください。",
             f"[System] Step {ps.idx + 1}/{ps.n} did not pass even with a new approach. The files were rolled back to {cp_label} and the {dropped} later messages were removed from the history. "
             "Report the situation to the user without using tools.")
