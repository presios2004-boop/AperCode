"""スキルのツール（v2.10.0）: list_skills / use_skill / save_skill / run_skill。"""
from __future__ import annotations

import asyncio
from pathlib import Path

from . import Tool, ToolContext, ToolError, register
from .. import skills as SK
from .. import sandbox

MAX_OUT = 30_000


async def list_skills(ctx: ToolContext, a: dict) -> str:
    sks = SK.list_skills(ctx.cfg)
    if not sks:
        return f"スキルはまだありません（置き場: {SK.skills_dir(ctx.cfg)}）。繰り返し使える手順ができたら save_skill で保存できます"
    rows = []
    for s in sks:
        st = "" if s["status"] == "ok" else "  ⚠ 未確認（ユーザーの確認待ち。使えない）"
        rows.append(f"- {s['name']}: {s['description'] or '（説明なし）'}{st}"
                    + (f"\n    ファイル: {', '.join(s['files'][:12])}" if s["files"] else ""))
    return f"スキル（{SK.skills_dir(ctx.cfg)}）:\n" + "\n".join(rows) + "\n\n使うときは use_skill で手順を読む"


async def use_skill(ctx: ToolContext, a: dict) -> str:
    try:
        sk = SK.get(ctx.cfg, str(a.get("name") or "").strip())
    except SK.SkillError as e:
        raise ToolError(str(e))
    files = "\n".join(f"- {f}" for f in sk["files"]) or "（なし）"
    return (f"# スキル: {sk['name']}\n説明: {sk['description']}\n場所: {sk['path']}\n\n## 手順（SKILL.md）\n{sk['body']}\n\n"
            f"## 付属ファイル\n{files}\n\nスクリプトは run_skill（name, script, args）で実行する。データファイルは read_file で読める。"
            "手順に従って作業し、ユーザーの指示と食い違う部分はユーザーの指示を優先する")


async def save_skill(ctx: ToolContext, a: dict) -> str:
    tainted = bool((ctx.taint or {}).get("active")) if isinstance(ctx.taint, dict) else False
    try:
        r = SK.save(ctx.cfg, str(a.get("name") or ""), str(a.get("description") or ""), str(a.get("instructions") or ""),
                    a.get("files") or {}, bool(a.get("overwrite")), tainted=tainted, session_id=ctx.session_id)
    except SK.SkillError as e:
        raise ToolError(str(e))
    note = ("\n⚠ 外部の内容を読んだ後に作ったため「未確認」として保存しました。ユーザーが画面の「スキル」で確認するまで使えません"
            if r["status"] == "untrusted" else "")
    prev = f"\n（前の版は {r['previous']} に保存）" if r["previous"] else ""
    return f"スキル {r['name']} を保存しました: {r['path']}\nファイル: SKILL.md{', ' + ', '.join(r['files']) if r['files'] else ''}{prev}{note}"


async def run_skill(ctx: ToolContext, a: dict) -> str:
    name = str(a.get("name") or "").strip()
    script = str(a.get("script") or "").strip()
    try:
        argv = SK.script_argv(ctx.cfg, name, script, a.get("args") or [], ctx.project_dir)
    except SK.SkillError as e:
        raise ToolError(str(e))
    timeout = int(a.get("timeout") or 120)
    try:
        full = sandbox.wrap(argv, ctx.project_dir, ctx.project_dir)
    except sandbox.SandboxError as e:
        raise ToolError(str(e))
    proc = await asyncio.create_subprocess_exec(*full, cwd=str(ctx.project_dir), stdout=asyncio.subprocess.PIPE,
                                                stderr=asyncio.subprocess.STDOUT,
                                                env={**sandbox.env_for(ctx.project_dir), "PYTHONUNBUFFERED": "1",
                                                     "SKILL_DIR": str(Path(argv[1]).parent)})
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        return f"$ skill {name}/{script}\n(タイムアウト {timeout}s)"
    except asyncio.CancelledError:
        proc.kill()
        raise
    text = out.decode("utf-8", errors="replace")
    if len(text) > MAX_OUT:
        text = text[:MAX_OUT // 2] + "\n... (中略) ...\n" + text[-MAX_OUT // 2:]
    return f"$ skill {name}/{script} {' '.join(str(x) for x in (a.get('args') or []))}\n(exit {proc.returncode})\n{text}"


register(Tool("list_skills", "保存済みのスキル（手順書とスクリプト）の一覧を見る。",
              {"type": "object", "properties": {}}, list_skills, lambda a: ""))
register(Tool("use_skill",
              "スキルの手順（SKILL.md）と付属ファイルの一覧を読む。作業がスキルの説明に当てはまるときに使い、その手順に従う。",
              {"type": "object", "properties": {"name": {"type": "string", "description": "スキル名"}}, "required": ["name"]},
              use_skill, lambda a: a.get("name", "")))
register(Tool("save_skill",
              "繰り返し使える手順・スクリプトをスキルとして保存する（AperCode の作業ディレクトリの skills/<name>/）。"
              "スキルのフォルダは write_file ではなく必ずこのツールで作る・更新する。",
              {"type": "object", "properties": {
                  "name": {"type": "string", "description": "英小文字・数字・- _（例: csv-cleanup）"},
                  "description": {"type": "string", "description": "何をするスキルか・どんなときに使うか（一覧に出る。具体的に）"},
                  "instructions": {"type": "string", "description": "SKILL.md の本文（Markdown）。手順・注意点・スクリプトの使い方"},
                  "files": {"type": "object", "description": "付属ファイル {相対パス: 内容}（例: {\"clean.py\": \"...\", \"rules.json\": \"...\"}）",
                            "additionalProperties": {"type": "string"}},
                  "overwrite": {"type": "boolean", "description": "既にあるスキルを更新する（前の版は履歴に残る）"}},
               "required": ["name", "description", "instructions"]},
              save_skill, lambda a: f"{a.get('name', '')}: {str(a.get('description', ''))[:80]}"))
register(Tool("run_skill",
              "スキルのスクリプト（.py / .sh / .js）をサンドボックスの中で実行する。作業ディレクトリで動き、Python は作業ディレクトリの .venv を使う。"
              "スクリプトからは環境変数 SKILL_DIR でスキルのフォルダが分かる（読み取り専用）。",
              {"type": "object", "properties": {
                  "name": {"type": "string"}, "script": {"type": "string", "description": "スキルのフォルダからの相対パス（例: clean.py）"},
                  "args": {"type": "array", "items": {"type": "string"}, "description": "引数"},
                  "timeout": {"type": "integer", "description": "秒（既定 120）"}},
               "required": ["name", "script"]},
              run_skill, lambda a: f"{a.get('name', '')}/{a.get('script', '')} {' '.join(str(x) for x in (a.get('args') or []))}"))
