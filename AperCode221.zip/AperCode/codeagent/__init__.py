"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "2.2.1"
__app_name__ = "AperCode"
