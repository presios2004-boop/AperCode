"""エージェントループ: ユーザー入力 → LLM → ツール実行 → LLM … を繰り返す。

- コンテキスト圧縮: 履歴が閾値を超えたら古い部分を LLM で要約し 1 メッセージに置き換える
- サブエージェント: spawn_agent ツールで独立コンテキストの子ループを起動する

UI とは emit(event: dict) コールバックと、承認要求用の ask_approval コルーチンで接続する。
"""
from __future__ import annotations

import asyncio
import re
import time
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from . import tools as T
from .config import Config
from .llm import LLMClient
from .backup import BackupManager
from .memory import MemoryStore, Embedder
from .prompts import build_system_prompt, P
from .session import Session, SessionStore
from . import verify as V
from .i18n import t
from . import browser as B
from .repl import ReplManager
from . import brief as BR
from . import security as SEC
from . import phases as PH
from .checkpoint import CheckpointStore, label_of
from .procs import ProcessManager
from .tools.browser_tools import BROWSER_TOOLS, is_local_url

# プロジェクトの言語・ツールをファイル構成から推定するための対応表（タグは小文字）
EXT_TAGS = {
    ".py": "python", ".mq5": "mql5", ".mqh": "mql5", ".mq4": "mql4", ".js": "javascript", ".ts": "typescript",
    ".tsx": "react", ".jsx": "react", ".go": "go", ".rs": "rust", ".java": "java", ".kt": "kotlin", ".c": "c",
    ".cpp": "c++", ".h": "c", ".hpp": "c++", ".cs": "c#", ".rb": "ruby", ".php": "php", ".sh": "bash",
    ".sql": "sql", ".html": "html", ".css": "css", ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
    ".dockerfile": "docker", ".ipynb": "jupyter", ".swift": "swift", ".dart": "flutter", ".lua": "lua",
}
FILE_TAGS = {
    "requirements.txt": "python", "pyproject.toml": "python", "package.json": "node", "Cargo.toml": "rust",
    "go.mod": "go", "Dockerfile": "docker", "docker-compose.yml": "docker", "Makefile": "make",
    "CMakeLists.txt": "cmake", ".git": "git", "pytest.ini": "pytest", "tsconfig.json": "typescript",
}


def detect_project_tags(project: Path, max_files: int = 400) -> list[str]:
    counts: dict[str, int] = {}
    try:
        for i, p in enumerate(project.rglob("*")):
            if i > max_files * 5:
                break
            if any(part in (".git", "node_modules", "__pycache__", ".venv", "venv") for part in p.parts):
                continue
            if p.name in FILE_TAGS:
                counts[FILE_TAGS[p.name]] = counts.get(FILE_TAGS[p.name], 0) + 5
            t = EXT_TAGS.get(p.suffix.lower())
            if t and p.is_file():
                counts[t] = counts.get(t, 0) + 1
    except OSError:
        pass
    return [t for t, _ in sorted(counts.items(), key=lambda x: -x[1])[:6]]

def _parse_json_array(text: str) -> list[dict]:
    """LLM 出力から JSON 配列を取り出す（前後の説明文やコードフェンスを許容）。"""
    import json, re
    text = text.strip()
    m = re.search(r"\[.*\]", text, re.S)
    if not m:
        return []
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return []
    return [d for d in data if isinstance(d, dict)] if isinstance(data, list) else []


# 常時許可の対象外にする「取り返しのつかない」コマンド（config の permissions.dangerous_commands で上書き可）
DEFAULT_DANGEROUS = [
    r"\brm\b", r"\brmdir\b", r"\bshred\b", r"\bunlink\b",
    r"\bgit\s+(reset\s+--hard|clean\b|checkout\s+--\s|restore\b|push\s+(-f|--force)|branch\s+-D|stash\s+drop)",
    r"\bsudo\b", r"\bsu\b", r"\bdd\b", r"\bmkfs", r"\bfdisk\b", r"\bparted\b",
    r"\bchmod\s+-R\b", r"\bchown\b", r"\bkill(all)?\b", r"\bpkill\b", r"\b(shutdown|reboot|poweroff)\b",
    r"\btruncate\b", r">\s*/dev/", r"\bdrop\s+(table|database)\b", r"\bpip3?\s+uninstall\b",
    r"\bapt(-get)?\s+(remove|purge|autoremove)\b", r"\bcurl\b[^|]*\|\s*(ba|z)?sh\b", r"\bwget\b[^|]*\|\s*(ba|z)?sh\b",
    r"\bmv\b.*\s/", r"\bcrontab\s+-r\b", r"\bsystemctl\s+(stop|disable|mask)\b",
]

Emit = Callable[[dict], Awaitable[None]]
AskApproval = Callable[[dict], Awaitable[str]]  # 戻り値: "allow" | "allow_always" | "deny"

# run_command でテストを走らせたと見なすコマンドのパターン
TEST_CMD_RE = re.compile(
    r"\b(pytest|py\.test|unittest|npm\s+(run\s+)?test|pnpm\s+test|yarn\s+test|jest|vitest|mocha|go\s+test|cargo\s+test|make\s+test|phpunit|rspec|dotnet\s+test|mvn\s+test|gradle\s+test)\b")


@dataclass
class VerifyState:
    """1 ターン分の検証状態（自動チェック・テスト・レビュー）。子エージェントとも共有する。"""
    changes: dict[str, dict] = field(default_factory=dict)   # path -> {"before": str|None, "after": str}
    checks: list[V.CheckResult] = field(default_factory=list)
    check_failures: dict[str, int] = field(default_factory=dict)  # path -> NG 回数
    tests: V.TestResult | None = None
    tests_fresh: bool = False          # 最後の変更以降にテストを実行したか
    test_rounds: int = 0               # 自動テストゲートで差し戻した回数
    tests_missing_prompted: bool = False
    review: dict | None = None         # 最後のレビュー結果 {"ok": bool, "issues": [...]}
    review_rounds: int = 0
    change_seq: int = 0                # 変更の通し番号（レビュー後に変更があったかの判定用）
    reviewed_seq: int = -1
    # v1.2.1: テストの保護。失敗したテストを「テスト側を書き換えて」通すのを防ぐ
    test_baseline: dict[str, str] = field(default_factory=dict)   # ターン開始時の既存テスト {rel: sha1}
    tests_locked: bool = False         # テストが一度失敗した後 True（既存テストの変更は要承認/拒否）
    tests_modified: list[str] = field(default_factory=list)       # 基準から変更・削除された既存テスト
    test_edit_denied: int = 0          # テスト変更をブロックした回数
    # v1.2.4: クラウド相談の発動条件用
    stuck_count: int = 0               # 行き詰まり検知の回数
    llm_error: bool = False            # このターンが LLM エラーで終わった
    cloud_calls: int = 0               # このターンの ask_cloud 回数
    cloud_denied: int = 0              # （予約）
    coverage_prompted: bool = False    # v1.10.0: 変更行のカバレッジ不足でテスト追加を求めたか（1 ターン 1 回）
    coverage: Any = None               # v1.10.0: 直近の CoverageReport

    def record_change(self, rel: str, before: str | None, after: str) -> None:
        c = self.changes.get(rel)
        if c is None:
            self.changes[rel] = {"before": before, "after": after}
        else:
            c["after"] = after
        self.tests_fresh = False
        self.change_seq += 1

    def record_tests(self, res: V.TestResult) -> None:
        self.tests = res
        self.tests_fresh = res.detected
        if res.detected and not res.ok:
            self.tests_locked = True

    def changed_lines(self) -> int:
        return sum(V.count_changed_lines(c["before"], c["after"]) for c in self.changes.values())

    def code_changed(self) -> bool:
        return any(Path(p).suffix.lower() in V.CHECKERS or Path(p).suffix.lower() in (".mq5", ".mqh")
                   for p in self.changes)

    def diff(self, max_chars: int = 24000) -> str:
        parts = [V.unified_diff(c["before"], c["after"], p) for p, c in self.changes.items()]
        text = "\n\n".join(parts)
        return text[:max_chars] + ("\n... (省略)" if len(text) > max_chars else "")

    def summary(self) -> dict:
        ng = [c for c in self.checks if not c.ok and not c.skipped]
        return {
            "files": len(self.changes), "lines": self.changed_lines(),
            "checks": {"run": len(self.checks), "ng": len(ng)},
            "tests": self.tests.summary() if self.tests else None,
            "tests_ok": self.tests.ok if self.tests else None,
            "review": (None if self.review is None else
                       {"ok": self.review.get("ok"), "issues": len(self.review.get("issues") or []), "rounds": self.review_rounds}),
            "tests_modified": list(self.tests_modified), "test_edit_denied": self.test_edit_denied,
        }


@dataclass
class LoopState:
    """1 つのエージェントループ（親または子）の状態。"""
    messages: list[dict]
    system: str
    tool_names: list[str] | None          # None = 全ツール
    ctx: T.ToolContext
    model: str | None = None
    usage: dict = field(default_factory=lambda: {"prompt_tokens": 0, "completion_tokens": 0})
    last_prompt_tokens: int = 0
    on_save: Callable[[], None] | None = None
    compacted_len: int = -1               # 直近の圧縮直後のメッセージ数（連続圧縮の防止用）
    brief_path: Path | None = None        # v1.8.0: 作業の指示書（毎回読み直してシステムプロンプトに添える）
    ctx_warned: bool = False              # 「圧縮しても減らない」警告を出したか
    phase: Any = None                     # v1.9.0: 作業フェーズ（PhaseState。親のみ）
    step_seq: int = -1                    # v1.9.0: 今の手順を始めたときの verify.change_seq（手順内で変更したかの判定）
    clarify: list = field(default_factory=list)   # v2.0.0: 作業前にユーザーへ聞く質問（指示書の不足点検）
    clarified: bool = False               # v2.0.0: このターンの入力は作業前の確認への回答
    chat_mode: bool = False               # v2.1.0: 会話モード（指示書・作業フェーズを使わない）
    chat_declined: bool = False           # v2.1.0: このターン、ユーザーが「会話を続ける」を選んだ
    switch_to: str = ""                   # v2.1.0: 作業開始が選ばれた（作業ディレクトリ）。このターンを止めて作業を始める
    paused: bool = False                  # v2.1.0: 承認で一時停止が選ばれた。このターンを止める
    qna: bool = False                     # v2.1.0: 一時停止の後の質問への回答ターン（手順の完了として扱わない）


class Agent:
    def __init__(self, cfg: Config, llm: LLMClient, store: SessionStore):
        self.cfg = cfg
        self.llm = llm
        self.store = store
        self.session_allow: dict[str, set[str]] = {}  # session_id -> 常時許可したツール名
        self._cancel: dict[str, asyncio.Event] = {}
        self._force_ask: dict[str, set[str]] = {}
        self._known_domains: dict[str, set[str]] = {}   # v2.2.0: session_id -> 検索結果・ユーザーの指示に出たドメイン    # v2.0.0: session_id -> 設定に関わらず承認を求めるツール（ピアからの依頼）
        self.memory: MemoryStore | None = None
        self._bg_tasks: set[asyncio.Task] = set()
        self._bg_compact: dict[str, dict] = {}
        self._helper_gpu_ok = True               # v1.7.2: サブ LLM を GPU で動かして失敗したら、以後は CPU で動かす
        self._helper_busy = 0                    # サブ LLM のリクエスト実行中の数
        self._helper_last = 0.0                  # 直近にサブ LLM が動いていた時刻   # v1.6.1: session_id -> サブ LLM が背景で準備中／準備済みの要約
        # ブラウザ（Playwright）。無効または未インストールなら None でツールを隠す
        self.browser = B.Browser(cfg) if (cfg.get("browser.enabled", True) and B.is_available()) else None
        # v1.5.0: 永続 REPL とバックグラウンドプロセス（サーバー終了時にまとめて停止）
        self.repls = ReplManager()
        self.procs = ProcessManager(store.root / "process_logs")
        # サブエージェント／レビュー用モデル（UI から変更可。None = config の subagents.*_model → 親と同じ）
        self.sub_model: str | None = (cfg.state().get("sub_model") or None)
        if cfg.get("memory.enabled", True):
            from .config import expand
            self.memory = MemoryStore(expand(cfg.get("memory.db_path", "~/.apercode/memory.sqlite")),
                                      Embedder(llm.base_url, cfg.get("memory.embed_model")))
        T.load_builtin()

    def cancel(self, session_id: str):
        ev = self._cancel.get(session_id)
        if ev:
            ev.set()

    # ------------------------------------------------------------------ 権限
    # 「このセッションでは常に許可」でまとめて許可されるツール群（編集・実行系）
    EDIT_RUN_GROUP = {"write_file", "edit_file", "run_command", "mt5_compile", "mt5_backtest", "make_icon", "repl", "process_start", "process_stop",
                      "gui_launch", "gui_activate", "gui_input"}

    # 状態を見るだけのツール（同じ呼び出しを繰り返しても行き詰まりと見なさない）
    OBSERVE_TOOLS = {"screenshot", "gui_windows", "browser_screenshot", "browser_read", "browser_console", "process_status", "process_logs"}

    def _session_allowed(self, session: Session) -> set[str]:
        """セッションごとの常時許可（メモリ上 + セッション JSON に永続化）。"""
        s = self.session_allow.setdefault(session.id, set())
        s.update(getattr(session, "allow", []) or [])
        return s

    def _grant(self, session: Session, key: str):
        self._session_allowed(session).add(key)
        session.allow = sorted(self._session_allowed(session))
        self.store.save(session)

    def _dangerous(self, name: str, args: dict) -> str | None:
        """取り返しのつかない操作なら理由を返す（常時許可の対象外にする）。"""
        import re
        if name == "restore_backup":
            return "バックアップからの復元"
        if name not in ("run_command", "process_start", "repl"):
            return None
        cmd = str(args.get("command", "")) if name != "repl" else str(args.get("code", ""))
        pats = self.cfg.get("permissions.dangerous_commands") or DEFAULT_DANGEROUS
        for pat in pats:
            try:
                if re.search(pat, cmd):
                    return f"危険なコマンド（{pat}）"
            except re.error:
                continue
        return None

    def _decide(self, session: Session, name: str, args: dict) -> str:
        mode = self.cfg.permission(name)
        if mode != "deny" and name in self._force_ask.get(session.id, ()):
            return "ask"                          # v2.0.0: ピアからの依頼では、実行・画面・外部アクセス系は必ず承認方針に通す
        if mode in ("allow", "deny"):
            return mode
        allowed = self._session_allowed(session)
        if name in allowed or (name in self.EDIT_RUN_GROUP and "edit_run" in allowed):
            return "allow"
        if name == "run_command":
            cmd = str(args.get("command", "")).strip()
            for pat in self.cfg.get("permissions.auto_allow_commands", []) or []:
                if cmd.startswith(pat):
                    return "allow"
        return "ask"

    # ------------------------------------------------------------------ 入口
    async def run(self, session: Session, user_text: str, emit: Emit, ask_approval: AskApproval,
                  attachments: list[dict] | None = None, tool_names: list[str] | None = None,
                  force_ask: set[str] | None = None, msg_kind: str | None = None, brief_source: str | None = None):
        cancel = asyncio.Event()
        self._cancel[session.id] = cancel
        if force_ask:
            self._force_ask[session.id] = set(force_ask)
        else:
            self._force_ask.pop(session.id, None)
        project = Path(session.project_dir)
        backup = BackupManager(self.cfg, project)
        backup.begin_turn()
        verify = VerifyState()   # 検証が無効でも、行き詰まり回数などの記録には使う
        # 前ターンが LLM エラーや未解決で終わっていれば、失敗回数を持ち越す（クラウド相談の発動条件がリセットされないように）
        verify.stuck_count = int(getattr(session, "stuck_carry", 0) or 0)
        if self.cfg.get("verify.enabled", True) and str(self.cfg.get("verify.lock_tests", "ask")) != "off":
            verify.test_baseline = V.snapshot_tests(project, self.cfg.get("verify.test_patterns") or None)
        ctx = T.ToolContext(self.cfg, project, depth=0, memory=self.memory, backup=backup, verify=verify,
                            browser=self.browser, files_dir=self.store.root / f"{session.id}_files",
                            session_id=session.id, repls=self.repls, procs=self.procs)
        # v2.2.0: 汚染状態（外部の内容を読んだか）はセッションに保存し、子エージェントとも共有する
        if not isinstance(getattr(session, "taint", None), dict) or "active" not in session.taint:
            session.taint = SEC.new_state()
        ctx.taint = session.taint
        known = self._known_domains.setdefault(session.id, set())
        for m in session.messages:
            if m.get("role") == "user" and not m.get("kind"):
                known |= SEC.domains_in(m.get("content") or "")
        known |= SEC.domains_in(user_text)
        # v1.9.0: 作業フェーズとチェックポイント
        ph = PH.PhaseState.from_dict(getattr(session, "phase", None))
        if self.cfg.get("phases.enabled", True):
            ctx.phase = ph
            ctx.checkpoints = CheckpointStore(project, session.id, int(self.cfg.get("phases.keep_checkpoints", 30)),
                                              float(self.cfg.get("backup.max_file_mb", 20)))

        def _save():
            session.phase = ph.to_dict() if ctx.phase is not None else {}
            self.store.save(session)
        project_tags = detect_project_tags(project)
        memories_text = await self._recall(user_text, project, project_tags, emit)
        state = LoopState(messages=session.messages,
                          system=build_system_prompt(project, self.cfg.workspace_root, memories_text),
                          tool_names=tool_names, ctx=ctx, usage=session.usage,
                          last_prompt_tokens=session.last_prompt_tokens,
                          on_save=_save, phase=ctx.phase)

        start_len = len(session.messages)
        user_msg = {"role": "user", "content": user_text, "ts": time.time()}
        if msg_kind:
            user_msg["kind"] = msg_kind
        # v2.1.0: 会話モードか作業モードか。auto は会話から始め、ファイルの変更・実行が必要になったらユーザーに確認して作業へ
        mode = str(getattr(session, "mode", "auto") or "auto")
        if mode == "work":
            working = True
        elif mode == "chat":
            working = False
        else:
            working = bool(session.working or ph.active or BR.path_for(project, session.id).exists())
        session.working = working
        state.chat_mode = not working
        state.qna = bool(getattr(session, "pause_pending", False))
        session.pause_pending = False
        if attachments:
            user_msg.update(self._store_attachments(session, user_text, attachments))
        session.messages.append(user_msg)
        if not state.chat_mode:
            await self._prepare_brief(state, session, project, brief_source or user_text, emit)
        if state.chat_mode:
            pass
        elif state.clarify:
            # v2.0.0: 指示書に重大な不足がある → 作業を始めずにユーザーへ確認する（返事を指示書に追記して開始）
            q = self._clarify_message(state.clarify)
            session.messages.append({"role": "assistant", "content": q, "tool_calls": [], "ts": time.time()})
            session.clarify_pending = True
            await emit({"type": "text", "delta": q})
            await emit({"type": "info", "text": "指示書に足りない点があるため、作業の前に確認しています。返事を送ると指示書に追記して作業を始めます"})
        else:
            await self._phase_begin(state, session, user_text, emit, force=state.clarified)
        if session.title in ("新しいセッション", "New session"):
            session.title = user_text.strip().splitlines()[0][:40]
        _save()
        max_iter = int(self.cfg.get("llm.max_iterations", 40))
        if state.phase is not None and state.phase.active:
            max_iter = max(max_iter, int(self.cfg.get("phases.max_iterations", 80)))
        try:
            if not state.clarify:
                await self._loop(state, session, emit, ask_approval, cancel, max_iter=max_iter)
            if backup.saved:
                await emit({"type": "info", "text": f"変更前のファイル {len(backup.saved)} 件を {backup.dirname}/{backup._stamp}/ に退避しました"})
            if verify.changes and self.cfg.get("verify.enabled", True):
                await emit({"type": "verify_summary", **verify.summary()})
        finally:
            session.last_prompt_tokens = state.last_prompt_tokens
            self._cancel.pop(session.id, None)
            self._force_ask.pop(session.id, None)
            # 失敗回数の持ち越し: 未解決（テスト失敗・自動検証 NG・LLM エラー）なら次ターンへ、解決していればリセット
            unresolved = (verify.tests is not None and verify.tests.detected and not verify.tests.ok) or \
                         any(verify.check_failures.values()) or verify.llm_error
            total = verify.stuck_count + verify.test_rounds + sum(verify.check_failures.values())
            session.stuck_carry = min(total, 10) if unresolved else 0
            # v2.1.0: auto で作業が終わった（指示書が片付き、作業フェーズも終わった）→ 次の入力からは会話モードに戻る
            if mode == "auto" and session.working and not state.switch_to and not ph.active and \
                    (self.cfg.get("brief.enabled", True) or self.cfg.get("phases.enabled", True)) and \
                    not BR.path_for(project, session.id).exists():
                session.working = False
            _save()
            await emit({"type": "mode", "mode": mode, "working": session.working})
            await emit({"type": "done", "usage": session.usage,
                        "context": self._context_info(state)})
        # 振り返り（教訓抽出）は応答完了後にバックグラウンドで行う。失敗しても会話には影響させない
        if not cancel.is_set() and not state.clarify and not state.switch_to:
            turn = list(session.messages[start_len:])
            tainted = bool((session.taint or {}).get("active"))
            task = asyncio.create_task(self._reflect_safe(turn, project, project_tags + ([SEC.UNTRUSTED_TAG] if tainted else []), emit))
            self._bg_tasks.add(task)
            task.add_done_callback(self._bg_tasks.discard)
        if state.switch_to and not cancel.is_set():
            # v2.1.0: 会話から作業へ。ここまでの会話を材料に指示書と計画を作り、作業ディレクトリで作業を始める
            source = self._conversation_digest(session.messages)
            await self.run(session, PH.L(f"【作業開始】ここまでの会話で話した作業を、作業ディレクトリ {state.switch_to} で進めてください。",
                                         f"[Start work] Carry out the work discussed so far in the working directory {state.switch_to}."),
                           emit, ask_approval, msg_kind="mode", brief_source=source)

    async def _reflect_safe(self, turn: list[dict], project: Path, tags: list[str], emit: Emit) -> None:
        # 時間制限は _reflect の中で試行ごとに掛ける（サブ LLM → メイン LLM の順）。ここは全体の安全弁
        total = float(self.cfg.get("memory.reflect_timeout", 180)) * 4 + 120
        try:
            await asyncio.wait_for(self._reflect(turn, project, tags, emit), timeout=total)
        except asyncio.TimeoutError:
            await emit({"type": "info", "text": "教訓の抽出がタイムアウトしたためスキップしました"})
        except Exception as e:  # noqa: BLE001
            try:
                await emit({"type": "info", "text": f"教訓の抽出をスキップ: {e}"})
            except Exception:
                pass

    def _store_attachments(self, session: Session, user_text: str, attachments: list[dict]) -> dict:
        """添付を処理する。画像はセッション用フォルダにファイル保存し、テキストは本文に埋め込む。"""
        import base64
        files_dir = self.store.root / f"{session.id}_files"
        images: list[str] = []
        texts: list[str] = []
        content = user_text
        for i, a in enumerate(attachments[:10]):
            kind = a.get("kind")
            name = str(a.get("name") or f"attachment{i}")
            if kind == "image":
                data = str(a.get("data", ""))
                if "," in data:
                    header, b64 = data.split(",", 1)
                    ext = "png" if "png" in header else "jpg" if "jpe" in header else "webp" if "webp" in header else "gif" if "gif" in header else "png"
                else:
                    b64, ext = data, "png"
                try:
                    raw = base64.b64decode(b64)
                except Exception:
                    continue
                if len(raw) > 8 * 1024 * 1024:
                    continue
                files_dir.mkdir(parents=True, exist_ok=True)
                fname = f"{int(time.time()*1000)}_{i}.{ext}"
                (files_dir / fname).write_bytes(raw)
                images.append(fname)
            elif kind == "text":
                body = str(a.get("content", ""))[:60_000]
                texts.append(name)
                content += "\n\n" + t(f"[添付テキスト: {name}]") + f"\n```\n{body}\n```"
        out: dict = {"content": content}
        if images:
            out["images"] = images  # ファイル名（セッション用フォルダ内）
        if texts:
            out["text_attachments"] = texts
        return out

    def _image_b64(self, session: Session, fname: str) -> str | None:
        import base64
        p = self.store.root / f"{session.id}_files" / fname
        if not p.is_file():
            return None
        return base64.b64encode(p.read_bytes()).decode()

    async def compact_now(self, session: Session, emit: Emit) -> None:
        """UI からの手動圧縮。"""
        project = Path(session.project_dir)
        ctx = T.ToolContext(self.cfg, project)
        state = LoopState(messages=session.messages, system="", tool_names=None, ctx=ctx,
                          usage=session.usage, on_save=lambda: self.store.save(session))
        await self._compact(state, session, emit, force=True)
        session.last_prompt_tokens = 0
        self.store.save(session)
        await emit({"type": "done", "usage": session.usage, "context": self._context_info(state)})

    # ------------------------------------------------------------------ ループ本体
    async def _loop(self, st: LoopState, session: Session, emit: Emit, ask_approval: AskApproval,
                    cancel: asyncio.Event, max_iter: int) -> str:
        """LLM とツールを往復する。最後のアシスタント発話を返す。

        行き詰まり検知: 同じツール呼び出しの繰り返し／連続エラーを検知したら、Web 検索など別アプローチを
        促すメッセージを履歴に差し込む。上限に達したら黙って止まらず、状況報告を生成させる。
        """
        import json as _json
        last_text = ""
        sig_count: dict[str, int] = {}      # 同一ツール呼び出しの回数
        consecutive_errors = 0
        nudges = 0
        searched_recently = False
        limit_hit = False
        no_progress = 0                      # 進捗（ファイル変更・テスト・相談）の無いツール呼び出しの連続回数
        PROGRESS_TOOLS = {"write_file", "edit_file", "run_tests", "mt5_compile", "mt5_backtest", "ask_cloud", "save_memory", "restore_backup",
                          "repl", "process_start", "check_js",
                          "gui_input", "digest", "ask_peer", "peer_reply", "cloud_chat"}   # v2.0.1: 会話では送信・整理が進捗
        np_limit = int(self.cfg.get("stuck.no_progress_calls", 12))
        repeat_limit = int(self.cfg.get("stuck.repeat_calls", 3))
        err_limit = int(self.cfg.get("stuck.consecutive_errors", 3))
        empty_nudges = 0                     # 思考だけで本文もツール呼び出しも無い応答への差し戻し回数
        llm_retry = 0                        # v1.7.2: LLM の一時エラー（500 など）をやり直した回数（連続）
        code_nudges = 0                      # コードをチャットに貼るだけで終わった応答への差し戻し回数
        think_limit = int(self.cfg.get("llm.think_limit_chars", 20000) or 0)   # v1.11.0: 思考がこれを超えたら打ち切る（0 = 無制限）
        next_think: str | None = None        # 打ち切った次の 1 回は思考なしで求める
        for _ in range(max_iter):
            if cancel.is_set():
                await emit({"type": "info", "text": "中断しました"})
                break
            if st.ctx.depth == 0:
                await self._compact(st, session, emit)

            text_parts: list[str] = []
            tool_calls: list[dict] = []
            think_chars = 0
            think_cut = False
            await emit({"type": "status", "phase": "thinking", "detail": st.model or self.llm.model})
            history = self._history(st.messages, session, with_images=st.ctx.depth == 0)
            try:
                try:
                    stream = self.llm.chat(self._system_with_brief(st), history, T.schemas(self._tools_for(st)), st.model,
                                           think=next_think)
                    next_think = None
                    first = await stream.__anext__()
                except StopAsyncIteration:
                    first = None
                except Exception as e:
                    # 画像非対応モデルの場合は画像を外して再試行
                    if any(m.get("images") for m in history) and any(w in str(e).lower() for w in ("image", "vision", "multimodal")):
                        await emit({"type": "info", "text": "このモデルは画像に対応していないため、画像を除いて送信します"})
                        history = self._history(st.messages, session, with_images=False)
                        stream = self.llm.chat(self._system_with_brief(st), history, T.schemas(self._tools_for(st)), st.model)
                        first = await stream.__anext__()
                    else:
                        raise

                async def _chain():
                    if first is not None:
                        yield first
                    async for ev in stream:
                        yield ev

                async for kind, data in _chain():
                    if cancel.is_set():
                        break
                    if kind == "text":
                        if not text_parts:
                            await emit({"type": "status", "phase": "generating", "detail": ""})
                        text_parts.append(data)
                        await emit({"type": "text", "delta": data})
                    elif kind == "thinking":
                        think_chars += len(data)
                        await emit({"type": "think", "delta": data})
                        if think_limit and think_chars > think_limit and not text_parts and not tool_calls:
                            think_cut = True
                            break
                    elif kind == "tool_call":
                        tool_calls.append(data)
                    elif kind == "done":
                        st.usage["prompt_tokens"] += data.get("prompt_tokens", 0)
                        st.usage["completion_tokens"] += data.get("completion_tokens", 0)
                        st.last_prompt_tokens = data.get("prompt_tokens", 0) or st.last_prompt_tokens
                        # ヘッダーの使用量・コンテキスト表示をリアルタイムに更新（子はコンテキスト無しで使用量のみ）
                        await emit({"type": "usage", "usage": st.usage,
                                    "context": self._context_info(st) if st.ctx.depth == 0 else None})
            except Exception as e:  # LLM 通信エラー
                es = str(e)
                transient = ("サーバーエラー 5" in es or "接続が途中で切れました" in es or "500" in es) and not cancel.is_set()
                if transient and llm_retry < 1:
                    # v1.7.2: サブ LLM の読み込みと重なって Ollama が一時的に 500 を返すことがある →
                    # 背景要約を止め、サブ LLM を CPU に切り替えてから 1 回だけやり直す
                    llm_retry += 1
                    helper_involved = self._helper_busy > 0 or time.time() - self._helper_last < 60
                    bgc = self._bg_compact.pop(session.id, None) if st.ctx.depth == 0 else None
                    if bgc is not None and not bgc["task"].done():
                        bgc["task"].cancel()
                        helper_involved = True
                    if helper_involved:
                        self._helper_gpu_ok = False
                    await emit({"type": "info", "text": ("サブ LLM の処理と重なって LLM サーバーがエラーを返しました。サブ LLM を CPU に切り替えて、もう一度実行します"
                                                          if helper_involved else "LLM サーバーが一時的なエラーを返したため、もう一度実行します") + f"（{es[:100]}）"})
                    await asyncio.sleep(3)
                    continue
                if st.ctx.verify is not None:
                    st.ctx.verify.llm_error = True
                    st.ctx.verify.stuck_count += 1   # 落ちた分も「行き詰まり」として数える
                await emit({"type": "error", "text": f"LLM エラー: {e}"})
                break

            llm_retry = 0
            if think_cut:
                # v1.11.0: 思考が長すぎる（思考のループ）。生成を止め、次の 1 回は思考なしで結論かツール呼び出しを求める
                try:
                    await stream.aclose()
                except Exception:  # noqa: BLE001
                    pass
                next_think = "off"
                await emit({"type": "info", "text": f"思考が長すぎるため打ち切りました（{think_chars:,} 文字）。次は思考なしで結論かツール呼び出しを求めます"})
                st.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content": t(
                    f"【システム】考えが長くなりすぎたため（{think_chars:,} 文字）打ち切りました。これ以上考え込まず、"
                    "次に行う 1 つの操作をツールで実行するか、分かっていることと次の一手を 5 行以内で書いてください。")})
                if st.on_save:
                    st.on_save()
                continue
            content = "".join(text_parts)
            # coder 系モデルが tool calling を使わず本文に JSON でツール呼び出しを書いた場合の救済
            if not tool_calls and content:
                extracted = self.llm.extract_text_tool_calls(content, set(self._tools_for(st)))
                if extracted:
                    tool_calls = extracted
                    await emit({"type": "info", "text": f"本文に書かれたツール呼び出し（{', '.join(tc['name'] for tc in extracted)}）を解析して実行します"})
            last_text = content or last_text
            st.messages.append({"role": "assistant", "content": content, "tool_calls": tool_calls,
                                "ts": time.time()})
            if st.on_save:
                st.on_save()
            if not tool_calls and not cancel.is_set():
                # ---- 思考だけで終わった（本文が空）→ 結論かツール呼び出しを求める
                if not content.strip() and empty_nudges < 2:
                    empty_nudges += 1
                    why = "思考だけで終わり、本文もツール呼び出しもありませんでした" + (f"（思考 {think_chars:,} 文字）" if think_chars else "")
                    await emit({"type": "info", "text": why + "。結論またはツール呼び出しを求めます"})
                    st.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content": t(
                        "【システム】" + why + "。長く考え込まず、次のどちらかをしてください: (a) 必要なツールを呼ぶ "
                        "(b) 結論と次の一手を 5 行以内で書く。")})
                    if st.on_save:
                        st.on_save()
                    continue
                # ---- コードをチャットに貼っただけ（ファイルに書いていない）→ ツールで書くよう求める
                if st.ctx.depth == 0 and code_nudges < 1 and self._phase_allows_code(st) and self._code_only_reply(st, content):
                    code_nudges += 1
                    await emit({"type": "info", "text": "コードがチャットに書かれただけでファイルに反映されていません。write_file / edit_file で書き込むよう求めます"})
                    st.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content": t(
                        "【システム】コードをチャットに書くだけでは何も実行・保存されません。write_file / edit_file ツールで実際のファイルに"
                        "書き込み、run_tests（または run_command / check_js）で動作を確認してから完了報告してください。"
                        "ユーザーが説明だけを求めている場合は、その旨を一言書いて終了して構いません。")})
                    if st.on_save:
                        st.on_save()
                    continue
                # ---- v1.9.0: 作業フェーズ（親のみ）。本文だけの応答 = そのフェーズの区切り
                if self._phase_on(st):
                    nxt = await self._phase_advance(st, session, emit, "reply", content)
                    if nxt:
                        st.messages.append({"role": "user", "kind": "nudge", "content": nxt, "ts": time.time()})
                        if st.on_save:
                            st.on_save()
                        sig_count.clear()
                        consecutive_errors = 0
                        no_progress = 0
                        continue
                    if self._phase_on(st) and st.phase.phase == "report":
                        break           # 報告フェーズ: 巻き戻し済みなので完了ゲートは掛けない
                # ---- 完了ゲート（親のみ）: テスト未実行なら自動実行、変更が大きければレビュー
                if st.ctx.depth == 0 and st.ctx.verify is not None and self.cfg.get("verify.enabled", True) and not cancel.is_set():
                    gate = await self._completion_gate(st, session, emit, ask_approval, cancel)
                    if gate:
                        st.messages.append({"role": "user", "kind": "nudge", "content": t(gate), "ts": time.time()})
                        if st.on_save:
                            st.on_save()
                        sig_count.clear()
                        consecutive_errors = 0
                        continue
                break

            repeated = False
            for tc in tool_calls:
                if cancel.is_set():
                    break
                sig = tc.get("name", "") + ":" + _json.dumps(tc.get("args", {}), sort_keys=True, ensure_ascii=False)[:500]
                if tc.get("name") not in self.OBSERVE_TOOLS and not self._is_wait(tc):   # 画面の確認・返事の待機は「繰り返し」に数えない（v1.11.0 / v2.0.1）
                    sig_count[sig] = sig_count.get(sig, 0) + 1
                    if sig_count[sig] >= repeat_limit:
                        repeated = True
                if tc.get("name") in ("web_search", "fetch_url", "search_memory"):
                    searched_recently = True
                if st.paused or st.switch_to:
                    result = PH.L("（一時停止・モード切り替えのため実行していません）", "(not executed: paused / mode switch)")
                else:
                    result = await self._exec_tool(st, session, tc, emit, ask_approval, cancel)
                is_err = result.startswith(("エラー", "不明", "ユーザーがこの操作を拒否", "Error", "Unknown", "The user denied")) or "(exit " in result and "(exit 0)" not in result
                consecutive_errors = consecutive_errors + 1 if is_err else 0
                no_progress = 0 if (tc.get("name") in PROGRESS_TOOLS and not is_err) else no_progress + 1
                st.messages.append({"role": "tool", "tool_call_id": tc["id"], "name": tc["name"],
                                    "content": result, "ts": time.time()})
                if st.on_save:
                    st.on_save()
                if self._phase_on(st) and st.phase.phase in ("implement", "fix") and not is_err:
                    self._phase_note_tool(st, tc)

            # ---- v2.1.0: 一時停止・作業への切り替え → このターンを止める（LLM には続けさせない）
            if st.ctx.depth == 0 and (st.paused or st.switch_to):
                if st.paused:
                    await emit({"type": "info", "text": "一時停止しました。確認したいことを入力してください（操作はまだ実行していません）"})
                break

            # ---- v1.9.0: set_plan / step_done の通知 → フェーズを進める
            if self._phase_on(st) and st.phase.signal is not None and not cancel.is_set():
                kind, data = st.phase.signal
                st.phase.signal = None
                nxt = await self._phase_advance(st, session, emit, kind, data)
                if nxt:
                    st.messages.append({"role": "user", "kind": "nudge", "content": nxt, "ts": time.time()})
                    if st.on_save:
                        st.on_save()
                sig_count.clear()
                consecutive_errors = 0
                no_progress = 0
                continue

            # ---- 行き詰まり検知 → 別アプローチ（Web 検索・クラウド相談）を促す
            stalled = np_limit > 0 and no_progress >= np_limit and st.ctx.depth == 0
            stuck = repeated or (consecutive_errors >= err_limit and not searched_recently) or stalled
            if stuck and self._phase_on(st) and st.phase.phase in ("implement", "fix") and not cancel.is_set():
                # v1.9.0: 実装・修正中の行き詰まり → 直前のチェックポイントへ巻き戻して調査へ
                why = ("同じツール呼び出しを繰り返しました" if repeated else
                       f"進捗のない呼び出しが {no_progress} 回続きました" if stalled else f"ツールの失敗が {consecutive_errors} 回連続しました")
                if st.ctx.verify is not None:
                    st.ctx.verify.stuck_count += 1
                nxt = await self._phase_fail(st, session, emit, why)
                st.messages.append({"role": "user", "kind": "nudge", "content": nxt, "ts": time.time()})
                if st.on_save:
                    st.on_save()
                sig_count.clear()
                consecutive_errors = 0
                no_progress = 0
                searched_recently = False
                continue
            if stuck and nudges < 3:
                nudges += 1
                if repeated:
                    why = "同じツール呼び出しを 3 回以上繰り返しています"
                elif stalled:
                    why = f"ファイルの変更やテストをせずに調査だけを {no_progress} 回続けています（進捗なし）"
                    no_progress = 0
                else:
                    why = f"ツールの失敗が {consecutive_errors} 回連続しています"
                if st.ctx.verify is not None:
                    st.ctx.verify.stuck_count += 1
                cloud_hint = ""
                if self.cfg.get("cloud.enabled", False) and st.ctx.depth == 0:
                    cloud_hint = " (5) それでも駄目なら ask_cloud で、目的・エラー・試したこと・関連ファイルを添えてクラウド AI に相談する。"
                if stalled:
                    nudge = (f"【システム】{why}。いったん調査を止めて、次を短く書き出してください: "
                             "(a) これまでに立てた仮説と、それぞれを検証した結果（否定された仮説は捨てる） (b) まだ確認していない層"
                             "（表示・初期化・ライブラリの呼び出し方・環境・プロセス/ポート） (c) 次に試す 1 つの具体的な変更。"
                             "エラーが出ないのに動かない場合は、コードを読み直す前に「存在確認」（DOM 要素・canvas・プロセス・ポート・ログ行が"
                             "本当にあるか）を行ってください。ライブラリの初期化・呼び出し方は記憶で書かず、そのバージョンの README を fetch_url で読んで確認してください。"
                             + (" 整理しても原因が絞れなければ、ask_cloud で目的・症状・試したことを添えてクラウド AI に相談してください。"
                                if self.cfg.get("cloud.enabled", False) else ""))
                else:
                    nudge = (f"【システム】{why}。同じ操作をこれ以上繰り返さないでください。次の手順で別のアプローチを取ってください: "
                             "(1) 直近のエラー文を読み直して原因の仮説を立てる (2) search_memory で過去の解決策を確認 "
                             "(3) web_search でエラー文・ライブラリ名を検索し fetch_url で解決策を読む (4) 別の方法を試す。" + cloud_hint +
                             "それでも解決しない場合は、試したこと・分かったこと・残る選択肢を整理してユーザーに報告して終了してください。")
                st.messages.append({"role": "user", "kind": "nudge", "content": t(nudge), "ts": time.time()})
                await emit({"type": "info", "text": f"行き詰まりを検知（{why}）。" + ("仮説の整理と別の層の確認を促しました" if stalled else "Web 検索などの別アプローチを促しました")})
                sig_count.clear()
                consecutive_errors = 0
                searched_recently = False
        else:
            limit_hit = True

        # ---- 上限到達: 黙って止まらず、状況報告を生成させる
        if limit_hit and not cancel.is_set():
            await emit({"type": "info", "text": f"ツール呼び出し上限 ({max_iter}) に達しました。状況報告を生成します"})
            st.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content": t(
                "【システム】ツール呼び出しの上限に達したため、いったん作業を止めます。ツールは使わずに、"
                "ここまでに完了したこと・未完了のこと・発生している問題と原因の推測・次に試すべき手順を簡潔に報告してください。"
                "ユーザーが「続けて」と送れば作業を再開できます。")})
            await emit({"type": "status", "phase": "generating", "detail": "状況報告"})
            parts: list[str] = []
            try:
                async for kind, data in self.llm.chat(st.system, self._history(st.messages, session, with_images=False),
                                                      [], st.model):
                    if kind == "text":
                        parts.append(data)
                        await emit({"type": "text", "delta": data})
                    elif kind == "done":
                        st.usage["prompt_tokens"] += data.get("prompt_tokens", 0)
                        st.usage["completion_tokens"] += data.get("completion_tokens", 0)
            except Exception as e:
                await emit({"type": "error", "text": f"状況報告の生成に失敗: {e}"})
            report = "".join(parts).strip()
            if report:
                st.messages.append({"role": "assistant", "content": report, "tool_calls": [], "ts": time.time()})
                last_text = report
            if st.on_save:
                st.on_save()
            if st.ctx.depth == 0:
                await emit({"type": "info", "text": "「続けて」と送ると作業を再開します（上限は config.yaml の llm.max_iterations で変更可）"})
        return last_text

    _CODE_FENCE = re.compile(r"```(?!tool_call)([\w+-]*)\n(.*?)```", re.S)

    def _code_only_reply(self, st: LoopState, content: str) -> bool:
        """コードブロック（8 行以上）を含むのに、このターンでファイルを書いていない応答か。"""
        if "write_file" not in self._tools_for(st):
            return False
        vs = st.ctx.verify
        if vs is not None and vs.changes:
            return False
        for m in self._CODE_FENCE.finditer(content or ""):
            lang = (m.group(1) or "").lower()
            if lang in ("", "text", "txt", "diff", "json", "yaml", "yml", "md", "markdown", "bash", "sh", "shell", "console"):
                continue
            if m.group(2).count("\n") >= 8:
                return True
        return False

    def _tools_for(self, st: LoopState) -> list[str]:
        """LLM に見せるツール一覧。クラウド相談が無効なら ask_cloud を隠す。"""
        names = list(st.tool_names) if st.tool_names is not None else [t.name for t in T.all_tools()]
        if not self.cfg.get("cloud.enabled", False):
            names = [n for n in names if n not in ("ask_cloud", "cloud_chat")]
        if not self.cfg.get("peers"):
            names = [n for n in names if not n.startswith("peer_") and n != "ask_peer"]
        if st.ctx.browser is None:
            names = [n for n in names if n not in BROWSER_TOOLS]
        if st.ctx.depth != 0 or st.brief_path is None or not st.brief_path.exists():
            names = [n for n in names if n != "finish_brief"]
        return self._phase_filter(st, names)

    # ------------------------------------------------------------------ v1.8.0: 作業の指示書
    def _system_with_brief(self, st: LoopState) -> str:
        """システムプロンプト + 作業の指示書（LLM を呼ぶたびにファイルを読み直す）+ 作業フェーズ。"""
        return self._system_brief_only(st) + self._phase_block(st) + self._chat_block(st)

    def _chat_block(self, st: LoopState) -> str:
        """v2.1.0: 会話モードの説明。調べもの・質問には手順書を作らずそのまま答える。"""
        if not st.chat_mode or st.ctx.depth != 0:
            return ""
        return PH.L("\n\n## いまは会話モード\n- 質問・相談・調べもの（Web 検索・ファイルを読む）には、計画や手順書を作らずにそのまま答える\n"
                    "- ファイルの変更やコマンドの実行が必要になったら、そのツールを呼んでよい。AperCode がユーザーに作業を始めるかを確認する\n",
                    "\n\n## Conversation mode\n- Answer questions, discussions and research (web search, reading files) directly, without plans or task briefs\n"
                    "- When files must be changed or commands run, just call the tool: AperCode asks the user whether to start working\n")

    def _system_brief_only(self, st: LoopState) -> str:
        if st.brief_path is None:
            return st.system
        body = BR.read(st.brief_path, int(self.cfg.get("brief.max_chars", 4000)))
        if not body:
            return st.system                     # ユーザーが削除した / 目的達成で片付け済み
        body = re.sub(r"^<!--.*?-->\s*", "", body, flags=re.S)
        from .prompts import prompt_language
        en = prompt_language() == "en"
        rel = BR.rel(st.ctx.project_dir, st.brief_path)
        if st.ctx.depth == 0:
            if en:
                block = (f"\n\n## Task brief (the user's goal — highest priority)\nFile: {rel} (the user may edit it; it is re-read for every request)\n\n"
                         f"{body}\n\n- At every step, check that what you are doing serves this goal, requirements and constraints. If you drifted, come back.\n"
                         "- When every item under Done when is satisfied and verification (tests etc.) passes, call finish_brief, then report completion.\n")
            else:
                block = (f"\n\n## 作業の指示書（ユーザーの目的。最優先で守る）\nファイル: {rel}（ユーザーが編集することがある。毎回読み直して渡している）\n\n"
                         f"{body}\n\n- 各段階で、今の作業がこの目的・要件・制約に沿っているか確かめる。脇道にそれていたら戻る\n"
                         "- 完了条件をすべて満たし、検証（テスト等）も通ったら finish_brief を呼んで指示書を片付け、完了報告する\n")
        else:
            short = body[:1500]
            block = (f"\n\n## Parent task goal (for reference)\n{short}\n- Your job is part of this goal. Do only the task you were given.\n" if en else
                     f"\n\n## 親タスクの目的（参考）\n{short}\n- あなたの担当はこの目的の一部。与えられたタスクだけを行う\n")
        return st.system + block

    async def _prepare_brief(self, st: LoopState, session: Session, project: Path, user_text: str, emit: Emit) -> None:
        if not self.cfg.get("brief.enabled", True):
            return
        bp = BR.path_for(project, session.id)
        rel = BR.rel(project, bp)
        try:
            if not bp.exists():
                session.clarify_pending = False       # 指示書が消されていれば確認待ちも取り消す
            if bp.exists() and getattr(session, "clarify_pending", False):
                # v2.0.0: 作業前の確認への回答（短い返事でも追記して、作業を始める）
                session.clarify_pending = False
                BR.append_answer(bp, user_text)
                st.brief_path = bp
                st.clarified = True
                await emit({"type": "brief", "state": "updated", "path": rel,
                            "text": f"確認への回答を作業の指示書に追記しました（{rel}）"})
                return
            if bp.exists():
                if BR.is_followup(user_text):
                    BR.append_instruction(bp, user_text)
                    await emit({"type": "brief", "state": "updated", "path": rel,
                                "text": f"指示を作業の指示書に追記しました（{rel}）"})
                st.brief_path = bp
                return
            if not BR.is_meaningful(user_text, int(self.cfg.get("brief.min_chars", 15))):
                return
            await emit({"type": "status", "phase": "thinking", "detail": t("作業の指示書を作成中")})
            from .prompts import prompt_language
            prompt = BR.BRIEF_PROMPT_EN if prompt_language() == "en" else BR.BRIEF_PROMPT
            hm = self._helper_model()
            body = ""
            for model in ([hm] if hm else []) + [None]:
                try:
                    opts = await self._helper_options(model, len(user_text) + 2000) if model else None
                    raw = await asyncio.wait_for(self._complete_nothink(prompt, user_text, model, opts),
                                                 timeout=float(self.cfg.get("brief.timeout", 90)))
                    body = BR.clean_llm_output(raw)
                    if body:
                        break
                except Exception:  # noqa: BLE001
                    continue
            if not body or "#" not in body:
                body = ("# Goal\n" if prompt_language() == "en" else "# 目的\n") + user_text.strip()
            BR.write_new(bp, body, user_text)
            st.brief_path = bp
            await emit({"type": "brief", "state": "created", "path": rel,
                        "text": f"作業の指示書を作成しました（{rel}）。LLM は毎回これを読んで目的を確認します。目的を達成すると自動で削除されます"})
            await self._clarify_brief(st, bp, rel, emit)
        except Exception as e:  # noqa: BLE001
            await emit({"type": "info", "text": f"作業の指示書を作成できませんでした: {e}"})

    async def _clarify_brief(self, st: LoopState, bp: Path, rel: str, emit: Emit) -> None:
        """v2.0.0: 指示書の不足を点検する。重大な不足は st.clarify（作業前にユーザーへ質問）、軽微なものは仮定として指示書に書く。"""
        mode = str(self.cfg.get("brief.clarify", "ask")).lower()
        if mode == "off" or st.ctx.depth != 0:
            return
        await emit({"type": "status", "phase": "thinking", "detail": t("指示書の不足を点検中")})
        from .prompts import prompt_language
        prompt = BR.CLARIFY_PROMPT_EN if prompt_language() == "en" else BR.CLARIFY_PROMPT
        try:
            raw = await asyncio.wait_for(self._complete_nothink(prompt, BR.read(bp, 6000), None, None),
                                         timeout=float(self.cfg.get("brief.timeout", 90)))
        except Exception as e:  # noqa: BLE001  点検できなくても作業は止めない
            await emit({"type": "info", "text": f"指示書の点検をスキップしました: {str(e)[:120]}"})
            return
        questions, assumptions = BR.parse_clarify(raw)
        if mode != "ask" and questions:
            assumptions = [PH.L(f"（未確認）{q} → AperCode が妥当な方を選ぶ", f"(unconfirmed) {q} -> AperCode picks a reasonable option")
                           for q in questions] + assumptions
            questions = []
        if assumptions:
            BR.append_assumptions(bp, assumptions)
            await emit({"type": "brief", "state": "updated", "path": rel,
                        "text": f"指示書に AperCode の仮定を {len(assumptions)} 件追記しました（{rel}）"})
        st.clarify = questions

    @staticmethod
    def _clarify_message(questions: list[str]) -> str:
        head = PH.L("作業を始める前に確認させてください。指示書に次の点が書かれていません。\n",
                    "Before I start, please confirm the following. The task brief does not say:\n")
        body = "\n".join(f"{i}. {q}" for i, q in enumerate(questions, 1))
        tail = PH.L("\n\n番号を付けて答えてください（「任せる」でも構いません）。回答は作業の指示書に追記して、作業を始めます。",
                    "\n\nPlease answer by number (\"up to you\" is fine). Your answer is added to the task brief and the work starts.")
        return head + body + tail

    # ------------------------------------------------------------------ v1.9.0: 作業フェーズとチェックポイント
    def _phase_on(self, st: LoopState) -> bool:
        return st.ctx.depth == 0 and st.phase is not None and st.phase.active

    def _phase_allows_code(self, st: LoopState) -> bool:
        return not self._phase_on(st) or st.phase.phase in ("implement", "fix")

    def _phase_filter(self, st: LoopState, names: list[str]) -> list[str]:
        """今のフェーズで使えるツールだけに絞る。フェーズ外では set_plan / step_done を隠す。"""
        if not self._phase_on(st):
            return [n for n in names if n not in PH.PHASE_ONLY_TOOLS]
        p = st.phase.phase
        if p in ("implement", "fix"):
            return [n for n in names if n != "finish_brief"]      # set_plan は残りの手順の出し直しに使える（v1.11.0）
        ro = set(T.READ_ONLY_TOOLS)
        allow = (ro | {"set_plan"} if p == "plan" else
                 ro | set(PH.INVESTIGATE_EXTRA) if p == "investigate" else
                 ro | set(PH.DONE_EXTRA) if p == "done_check" else set())
        return [n for n in names if n in allow]

    def _phase_denied(self, st: LoopState, name: str) -> str:
        p = st.phase.phase
        hint = {"plan": PH.L("まず読み取り系ツールで調べ、set_plan で手順を登録してください。",
                             "Investigate with read-only tools first, then register the steps with set_plan."),
                "investigate": PH.L("調査フェーズではファイルを変更できません。調べ終えたら新しい方針を書いて終えてください。",
                                    "Files cannot be changed while investigating. Write the new approach when done."),
                "done_check": PH.L("足りない点があれば set_plan で手順を追加してください。",
                                   "If something is missing, add steps with set_plan."),
                "report": PH.L("ツールは使わずに報告を書いてください。", "Write the report without tools.")}.get(p, "")
        return PH.L(f"ツール {name} は現在のフェーズ（{PH.label(p)}）では使えません。", f"Tool {name} is not available in the current phase ({PH.label(p)}). ") + hint

    def _phase_block(self, st: LoopState) -> str:
        if not self._phase_on(st):
            return ""
        last = st.ctx.checkpoints.last() if st.ctx.checkpoints is not None else None
        return PH.block(st.phase, max_fix=int(self.cfg.get("phases.max_fix_rounds", 3)),
                        cloud=bool(self.cfg.get("cloud.enabled", False)),
                        brief=st.brief_path is not None and st.brief_path.exists(),
                        checkpoint=label_of(last) if last else "-")

    async def _phase_emit(self, st: LoopState, emit: Emit) -> None:
        await emit({"type": "phase", **st.phase.view()})

    async def _phase_checkpoint(self, st: LoopState, emit: Emit, label: str) -> dict | None:
        cps = st.ctx.checkpoints
        if cps is None:
            return None
        anchor = st.messages[-1].get("ts") if st.messages else None
        try:
            item = cps.save(label, anchor, st.phase.to_dict())
        except OSError as e:
            await emit({"type": "info", "text": f"チェックポイントを保存できませんでした: {e}"})
            return None
        await emit({"type": "checkpoint", "id": item["id"], "label": label, "files": len(item["files"]),
                    "text": f"チェックポイント #{item['id']} を保存しました（{label}、追跡中のファイル {len(item['files'])} 件）"})
        return item

    async def _phase_begin(self, st: LoopState, session: Session, user_text: str, emit: Emit, force: bool = False) -> None:
        ph = st.phase
        if ph is None:
            return
        restart = bool(PH.RESTART_RE.search(user_text or ""))
        if ph.active and not restart:
            if ph.phase in ("report", "verify"):
                ph.phase = "implement"
                ph.fix_rounds = 0
                ph.investigations = 0
            if ph.phase in ("implement", "fix") and BR.is_followup(user_text):
                # v1.11.0: 作業中の追加指示・ヒントでは計画を立て直さない（毎回計画フェーズに戻ると操作系のツールが使えず作業が止まる）
                ph.fix_rounds = 0
                await emit({"type": "info", "text": "追加の指示を受けました。今の手順を続けます（残りの手順が合わなければ LLM が出し直します）"})
            elif ph.phase == "plan" and not ph.steps:
                # v1.9.1: 計画の途中でユーザーに確認していた → 返事を受けて計画を続ける（長さに関係なく再開）
                await emit({"type": "info", "text": "返事を受けて計画フェーズを続けます"})
            elif BR.is_followup(user_text):
                ph.replan = True
                ph.phase = "plan"
                await emit({"type": "info", "text": "追加の指示を受けたため、残りの手順を計画し直します"})
            else:
                await emit({"type": "info", "text": f"作業フェーズを再開します（{PH.label(ph.phase)}・手順 {min(ph.idx + 1, ph.n)}/{ph.n}）"})
            st.step_seq = -1          # 再開直後の検証ではテストを必ず実行する
            await self._phase_emit(st, emit)
            return
        if not restart and not force and not BR.is_meaningful(user_text, int(self.cfg.get("brief.min_chars", 15))):
            return
        if restart and ph.active:
            await emit({"type": "info", "text": "最初からやり直す指示を受けたため、計画を作り直します"})
        fresh = PH.PhaseState(active=True, phase="plan")
        for k in fresh.to_dict():
            setattr(ph, k, getattr(fresh, k))
        ph.signal = None
        await self._phase_checkpoint(st, emit, "開始時点")
        await self._phase_emit(st, emit)

    async def _phase_advance(self, st: LoopState, session: Session, emit: Emit, kind: str, data) -> str | None:
        """フェーズの区切り（set_plan / step_done / 本文だけの応答）で次のフェーズへ進める。履歴に入れる指示を返す（None = ターン終了）。"""
        ph = st.phase
        p = ph.phase
        vs = st.ctx.verify
        if p == "plan":
            steps = data if kind == "set_plan" else PH.parse_steps(data or "")
            if not steps:
                if kind == "reply":
                    if PH.asks_user(data or ""):
                        # v1.9.1: 計画に必要な確認をユーザーに求めて止まった → 計画フェーズのまま返事を待つ
                        await emit({"type": "info", "text": "計画の途中でユーザーに確認しています。返事を送ると計画フェーズから続けます"})
                        return None
                    ph.active = False        # 計画を立てずに回答した = 変更不要の質問・説明
                    await self._phase_emit(st, emit)
                return None
            ph.set_steps(steps)
            ph.phase = "implement"
            st.step_seq = vs.change_seq if vs is not None else -1
            await emit({"type": "info", "text": f"計画を登録しました（{ph.n} 手順）"})
            await self._phase_emit(st, emit)
            return PH.msg_start(ph)
        if p in ("implement", "fix") and kind == "set_plan":
            ph.replan = True                   # 完了済みの手順は残して、残りを置き換える
            ph.set_steps(data)
            ph.phase = "implement"
            st.step_seq = vs.change_seq if vs is not None else -1
            await emit({"type": "info", "text": f"残りの手順を出し直しました（全 {ph.n} 手順）"})
            await self._phase_emit(st, emit)
            return PH.msg_start(ph)
        if p in ("implement", "fix"):
            if kind == "reply" and st.qna:
                return None                    # v2.1.0: 一時停止の後、ユーザーの質問に答えただけ。手順の完了としては扱わない
            if kind == "reply":
                changed = vs is not None and vs.change_seq != st.step_seq
                if not changed and (data or "").rstrip().endswith(("?", "？")):
                    return None               # ユーザーへの質問で止まった。フェーズはそのまま（返事で再開）
            if kind in ("reply", "step_done"):
                evidence = (data or {}).get("evidence", "") if isinstance(data, dict) else (data or "")
                return await self._phase_verify(st, session, emit, evidence)
            return None
        if p == "investigate":
            if kind == "reply":
                ph.approach = (data or "").strip()[:1500]
                ph.phase = "implement"
                ph.fix_rounds = 0
                st.step_seq = vs.change_seq if vs is not None else -1
                await self._phase_emit(st, emit)
                return PH.msg_retry(ph)
            return None
        if p == "done_check":
            if kind == "set_plan":
                ph.add_steps(data)
                ph.phase = "implement"
                st.step_seq = vs.change_seq if vs is not None else -1
                await emit({"type": "info", "text": f"完了確認で手順を {len(data)} 個追加しました"})
                await self._phase_emit(st, emit)
                return PH.msg_start(ph)
            if kind == "reply":
                if ph.undigested() and not ph.final_digest_asked:
                    # v2.0.0: 相手の最後の返事を整理しないまま終わろうとした → 1 度だけ整理を求める
                    ph.final_digest_asked = True
                    await emit({"type": "info", "text": "相手の最後の返事がまだ整理されていないため、digest を求めます"})
                    return PH.msg_final_digest(ph)
                ph.active = False
                await emit({"type": "info", "text": f"作業フェーズを完了しました（全 {ph.n} 手順）"})
                await self._phase_emit(st, emit)
            return None
        return None                            # report: 報告を書いたら終了（「続けて」で再開）

    def _phase_note_tool(self, st: LoopState, tc: dict) -> None:
        """v1.10.1: 手順で使ったツールを記録する（外部に作用したか・コードを変更したかの判定用）。"""
        ph = st.phase
        name = str(tc.get("name") or "")
        if name in ("step_done", "set_plan", "digest") or self._is_wait(tc):
            return                                # v2.0.1: 待つだけの sleep は操作にも観察にも数えない
        tags = [name]
        now = time.time()
        args = tc.get("args") or {}
        # v2.0.0: 会話の送受信を記録する（受け取った返事を digest で整理するまで次の送信を止めるため）
        if self._is_send(name, args):
            ph.sent_ts = now
            if name in PH.PEER_TALK_TOOLS:
                ph.inbox_ts = now                 # 出力がそのまま相手の返事（同じ時刻の digest は「整理済み」になる）
        elif name == "peer_status" and ph.sent_ts > ph.digest_ts:
            ph.inbox_ts = now                     # 依頼したピアの応答を受け取った
        elif ph.sent_ts > ph.digest_ts and ph.kind == "converse" and (name in self.OBSERVE_TOOLS or name == "read_file"):
            ph.inbox_ts = now                     # 送った後（整理より後）に画面などを見た = 相手の返事を受け取った
        acted = name in PH.EXTERNAL_TOOLS
        if name in ("write_file", "edit_file"):
            path = str((tc.get("args") or {}).get("path") or "")
            if Path(path).suffix.lower() in PH.CODE_EXTS:
                tags.append("code_edit")
                acted = True
        # v1.11.1: 操作と観察の時刻を記録する（最後の操作の後に観察していれば、証拠のための撮り直しを求めない）
        if acted:
            ph.last_action_ts = now
            if name in PH.SELF_REPORTING_TOOLS:
                ph.last_observe_ts = now          # コマンドの出力 = そのまま結果の観察
        elif name not in ("write_file", "edit_file"):
            ph.last_observe_ts = now              # スクリーンショット・ファイルの読み取り・状態確認など
        for t_ in tags:
            if t_ not in ph.step_tools:
                ph.step_tools.append(t_)

    # ------------------------------------------------------------------ v2.2.0: プロンプトインジェクション対策
    def _taint_reason(self, session: Session, name: str, args: dict) -> str:
        """汚染ありのときに承認を求める理由（空 = 求めない）。"""
        tnt = getattr(session, "taint", None) or {}
        if not tnt.get("active") or not self.cfg.get("security.taint_guard", True):
            return ""
        if name in SEC.URL_TOOLS:
            known = set(self._known_domains.get(session.id, set())) | {
                str(t).lower() for t in (self.cfg.get("security.trusted_domains", SEC.DEFAULT_TRUSTED) or [])}
            why = SEC.url_risk(str(args.get("url") or ""), known)
            return f"外部の内容を読んだ後のアクセス: {why}" if why else ""
        if name in SEC.TAINT_ASK or (name == "spawn_agent" and str(args.get("mode", "code")) == "code"):
            return "外部の内容（Web・ほかの AI）を読んだ後の操作です。プロンプトインジェクションで誘導されていないか確認してください"
        return ""

    @staticmethod
    def _content_url(st: LoopState, name: str, args: dict, out: str) -> str:
        """読んだ内容の URL（リダイレクト後。ブラウザは今開いているページ）。分からなければ空。"""
        if name == "fetch_url":
            m = re.match(r"URL:\s*(\S+)", out)
            return m.group(1) if m else str(args.get("url") or "")
        if name.startswith("browser_"):
            pg = getattr(st.ctx.browser, "_page", None)
            try:
                if pg is not None and not pg.is_closed():
                    return str(pg.url or "")
            except Exception:  # noqa: BLE001
                pass
            return str(args.get("url") or "")
        return ""

    async def _untrusted_output(self, st: LoopState, session: Session, name: str, args: dict, out: str, emit: Emit) -> str:
        """外部の内容: 見えない文字を除き、典型的な文言を探し、データの枠で囲み、セッションを汚染ありにする。"""
        out = SEC.strip_invisible(out)
        if name == "web_search":
            self._known_domains.setdefault(session.id, set()).update(SEC.domains_in(out))
        hits = SEC.detect(out)
        detail = str(args.get("url") or args.get("query") or args.get("peer") or args.get("message") or "")[:100]
        # v2.2.1: 検索結果（短い抜粋）だけでは汚染ありにしない。信頼できるサイト（公式ドキュメントなど）を読んでも汚染ありにしない。
        # どちらも、AI への指示に見える文言が見つかったときは汚染ありにする
        url = self._content_url(st, name, args, out)
        trusted = bool(url) and SEC.is_trusted(url, self.cfg.get("security.trusted_domains", SEC.DEFAULT_TRUSTED))
        if (name == "web_search" or trusted) and not hits:
            return SEC.wrap(name, out, hits) if self.cfg.get("security.wrap_external", True) else out
        tnt = st.ctx.taint if isinstance(st.ctx.taint, dict) else session.taint
        first = SEC.mark(tnt, name, detail, hits)
        if first or hits:
            await emit({"type": "taint", "active": True, "source": name, "detail": detail, "suspicious": hits[:3],
                        "text": ("外部の内容に、AI への指示に見える文言が含まれています（プロンプトインジェクションの可能性）: "
                                 + " ／ ".join(h[:60] for h in hits[:2])) if hits else
                                ("外部の内容（" + name + "）を読みました。以後、ファイルの変更・コマンド・送信などは毎回確認します")})
        return SEC.wrap(name, out, hits) if self.cfg.get("security.wrap_external", True) else out

    # v2.1.0: 会話モードで呼ばれたら、作業を始めるかをユーザーに確認するツール（ファイルの変更・実行・外部への作用）
    WORK_TOOLS = {"write_file", "edit_file", "run_command", "process_start", "process_stop", "repl", "run_tests", "mt5_compile",
                  "mt5_backtest", "make_icon", "restore_backup", "gui_launch", "gui_input", "ask_peer", "peer_reply", "peer_verify"}

    async def _mode_gate(self, st: LoopState, session: Session, tc: dict, tool, emit: Emit,
                         ask_approval: AskApproval) -> str | None:
        """v2.1.0: 会話モードで作業系のツールが呼ばれた → 作業を始めるか（作業ディレクトリ）／会話を続けるかをユーザーに聞く。"""
        name, args = tc.get("name"), tc.get("args") or {}
        work = name in self.WORK_TOOLS or (name == "spawn_agent" and str(args.get("mode", "code")) == "code")
        if not st.chat_mode or st.ctx.depth != 0 or not work:
            return None
        decline = PH.L("（会話モード）ユーザーは会話を続けることを選んでいます。ファイルの変更やコマンドの実行はせず、会話で答えてください"
                       "（コード例を示すのは構いません）。",
                       "(Conversation mode) The user chose to keep talking. Do not change files or run commands; answer in the conversation "
                       "(showing example code is fine).")
        await emit({"type": "tool_call", "id": tc["id"], "name": name, "args": args, "summary": tool.summarize(args)})
        if str(getattr(session, "mode", "auto")) == "chat" or st.chat_declined:
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": decline, "error": False})
            return decline
        prev_focus = await self._focused_window() if self.cfg.get("permissions.restore_focus", True) else None
        await emit({"type": "status", "phase": "approval", "detail": name})
        decision = str(await ask_approval({"id": tc["id"], "kind": "mode_switch", "name": name, "args": args,
                                           "summary": tool.summarize(args), "project_dir": session.project_dir}) or "chat")
        if prev_focus:
            await self._restore_focus(prev_focus)
        if not decision.startswith("work"):
            st.chat_declined = True
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": decline, "error": False})
            return decline
        from .config import expand
        want = decision.split(":", 1)[1].strip() if ":" in decision else ""
        target = expand(want) if want else Path(session.project_dir)
        if not (self.cfg.in_workspace(target) and target.is_dir()):
            await emit({"type": "info", "text": f"作業ディレクトリ {target} を使えないため、今のディレクトリで作業します"})
            target = Path(session.project_dir)
        session.project_dir = str(target)
        session.working = True
        try:
            self.cfg.remember_project(target)
        except Exception:  # noqa: BLE001
            pass
        st.switch_to = str(target)
        msg = PH.L(f"作業モードに切り替えました（作業ディレクトリ: {target}）。ここまでの会話から指示書と計画を作って作業を始めます"
                   "（この操作はまだ実行していません）。",
                   f"Switched to work mode (working directory: {target}). A task brief and plan are made from the conversation so far "
                   "before the work starts (this action has not been executed).")
        await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": False})
        await emit({"type": "mode", "mode": str(getattr(session, "mode", "auto")), "working": True, "project_dir": str(target)})
        return msg

    @staticmethod
    def _conversation_digest(messages: list[dict], max_msgs: int = 10, per: int = 1200) -> str:
        """v2.1.0: 作業開始時に指示書の材料にする、直近の会話の抜粋（ツールの出力とシステムの指示は除く）。"""
        picked = []
        for m in reversed(messages):
            if m.get("kind") in ("nudge", "summary", "screenshot", "mode"):
                continue
            if m.get("role") in ("user", "assistant") and (m.get("content") or "").strip():
                picked.append(("ユーザー" if m["role"] == "user" else "AperCode", m["content"].strip()[:per]))
            if len(picked) >= max_msgs:
                break
        body = "\n\n".join(f"{who}: {txt}" for who, txt in reversed(picked))
        return ("（以下はユーザーと AperCode の会話の抜粋。会話の最後に合意した作業を指示書にする）\n\n" + body) if body else ""

    WAIT_RE = re.compile(r"^\s*sleep\s+\d+(\.\d+)?[smh]?\s*;?\s*$")

    @classmethod
    def _is_wait(cls, tc: dict) -> bool:
        """v2.0.1: 返事などを待つだけのコマンド（sleep 10）。操作でも観察でもなく、繰り返しても行き詰まりではない。"""
        return tc.get("name") == "run_command" and bool(cls.WAIT_RE.match(str((tc.get("args") or {}).get("command") or "")))

    @staticmethod
    def _is_send(name: str, args: dict) -> bool:
        """v2.0.0: 会話の相手へ送る操作か（GUI への文章の入力・別の AperCode やクラウド AI への送信）。"""
        return name in PH.PEER_TALK_TOOLS or (name == "gui_input" and bool(str(args.get("text") or "").strip()))

    def _converse_gate(self, st: LoopState, name: str, args: dict) -> str | None:
        """v2.0.0: 相手の返事を受け取った後、digest で整理しないまま次を送ろうとしたら止める。"""
        if not self._phase_on(st) or st.phase.phase not in ("implement", "fix") or not self._is_send(name, args):
            return None
        ph = st.phase
        if (ph.kind == "converse" or name in PH.PEER_TALK_TOOLS) and ph.undigested():
            return "エラー: " + PH.msg_digest_first(ph)
        return None

    async def _phase_evidence_gate(self, st: LoopState, session: Session, emit: Emit, evidence: str,
                                   tests_ok: bool) -> str | None:
        """v1.10.1: テストで確かめられない手順（コマンド・GUI 操作）は、結果を観察した証拠が出るまで完了にしない。
        完了を認めるなら None、差し戻すならその指示を返す。"""
        ph = st.phase
        if not self.cfg.get("phases.require_evidence", True):
            return None
        external = set(ph.step_tools) & PH.EXTERNAL_TOOLS
        cov = st.ctx.verify.coverage if st.ctx.verify is not None else None
        tested = tests_ok and not (cov is not None and cov.never_imported)
        code = "code_edit" in ph.step_tools
        if code and tested:
            return None                              # 変更したコードをテストが実行して通った
        if not external and not code:
            return None                              # 文書などのファイルの読み書きだけ: 自動検証とツール結果で十分
        if code and not external:
            external = {"テストで実行されていないコード"}   # v1.11.0: 書いたスクリプトは一度動かして確かめるまで完了にしない
        label = f"手順 {ph.idx + 1}/{ph.n}"
        observed = ph.last_observe_ts > 0 and ph.last_observe_ts >= ph.last_action_ts
        has_evidence = len((evidence or "").strip()) >= 10
        if not ph.confirm_ts:
            if observed and has_evidence:
                # v1.11.1: 操作の後に観察し、何を見たかも書いてある → 確認の依頼（撮り直し）なしで完了
                await emit({"type": "verify", "kind": "evidence", "ok": True, "text": f"{label}: 観察による確認: {evidence.strip()[:200]}"})
                return None
            ph.confirm_ts = time.time()
            ph.phase = "implement"
            await emit({"type": "verify", "kind": "evidence", "ok": None,
                        "text": f"{label}: テストで確かめられない作業（{', '.join(sorted(external))}）のため、結果の確認を求めました"})
            await self._phase_emit(st, emit)
            return PH.msg_confirm(ph, observed=observed)
        why = ("最後の操作の後に、結果を観察していません" if not observed else
               "evidence に何を見て成功と判断したかが書かれていません" if not has_evidence else "")
        if why:
            ph.fix_rounds += 1
            max_fix = int(self.cfg.get("phases.max_fix_rounds", 3))
            ph.last_error = f"{label}: {why}"
            if ph.fix_rounds > max_fix:
                return await self._phase_fail(st, session, emit, "結果を確認できませんでした")
            ph.phase = "implement"
            await emit({"type": "verify", "kind": "evidence", "ok": False, "text": f"{label}: 完了を認めません（{why}）"})
            await self._phase_emit(st, emit)
            return PH.msg_confirm(ph, again=why)
        await emit({"type": "verify", "kind": "evidence", "ok": True, "text": f"{label}: 観察による確認: {evidence.strip()[:200]}"})
        return None

    async def _phase_verify(self, st: LoopState, session: Session, emit: Emit, evidence: str = "") -> str:
        """手順の検証（AperCode が行う。LLM は呼ばない）。通れば次の手順、駄目なら修正、上限を超えたら巻き戻し。"""
        ph = st.phase
        vs = st.ctx.verify
        ph.phase = "verify"
        await self._phase_emit(st, emit)
        problems: list[str] = []
        tests_ok = False
        if vs is not None and self.cfg.get("verify.enabled", True):
            for rel, n in vs.check_failures.items():
                if not n:
                    continue
                last = next((c for c in reversed(vs.checks) if c.path == rel and not c.ok and not c.skipped), None)
                problems.append(f"自動検証 NG: {rel}" + (f"\n{last.output[:1500]}" if last else ""))
            changed = vs.change_seq != st.step_seq
            if changed and self.cfg.get("phases.test_each_step", True) and str(self.cfg.get("verify.tests", "auto")) == "auto":
                await emit({"type": "status", "phase": "verifying", "detail": t(f"手順 {ph.idx + 1}/{ph.n} のテスト")})
                res, gap = await self._tests_with_coverage(st, emit, f"手順 {ph.idx + 1}/{ph.n} のカバレッジ")
                if res.detected:
                    vs.record_tests(res)
                    await emit({"type": "verify", "kind": "tests", "ok": res.ok,
                                "text": f"手順 {ph.idx + 1}/{ph.n} のテスト: " + res.summary(), "detail": res.output[-3000:]})
                    tests_ok = res.ok
                    if not res.ok:
                        problems.append(f"テスト失敗: $ {res.command}\n{res.summary()}\n{res.output[-2500:]}")
                    elif gap and not ph.cov_asked:
                        # v1.10.0: テストは通ったが、この手順で変更した行が一度も実行されていない → 1 回だけテスト追加を求める
                        ph.cov_asked = True
                        vs.coverage_prompted = True
                        problems.append("テストは通りましたが、この手順で変更した次の行はテストで一度も実行されていません:\n" + gap +
                                        "\nこれらの行を実行するテストを追加してください。テストで実行できない理由がある場合は、"
                                        "その理由を step_done の summary に書いてください。")
            elif vs.tests is not None and vs.tests.detected and not vs.tests.ok:
                # 何も変更せずに step_done した: 前回の失敗がそのまま残っている（再実行はしない）
                res = vs.tests
                problems.append(f"テスト失敗（前回の検証から何も変更していません）: $ {res.command}\n{res.summary()}\n{res.output[-2500:]}")
        max_fix = int(self.cfg.get("phases.max_fix_rounds", 3))
        if problems:
            ph.fix_rounds += 1
            ph.last_error = "\n\n".join(problems)[:4000]
            if ph.fix_rounds > max_fix:
                return await self._phase_fail(st, session, emit, f"{max_fix} 回修正しても検証が通りません")
            ph.phase = "fix"
            st.step_seq = vs.change_seq if vs is not None else -1
            await self._phase_emit(st, emit)
            return PH.msg_fix(ph, max_fix)
        gate = await self._phase_evidence_gate(st, session, emit, evidence, tests_ok)
        if gate:
            return gate
        done_i, n = ph.idx + 1, ph.n
        text = ph.current()
        ph.steps[ph.idx]["status"] = "done"
        ph.idx += 1
        ph.reset_step()
        ph.phase = "implement" if ph.idx < ph.n else "done_check"
        st.step_seq = vs.change_seq if vs is not None else -1
        item = await self._phase_checkpoint(st, emit, f"手順 {done_i}/{n} 完了: {text[:40]}")
        await self._phase_emit(st, emit)
        if ph.phase == "implement":
            return PH.msg_next(ph, label_of(item) if item else "-")
        return PH.msg_done_check(ph, st.brief_path is not None and st.brief_path.exists())

    async def _phase_fail(self, st: LoopState, session: Session, emit: Emit, why: str) -> str:
        """手順が通らない: 直前のチェックポイントへファイルと履歴を巻き戻し、調査（上限を超えたら報告）へ。
        v1.11.0: ファイルを変えていない手順（アプリ操作など）や operate の作業では、巻き戻し・調査フェーズを挟まず別のやり方でやり直させる。"""
        ph = st.phase
        if ph.kind in ("operate", "converse") or not ({"write_file", "edit_file"} & set(ph.step_tools)):
            return await self._phase_fail_light(st, emit, why)
        rec = (f"方針「{ph.approach[:200]}」: " if ph.approach else "") + why + (f"（{ph.last_error[:300]}）" if ph.last_error else "")
        ph.failures = (ph.failures + [rec])[-5:]
        ph.investigations += 1
        ph.fix_rounds = 0
        ph.approach = ""
        ph.step_tools = []
        ph.confirm_ts = 0.0
        cps = st.ctx.checkpoints
        item = cps.last() if cps is not None else None
        dropped, cp_label = 0, "-"
        if item is not None:
            try:
                res = cps.restore(item["id"], st.ctx.backup)
            except Exception as e:  # noqa: BLE001
                res = {"written": [], "deleted": []}
                await emit({"type": "error", "text": f"チェックポイントへの巻き戻しに失敗しました: {e}"})
            self._after_restore(st, res)
            dropped = self._drop_history_after(st, session, item.get("anchor_ts"))
            cp_label = label_of(item)
            await emit({"type": "rollback", "id": item["id"], "label": item["label"], "written": res["written"],
                        "deleted": res["deleted"], "dropped": dropped,
                        "text": f"チェックポイント {cp_label} に戻しました（ファイル {len(res['written']) + len(res['deleted'])} 件を復元、以降の履歴 {dropped} 件を除外）"})
        st.step_seq = st.ctx.verify.change_seq if st.ctx.verify is not None else -1
        if ph.investigations > int(self.cfg.get("phases.max_investigations", 1)):
            ph.phase = "report"
            await self._phase_emit(st, emit)
            return PH.msg_report(ph, cp_label, dropped)
        ph.phase = "investigate"
        await self._phase_emit(st, emit)
        return PH.msg_investigate(ph, cp_label, why, dropped)

    async def _phase_fail_light(self, st: LoopState, emit: Emit, why: str) -> str:
        ph = st.phase
        rec = why + (f"（{ph.last_error[:300]}）" if ph.last_error else "")
        ph.failures = (ph.failures + [rec])[-5:]
        ph.investigations += 1
        ph.fix_rounds = 0
        ph.approach = ""
        ph.step_tools = []
        ph.confirm_ts = 0.0
        st.step_seq = st.ctx.verify.change_seq if st.ctx.verify is not None else -1
        await emit({"type": "info", "text": f"手順 {ph.idx + 1}/{ph.n}: {why}。別のやり方でやり直させます"})
        if ph.investigations > int(self.cfg.get("phases.max_investigations", 1)) + 1:
            ph.phase = "report"
            await self._phase_emit(st, emit)
            return PH.msg_report_plain(ph)
        ph.phase = "implement"
        await self._phase_emit(st, emit)
        return PH.msg_retry_other(ph, why)

    def _after_restore(self, st: LoopState, res: dict) -> None:
        """巻き戻したファイルの検証状態を合わせる。"""
        vs: VerifyState | None = st.ctx.verify
        if vs is None:
            return
        for rel in res.get("written", []) + res.get("deleted", []):
            vs.check_failures.pop(rel, None)
            c = vs.changes.get(rel)
            if c is None:
                continue
            p = st.ctx.project_dir / rel
            if p.is_file():
                c["after"] = p.read_text(encoding="utf-8", errors="replace")
            elif c["before"] is None:
                vs.changes.pop(rel, None)
            else:
                c["after"] = ""
        vs.tests_fresh = False
        vs.change_seq += 1

    def _drop_history_after(self, st: LoopState, session: Session, anchor_ts) -> int:
        """チェックポイント以降の会話を LLM の履歴から外す（session.archive に移す）。"""
        if anchor_ts is None:
            return 0
        msgs = st.messages
        idx = next((i for i in range(len(msgs) - 1, -1, -1) if msgs[i].get("ts") == anchor_ts), None)
        if idx is None:
            return 0                               # 圧縮で要約済み。ファイルだけ戻す
        dropped = msgs[idx + 1:]
        if not dropped:
            return 0
        if msgs is session.messages:
            session.archive.append({"ts": time.time(), "rolled_back": True, "messages": list(dropped)})
        del msgs[idx + 1:]
        st.last_prompt_tokens = 0
        return len(dropped)

    def restore_checkpoint(self, session: Session, cid: int) -> dict:
        """UI から: チェックポイントへファイル・履歴・作業フェーズを戻す。"""
        project = Path(session.project_dir)
        cps = CheckpointStore(project, session.id, int(self.cfg.get("phases.keep_checkpoints", 30)),
                              float(self.cfg.get("backup.max_file_mb", 20)))
        item = cps.get(cid)
        if item is None:
            raise KeyError(f"チェックポイント #{cid} がありません")
        backup = BackupManager(self.cfg, project)
        backup.begin_turn()
        res = cps.restore(cid, backup)
        ctx = T.ToolContext(self.cfg, project)
        st = LoopState(messages=session.messages, system="", tool_names=None, ctx=ctx)
        dropped = self._drop_history_after(st, session, item.get("anchor_ts"))
        ph = PH.PhaseState.from_dict(item.get("phase"))
        if ph.active and ph.phase == "verify":
            ph.phase = "implement"
        session.phase = ph.to_dict()
        n = len(res["written"]) + len(res["deleted"])
        session.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content": PH.L(
            f"【システム】ユーザーがチェックポイント {label_of(item)} に戻しました（ファイル {n} 件を復元）。これより後の変更と会話は取り消されています。",
            f"[System] The user rolled back to checkpoint #{item['id']} ({item['label']}); {n} files restored. Later changes and messages were undone.")})
        session.last_prompt_tokens = 0
        self.store.save(session)
        return {"ok": True, "written": res["written"], "deleted": res["deleted"], "dropped": dropped,
                "backup": f"{backup.dirname}/{backup._stamp}" if backup.saved else None}

    async def _exec_tool(self, st: LoopState, session: Session, tc: dict, emit: Emit,
                         ask_approval: AskApproval, cancel: asyncio.Event) -> str:
        name, args = tc.get("name"), tc.get("args") or {}
        tool = T.get(name) if name else None
        allowed = st.tool_names is None or name in (st.tool_names or [])
        if not tool or not allowed:
            msg = t(f"不明または使用不可のツール: {name}")
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg
        if self._phase_on(st) and name not in self._phase_filter(st, [name]):
            msg = self._phase_denied(st, name)
            await emit({"type": "tool_call", "id": tc["id"], "name": name, "args": args, "summary": tool.summarize(args)})
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg
        mgate = await self._mode_gate(st, session, tc, tool, emit, ask_approval)
        if mgate is not None:
            return mgate
        cgate = self._converse_gate(st, name, args)
        if cgate:
            await emit({"type": "tool_call", "id": tc["id"], "name": name, "args": args, "summary": tool.summarize(args)})
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": cgate, "error": True})
            return cgate
        summary = tool.summarize(args)
        await emit({"type": "tool_call", "id": tc["id"], "name": name, "args": args, "summary": summary})

        decision = self._decide(session, name, args)
        reason = ""
        always_key: str | None = "edit_run" if name in self.EDIT_RUN_GROUP else name
        # 作業ディレクトリの外に触れる操作は、ツールの権限設定に関わらずユーザーの許可を求める
        outside = self._outside_paths(st.ctx, name, args)
        if outside:
            mode = str(self.cfg.get("permissions.outside_project", "ask"))
            if mode == "deny":
                decision = "deny"
            elif mode == "ask" and "outside_project" not in self._session_allowed(session):
                decision = "ask"
                reason = "作業ディレクトリの外へのアクセス: " + ", ".join(outside[:3])
                always_key = "outside_project"
        # ブラウザで外部サイトを開くときは確認（localhost は不要）。「常に許可」で以後は確認しない
        if name == "browser_open" and decision != "deny" and not is_local_url(str(args.get("url", ""))):
            mode = str(self.cfg.get("browser.external_sites", "ask"))
            if mode == "deny":
                decision = "deny"
            elif mode == "ask" and "browser_external" not in self._session_allowed(session):
                decision = "ask"
                reason = (reason + " / " if reason else "") + "外部サイトをブラウザで開く: " + str(args.get("url", ""))[:80]
                always_key = "browser_external"
        # v1.2.1: テスト失敗後の既存テスト変更は「常時許可」の対象外（ask）または拒否（deny）
        lock = self._test_lock(st, name, args) if decision != "deny" else None
        if lock:
            mode = str(self.cfg.get("verify.lock_tests", "ask"))
            if mode == "deny":
                st.ctx.verify.test_edit_denied += 1
                msg = t("テストが失敗した後は、既存のテストファイルを変更できません（検証の弱体化を防ぐため）: " + lock +
                        "\nテストではなく実装を修正してください。テスト自体が誤っていると考える場合は、その根拠を"
                        "完了報告に書いてユーザーの判断を仰いでください。")
                await emit({"type": "verify", "kind": "lock", "ok": False, "text": f"テスト変更をブロック: {lock}"})
                await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
                return msg
            decision = "ask"
            reason = (reason + " / " if reason else "") + "テスト失敗後のテスト変更（テストを実装に合わせて弱めていないか確認）: " + lock
            always_key = None
        # 取り返しのつかない操作は常時許可の対象外（毎回確認）
        danger = self._dangerous(name, args) if decision != "deny" else None
        if danger:
            decision = "ask"
            reason = (reason + " / " if reason else "") + danger
            always_key = None
        # v2.2.0: 外部の内容を読んだ後（汚染あり）は、外部に作用する操作を「常に許可」していても確認する
        taint_why = self._taint_reason(session, name, args) if decision != "deny" else ""
        if taint_why:
            decision = "ask"
            reason = (reason + " / " if reason else "") + taint_why
            always_key = None
        prev_focus = None
        if decision == "ask" and self.cfg.get("permissions.restore_focus", True):
            prev_focus = await self._focused_window()      # v1.11.0: 承認で AperCode が前面に出る前のウィンドウ
        if decision == "ask":
            await emit({"type": "status", "phase": "approval", "detail": name})
            decision = await ask_approval({"id": tc["id"], "name": name, "args": args, "summary": summary,
                                           "reason": reason, "always": always_key is not None,
                                           "always_label": ("このセッションでは編集・実行を常に許可" if always_key == "edit_run"
                                                            else "このセッションでは常に許可")})
            if decision == "allow_always":
                if always_key:
                    self._grant(session, always_key)
                decision = "allow"
        if decision == "pause":
            # v2.1.0: 許可でも拒否でもなく、ユーザーが確認したいことがある → 実行せずにこのターンを止め、質問を待つ
            st.paused = True
            session.pause_pending = True
            msg = PH.L("【一時停止】ユーザーが確認したいことがあるため、この操作を一時停止しました（まだ実行していません）。"
                       "次のユーザーの質問に答えてください。答えた後に、この操作を続けてよいかをユーザーに確認し、勝手に再実行しないこと。",
                       "[Paused] The user wants to ask something first, so this action was paused (not executed). Answer the user's next question, "
                       "then ask whether to continue with this action. Do not re-run it on your own.")
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": False})
            return msg
        if decision != "allow":
            if lock:
                st.ctx.verify.test_edit_denied += 1
                await emit({"type": "verify", "kind": "lock", "ok": False, "text": f"テスト変更を拒否: {lock}"})
            msg = t("ユーザーがこの操作を拒否しました。別の方法を検討するか、ユーザーに確認してください。")
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg

        if prev_focus:
            await self._restore_focus(prev_focus)

        # サブエージェントの実体を注入（子のイベントは parent id 付きで流す）
        if name == "spawn_agent":
            st.ctx.spawn = lambda a: self._spawn(st, session, a, tc["id"], emit, ask_approval, cancel)

        t0 = time.time()
        phase = ("searching" if name in ("web_search", "fetch_url") else "memory" if name in ("save_memory", "search_memory")
                 else "cloud" if name == "ask_cloud" else "browser" if name.startswith("browser_") else "tool")
        await emit({"type": "status", "phase": phase, "detail": f"{name} {summary}"[:80]})
        # 変更前の内容（自動検証・レビュー用の差分に使う）
        before: str | None = None
        target: Path | None = None
        if st.ctx.verify is not None and name in ("write_file", "edit_file") and isinstance(args.get("path"), str):
            try:
                target = st.ctx.resolve(args["path"])
                before = target.read_text(encoding="utf-8", errors="replace") if target.is_file() else None
            except Exception:  # noqa: BLE001
                target = None
        if st.ctx.checkpoints is not None and name in ("write_file", "edit_file") and isinstance(args.get("path"), str):
            try:
                st.ctx.checkpoints.track(st.ctx.resolve(args["path"]))   # v1.9.0: 初めて変更するファイルの変更前を記録
            except Exception:  # noqa: BLE001
                pass
        try:
            out = await tool.handler(st.ctx, args)
            err = False
        except T.ToolError as e:
            out, err = f"エラー: {e}", True
        except Exception as e:
            out, err = f"エラー: {type(e).__name__}: {e}\n{traceback.format_exc()[-1500:]}", True
        out = t(out)
        if not err and name in SEC.UNTRUSTED_TOOLS and self.cfg.get("security.taint_guard", True):
            out = await self._untrusted_output(st, session, name, args, out, emit)
        await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": out, "error": err,
                    "elapsed": round(time.time() - t0, 2)})
        # スクリーンショット: 画面に表示し、vision 対応モデル向けに画像付きメッセージとして履歴に入れる
        m = re.search(r"\[\[screenshot:([^\]]+)\]\]", out) if not err else None
        if m:
            fname = m.group(1)
            await emit({"type": "image", "url": f"/api/sessions/{session.id}/files/{fname}", "caption": t("スクリーンショット")})
            cap = ("（画面のスクリーンショット。画像を確認して判断すること。gui_input の click はこの画像上の座標）" if name == "screenshot"
                   else "（ブラウザのスクリーンショット。画像を確認して判断すること）")
            st.messages.append({"role": "user", "kind": "screenshot", "content": t(cap), "images": [fname], "ts": time.time()})
        if not err and st.ctx.verify is not None and self.cfg.get("verify.enabled", True):
            if target is not None and target.is_file():
                out += await self._auto_check(st, target, before, emit)
            elif name == "run_command" and TEST_CMD_RE.search(str(args.get("command", ""))):
                # LLM が自分でテストを走らせた場合も「テスト済み」として扱う
                m = re.search(r"\(exit (-?\d+)\)", out)
                code = int(m.group(1)) if m else 1
                p, f = V._parse_counts(out)
                st.ctx.verify.record_tests(V.TestResult(command=str(args.get("command", "")), exit_code=code,
                                                        passed=p, failed=f, output=out))
        return out

    # ------------------------------------------------------------------ v1.11.0: 承認でフォーカスが外れた GUI を戻す
    @staticmethod
    async def _focused_window() -> str | None:
        import os
        if not os.environ.get("DISPLAY"):
            return None
        try:
            from . import gui as G
            return await G.active_id()
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    async def _restore_focus(wid: str) -> None:
        try:
            from . import gui as G
            if await G.active_id() != wid:
                await G._run(["wmctrl", "-i", "-a", wid], 3)
                await asyncio.sleep(0.5)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------ 検証レイヤー（v1.2.0）
    def _test_lock(self, st: LoopState, name: str, args: dict) -> str | None:
        """テスト失敗後に既存テストを書き換えようとしていれば、その対象を返す（新規テストの追加は許可）。"""
        vs: VerifyState | None = st.ctx.verify
        if vs is None or not vs.tests_locked or str(self.cfg.get("verify.lock_tests", "ask")) == "off":
            return None
        pats = self.cfg.get("verify.test_patterns") or None
        if name in ("write_file", "edit_file") and isinstance(args.get("path"), str):
            try:
                target = st.ctx.resolve(args["path"])
                rel = str(target.relative_to(st.ctx.project_dir))
            except Exception:  # noqa: BLE001
                return None
            if V.is_test_file(rel, pats) and (rel in vs.test_baseline or target.is_file()):
                return rel
            return None
        if name == "run_command":
            return V.command_touches_tests(str(args.get("command", "")), pats)
        return None

    async def _auto_check(self, st: LoopState, target: Path, before: str | None, emit: Emit) -> str:
        """write/edit 直後の自動チェック。ツール結果に付け足す文字列を返す。"""
        vs: VerifyState = st.ctx.verify
        project = st.ctx.project_dir
        try:
            after = target.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""
        try:
            rel = str(target.relative_to(project))
        except ValueError:
            rel = str(target)
        vs.record_change(rel, before, after)
        lint_mode = str(self.cfg.get("verify.lint", "auto"))
        if lint_mode == "off":
            return ""
        res = await V.check_file(target, project, lint=True, types=self._types_on(),
                                 timeout=int(self.cfg.get("verify.check_timeout", 180)), before=before,
                                 structure=bool(self.cfg.get("verify.structure", True)))
        if res is None or res.skipped:
            return ""
        vs.checks.append(res)
        max_rounds = int(self.cfg.get("verify.max_fix_rounds", 3))
        if res.ok:
            vs.check_failures.pop(rel, None)
            await emit({"type": "verify", "kind": "check", "ok": True, "text": f"自動検証 OK: {res.summary()}"})
            return t(f"\n\n## 自動検証\n{res.summary()}")
        n = vs.check_failures.get(rel, 0) + 1
        vs.check_failures[rel] = n
        await emit({"type": "verify", "kind": "check", "ok": False, "text": f"自動検証 NG: {res.summary()}", "detail": res.output[:2000]})
        tail = ("\n\n## 自動検証\n" + res.summary() + "\n```\n" + res.output[:3000] + "\n```\n")
        if n >= max_rounds:
            tail += (f"このファイルの自動検証が {n} 回連続で NG です。同じ修正を繰り返さず、原因を根本から見直すか、"
                     "解決できない理由を整理してユーザーに報告してください。")
        else:
            tail += "上記の指摘を修正してから次に進んでください（修正後に再度自動検証されます）。"
        return t(tail)

    def _types_on(self) -> bool:
        v = self.cfg.get("verify.types", "auto")
        return v is True or str(v).lower() in ("auto", "on", "true")

    def _coverage_on(self) -> bool:
        return str(self.cfg.get("verify.coverage", "auto")).lower() not in ("off", "false", "0")

    async def _tests_with_coverage(self, st: LoopState, emit: Emit, label: str):
        """テストを実行し、使えれば変更行のカバレッジも取る。(TestResult, 追加を求める変更行の説明 | None)"""
        vs: VerifyState = st.ctx.verify
        ign = (str(self.cfg.get("backup.dir", "backup")), ".apercode")
        timeout = int(self.cfg.get("verify.test_timeout", 600))
        if self._coverage_on():
            res, rep = await V.run_tests_cov(st.ctx.project_dir, vs.changes, timeout=timeout, ignore_dirs=ign,
                                             patterns=self.cfg.get("verify.test_patterns") or None)
        else:
            res, rep = await V.run_tests(st.ctx.project_dir, timeout=timeout, ignore_dirs=ign), None
        vs.coverage = rep
        gap = None
        if rep is not None and res.detected and res.ok:
            if rep.n_uncovered or rep.never_imported:
                ask = bool(rep.never_imported) or rep.n_uncovered >= int(self.cfg.get("verify.coverage_min_lines", 3))
                gap = rep.summary() if ask else None
                await emit({"type": "verify", "kind": "coverage", "ok": None,
                            "text": f"{label}: 変更した行のうち {rep.n_uncovered} 行がテストで一度も実行されていません"
                                    + (f"（テストから読み込まれていないファイル {len(rep.never_imported)} 件）" if rep.never_imported else "")
                                    + ("" if ask else "（少ないためテストの追加は求めません）"),
                            "detail": rep.summary()})
            elif rep.checked:
                await emit({"type": "verify", "kind": "coverage", "ok": True,
                            "text": f"{label}: 変更した行はすべてテストで実行されました（{rep.checked} 行）"})
        return res, gap

    async def _completion_gate(self, st: LoopState, session: Session, emit: Emit,
                               ask_approval: AskApproval, cancel: asyncio.Event) -> str | None:
        """LLM が完了報告をしようとした時点で、テスト・レビューを行う。差し戻す場合はその指示文を返す。"""
        vs: VerifyState = st.ctx.verify
        if not vs.changes or not vs.code_changed():
            return None
        max_rounds = int(self.cfg.get("verify.max_fix_rounds", 3))

        # ---- 1) テスト
        tests_mode = str(self.cfg.get("verify.tests", "auto"))
        still_failing = vs.tests_fresh and vs.tests is not None and vs.tests.detected and not vs.tests.ok
        if tests_mode == "auto" and (not vs.tests_fresh or still_failing) and vs.test_rounds < max_rounds:
            if still_failing:
                # 失敗したまま何も変更していないのに完了しようとしている → 再実行せずに差し戻す
                res = vs.tests
            else:
                await emit({"type": "status", "phase": "verifying", "detail": "テスト実行"})
                res, gap = await self._tests_with_coverage(st, emit, "カバレッジ")
                if gap and not vs.coverage_prompted:
                    vs.record_tests(res)
                    await emit({"type": "verify", "kind": "tests", "ok": True, "text": "テスト: " + res.summary(), "detail": res.output[-3000:]})
                    vs.coverage_prompted = True
                    return ("【システム】テストは通りましたが、今回変更した次の行はテストで一度も実行されていません"
                            "（新しいコードが本当に動くかを確認できていません）:\n" + gap +
                            "\nこれらの行を実行するテストを追加し、run_tests で通ることを確認してから完了報告してください。"
                            "テストで実行できない理由がある場合（GUI・外部サービス・実機が必要など）は、その理由を完了報告に書いてください。")
            if res.detected:
                vs.record_tests(res)
                await emit({"type": "verify", "kind": "tests", "ok": res.ok,
                            "text": ("テスト（未修正のまま）: " if still_failing else "テスト: ") + res.summary(),
                            "detail": res.output[-3000:]})
                if res.ok and vs.test_baseline:
                    changed = V.changed_tests(st.ctx.project_dir, vs.test_baseline, self.cfg.get("verify.test_patterns") or None)
                    if changed and changed != vs.tests_modified:
                        vs.tests_modified = changed
                        await emit({"type": "verify", "kind": "lock", "ok": None,
                                    "text": f"注意: 既存テストが変更されています（{len(changed)} 件）。結果の妥当性を確認してください",
                                    "detail": "\n".join(changed)})
                if not res.ok:
                    vs.test_rounds += 1          # 差し戻した回数だけ数える（成功は数えない）
                    last = vs.test_rounds >= max_rounds
                    return ("【システム】完了報告の前にテストを自動実行したところ失敗しました。\n"
                            f"$ {res.command}\n{res.summary()}\n```\n{res.output[-4000:]}\n```\n"
                            + ("自動差し戻しの上限に達しました。「テストは失敗している」と正直に書き、失敗の内容と原因の推測、"
                               "対処案をユーザーに報告してください。"
                               if last else "失敗の原因を実装側で直してから、run_tests で再実行して完了報告してください。"
                               "テストが通っていない状態で「完了」「PASS」と報告しないでください。"
                               + ("原因が分からなければ web_search、それでも駄目なら ask_cloud で相談してください。"
                                  if self.cfg.get("cloud.enabled", False) else "")))
            elif self.cfg.get("verify.create_missing_tests", True):
                vs.test_rounds += 1
                if res.command:
                    # コマンドはあったがテストが 0 件（pytest 形式のテストを unittest で実行した等）
                    await emit({"type": "verify", "kind": "tests", "ok": None, "text": f"テスト: 0 件実行（{res.command}）",
                                "detail": res.output[-2000:]})
                    return ("【システム】テストを実行しましたが 1 件も実行されませんでした。\n"
                            f"$ {res.command}\n```\n{res.output[-2000:]}\n```\n"
                            "テストが実行できる状態にして（必要なら pytest のインストールや tests/__init__.py の追加）、"
                            "run_tests で通ることを確認してから完了報告してください。")
                if not vs.tests_missing_prompted:
                    vs.tests_missing_prompted = True
                    await emit({"type": "verify", "kind": "tests", "ok": None, "text": "テスト: コマンドが見つかりません（作成を促します）"})
                    return ("【システム】このプロジェクトにはテストが見つかりません。完了報告の前に、今回変更した機能に対する"
                            "最小限のテスト（Python なら tests/test_*.py、Node なら package.json の scripts.test 等）を作成し、"
                            "run_tests で実行して通ることを確認してください。テストが本当に不要な場合（設定ファイルのみの変更など）は、"
                            "その理由を書いて完了報告してください。")

        # ---- 2) レビュー（変更が一定量以上）
        rcfg = self.cfg.get("verify.review", {}) or {}
        if rcfg.get("enabled", True) and self.cfg.get("subagents.enabled", True):
            lines = vs.changed_lines()
            min_lines = int(rcfg.get("min_changed_lines", 50))
            max_rev = int(rcfg.get("max_rounds", 2))
            if lines >= min_lines and vs.review_rounds < max_rev and vs.change_seq != vs.reviewed_seq:
                vs.review_rounds += 1
                vs.reviewed_seq = vs.change_seq
                await emit({"type": "status", "phase": "verifying", "detail": f"コードレビュー（{lines} 行）"})
                review = await self._review(st, session, emit, ask_approval, cancel)
                vs.review = review
                issues = [i for i in review.get("issues", []) if str(i.get("severity", "medium")).lower() in ("high", "medium")]
                await emit({"type": "verify", "kind": "review", "ok": review.get("ok", True) and not issues,
                            "text": f"レビュー: {'指摘なし' if not issues else str(len(issues)) + ' 件の指摘'}（{lines} 行）",
                            "detail": "\n".join(f"- [{i.get('severity')}] {i.get('file')}:{i.get('line')} {i.get('problem')} → {i.get('fix')}" for i in issues)[:3000]})
                if issues:
                    body = "\n".join(f"- [{i.get('severity')}] {i.get('file')}" + (f":{i['line']}" if i.get("line") else "") +
                                     f" {i.get('problem')}\n  対処案: {i.get('fix')}" for i in issues)
                    last = vs.review_rounds >= max_rev
                    return ("【レビュー指摘】レビュー担当の子エージェントが以下を指摘しました。妥当なものは修正し、"
                            "修正後は run_tests で確認してから完了報告してください。妥当でない指摘は理由を完了報告に書いてください。\n"
                            + body + ("\n（レビューはこれが最後です。残る指摘は完了報告に含めてください）" if last else ""))
        return None

    async def _review(self, st: LoopState, session: Session, emit: Emit, ask_approval: AskApproval,
                      cancel: asyncio.Event) -> dict:
        """読み取り専用の子エージェントに diff をレビューさせ、{"ok": bool, "issues": [...]} を返す。"""
        import json as _json
        vs: VerifyState = st.ctx.verify
        # 今回のユーザー指示（最後の通常ユーザー発話）
        task = ""
        for m in reversed(st.messages):
            if m["role"] == "user" and m.get("kind") not in ("nudge", "summary"):
                task = m.get("content", "")[:2000]
                break
        prompt = P("REVIEW").replace("{task}", task or "(不明)").replace("{diff}", vs.diff())
        model = self.sub_model or self.cfg.get("verify.review.model") or self.cfg.get("subagents.explore_model") or st.model
        child_ctx = T.ToolContext(self.cfg, st.ctx.project_dir, depth=st.ctx.depth + 1, memory=self.memory,
                                  backup=st.ctx.backup, verify=None, browser=st.ctx.browser, files_dir=st.ctx.files_dir,
                                  session_id=st.ctx.session_id, repls=st.ctx.repls, procs=st.ctx.procs)
        child_ctx.taint = st.ctx.taint
        system = build_system_prompt(st.ctx.project_dir, self.cfg.workspace_root) + P("SUBAGENT").format(mode="explore")
        child = LoopState(messages=[{"role": "user", "content": prompt}], system=system,
                          tool_names=[n for n in T.READ_ONLY_TOOLS if st.tool_names is None or n in st.tool_names],
                          ctx=child_ctx, model=model, usage=st.usage)
        rid = "review-" + uuid.uuid4().hex[:6]

        async def child_emit(ev: dict):
            await emit({"type": "sub", "parent": rid, "event": ev})

        await emit({"type": "subagent_start", "id": rid, "mode": "review", "task": f"変更 {len(vs.changes)} ファイルのレビュー",
                    "model": model, "is_sub_model": model != st.model})
        try:
            result = await self._loop(child, session, child_emit, ask_approval, cancel,
                                      max_iter=int(self.cfg.get("verify.review.max_iterations", 12)))
        except Exception as e:  # noqa: BLE001
            await emit({"type": "info", "text": f"レビューをスキップ: {e}"})
            return {"ok": True, "issues": [], "error": str(e)}
        # 最後の JSON オブジェクトを取り出す
        objs = [m for m in re.finditer(r"\{[^{}]*\"ok\"[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", result, re.S)]
        for m in reversed(objs):
            try:
                data = _json.loads(m.group(0))
                if isinstance(data, dict) and "ok" in data:
                    data["issues"] = [i for i in (data.get("issues") or []) if isinstance(i, dict)]
                    return data
            except _json.JSONDecodeError:
                continue
        return {"ok": True, "issues": [], "raw": result[:2000]}

    # ------------------------------------------------------------------ 作業ディレクトリ外の検出
    _ABS_PATH_RE = None

    def _outside_paths(self, ctx: T.ToolContext, name: str, args: dict) -> list[str]:
        """ツール引数が作業ディレクトリ（ctx.project_dir）の外を指していれば、そのパス一覧を返す。"""
        import re
        if self._ABS_PATH_RE is None:
            self._ABS_PATH_RE = re.compile(r"(?<![\w@:.~/])(~/[^\s'\"`;|&<>)]*|/[^\s'\"`;|&<>)]+)")
        project = ctx.project_dir.resolve()

        def is_outside(p: Path) -> bool:
            try:
                p = p.expanduser().resolve()
            except OSError:
                return False
            return p != project and project not in p.parents

        found: list[str] = []
        for key in ("path", "cwd", "image", "out"):
            v = args.get(key)
            if isinstance(v, str) and v.strip():
                p = Path(v).expanduser()
                if not p.is_absolute():
                    p = project / p
                if is_outside(p):
                    found.append(v)
        if name == "run_command":
            cmd = str(args.get("command", ""))
            for m in self._ABS_PATH_RE.finditer(cmd):
                cand = m.group(1)
                # /dev/null, /usr/bin/… など明らかにシステム側の読み取り専用パスは対象外
                if cand.startswith(("/dev/", "/usr/", "/bin/", "/etc/", "/proc/", "/sys/", "/opt/", "/lib", "/tmp/")):
                    continue
                if is_outside(Path(cand)):
                    found.append(cand)
            # cd による移動（相対でも親方向なら外）
            for m in re.finditer(r"(?:^|[;&|]\s*)cd\s+([^\s;&|]+)", cmd):
                target = m.group(1).strip("'\"")
                if target in ("-",):
                    found.append("cd -")
                    continue
                p = Path(target).expanduser()
                if not p.is_absolute():
                    p = project / p
                if is_outside(p):
                    found.append(f"cd {target}")
        # 重複除去（順序維持）
        seen, out = set(), []
        for f in found:
            if f not in seen:
                seen.add(f); out.append(f)
        return out

    # ------------------------------------------------------------------ サブエージェント
    async def _spawn(self, parent: LoopState, session: Session, a: dict, parent_id: str,
                     emit: Emit, ask_approval: AskApproval, cancel: asyncio.Event) -> str:
        if not self.cfg.get("subagents.enabled", True):
            raise T.ToolError(t("サブエージェントは無効化されています"))
        max_depth = int(self.cfg.get("subagents.max_depth", 1))
        if parent.ctx.depth >= max_depth:
            raise T.ToolError(t(f"サブエージェントの深さ上限 ({max_depth}) に達しています。自分で作業してください"))
        mode = a.get("mode", "code")
        tool_names = list(T.READ_ONLY_TOOLS if mode == "explore" else T.CODE_TOOLS)
        if parent.ctx.depth + 1 < max_depth:
            tool_names.append("spawn_agent")
        if parent.tool_names is not None:          # v2.0.0: 親がツールを制限されていれば（ピアからの依頼など）子も同じ範囲に
            tool_names = [n for n in tool_names if n in parent.tool_names]
        model = self.sub_model or self.cfg.get(f"subagents.{mode}_model") or parent.model

        child_ctx = T.ToolContext(self.cfg, parent.ctx.project_dir, depth=parent.ctx.depth + 1, memory=self.memory,
                                  backup=parent.ctx.backup, verify=parent.ctx.verify, browser=parent.ctx.browser,
                                  files_dir=parent.ctx.files_dir, session_id=parent.ctx.session_id,
                                  repls=parent.ctx.repls, procs=parent.ctx.procs, checkpoints=parent.ctx.checkpoints)
        child_ctx.taint = parent.ctx.taint
        system = build_system_prompt(parent.ctx.project_dir, self.cfg.workspace_root) + P("SUBAGENT").format(mode=mode)
        task = a["task"] + (f"\n\n## 補足情報\n{a['context']}" if a.get("context") else "")
        child = LoopState(messages=[{"role": "user", "content": task}], system=system,
                          tool_names=tool_names, ctx=child_ctx, model=model, usage=parent.usage)
        child.brief_path = parent.brief_path     # 子にも親の目的を参考として渡す

        async def child_emit(ev: dict):
            await emit({"type": "sub", "parent": parent_id, "event": ev})

        await emit({"type": "subagent_start", "id": parent_id, "mode": mode, "task": a["task"], "model": model,
                    "is_sub_model": model != parent.model})
        result = await self._loop(child, session, child_emit, ask_approval, cancel,
                                  max_iter=int(self.cfg.get("subagents.max_iterations", 30)))
        if not result.strip():
            # 最終報告が無い場合は最後のツール結果を返す
            tails = [m["content"] for m in child.messages if m["role"] == "tool"]
            result = "(子エージェントは最終報告を返しませんでした)\n最後のツール結果:\n" + (tails[-1][:3000] if tails else "なし")
        n_tools = sum(1 for m in child.messages if m["role"] == "tool")
        return t(f"[子エージェント ({mode}) 完了: ツール呼び出し {n_tools} 回]") + "\n" + result

    # ------------------------------------------------------------------ 経験メモリ
    async def _recall(self, user_text: str, project: Path, tags: list[str], emit: Emit) -> str:
        """ユーザー入力に関連する経験を検索し、プロンプト注入用テキストを返す。"""
        if not self.memory or self.memory.count() == 0:
            return ""
        if len(user_text.strip()) < 8:  # 「はい」「OK」などの短い相づちには注入しない
            return ""
        try:
            hits = await self.memory.search(user_text, limit=int(self.cfg.get("memory.inject_top_k", 3)),
                                            tags=tags, project=str(project),
                                            min_score=float(self.cfg.get("memory.inject_min_score", 0.4)))
        except Exception as e:
            await emit({"type": "info", "text": f"経験メモリの検索に失敗: {e}"})
            return ""
        # v2.2.0: 外部の内容を読んだ後に保存された未確認の知見は、ユーザーが確認するまで使わない
        hits = [m for m in hits if not (SEC.UNTRUSTED_TAG in (m.tags or []) and not m.verified)]
        if not hits:
            return ""
        self.memory.touch([m.id for m in hits])
        await emit({"type": "memories_used", "items": [m.to_dict() for m in hits]})
        return "\n".join(f"- {m.to_prompt()}" for m in hits)

    async def _complete_nothink(self, system: str, text: str, model: str | None, options: dict | None) -> str:
        """思考モードを切って単発生成する。思考モードに対応しないモデルでエラーになったら、指定なしでやり直す。"""
        try:
            return await self.llm.complete(system, text, model=model, options=options, think="off")
        except RuntimeError as e:
            if "400" in str(e) or "think" in str(e).lower():
                return await self.llm.complete(system, text, model=model, options=options)
            raise

    @staticmethod
    def _reflect_transcript(messages: list[dict], limit: int) -> str:
        """教訓抽出用に要点だけを残した記録（新しい方を優先して limit 文字以内）。"""
        lines: list[str] = []
        for m in messages:
            r = m.get("role")
            c = m.get("content") or ""
            if r == "user":
                lines.append("[USER]\n" + c[:1500])
            elif r == "assistant":
                if c:
                    lines.append("[ASSISTANT]\n" + c[:1500])
                for tc in m.get("tool_calls") or []:
                    lines.append(f"[TOOL CALL] {tc.get('name')} {str(tc.get('args', ''))[:200]}")
            elif r == "tool":
                err = c.startswith(("エラー", "Error")) or "Traceback" in c[:2000] or "## 自動検証" in c and "NG" in c
                lines.append(f"[TOOL RESULT {m.get('name')}{' ERROR' if err else ''}]\n" + (c[:800] if err else c[:300]))
        out: list[str] = []
        total = 0
        for ln in reversed(lines):
            if total + len(ln) > limit:
                break
            out.append(ln)
            total += len(ln) + 2
        return "\n\n".join(reversed(out))

    async def _reflect(self, turn_messages: list[dict], project: Path, tags: list[str], emit: Emit) -> None:
        """今回のターンから教訓を抽出して保存する（memory.reflect: auto のとき）。"""
        if not self.memory or self.cfg.get("memory.reflect", "auto") != "auto":
            return
        n_tools = sum(1 for m in turn_messages if m["role"] == "tool")
        if n_tools < int(self.cfg.get("memory.reflect_min_tools", 3)):
            return
        await emit({"type": "status", "phase": "reflecting", "detail": "今回の作業から教訓を抽出して経験メモリに保存"})
        # v1.7.1: タイムアウト対策
        #  - 記録は要点だけに圧縮して渡す（ツール結果は短く、エラーは長めに残す）。CPU 実行なら更に短く
        #  - 思考モード（qwen3 など）は切る（教訓抽出で長考してタイムアウトしていた）
        #  - サブ LLM が時間切れ・失敗なら、メイン LLM（GPU）で 1 回だけやり直す
        timeout = float(self.cfg.get("memory.reflect_timeout", 180))
        max_chars = int(self.cfg.get("memory.reflect_max_chars", 16000))
        attempts: list[tuple[str | None, dict | None, float, int, str]] = []
        hm = self._helper_model() if self.cfg.get("memory.reflect_with_sub", True) else None
        if hm:   # v1.6.1: 教訓抽出はサブ LLM に任せ、メイン LLM を次の入力のために空けておく
            opts = await self._helper_options(hm, max_chars)
            on_cpu = opts.get("num_gpu") == 0
            attempts.append((hm, opts, timeout * (2.5 if on_cpu else 1), max_chars // 2 if on_cpu else max_chars,
                             f"サブ LLM {hm}" + ("・CPU" if on_cpu else "")))
        attempts.append((None, None, timeout, max_chars, "メイン LLM"))
        raw = None
        last_err = ""
        for i, (model, opts, limit, chars, label) in enumerate(attempts):
            text = self._reflect_transcript(turn_messages, chars)
            if opts is not None:
                opts = {**opts, "num_ctx": max(int(opts.get("num_ctx", 8192)), min(self.llm.num_ctx, int(len(text) / 2) + 3072))}
            await emit({"type": "status", "phase": "reflecting", "detail": f"教訓を抽出中（{label}）"})
            if model is not None:
                self._helper_busy += 1
            try:
                raw = await asyncio.wait_for(self._complete_nothink(P("REFLECT"), text, model, opts), timeout=limit)
                break
            except asyncio.TimeoutError:
                last_err = f"{label} が {limit:.0f} 秒以内に終わりませんでした"
            except Exception as e:  # noqa: BLE001
                last_err = f"{label}: {e}"
                if model is not None and opts and opts.get("num_gpu") != 0:
                    self._helper_gpu_ok = False      # GPU で失敗 → 以後のサブ LLM は CPU
            finally:
                if model is not None:
                    self._helper_busy -= 1
                    self._helper_last = time.time()
            if i + 1 < len(attempts):
                await emit({"type": "info", "text": f"教訓の抽出: {last_err}。メイン LLM でやり直します"})
        if raw is None:
            await emit({"type": "info", "text": f"教訓の抽出をスキップしました（{last_err}）"})
            return
        try:
            items = _parse_json_array(raw)
        except Exception as e:
            await emit({"type": "info", "text": f"教訓の抽出に失敗: {e}"})
            return
        saved = []
        for it in items[:5]:
            lesson = str(it.get("lesson", "")).strip()
            if not lesson:
                continue
            outcome = it.get("outcome", "info")
            outcome = outcome if outcome in ("success", "failure", "info") else "info"
            item_tags = [str(t) for t in (it.get("tags") or [])] or tags[:2]
            if SEC.UNTRUSTED_TAG in tags and SEC.UNTRUSTED_TAG not in item_tags:
                item_tags.append(SEC.UNTRUSTED_TAG)          # v2.2.0: 外部の内容を読んだターンの教訓は未確認扱い
            m, dup = await self.memory.add(lesson=lesson, situation=str(it.get("situation", ""))[:300],
                                           action=str(it.get("action", ""))[:300], outcome=outcome,
                                           tags=item_tags, project=str(project), source="auto",
                                           dedup_threshold=float(self.cfg.get("memory.dedup_threshold", 0.92)))
            if m:
                saved.append(m.to_dict())
        if saved:
            await emit({"type": "memories_saved", "items": saved})
        await emit({"type": "status", "phase": None})

    # ------------------------------------------------------------------ 圧縮
    def _estimate_tokens(self, messages: list[dict]) -> int:
        cpt = float(self.cfg.get("compaction.chars_per_token", 2.5))
        n = 0
        for m in messages:
            n += len(m.get("content") or "")
            for tc in m.get("tool_calls") or []:
                n += len(str(tc.get("args", "")))
        return int(n / cpt)

    def _context_info(self, st: LoopState) -> dict:
        est = max(self._estimate_tokens(st.messages), st.last_prompt_tokens)
        return {"estimated_tokens": est, "num_ctx": self.llm.num_ctx, "messages": len(st.messages)}

    # ------------------------------------------------------------------ 履歴圧縮（v1.6.1: サブ LLM による背景準備）
    @staticmethod
    def _cut_index(msgs: list[dict], keep: int) -> int:
        """要約で置き換える範囲の終端。assistant(tool_calls) と tool の対を分断しない位置にする。"""
        cut = len(msgs) - keep
        while cut > 1 and not (msgs[cut]["role"] == "user" or
                               (msgs[cut]["role"] == "assistant" and msgs[cut - 1]["role"] != "assistant")):
            cut -= 1
        return cut

    def _summary_budget(self) -> int:
        cpt = float(self.cfg.get("compaction.chars_per_token", 2.5))
        return max(12_000, int(self.llm.num_ctx * 0.4 * cpt))

    def _helper_model(self) -> str | None:
        """補助作業（背景要約・教訓抽出）に使うモデル。メインと同じなら None（背景では動かさない）。"""
        m = self.cfg.get("compaction.model") or self.sub_model
        return m if m and m != self.llm.model and self.llm.provider == "ollama" else None

    async def _helper_options(self, model: str, prompt_chars: int) -> dict:
        """補助モデル用の Ollama options。必要なだけの num_ctx にし、VRAM に載らないなら CPU で動かす
        （メインモデルを VRAM から追い出して再ロードさせないため）。"""
        from . import vram as V
        cpt = float(self.cfg.get("compaction.chars_per_token", 2.5))
        ctx = int(prompt_chars / cpt * 1.15) + 3072
        ctx = max(8192, min(((ctx + 1023) // 1024) * 1024, self.llm.num_ctx))
        opts: dict = {"num_ctx": ctx, "num_predict": 4096, "temperature": 0.2}
        dev = str(self.cfg.get("compaction.bg_device", "auto")).lower()
        if dev == "cpu":
            opts["num_gpu"] = 0
        elif dev == "auto" and not self._helper_gpu_ok:
            opts["num_gpu"] = 0                  # 以前 GPU での実行に失敗した → CPU（メインを巻き込まない）
        elif dev == "auto":
            base = self.llm.base_url
            kv_type = str(self.cfg.get("llm.auto_ctx.kv_cache_type", "f16"))

            remote = not V.is_local_url(base)

            def fits() -> bool:
                if V._loaded_vram_mb(base, model) > 0:
                    return True                       # 既に GPU に載っている
                if remote:
                    rv = int(self.cfg.get("llm.auto_ctx.remote_vram_mb", 0) or 0)
                    if rv <= 0:
                        return False                  # 別マシンの空き VRAM が分からない → CPU（メインを追い出さない）
                    g = (rv - V.loaded_vram_total_mb(base), rv)
                else:
                    g = V.gpu_free_total_mb()
                if not g:
                    return True                       # GPU 情報なし → Ollama に任せる
                info, size = V._model_info(base, model)
                kvpt, _ = V._kv_bytes_per_token(info)
                need = size + int(ctx * kvpt * V.KV_TYPE_FACTOR.get(kv_type, 1.0) / 1048576) + 768
                # 読み込み時の一時メモリ（計算グラフ等）で見積もりを超えることがあるため、余裕を大きめに取る。
                # ぎりぎりで GPU に載せると、読み込み中の VRAM 不足でメインの応答まで 500 で落ちることがある
                return g[0] >= int(need * 1.3) + 1536
            try:
                if not await asyncio.to_thread(fits):
                    opts["num_gpu"] = 0
            except Exception:  # noqa: BLE001
                pass
        return opts

    @staticmethod
    def _bg_valid(msgs: list[dict], bg: dict) -> bool:
        cut = bg["cut"]
        return len(msgs) >= cut and msgs[0] is bg["first"] and msgs[cut - 1] is bg["last"]

    async def _start_bg_compact(self, st: LoopState, session: Session, emit: Emit) -> None:
        model = self._helper_model()
        if not model:
            return
        msgs = st.messages
        keep = int(self.cfg.get("compaction.keep_recent", 8))
        if len(msgs) <= keep + 2:
            return
        cut = self._cut_index(msgs, keep)
        if cut < 2 or self._estimate_tokens(msgs[:cut]) < 1000:
            return
        budget = self._summary_budget()
        transcript = self._transcript(msgs[:cut], limit=budget * 4)

        async def job() -> str:
            t0 = time.time()
            opts = await self._helper_options(model, min(len(transcript), budget))
            where = "CPU" if opts.get("num_gpu") == 0 else "GPU"
            self._helper_busy += 1
            try:
                try:
                    summary = await self._summarize_chunked(transcript, budget, model=model, options=opts)
                except Exception as e:  # noqa: BLE001
                    if where != "GPU":
                        raise
                    # GPU での読み込み・実行に失敗（VRAM 不足で 500 など）→ 以後は CPU で。今回も CPU でやり直す
                    self._helper_gpu_ok = False
                    try:
                        await emit({"type": "bg", "task": "compact", "state": "running", "model": model,
                                    "text": f"サブ LLM を GPU で動かせなかったため（{str(e)[:120]}）、CPU でやり直します"})
                    except Exception:  # noqa: BLE001
                        pass
                    where = "CPU"
                    summary = await self._summarize_chunked(transcript, budget, model=model, options={**opts, "num_gpu": 0})
            finally:
                self._helper_busy -= 1
                self._helper_last = time.time()
            summary = summary.strip()
            try:
                await emit({"type": "bg", "task": "compact", "state": "ready", "model": model,
                            "text": f"サブ LLM（{model} / {where}）が履歴の要約を準備しました（{time.time() - t0:.0f} 秒）。必要になった時点で待ち時間なしで圧縮します"})
            except Exception:  # noqa: BLE001
                pass
            return summary

        task = asyncio.create_task(job())
        task.add_done_callback(lambda tk: tk.cancelled() or tk.exception())   # 未取得の例外警告を抑える
        self._bg_compact[session.id] = {"task": task, "cut": cut, "first": msgs[0], "last": msgs[cut - 1],
                                        "model": model, "started": time.time()}
        await emit({"type": "bg", "task": "compact", "state": "running", "model": model,
                    "text": f"サブ LLM（{model}）がバックグラウンドで古い履歴の要約を準備しています（メインの作業はそのまま続きます）"})

    async def _compact(self, st: LoopState, session: Session, emit: Emit, force: bool = False) -> None:
        if not force and not self.cfg.get("compaction.enabled", True):
            return
        threshold = int(self.llm.num_ctx * float(self.cfg.get("compaction.threshold", 0.7)))
        est = max(self._estimate_tokens(st.messages), st.last_prompt_tokens)
        msgs = st.messages
        keep = int(self.cfg.get("compaction.keep_recent", 8))

        # ---- サブ LLM が背景で準備した要約
        bg = self._bg_compact.get(session.id) if st.ctx.depth == 0 else None
        if bg and not self._bg_valid(msgs, bg):
            bg["task"].cancel()
            self._bg_compact.pop(session.id, None)
            bg = None
        if not force and est < threshold:
            prepare = int(threshold * float(self.cfg.get("compaction.prepare_ratio", 0.75)))
            if (bg is None and st.ctx.depth == 0 and est >= prepare and self.cfg.get("compaction.background", True)
                    and not (st.compacted_len >= 0 and len(msgs) - st.compacted_len < 4)):
                await self._start_bg_compact(st, session, emit)
            return
        if bg is not None:
            task = bg["task"]
            hard = int(self.llm.num_ctx * float(self.cfg.get("compaction.hard_ratio", 0.9)))
            if not task.done() and not force and est < hard:
                return            # まだ余裕がある: 準備が終わるまでメインは作業を続ける
            if not task.done():
                await emit({"type": "status", "phase": "compacting", "detail": t("サブ LLM の要約を待っています")})
                try:
                    await asyncio.wait_for(asyncio.shield(task), timeout=float(self.cfg.get("compaction.bg_wait", 300)))
                except (asyncio.TimeoutError, Exception):  # noqa: BLE001
                    pass
            self._bg_compact.pop(session.id, None)
            summary = None
            if task.done() and not task.cancelled() and task.exception() is None:
                summary = task.result()
            else:
                reason = ""
                if task.done() and not task.cancelled() and task.exception() is not None:
                    reason = f"（{str(task.exception())[:150]}）"
                task.cancel()
                await emit({"type": "bg", "task": "compact", "state": "failed", "model": bg["model"],
                            "text": "サブ LLM の要約が使えなかったため、メイン LLM で要約します" + reason})
            if summary and self._bg_valid(msgs, bg):
                await self._apply_summary(st, session, emit, bg["cut"], summary, by=bg["model"])
                return

        if len(msgs) <= keep + 2 or (not force and st.compacted_len >= 0 and len(msgs) - st.compacted_len < 4):
            if force:
                await emit({"type": "info", "text": "履歴が短いため要約は不要です"})
            return
        cut = self._cut_index(msgs, keep)
        old = msgs[:cut]
        if not old:
            return
        if not force and self._estimate_tokens(old) < max(1000, threshold * 0.1):
            # 圧縮しても減らない（コンテキストの大半がシステムプロンプトとツール定義）。毎ステップ要約し続けるのを防ぐ
            if not st.ctx_warned:
                st.ctx_warned = True
                await emit({"type": "info", "text": f"コンテキストの大半がシステムプロンプトとツール定義で占められているため、履歴を圧縮しても減りません。設定でコンテキスト上限を増やしてください（現在 {self.llm.num_ctx:,} tokens）"})
            return

        await emit({"type": "info", "text": f"会話を続けられるように履歴を圧縮しています… (推定 {est:,} / {self.llm.num_ctx:,} tokens)"})
        await emit({"type": "status", "phase": "compacting", "detail": ""})
        # 要約リクエストが num_ctx を超えて Ollama が落ちないよう、1 回に渡す文字数を num_ctx の 4 割程度に抑え、
        # それより長い記録は分割して段階的に要約する
        budget = self._summary_budget()
        transcript = self._transcript(old, limit=budget * 4)
        try:
            summary = await self._summarize_chunked(transcript, budget)
        except Exception as e:
            await emit({"type": "error", "text": f"要約に失敗しました: {e}"})
            return
        await self._apply_summary(st, session, emit, cut, summary.strip() or "(要約なし)")

    async def _apply_summary(self, st: LoopState, session: Session, emit: Emit, cut: int, summary: str,
                             by: str | None = None) -> None:
        msgs = st.messages
        old, recent = msgs[:cut], msgs[cut:]
        # 以前の要約があれば統合済みなので置換、無ければ先頭に挿入
        summary_msg = {"role": "user", "kind": "summary", "ts": time.time(),
                       "content": t("【これまでの作業の要約（自動圧縮）】\n") + summary}
        ack = {"role": "assistant", "content": t("要約を確認しました。この内容を踏まえて作業を続けます。"), "tool_calls": [], "ts": time.time()}
        session.archive.append({"ts": time.time(), "messages": [m for m in old if m.get("kind") != "summary"]})
        msgs[:] = [summary_msg, ack] + recent
        st.last_prompt_tokens = 0
        st.compacted_len = len(msgs)
        if st.on_save:
            st.on_save()
        await emit({"type": "compacted", "summary": summary, "removed": len(old), "kept": len(recent), "by": by})
        if by:
            await emit({"type": "bg", "task": "compact", "state": "applied", "model": by,
                        "text": f"サブ LLM（{by}）が準備した要約で履歴を圧縮しました（待ち時間なし）"})

    async def _summarize_chunked(self, transcript: str, budget: int, model: str | None = None,
                                 options: dict | None = None) -> str:
        """budget 文字ごとに分割して要約し、複数になれば要約同士をもう一度まとめる。"""
        async def one(text: str) -> str:
            return await self.llm.complete(P("SUMMARY"), text, model=model, options=options)
        if len(transcript) <= budget:
            return await one(transcript)
        chunks = [transcript[i:i + budget] for i in range(0, len(transcript), budget)]
        parts = []
        for i, ch in enumerate(chunks, 1):
            parts.append(f"[部分 {i}/{len(chunks)} の要約]\n" + await one(ch))
        merged = "\n\n".join(parts)
        if len(merged) <= budget:
            return await one("以下は会話記録を分割して要約したものです。重複を除いて 1 つに統合してください。\n\n" + merged)
        return merged[-budget:]

    @staticmethod
    def _transcript(messages: list[dict], limit: int = 80_000) -> str:
        lines = []
        for m in messages:
            r = m["role"]
            if r == "user":
                lines.append(f"[USER]\n{m['content']}")
            elif r == "assistant":
                if m.get("content"):
                    lines.append(f"[ASSISTANT]\n{m['content']}")
                for tc in m.get("tool_calls") or []:
                    args = str(tc.get("args", ""))
                    lines.append(f"[TOOL CALL] {tc['name']} {args[:400]}")
            elif r == "tool":
                lines.append(f"[TOOL RESULT {m.get('name')}]\n{(m['content'] or '')[:1200]}")
        text = "\n\n".join(lines)
        return text[-limit:]

    # ---------------------------------------------------------------- 履歴
    def _history(self, messages: list[dict], session: Session | None = None, with_images: bool = True) -> list[dict]:
        """LLM に渡す履歴。古いツール結果は短縮し、画像は直近 2 件のユーザー発話分だけ base64 で添付する。"""
        msgs = [{k: v for k, v in m.items() if k not in ("ts", "kind", "text_attachments")} for m in messages]
        tool_idx = [i for i, m in enumerate(msgs) if m["role"] == "tool"]
        for i in tool_idx[:-6]:
            c = msgs[i]["content"]
            if len(c) > 1500:
                msgs[i]["content"] = c[:1500] + "\n...(省略)"
        img_idx = [i for i, m in enumerate(msgs) if m["role"] == "user" and m.get("images")]
        for n, i in enumerate(reversed(img_idx)):
            names = msgs[i].pop("images")
            b64s = [b for b in (self._image_b64(session, f) for f in names)] if (session and with_images and n < 2) else []
            b64s = [b for b in b64s if b]
            if b64s:
                msgs[i]["images"] = b64s
            else:
                msgs[i]["content"] = f"[画像 {len(names)} 枚を添付]\n" + msgs[i]["content"]
        return msgs
