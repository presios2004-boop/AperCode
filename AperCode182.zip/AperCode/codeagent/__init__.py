"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "1.8.2"
__app_name__ = "AperCode"
