"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "2.11.26"
__app_name__ = "AperCode"
