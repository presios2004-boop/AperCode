# AperCode

[日本語](README.md)

A general-purpose coding agent that runs on local LLMs (Ollama), with a browser/desktop UI.
Built for medium-sized projects: context compaction, sub-agents, and an experience memory that learns from past successes and failures.

## Language

The UI, dialogs, verification messages and tool descriptions are available in **English and Japanese**. The default is `auto`
(follows the OS `LANG`); change it with the language selector at the bottom of the sidebar or `ui.language: en` in
`~/.apercode/config.yaml`. The system prompt has an English version too (`llm.prompt_language`, `auto` follows the UI
language); the model replies in the language you write in.

## Features

- **Agent loop with tools**: read/write/edit files, search, run shell commands, with per-tool approval (allow / ask / deny). "Always allow for this session" covers code generation, edits and test runs; destructive commands (`rm`, `git reset --hard`, `sudo`, `dd`, `kill`, `drop table`, …) always ask
- **Local first**: works with any Ollama model that supports tool calling (a JSON fallback is available for models that don't); Anthropic API is optional
- **Context compaction**: when the history approaches the context window, older messages are summarized automatically
- **Sub-agents**: delegate exploration (read-only) or implementation (read/write) tasks to child agents with their own context. Since v1.2.2 the UI has two model selectors: the main model (chat/implementation) and a sub model used for sub-agents and code review — pick a small model (e.g. `llama3.1:8b`) there to make exploration and review faster; the choice is remembered in `~/.apercode/state.json`
- **Experience memory**: lessons are extracted after each task and stored in SQLite (FTS5 + embedding vectors, hybrid search). Relevant lessons are injected into the prompt on every request. Domain-agnostic — tags are inferred from the project.
- **Automatic context sizing**: at startup and on model switch, the free VRAM (or RAM) and the model's layer/KV-head geometry are used to pick a `num_ctx` that actually fits (capped by `llm.num_ctx`; tunable via `llm.auto_ctx.*`, incl. `kv_cache_type` for q8_0 KV cache) With multiple GPUs, free VRAM is summed across all of them.
- **Verification layer (v1.2.0)**: every `write_file`/`edit_file` is followed by a syntax/lint/type check for that language (`py_compile`+`ruff`, `node --check`/`tsc`, `go vet`, `cargo check`, `shellcheck`, …; external tools are used only if installed) and failures are handed back to the model to fix. Before the final answer the project's tests are run automatically (`pytest`/`unittest`/`npm test`/`go test`/`cargo test`/`make test`, auto-detected; a `run_tests` tool is also available) and failures are pushed back, up to `verify.max_fix_rounds` times; projects without tests are asked to add minimal ones. Changes above `verify.review.min_changed_lines` are reviewed by a read-only sub-agent that reads the diff and reports high/medium issues for the parent to fix. A verification summary is shown at the end of each turn. **Tests are protected against assertion weakening (v1.2.1)**: once a test run has failed in a turn, edits to existing test files (and shell commands that rewrite them) are excluded from "always allow" and require explicit approval (`verify.lock_tests: ask`) or are rejected (`deny`); adding new tests stays allowed, and any change to pre-existing tests is flagged in the summary.
- **Cloud consultation (v1.2.4)**: when the local model is still stuck after web search, an `ask_cloud` tool sends only the goal, the error, what was tried and short code excerpts to a cloud model (Anthropic, Gemini, OpenAI, DeepSeek, Groq, Mistral, OpenRouter, xAI or any OpenAI-compatible URL) and gets back hypotheses and a fix proposal; the local agent still implements and verifies. Gated behind a minimum number of failures, capped per turn, approval before sending, secrets masked. Configured from the "クラウド相談" dialog (stored in `~/.apercode/config.yaml`) or `cloud.*`
- **Browser (v1.4.0)**: with Playwright installed (`pip install playwright && python -m playwright install chromium`; optional) the agent gets `browser_open` / `browser_read` / `browser_click` / `browser_type` / `browser_press` / `browser_scroll` / `browser_eval` / `browser_screenshot` / `browser_console` / `browser_close` and is told to verify web apps it built in a real browser (console errors, DOM existence, screenshot) before reporting done. Screenshots are shown in the chat and passed to vision-capable models as images. `browser.mode: headed` (default, a visible window) or `headless`; `browser.channel: chromium | chrome | msedge | firefox` to use an installed browser; `browser.cdp_url` to attach to a running Chrome (`--remote-debugging-port=9222`); sites other than `localhost` ask for approval (`browser.external_sites`). A "ブラウザ / Browser" button in the sidebar (v1.4.1) launches the same browser at a URL you enter, and the LLM continues from that page
- **Helper tools (v1.5.0)**: `repl` (a persistent Python / Node session — variables and imports survive across calls; uses the project's `.venv`), `process_start` / `process_status` / `process_logs` / `process_stop` (background servers with logged output, optional wait-for-port, stopped on exit), `read_document` (PDF / Word / Excel / PowerPoint / OpenDocument / CSV to text, no extra libraries needed except for PDF) and `check_js` (JavaScript / HTML checker: syntax, unresolvable `import` / `require` and `<script src>`, plus a real-browser run that collects JS exceptions, `console.error` and failed requests; `probes` evaluate JS expressions such as `ForceGraph3D.toString()` to verify how a library is initialised, and `libraries` loads CDN URLs into a blank page to inspect an API before writing code). `.html` files are now part of the automatic post-edit verification
- **Stuck detection**: repeated identical tool calls or consecutive failures trigger a nudge to research (memory → web search) and change approach; hitting the tool-call limit produces a status report instead of silence, and "continue" resumes
- **Web search when stuck**: `web_search` (DuckDuckGo → Bing → Brave → Mojeek fallback chain, no API key) and `fetch_url` tools; the system prompt tells the agent to search, read docs/issues, try fixes, and save what worked to memory with the source URL instead of giving up
- **Automatic backups**: before `write_file`/`edit_file` touches an existing file, the original is copied to `backup/<timestamp>/` in the project (one folder per user request). Restore with the `restore_backup` tool or a plain `cp -r`
- **Icon generator**: `make_icon` tool / `python3 -m codeagent.tools.icon` produces PNG (16–512), `.ico` and `.svg` app icons (Pillow)
- **Background summarisation by the sub LLM (v1.6.1)**: when the history reaches 75 % of the compaction threshold, the sub LLM starts summarising older history in the background while the main LLM keeps working; when compaction is due the prepared summary is swapped in with no wait. The sub LLM runs on GPU only if it fits in free VRAM, otherwise on CPU (`compaction.bg_device: auto`), so the main model is never evicted. Lesson extraction also runs on the sub LLM
- **Settings dialog (v1.6.0)**: change LLM parameters (thinking mode `think`, `num_predict`, temperature, timeout, keep_alive, tool mode, tool-call limit), context sizing and compaction, stuck-detection thresholds, cloud-consult conditions, verification / review / sub-agent / browser options from the UI; saved to `~/.apercode/config.yaml` and applied immediately, with "reset all" back to `config.yaml`. Model thinking (Ollama `thinking`) is shown collapsed in the chat; a reply that ends after thinking only is bounced back with "conclude or call a tool". For coder models that write code or tool-call JSON in the chat instead of calling tools: JSON tool calls in the text are parsed and executed even in native mode, and code-only replies are bounced back once with "write it with write_file / edit_file"
- **Colour-coded chat** (v1.5.1): main-LLM replies (blue), sub-LLM agents / reviews (purple, with a `sub LLM · model · mode` badge), web searches (green) and cloud consultations (orange, with provider / model) are distinguishable at a glance; a legend sits above the log
- **Code blocks with copy button** (v1.2.3): fenced code in replies is rendered with a language label and a Copy button; right-click in the chat gives "copy selection / copy code block / copy message"
- **Attachments**: paste images / long text from the clipboard, drag & drop files, right-click paste
- **Desktop app**: `app.py` starts the server and opens a dedicated window (pywebview → Chromium `--app` → default browser)
- **MetaTrader 5 (wine)**: compile MQL5 and run the strategy tester as tools (optional)

## Quick start

```bash
git clone <this repo> apercode && cd apercode
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m playwright install chromium   # optional: browser tools (v1.4.0)
cp config.example.yaml config.yaml      # edit model name, workspace root, etc.
ollama pull qwen3:8b bge-m3             # chat model + embedding model
python3 app.py                          # or: python3 main.py and open http://127.0.0.1:8765
```

Linux desktop launcher (app menu + desktop icon):

```bash
bash install_desktop.sh
bash setup_linux_window.sh              # optional: dedicated GTK window with native IME support (recommended on Linux)
# or: pip install "pywebview[qt]"        # Qt window (no fcitx IME support in pip Qt)
```

## Troubleshooting

**Selecting a model gives "LLM server error 400 (the model name may be wrong: …)"**

If the name is correct, the model almost certainly **does not support tool calling in Ollama** (e.g. `deepseek-coder-v2:16b`,
`codellama`, older `gemma2`). Ollama answers `400 model does not support tools` when `tools` are sent to such a model.
Pick a model with the **tools** tag on its Ollama page (for coding: `qwen2.5-coder:14b` / `qwen2.5-coder:32b`, `qwen3-coder:30b`, …),
or set `llm.tool_mode: json` to use the JSON-in-text fallback (less reliable). `docker logs ollama --tail 20` shows the actual message.

**Japanese / CJK input method (Mozc, fcitx5, ibus) does not work in the dedicated window**

The Qt shipped by pip (`pywebview[qt]`) does not include the fcitx input-method plugin, so the IME never activates
inside a Qt-backed window, even though it works fine in Firefox or Chromium. Switch to the GTK backend, which uses the
system WebKit2GTK and therefore the system input method:

```bash
bash setup_linux_window.sh
```

The script installs `python3-gi` + WebKit2GTK bindings via apt, recreates `.venv` with `--system-site-packages`
(re-installing requirements) and removes the pip Qt packages. `app.py` prefers the GTK backend whenever it is available.

**The dedicated window does not open and the default browser is used instead**

Check `~/.apercode/app.log`. If it says `Could not load the Qt platform plugin "xcb"`, install `libxcb-cursor0`
(Debian/Ubuntu: `sudo apt install -y libxcb-cursor0`).

**Keeping the agent inside the working directory**

Since 1.1.4, any tool call that points outside the session's working directory (absolute paths, `~/…`, `../`,
or `cd` / absolute paths inside `run_command`) asks for approval even for read-only tools. Approve once, or choose
"always allow for this session". `permissions.outside_project` can be set to `ask` / `allow` / `deny`.
Paths outside `workspace.root` are always rejected.

**The model stops responding right after "saved to memory"**

Fixed in 1.1.7: the post-turn reflection (an extra chat call plus loading the embedding model) now runs in the
background with a timeout, the transcript is capped, the embedding model is released quickly (`keep_alive: 2m`),
the chat model is kept resident (`llm.keep_alive`), and transient Ollama outages are retried. If it still happens,
lower `llm.num_ctx`, clear `memory.embed_model`, or set `memory.reflect: off` (VRAM pressure).

**A new session in a new working directory still works in the previous directory**

Fixed in 1.1.3. Two causes: (1) a server started earlier with `python3 main.py` was still running and `app.py`
attached to it; the launcher now compares the running server's version with the code and restarts it when they
differ. (2) experience memories mentioning other projects' paths pulled the model away; the system prompt now
states the current working directory first and tells the model not to follow paths from memories.

**The model dropdown is rendered white-on-white in the GTK window**

WebKitGTK draws `<select>` with the OS theme. Fixed in 1.1.2 (custom-drawn select, dark colors); update `index.html`.

**`web_search` fails with HTTP 403**

The search site is blocking non-browser clients. Install the `ddgs` package (included in requirements.txt since
v1.2.1.1; for an existing venv run `.venv/bin/pip install ddgs`) — it connects with browser-like TLS and is tried
first. If it still fails, the tool falls back to Bing → Brave → Mojeek → Stack Exchange / GitHub / Wikipedia APIs;
the first line of the result names the engine that was used. If every engine fails, the error lists each engine's
result so you can tell whether your network is blocking them. A self-hosted SearXNG can be set via `web.searxng_url`.

**Pressing Enter to confirm an IME conversion sends the message**

Fixed: Enter is ignored while a composition is in progress. Make sure you are on the latest `index.html`.

## Configuration

Settings are merged in this order (later wins):
1. `config.example.yaml` (bundled defaults)
2. `config.yaml` (project root, git-ignored)
3. `~/.apercode/config.yaml` (per-user overrides)

Key settings: `llm.model`, `llm.num_ctx`, `workspace.root` (the only directory tree the agent may touch),
`permissions.*`, `compaction.*`, `subagents.*`, `memory.*`, `browser.*`, `repl.*`, `process.*`, `mt5.*`.

User data (sessions, memory DB, logs) lives in `~/.apercode/`.

## Layout

```
app.py                  desktop launcher
main.py                 server only
codeagent/agent.py      agent loop, compaction, sub-agents, memory recall/reflection
codeagent/llm.py        Ollama / Anthropic client
codeagent/memory/       experience memory store
codeagent/tools/        fs, shell, mt5, subagent, memory, web tools
codeagent/server/       FastAPI + WebSocket, static UI
```

## License

MIT
