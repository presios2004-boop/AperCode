"""エージェントループ: ユーザー入力 → LLM → ツール実行 → LLM … を繰り返す。

- コンテキスト圧縮: 履歴が閾値を超えたら古い部分を LLM で要約し 1 メッセージに置き換える
- サブエージェント: spawn_agent ツールで独立コンテキストの子ループを起動する

UI とは emit(event: dict) コールバックと、承認要求用の ask_approval コルーチンで接続する。
"""
from __future__ import annotations

import asyncio
import re
import time
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from . import tools as T
from .config import Config
from .llm import LLMClient
from .backup import BackupManager
from .memory import MemoryStore, Embedder
from .prompts import build_system_prompt, P
from .session import Session, SessionStore
from . import verify as V
from .i18n import t
from . import browser as B
from .repl import ReplManager
from .procs import ProcessManager
from .tools.browser_tools import BROWSER_TOOLS, is_local_url

# プロジェクトの言語・ツールをファイル構成から推定するための対応表（タグは小文字）
EXT_TAGS = {
    ".py": "python", ".mq5": "mql5", ".mqh": "mql5", ".mq4": "mql4", ".js": "javascript", ".ts": "typescript",
    ".tsx": "react", ".jsx": "react", ".go": "go", ".rs": "rust", ".java": "java", ".kt": "kotlin", ".c": "c",
    ".cpp": "c++", ".h": "c", ".hpp": "c++", ".cs": "c#", ".rb": "ruby", ".php": "php", ".sh": "bash",
    ".sql": "sql", ".html": "html", ".css": "css", ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
    ".dockerfile": "docker", ".ipynb": "jupyter", ".swift": "swift", ".dart": "flutter", ".lua": "lua",
}
FILE_TAGS = {
    "requirements.txt": "python", "pyproject.toml": "python", "package.json": "node", "Cargo.toml": "rust",
    "go.mod": "go", "Dockerfile": "docker", "docker-compose.yml": "docker", "Makefile": "make",
    "CMakeLists.txt": "cmake", ".git": "git", "pytest.ini": "pytest", "tsconfig.json": "typescript",
}


def detect_project_tags(project: Path, max_files: int = 400) -> list[str]:
    counts: dict[str, int] = {}
    try:
        for i, p in enumerate(project.rglob("*")):
            if i > max_files * 5:
                break
            if any(part in (".git", "node_modules", "__pycache__", ".venv", "venv") for part in p.parts):
                continue
            if p.name in FILE_TAGS:
                counts[FILE_TAGS[p.name]] = counts.get(FILE_TAGS[p.name], 0) + 5
            t = EXT_TAGS.get(p.suffix.lower())
            if t and p.is_file():
                counts[t] = counts.get(t, 0) + 1
    except OSError:
        pass
    return [t for t, _ in sorted(counts.items(), key=lambda x: -x[1])[:6]]

def _parse_json_array(text: str) -> list[dict]:
    """LLM 出力から JSON 配列を取り出す（前後の説明文やコードフェンスを許容）。"""
    import json, re
    text = text.strip()
    m = re.search(r"\[.*\]", text, re.S)
    if not m:
        return []
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return []
    return [d for d in data if isinstance(d, dict)] if isinstance(data, list) else []


# 常時許可の対象外にする「取り返しのつかない」コマンド（config の permissions.dangerous_commands で上書き可）
DEFAULT_DANGEROUS = [
    r"\brm\b", r"\brmdir\b", r"\bshred\b", r"\bunlink\b",
    r"\bgit\s+(reset\s+--hard|clean\b|checkout\s+--\s|restore\b|push\s+(-f|--force)|branch\s+-D|stash\s+drop)",
    r"\bsudo\b", r"\bsu\b", r"\bdd\b", r"\bmkfs", r"\bfdisk\b", r"\bparted\b",
    r"\bchmod\s+-R\b", r"\bchown\b", r"\bkill(all)?\b", r"\bpkill\b", r"\b(shutdown|reboot|poweroff)\b",
    r"\btruncate\b", r">\s*/dev/", r"\bdrop\s+(table|database)\b", r"\bpip3?\s+uninstall\b",
    r"\bapt(-get)?\s+(remove|purge|autoremove)\b", r"\bcurl\b[^|]*\|\s*(ba|z)?sh\b", r"\bwget\b[^|]*\|\s*(ba|z)?sh\b",
    r"\bmv\b.*\s/", r"\bcrontab\s+-r\b", r"\bsystemctl\s+(stop|disable|mask)\b",
]

Emit = Callable[[dict], Awaitable[None]]
AskApproval = Callable[[dict], Awaitable[str]]  # 戻り値: "allow" | "allow_always" | "deny"

# run_command でテストを走らせたと見なすコマンドのパターン
TEST_CMD_RE = re.compile(
    r"\b(pytest|py\.test|unittest|npm\s+(run\s+)?test|pnpm\s+test|yarn\s+test|jest|vitest|mocha|go\s+test|cargo\s+test|make\s+test|phpunit|rspec|dotnet\s+test|mvn\s+test|gradle\s+test)\b")


@dataclass
class VerifyState:
    """1 ターン分の検証状態（自動チェック・テスト・レビュー）。子エージェントとも共有する。"""
    changes: dict[str, dict] = field(default_factory=dict)   # path -> {"before": str|None, "after": str}
    checks: list[V.CheckResult] = field(default_factory=list)
    check_failures: dict[str, int] = field(default_factory=dict)  # path -> NG 回数
    tests: V.TestResult | None = None
    tests_fresh: bool = False          # 最後の変更以降にテストを実行したか
    test_rounds: int = 0               # 自動テストゲートで差し戻した回数
    tests_missing_prompted: bool = False
    review: dict | None = None         # 最後のレビュー結果 {"ok": bool, "issues": [...]}
    review_rounds: int = 0
    change_seq: int = 0                # 変更の通し番号（レビュー後に変更があったかの判定用）
    reviewed_seq: int = -1
    # v1.2.1: テストの保護。失敗したテストを「テスト側を書き換えて」通すのを防ぐ
    test_baseline: dict[str, str] = field(default_factory=dict)   # ターン開始時の既存テスト {rel: sha1}
    tests_locked: bool = False         # テストが一度失敗した後 True（既存テストの変更は要承認/拒否）
    tests_modified: list[str] = field(default_factory=list)       # 基準から変更・削除された既存テスト
    test_edit_denied: int = 0          # テスト変更をブロックした回数
    # v1.2.4: クラウド相談の発動条件用
    stuck_count: int = 0               # 行き詰まり検知の回数
    llm_error: bool = False            # このターンが LLM エラーで終わった
    cloud_calls: int = 0               # このターンの ask_cloud 回数
    cloud_denied: int = 0              # （予約）

    def record_change(self, rel: str, before: str | None, after: str) -> None:
        c = self.changes.get(rel)
        if c is None:
            self.changes[rel] = {"before": before, "after": after}
        else:
            c["after"] = after
        self.tests_fresh = False
        self.change_seq += 1

    def record_tests(self, res: V.TestResult) -> None:
        self.tests = res
        self.tests_fresh = res.detected
        if res.detected and not res.ok:
            self.tests_locked = True

    def changed_lines(self) -> int:
        return sum(V.count_changed_lines(c["before"], c["after"]) for c in self.changes.values())

    def code_changed(self) -> bool:
        return any(Path(p).suffix.lower() in V.CHECKERS or Path(p).suffix.lower() in (".mq5", ".mqh")
                   for p in self.changes)

    def diff(self, max_chars: int = 24000) -> str:
        parts = [V.unified_diff(c["before"], c["after"], p) for p, c in self.changes.items()]
        text = "\n\n".join(parts)
        return text[:max_chars] + ("\n... (省略)" if len(text) > max_chars else "")

    def summary(self) -> dict:
        ng = [c for c in self.checks if not c.ok and not c.skipped]
        return {
            "files": len(self.changes), "lines": self.changed_lines(),
            "checks": {"run": len(self.checks), "ng": len(ng)},
            "tests": self.tests.summary() if self.tests else None,
            "tests_ok": self.tests.ok if self.tests else None,
            "review": (None if self.review is None else
                       {"ok": self.review.get("ok"), "issues": len(self.review.get("issues") or []), "rounds": self.review_rounds}),
            "tests_modified": list(self.tests_modified), "test_edit_denied": self.test_edit_denied,
        }


@dataclass
class LoopState:
    """1 つのエージェントループ（親または子）の状態。"""
    messages: list[dict]
    system: str
    tool_names: list[str] | None          # None = 全ツール
    ctx: T.ToolContext
    model: str | None = None
    usage: dict = field(default_factory=lambda: {"prompt_tokens": 0, "completion_tokens": 0})
    last_prompt_tokens: int = 0
    on_save: Callable[[], None] | None = None
    compacted_len: int = -1               # 直近の圧縮直後のメッセージ数（連続圧縮の防止用）
    ctx_warned: bool = False              # 「圧縮しても減らない」警告を出したか


class Agent:
    def __init__(self, cfg: Config, llm: LLMClient, store: SessionStore):
        self.cfg = cfg
        self.llm = llm
        self.store = store
        self.session_allow: dict[str, set[str]] = {}  # session_id -> 常時許可したツール名
        self._cancel: dict[str, asyncio.Event] = {}
        self.memory: MemoryStore | None = None
        self._bg_tasks: set[asyncio.Task] = set()
        self._bg_compact: dict[str, dict] = {}   # v1.6.1: session_id -> サブ LLM が背景で準備中／準備済みの要約
        # ブラウザ（Playwright）。無効または未インストールなら None でツールを隠す
        self.browser = B.Browser(cfg) if (cfg.get("browser.enabled", True) and B.is_available()) else None
        # v1.5.0: 永続 REPL とバックグラウンドプロセス（サーバー終了時にまとめて停止）
        self.repls = ReplManager()
        self.procs = ProcessManager(store.root / "process_logs")
        # サブエージェント／レビュー用モデル（UI から変更可。None = config の subagents.*_model → 親と同じ）
        self.sub_model: str | None = (cfg.state().get("sub_model") or None)
        if cfg.get("memory.enabled", True):
            from .config import expand
            self.memory = MemoryStore(expand(cfg.get("memory.db_path", "~/.apercode/memory.sqlite")),
                                      Embedder(llm.base_url, cfg.get("memory.embed_model")))
        T.load_builtin()

    def cancel(self, session_id: str):
        ev = self._cancel.get(session_id)
        if ev:
            ev.set()

    # ------------------------------------------------------------------ 権限
    # 「このセッションでは常に許可」でまとめて許可されるツール群（編集・実行系）
    EDIT_RUN_GROUP = {"write_file", "edit_file", "run_command", "mt5_compile", "mt5_backtest", "make_icon", "repl", "process_start", "process_stop"}

    def _session_allowed(self, session: Session) -> set[str]:
        """セッションごとの常時許可（メモリ上 + セッション JSON に永続化）。"""
        s = self.session_allow.setdefault(session.id, set())
        s.update(getattr(session, "allow", []) or [])
        return s

    def _grant(self, session: Session, key: str):
        self._session_allowed(session).add(key)
        session.allow = sorted(self._session_allowed(session))
        self.store.save(session)

    def _dangerous(self, name: str, args: dict) -> str | None:
        """取り返しのつかない操作なら理由を返す（常時許可の対象外にする）。"""
        import re
        if name == "restore_backup":
            return "バックアップからの復元"
        if name not in ("run_command", "process_start", "repl"):
            return None
        cmd = str(args.get("command", "")) if name != "repl" else str(args.get("code", ""))
        pats = self.cfg.get("permissions.dangerous_commands") or DEFAULT_DANGEROUS
        for pat in pats:
            try:
                if re.search(pat, cmd):
                    return f"危険なコマンド（{pat}）"
            except re.error:
                continue
        return None

    def _decide(self, session: Session, name: str, args: dict) -> str:
        mode = self.cfg.permission(name)
        if mode in ("allow", "deny"):
            return mode
        allowed = self._session_allowed(session)
        if name in allowed or (name in self.EDIT_RUN_GROUP and "edit_run" in allowed):
            return "allow"
        if name == "run_command":
            cmd = str(args.get("command", "")).strip()
            for pat in self.cfg.get("permissions.auto_allow_commands", []) or []:
                if cmd.startswith(pat):
                    return "allow"
        return "ask"

    # ------------------------------------------------------------------ 入口
    async def run(self, session: Session, user_text: str, emit: Emit, ask_approval: AskApproval,
                  attachments: list[dict] | None = None):
        cancel = asyncio.Event()
        self._cancel[session.id] = cancel
        project = Path(session.project_dir)
        backup = BackupManager(self.cfg, project)
        backup.begin_turn()
        verify = VerifyState()   # 検証が無効でも、行き詰まり回数などの記録には使う
        # 前ターンが LLM エラーや未解決で終わっていれば、失敗回数を持ち越す（クラウド相談の発動条件がリセットされないように）
        verify.stuck_count = int(getattr(session, "stuck_carry", 0) or 0)
        if self.cfg.get("verify.enabled", True) and str(self.cfg.get("verify.lock_tests", "ask")) != "off":
            verify.test_baseline = V.snapshot_tests(project, self.cfg.get("verify.test_patterns") or None)
        ctx = T.ToolContext(self.cfg, project, depth=0, memory=self.memory, backup=backup, verify=verify,
                            browser=self.browser, files_dir=self.store.root / f"{session.id}_files",
                            session_id=session.id, repls=self.repls, procs=self.procs)
        project_tags = detect_project_tags(project)
        memories_text = await self._recall(user_text, project, project_tags, emit)
        state = LoopState(messages=session.messages,
                          system=build_system_prompt(project, self.cfg.workspace_root, memories_text),
                          tool_names=None, ctx=ctx, usage=session.usage,
                          last_prompt_tokens=session.last_prompt_tokens,
                          on_save=lambda: self.store.save(session))

        start_len = len(session.messages)
        user_msg = {"role": "user", "content": user_text, "ts": time.time()}
        if attachments:
            user_msg.update(self._store_attachments(session, user_text, attachments))
        session.messages.append(user_msg)
        if session.title in ("新しいセッション", "New session"):
            session.title = user_text.strip().splitlines()[0][:40]
        self.store.save(session)
        try:
            await self._loop(state, session, emit, ask_approval, cancel,
                             max_iter=int(self.cfg.get("llm.max_iterations", 40)))
            if backup.saved:
                await emit({"type": "info", "text": f"変更前のファイル {len(backup.saved)} 件を {backup.dirname}/{backup._stamp}/ に退避しました"})
            if verify.changes and self.cfg.get("verify.enabled", True):
                await emit({"type": "verify_summary", **verify.summary()})
        finally:
            session.last_prompt_tokens = state.last_prompt_tokens
            self._cancel.pop(session.id, None)
            # 失敗回数の持ち越し: 未解決（テスト失敗・自動検証 NG・LLM エラー）なら次ターンへ、解決していればリセット
            unresolved = (verify.tests is not None and verify.tests.detected and not verify.tests.ok) or \
                         any(verify.check_failures.values()) or verify.llm_error
            total = verify.stuck_count + verify.test_rounds + sum(verify.check_failures.values())
            session.stuck_carry = min(total, 10) if unresolved else 0
            self.store.save(session)
            await emit({"type": "done", "usage": session.usage,
                        "context": self._context_info(state)})
        # 振り返り（教訓抽出）は応答完了後にバックグラウンドで行う。失敗しても会話には影響させない
        if not cancel.is_set():
            turn = list(session.messages[start_len:])
            task = asyncio.create_task(self._reflect_safe(turn, project, project_tags, emit))
            self._bg_tasks.add(task)
            task.add_done_callback(self._bg_tasks.discard)

    async def _reflect_safe(self, turn: list[dict], project: Path, tags: list[str], emit: Emit) -> None:
        try:
            await asyncio.wait_for(self._reflect(turn, project, tags, emit), timeout=float(self.cfg.get("memory.reflect_timeout", 180)))
        except asyncio.TimeoutError:
            await emit({"type": "info", "text": "教訓の抽出がタイムアウトしたためスキップしました"})
        except Exception as e:  # noqa: BLE001
            try:
                await emit({"type": "info", "text": f"教訓の抽出をスキップ: {e}"})
            except Exception:
                pass

    def _store_attachments(self, session: Session, user_text: str, attachments: list[dict]) -> dict:
        """添付を処理する。画像はセッション用フォルダにファイル保存し、テキストは本文に埋め込む。"""
        import base64
        files_dir = self.store.root / f"{session.id}_files"
        images: list[str] = []
        texts: list[str] = []
        content = user_text
        for i, a in enumerate(attachments[:10]):
            kind = a.get("kind")
            name = str(a.get("name") or f"attachment{i}")
            if kind == "image":
                data = str(a.get("data", ""))
                if "," in data:
                    header, b64 = data.split(",", 1)
                    ext = "png" if "png" in header else "jpg" if "jpe" in header else "webp" if "webp" in header else "gif" if "gif" in header else "png"
                else:
                    b64, ext = data, "png"
                try:
                    raw = base64.b64decode(b64)
                except Exception:
                    continue
                if len(raw) > 8 * 1024 * 1024:
                    continue
                files_dir.mkdir(parents=True, exist_ok=True)
                fname = f"{int(time.time()*1000)}_{i}.{ext}"
                (files_dir / fname).write_bytes(raw)
                images.append(fname)
            elif kind == "text":
                body = str(a.get("content", ""))[:60_000]
                texts.append(name)
                content += "\n\n" + t(f"[添付テキスト: {name}]") + f"\n```\n{body}\n```"
        out: dict = {"content": content}
        if images:
            out["images"] = images  # ファイル名（セッション用フォルダ内）
        if texts:
            out["text_attachments"] = texts
        return out

    def _image_b64(self, session: Session, fname: str) -> str | None:
        import base64
        p = self.store.root / f"{session.id}_files" / fname
        if not p.is_file():
            return None
        return base64.b64encode(p.read_bytes()).decode()

    async def compact_now(self, session: Session, emit: Emit) -> None:
        """UI からの手動圧縮。"""
        project = Path(session.project_dir)
        ctx = T.ToolContext(self.cfg, project)
        state = LoopState(messages=session.messages, system="", tool_names=None, ctx=ctx,
                          usage=session.usage, on_save=lambda: self.store.save(session))
        await self._compact(state, session, emit, force=True)
        session.last_prompt_tokens = 0
        self.store.save(session)
        await emit({"type": "done", "usage": session.usage, "context": self._context_info(state)})

    # ------------------------------------------------------------------ ループ本体
    async def _loop(self, st: LoopState, session: Session, emit: Emit, ask_approval: AskApproval,
                    cancel: asyncio.Event, max_iter: int) -> str:
        """LLM とツールを往復する。最後のアシスタント発話を返す。

        行き詰まり検知: 同じツール呼び出しの繰り返し／連続エラーを検知したら、Web 検索など別アプローチを
        促すメッセージを履歴に差し込む。上限に達したら黙って止まらず、状況報告を生成させる。
        """
        import json as _json
        last_text = ""
        sig_count: dict[str, int] = {}      # 同一ツール呼び出しの回数
        consecutive_errors = 0
        nudges = 0
        searched_recently = False
        limit_hit = False
        no_progress = 0                      # 進捗（ファイル変更・テスト・相談）の無いツール呼び出しの連続回数
        PROGRESS_TOOLS = {"write_file", "edit_file", "run_tests", "mt5_compile", "mt5_backtest", "ask_cloud", "save_memory", "restore_backup",
                          "repl", "process_start", "check_js"}
        np_limit = int(self.cfg.get("stuck.no_progress_calls", 12))
        repeat_limit = int(self.cfg.get("stuck.repeat_calls", 3))
        err_limit = int(self.cfg.get("stuck.consecutive_errors", 3))
        empty_nudges = 0                     # 思考だけで本文もツール呼び出しも無い応答への差し戻し回数
        code_nudges = 0                      # コードをチャットに貼るだけで終わった応答への差し戻し回数
        for _ in range(max_iter):
            if cancel.is_set():
                await emit({"type": "info", "text": "中断しました"})
                break
            if st.ctx.depth == 0:
                await self._compact(st, session, emit)

            text_parts: list[str] = []
            tool_calls: list[dict] = []
            think_chars = 0
            await emit({"type": "status", "phase": "thinking", "detail": st.model or self.llm.model})
            history = self._history(st.messages, session, with_images=st.ctx.depth == 0)
            try:
                try:
                    stream = self.llm.chat(st.system, history, T.schemas(self._tools_for(st)), st.model)
                    first = await stream.__anext__()
                except StopAsyncIteration:
                    first = None
                except Exception as e:
                    # 画像非対応モデルの場合は画像を外して再試行
                    if any(m.get("images") for m in history) and any(w in str(e).lower() for w in ("image", "vision", "multimodal")):
                        await emit({"type": "info", "text": "このモデルは画像に対応していないため、画像を除いて送信します"})
                        history = self._history(st.messages, session, with_images=False)
                        stream = self.llm.chat(st.system, history, T.schemas(self._tools_for(st)), st.model)
                        first = await stream.__anext__()
                    else:
                        raise

                async def _chain():
                    if first is not None:
                        yield first
                    async for ev in stream:
                        yield ev

                async for kind, data in _chain():
                    if cancel.is_set():
                        break
                    if kind == "text":
                        if not text_parts:
                            await emit({"type": "status", "phase": "generating", "detail": ""})
                        text_parts.append(data)
                        await emit({"type": "text", "delta": data})
                    elif kind == "thinking":
                        think_chars += len(data)
                        await emit({"type": "think", "delta": data})
                    elif kind == "tool_call":
                        tool_calls.append(data)
                    elif kind == "done":
                        st.usage["prompt_tokens"] += data.get("prompt_tokens", 0)
                        st.usage["completion_tokens"] += data.get("completion_tokens", 0)
                        st.last_prompt_tokens = data.get("prompt_tokens", 0) or st.last_prompt_tokens
                        # ヘッダーの使用量・コンテキスト表示をリアルタイムに更新（子はコンテキスト無しで使用量のみ）
                        await emit({"type": "usage", "usage": st.usage,
                                    "context": self._context_info(st) if st.ctx.depth == 0 else None})
            except Exception as e:  # LLM 通信エラー
                if st.ctx.verify is not None:
                    st.ctx.verify.llm_error = True
                    st.ctx.verify.stuck_count += 1   # 落ちた分も「行き詰まり」として数える
                await emit({"type": "error", "text": f"LLM エラー: {e}"})
                break

            content = "".join(text_parts)
            # coder 系モデルが tool calling を使わず本文に JSON でツール呼び出しを書いた場合の救済
            if not tool_calls and content:
                extracted = self.llm.extract_text_tool_calls(content, set(self._tools_for(st)))
                if extracted:
                    tool_calls = extracted
                    await emit({"type": "info", "text": f"本文に書かれたツール呼び出し（{', '.join(tc['name'] for tc in extracted)}）を解析して実行します"})
            last_text = content or last_text
            st.messages.append({"role": "assistant", "content": content, "tool_calls": tool_calls,
                                "ts": time.time()})
            if st.on_save:
                st.on_save()
            if not tool_calls and not cancel.is_set():
                # ---- 思考だけで終わった（本文が空）→ 結論かツール呼び出しを求める
                if not content.strip() and empty_nudges < 2:
                    empty_nudges += 1
                    why = "思考だけで終わり、本文もツール呼び出しもありませんでした" + (f"（思考 {think_chars:,} 文字）" if think_chars else "")
                    await emit({"type": "info", "text": why + "。結論またはツール呼び出しを求めます"})
                    st.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content": t(
                        "【システム】" + why + "。長く考え込まず、次のどちらかをしてください: (a) 必要なツールを呼ぶ "
                        "(b) 結論と次の一手を 5 行以内で書く。")})
                    if st.on_save:
                        st.on_save()
                    continue
                # ---- コードをチャットに貼っただけ（ファイルに書いていない）→ ツールで書くよう求める
                if st.ctx.depth == 0 and code_nudges < 1 and self._code_only_reply(st, content):
                    code_nudges += 1
                    await emit({"type": "info", "text": "コードがチャットに書かれただけでファイルに反映されていません。write_file / edit_file で書き込むよう求めます"})
                    st.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content": t(
                        "【システム】コードをチャットに書くだけでは何も実行・保存されません。write_file / edit_file ツールで実際のファイルに"
                        "書き込み、run_tests（または run_command / check_js）で動作を確認してから完了報告してください。"
                        "ユーザーが説明だけを求めている場合は、その旨を一言書いて終了して構いません。")})
                    if st.on_save:
                        st.on_save()
                    continue
                # ---- 完了ゲート（親のみ）: テスト未実行なら自動実行、変更が大きければレビュー
                if st.ctx.depth == 0 and st.ctx.verify is not None and self.cfg.get("verify.enabled", True) and not cancel.is_set():
                    gate = await self._completion_gate(st, session, emit, ask_approval, cancel)
                    if gate:
                        st.messages.append({"role": "user", "kind": "nudge", "content": t(gate), "ts": time.time()})
                        if st.on_save:
                            st.on_save()
                        sig_count.clear()
                        consecutive_errors = 0
                        continue
                break

            repeated = False
            for tc in tool_calls:
                if cancel.is_set():
                    break
                sig = tc.get("name", "") + ":" + _json.dumps(tc.get("args", {}), sort_keys=True, ensure_ascii=False)[:500]
                sig_count[sig] = sig_count.get(sig, 0) + 1
                if sig_count[sig] >= repeat_limit:
                    repeated = True
                if tc.get("name") in ("web_search", "fetch_url", "search_memory"):
                    searched_recently = True
                result = await self._exec_tool(st, session, tc, emit, ask_approval, cancel)
                is_err = result.startswith(("エラー", "不明", "ユーザーがこの操作を拒否", "Error", "Unknown", "The user denied")) or "(exit " in result and "(exit 0)" not in result
                consecutive_errors = consecutive_errors + 1 if is_err else 0
                no_progress = 0 if (tc.get("name") in PROGRESS_TOOLS and not is_err) else no_progress + 1
                st.messages.append({"role": "tool", "tool_call_id": tc["id"], "name": tc["name"],
                                    "content": result, "ts": time.time()})
                if st.on_save:
                    st.on_save()

            # ---- 行き詰まり検知 → 別アプローチ（Web 検索・クラウド相談）を促す
            stalled = np_limit > 0 and no_progress >= np_limit and st.ctx.depth == 0
            stuck = repeated or (consecutive_errors >= err_limit and not searched_recently) or stalled
            if stuck and nudges < 3:
                nudges += 1
                if repeated:
                    why = "同じツール呼び出しを 3 回以上繰り返しています"
                elif stalled:
                    why = f"ファイルの変更やテストをせずに調査だけを {no_progress} 回続けています（進捗なし）"
                    no_progress = 0
                else:
                    why = f"ツールの失敗が {consecutive_errors} 回連続しています"
                if st.ctx.verify is not None:
                    st.ctx.verify.stuck_count += 1
                cloud_hint = ""
                if self.cfg.get("cloud.enabled", False) and st.ctx.depth == 0:
                    cloud_hint = " (5) それでも駄目なら ask_cloud で、目的・エラー・試したこと・関連ファイルを添えてクラウド AI に相談する。"
                if stalled:
                    nudge = (f"【システム】{why}。いったん調査を止めて、次を短く書き出してください: "
                             "(a) これまでに立てた仮説と、それぞれを検証した結果（否定された仮説は捨てる） (b) まだ確認していない層"
                             "（表示・初期化・ライブラリの呼び出し方・環境・プロセス/ポート） (c) 次に試す 1 つの具体的な変更。"
                             "エラーが出ないのに動かない場合は、コードを読み直す前に「存在確認」（DOM 要素・canvas・プロセス・ポート・ログ行が"
                             "本当にあるか）を行ってください。ライブラリの初期化・呼び出し方は記憶で書かず、そのバージョンの README を fetch_url で読んで確認してください。"
                             + (" 整理しても原因が絞れなければ、ask_cloud で目的・症状・試したことを添えてクラウド AI に相談してください。"
                                if self.cfg.get("cloud.enabled", False) else ""))
                else:
                    nudge = (f"【システム】{why}。同じ操作をこれ以上繰り返さないでください。次の手順で別のアプローチを取ってください: "
                             "(1) 直近のエラー文を読み直して原因の仮説を立てる (2) search_memory で過去の解決策を確認 "
                             "(3) web_search でエラー文・ライブラリ名を検索し fetch_url で解決策を読む (4) 別の方法を試す。" + cloud_hint +
                             "それでも解決しない場合は、試したこと・分かったこと・残る選択肢を整理してユーザーに報告して終了してください。")
                st.messages.append({"role": "user", "kind": "nudge", "content": t(nudge), "ts": time.time()})
                await emit({"type": "info", "text": f"行き詰まりを検知（{why}）。" + ("仮説の整理と別の層の確認を促しました" if stalled else "Web 検索などの別アプローチを促しました")})
                sig_count.clear()
                consecutive_errors = 0
                searched_recently = False
        else:
            limit_hit = True

        # ---- 上限到達: 黙って止まらず、状況報告を生成させる
        if limit_hit and not cancel.is_set():
            await emit({"type": "info", "text": f"ツール呼び出し上限 ({max_iter}) に達しました。状況報告を生成します"})
            st.messages.append({"role": "user", "kind": "nudge", "ts": time.time(), "content": t(
                "【システム】ツール呼び出しの上限に達したため、いったん作業を止めます。ツールは使わずに、"
                "ここまでに完了したこと・未完了のこと・発生している問題と原因の推測・次に試すべき手順を簡潔に報告してください。"
                "ユーザーが「続けて」と送れば作業を再開できます。")})
            await emit({"type": "status", "phase": "generating", "detail": "状況報告"})
            parts: list[str] = []
            try:
                async for kind, data in self.llm.chat(st.system, self._history(st.messages, session, with_images=False),
                                                      [], st.model):
                    if kind == "text":
                        parts.append(data)
                        await emit({"type": "text", "delta": data})
                    elif kind == "done":
                        st.usage["prompt_tokens"] += data.get("prompt_tokens", 0)
                        st.usage["completion_tokens"] += data.get("completion_tokens", 0)
            except Exception as e:
                await emit({"type": "error", "text": f"状況報告の生成に失敗: {e}"})
            report = "".join(parts).strip()
            if report:
                st.messages.append({"role": "assistant", "content": report, "tool_calls": [], "ts": time.time()})
                last_text = report
            if st.on_save:
                st.on_save()
            if st.ctx.depth == 0:
                await emit({"type": "info", "text": "「続けて」と送ると作業を再開します（上限は config.yaml の llm.max_iterations で変更可）"})
        return last_text

    _CODE_FENCE = re.compile(r"```(?!tool_call)([\w+-]*)\n(.*?)```", re.S)

    def _code_only_reply(self, st: LoopState, content: str) -> bool:
        """コードブロック（8 行以上）を含むのに、このターンでファイルを書いていない応答か。"""
        if "write_file" not in self._tools_for(st):
            return False
        vs = st.ctx.verify
        if vs is not None and vs.changes:
            return False
        for m in self._CODE_FENCE.finditer(content or ""):
            lang = (m.group(1) or "").lower()
            if lang in ("", "text", "txt", "diff", "json", "yaml", "yml", "md", "markdown", "bash", "sh", "shell", "console"):
                continue
            if m.group(2).count("\n") >= 8:
                return True
        return False

    def _tools_for(self, st: LoopState) -> list[str]:
        """LLM に見せるツール一覧。クラウド相談が無効なら ask_cloud を隠す。"""
        names = list(st.tool_names) if st.tool_names is not None else [t.name for t in T.all_tools()]
        if not self.cfg.get("cloud.enabled", False):
            names = [n for n in names if n != "ask_cloud"]
        if st.ctx.browser is None:
            names = [n for n in names if n not in BROWSER_TOOLS]
        return names

    async def _exec_tool(self, st: LoopState, session: Session, tc: dict, emit: Emit,
                         ask_approval: AskApproval, cancel: asyncio.Event) -> str:
        name, args = tc.get("name"), tc.get("args") or {}
        tool = T.get(name) if name else None
        allowed = st.tool_names is None or name in (st.tool_names or [])
        if not tool or not allowed:
            msg = t(f"不明または使用不可のツール: {name}")
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg
        summary = tool.summarize(args)
        await emit({"type": "tool_call", "id": tc["id"], "name": name, "args": args, "summary": summary})

        decision = self._decide(session, name, args)
        reason = ""
        always_key: str | None = "edit_run" if name in self.EDIT_RUN_GROUP else name
        # 作業ディレクトリの外に触れる操作は、ツールの権限設定に関わらずユーザーの許可を求める
        outside = self._outside_paths(st.ctx, name, args)
        if outside:
            mode = str(self.cfg.get("permissions.outside_project", "ask"))
            if mode == "deny":
                decision = "deny"
            elif mode == "ask" and "outside_project" not in self._session_allowed(session):
                decision = "ask"
                reason = "作業ディレクトリの外へのアクセス: " + ", ".join(outside[:3])
                always_key = "outside_project"
        # ブラウザで外部サイトを開くときは確認（localhost は不要）。「常に許可」で以後は確認しない
        if name == "browser_open" and decision != "deny" and not is_local_url(str(args.get("url", ""))):
            mode = str(self.cfg.get("browser.external_sites", "ask"))
            if mode == "deny":
                decision = "deny"
            elif mode == "ask" and "browser_external" not in self._session_allowed(session):
                decision = "ask"
                reason = (reason + " / " if reason else "") + "外部サイトをブラウザで開く: " + str(args.get("url", ""))[:80]
                always_key = "browser_external"
        # v1.2.1: テスト失敗後の既存テスト変更は「常時許可」の対象外（ask）または拒否（deny）
        lock = self._test_lock(st, name, args) if decision != "deny" else None
        if lock:
            mode = str(self.cfg.get("verify.lock_tests", "ask"))
            if mode == "deny":
                st.ctx.verify.test_edit_denied += 1
                msg = t("テストが失敗した後は、既存のテストファイルを変更できません（検証の弱体化を防ぐため）: " + lock +
                        "\nテストではなく実装を修正してください。テスト自体が誤っていると考える場合は、その根拠を"
                        "完了報告に書いてユーザーの判断を仰いでください。")
                await emit({"type": "verify", "kind": "lock", "ok": False, "text": f"テスト変更をブロック: {lock}"})
                await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
                return msg
            decision = "ask"
            reason = (reason + " / " if reason else "") + "テスト失敗後のテスト変更（テストを実装に合わせて弱めていないか確認）: " + lock
            always_key = None
        # 取り返しのつかない操作は常時許可の対象外（毎回確認）
        danger = self._dangerous(name, args) if decision != "deny" else None
        if danger:
            decision = "ask"
            reason = (reason + " / " if reason else "") + danger
            always_key = None
        if decision == "ask":
            await emit({"type": "status", "phase": "approval", "detail": name})
            decision = await ask_approval({"id": tc["id"], "name": name, "args": args, "summary": summary,
                                           "reason": reason, "always": always_key is not None,
                                           "always_label": ("このセッションでは編集・実行を常に許可" if always_key == "edit_run"
                                                            else "このセッションでは常に許可")})
            if decision == "allow_always":
                if always_key:
                    self._grant(session, always_key)
                decision = "allow"
        if decision != "allow":
            if lock:
                st.ctx.verify.test_edit_denied += 1
                await emit({"type": "verify", "kind": "lock", "ok": False, "text": f"テスト変更を拒否: {lock}"})
            msg = t("ユーザーがこの操作を拒否しました。別の方法を検討するか、ユーザーに確認してください。")
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg

        # サブエージェントの実体を注入（子のイベントは parent id 付きで流す）
        if name == "spawn_agent":
            st.ctx.spawn = lambda a: self._spawn(st, session, a, tc["id"], emit, ask_approval, cancel)

        t0 = time.time()
        phase = ("searching" if name in ("web_search", "fetch_url") else "memory" if name in ("save_memory", "search_memory")
                 else "cloud" if name == "ask_cloud" else "browser" if name.startswith("browser_") else "tool")
        await emit({"type": "status", "phase": phase, "detail": f"{name} {summary}"[:80]})
        # 変更前の内容（自動検証・レビュー用の差分に使う）
        before: str | None = None
        target: Path | None = None
        if st.ctx.verify is not None and name in ("write_file", "edit_file") and isinstance(args.get("path"), str):
            try:
                target = st.ctx.resolve(args["path"])
                before = target.read_text(encoding="utf-8", errors="replace") if target.is_file() else None
            except Exception:  # noqa: BLE001
                target = None
        try:
            out = await tool.handler(st.ctx, args)
            err = False
        except T.ToolError as e:
            out, err = f"エラー: {e}", True
        except Exception as e:
            out, err = f"エラー: {type(e).__name__}: {e}\n{traceback.format_exc()[-1500:]}", True
        out = t(out)
        await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": out, "error": err,
                    "elapsed": round(time.time() - t0, 2)})
        # スクリーンショット: 画面に表示し、vision 対応モデル向けに画像付きメッセージとして履歴に入れる
        m = re.search(r"\[\[screenshot:([^\]]+)\]\]", out) if not err else None
        if m:
            fname = m.group(1)
            await emit({"type": "image", "url": f"/api/sessions/{session.id}/files/{fname}", "caption": t("スクリーンショット")})
            st.messages.append({"role": "user", "kind": "screenshot", "content": t("（ブラウザのスクリーンショット。画像を確認して判断すること）"),
                                "images": [fname], "ts": time.time()})
        if not err and st.ctx.verify is not None and self.cfg.get("verify.enabled", True):
            if target is not None and target.is_file():
                out += await self._auto_check(st, target, before, emit)
            elif name == "run_command" and TEST_CMD_RE.search(str(args.get("command", ""))):
                # LLM が自分でテストを走らせた場合も「テスト済み」として扱う
                m = re.search(r"\(exit (-?\d+)\)", out)
                code = int(m.group(1)) if m else 1
                p, f = V._parse_counts(out)
                st.ctx.verify.record_tests(V.TestResult(command=str(args.get("command", "")), exit_code=code,
                                                        passed=p, failed=f, output=out))
        return out

    # ------------------------------------------------------------------ 検証レイヤー（v1.2.0）
    def _test_lock(self, st: LoopState, name: str, args: dict) -> str | None:
        """テスト失敗後に既存テストを書き換えようとしていれば、その対象を返す（新規テストの追加は許可）。"""
        vs: VerifyState | None = st.ctx.verify
        if vs is None or not vs.tests_locked or str(self.cfg.get("verify.lock_tests", "ask")) == "off":
            return None
        pats = self.cfg.get("verify.test_patterns") or None
        if name in ("write_file", "edit_file") and isinstance(args.get("path"), str):
            try:
                target = st.ctx.resolve(args["path"])
                rel = str(target.relative_to(st.ctx.project_dir))
            except Exception:  # noqa: BLE001
                return None
            if V.is_test_file(rel, pats) and (rel in vs.test_baseline or target.is_file()):
                return rel
            return None
        if name == "run_command":
            return V.command_touches_tests(str(args.get("command", "")), pats)
        return None

    async def _auto_check(self, st: LoopState, target: Path, before: str | None, emit: Emit) -> str:
        """write/edit 直後の自動チェック。ツール結果に付け足す文字列を返す。"""
        vs: VerifyState = st.ctx.verify
        project = st.ctx.project_dir
        try:
            after = target.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""
        try:
            rel = str(target.relative_to(project))
        except ValueError:
            rel = str(target)
        vs.record_change(rel, before, after)
        lint_mode = str(self.cfg.get("verify.lint", "auto"))
        if lint_mode == "off":
            return ""
        res = await V.check_file(target, project, lint=True, types=bool(self.cfg.get("verify.types", False)),
                                 timeout=int(self.cfg.get("verify.check_timeout", 180)))
        if res is None or res.skipped:
            return ""
        vs.checks.append(res)
        max_rounds = int(self.cfg.get("verify.max_fix_rounds", 3))
        if res.ok:
            vs.check_failures.pop(rel, None)
            await emit({"type": "verify", "kind": "check", "ok": True, "text": f"自動検証 OK: {res.summary()}"})
            return t(f"\n\n## 自動検証\n{res.summary()}")
        n = vs.check_failures.get(rel, 0) + 1
        vs.check_failures[rel] = n
        await emit({"type": "verify", "kind": "check", "ok": False, "text": f"自動検証 NG: {res.summary()}", "detail": res.output[:2000]})
        tail = ("\n\n## 自動検証\n" + res.summary() + "\n```\n" + res.output[:3000] + "\n```\n")
        if n >= max_rounds:
            tail += (f"このファイルの自動検証が {n} 回連続で NG です。同じ修正を繰り返さず、原因を根本から見直すか、"
                     "解決できない理由を整理してユーザーに報告してください。")
        else:
            tail += "上記の指摘を修正してから次に進んでください（修正後に再度自動検証されます）。"
        return t(tail)

    async def _completion_gate(self, st: LoopState, session: Session, emit: Emit,
                               ask_approval: AskApproval, cancel: asyncio.Event) -> str | None:
        """LLM が完了報告をしようとした時点で、テスト・レビューを行う。差し戻す場合はその指示文を返す。"""
        vs: VerifyState = st.ctx.verify
        if not vs.changes or not vs.code_changed():
            return None
        max_rounds = int(self.cfg.get("verify.max_fix_rounds", 3))

        # ---- 1) テスト
        tests_mode = str(self.cfg.get("verify.tests", "auto"))
        still_failing = vs.tests_fresh and vs.tests is not None and vs.tests.detected and not vs.tests.ok
        if tests_mode == "auto" and (not vs.tests_fresh or still_failing) and vs.test_rounds < max_rounds:
            if still_failing:
                # 失敗したまま何も変更していないのに完了しようとしている → 再実行せずに差し戻す
                res = vs.tests
            else:
                await emit({"type": "status", "phase": "verifying", "detail": "テスト実行"})
                res = await V.run_tests(st.ctx.project_dir, timeout=int(self.cfg.get("verify.test_timeout", 600)),
                                        ignore_dirs=(str(self.cfg.get("backup.dir", "backup")),))
            if res.detected:
                vs.record_tests(res)
                await emit({"type": "verify", "kind": "tests", "ok": res.ok,
                            "text": ("テスト（未修正のまま）: " if still_failing else "テスト: ") + res.summary(),
                            "detail": res.output[-3000:]})
                if res.ok and vs.test_baseline:
                    changed = V.changed_tests(st.ctx.project_dir, vs.test_baseline, self.cfg.get("verify.test_patterns") or None)
                    if changed and changed != vs.tests_modified:
                        vs.tests_modified = changed
                        await emit({"type": "verify", "kind": "lock", "ok": None,
                                    "text": f"注意: 既存テストが変更されています（{len(changed)} 件）。結果の妥当性を確認してください",
                                    "detail": "\n".join(changed)})
                if not res.ok:
                    vs.test_rounds += 1          # 差し戻した回数だけ数える（成功は数えない）
                    last = vs.test_rounds >= max_rounds
                    return ("【システム】完了報告の前にテストを自動実行したところ失敗しました。\n"
                            f"$ {res.command}\n{res.summary()}\n```\n{res.output[-4000:]}\n```\n"
                            + ("自動差し戻しの上限に達しました。「テストは失敗している」と正直に書き、失敗の内容と原因の推測、"
                               "対処案をユーザーに報告してください。"
                               if last else "失敗の原因を実装側で直してから、run_tests で再実行して完了報告してください。"
                               "テストが通っていない状態で「完了」「PASS」と報告しないでください。"
                               + ("原因が分からなければ web_search、それでも駄目なら ask_cloud で相談してください。"
                                  if self.cfg.get("cloud.enabled", False) else "")))
            elif self.cfg.get("verify.create_missing_tests", True):
                vs.test_rounds += 1
                if res.command:
                    # コマンドはあったがテストが 0 件（pytest 形式のテストを unittest で実行した等）
                    await emit({"type": "verify", "kind": "tests", "ok": None, "text": f"テスト: 0 件実行（{res.command}）",
                                "detail": res.output[-2000:]})
                    return ("【システム】テストを実行しましたが 1 件も実行されませんでした。\n"
                            f"$ {res.command}\n```\n{res.output[-2000:]}\n```\n"
                            "テストが実行できる状態にして（必要なら pytest のインストールや tests/__init__.py の追加）、"
                            "run_tests で通ることを確認してから完了報告してください。")
                if not vs.tests_missing_prompted:
                    vs.tests_missing_prompted = True
                    await emit({"type": "verify", "kind": "tests", "ok": None, "text": "テスト: コマンドが見つかりません（作成を促します）"})
                    return ("【システム】このプロジェクトにはテストが見つかりません。完了報告の前に、今回変更した機能に対する"
                            "最小限のテスト（Python なら tests/test_*.py、Node なら package.json の scripts.test 等）を作成し、"
                            "run_tests で実行して通ることを確認してください。テストが本当に不要な場合（設定ファイルのみの変更など）は、"
                            "その理由を書いて完了報告してください。")

        # ---- 2) レビュー（変更が一定量以上）
        rcfg = self.cfg.get("verify.review", {}) or {}
        if rcfg.get("enabled", True) and self.cfg.get("subagents.enabled", True):
            lines = vs.changed_lines()
            min_lines = int(rcfg.get("min_changed_lines", 50))
            max_rev = int(rcfg.get("max_rounds", 2))
            if lines >= min_lines and vs.review_rounds < max_rev and vs.change_seq != vs.reviewed_seq:
                vs.review_rounds += 1
                vs.reviewed_seq = vs.change_seq
                await emit({"type": "status", "phase": "verifying", "detail": f"コードレビュー（{lines} 行）"})
                review = await self._review(st, session, emit, ask_approval, cancel)
                vs.review = review
                issues = [i for i in review.get("issues", []) if str(i.get("severity", "medium")).lower() in ("high", "medium")]
                await emit({"type": "verify", "kind": "review", "ok": review.get("ok", True) and not issues,
                            "text": f"レビュー: {'指摘なし' if not issues else str(len(issues)) + ' 件の指摘'}（{lines} 行）",
                            "detail": "\n".join(f"- [{i.get('severity')}] {i.get('file')}:{i.get('line')} {i.get('problem')} → {i.get('fix')}" for i in issues)[:3000]})
                if issues:
                    body = "\n".join(f"- [{i.get('severity')}] {i.get('file')}" + (f":{i['line']}" if i.get("line") else "") +
                                     f" {i.get('problem')}\n  対処案: {i.get('fix')}" for i in issues)
                    last = vs.review_rounds >= max_rev
                    return ("【レビュー指摘】レビュー担当の子エージェントが以下を指摘しました。妥当なものは修正し、"
                            "修正後は run_tests で確認してから完了報告してください。妥当でない指摘は理由を完了報告に書いてください。\n"
                            + body + ("\n（レビューはこれが最後です。残る指摘は完了報告に含めてください）" if last else ""))
        return None

    async def _review(self, st: LoopState, session: Session, emit: Emit, ask_approval: AskApproval,
                      cancel: asyncio.Event) -> dict:
        """読み取り専用の子エージェントに diff をレビューさせ、{"ok": bool, "issues": [...]} を返す。"""
        import json as _json
        vs: VerifyState = st.ctx.verify
        # 今回のユーザー指示（最後の通常ユーザー発話）
        task = ""
        for m in reversed(st.messages):
            if m["role"] == "user" and m.get("kind") not in ("nudge", "summary"):
                task = m.get("content", "")[:2000]
                break
        prompt = P("REVIEW").replace("{task}", task or "(不明)").replace("{diff}", vs.diff())
        model = self.sub_model or self.cfg.get("verify.review.model") or self.cfg.get("subagents.explore_model") or st.model
        child_ctx = T.ToolContext(self.cfg, st.ctx.project_dir, depth=st.ctx.depth + 1, memory=self.memory,
                                  backup=st.ctx.backup, verify=None, browser=st.ctx.browser, files_dir=st.ctx.files_dir,
                                  session_id=st.ctx.session_id, repls=st.ctx.repls, procs=st.ctx.procs)
        system = build_system_prompt(st.ctx.project_dir, self.cfg.workspace_root) + P("SUBAGENT").format(mode="explore")
        child = LoopState(messages=[{"role": "user", "content": prompt}], system=system,
                          tool_names=list(T.READ_ONLY_TOOLS), ctx=child_ctx, model=model, usage=st.usage)
        rid = "review-" + uuid.uuid4().hex[:6]

        async def child_emit(ev: dict):
            await emit({"type": "sub", "parent": rid, "event": ev})

        await emit({"type": "subagent_start", "id": rid, "mode": "review", "task": f"変更 {len(vs.changes)} ファイルのレビュー",
                    "model": model, "is_sub_model": model != st.model})
        try:
            result = await self._loop(child, session, child_emit, ask_approval, cancel,
                                      max_iter=int(self.cfg.get("verify.review.max_iterations", 12)))
        except Exception as e:  # noqa: BLE001
            await emit({"type": "info", "text": f"レビューをスキップ: {e}"})
            return {"ok": True, "issues": [], "error": str(e)}
        # 最後の JSON オブジェクトを取り出す
        objs = [m for m in re.finditer(r"\{[^{}]*\"ok\"[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", result, re.S)]
        for m in reversed(objs):
            try:
                data = _json.loads(m.group(0))
                if isinstance(data, dict) and "ok" in data:
                    data["issues"] = [i for i in (data.get("issues") or []) if isinstance(i, dict)]
                    return data
            except _json.JSONDecodeError:
                continue
        return {"ok": True, "issues": [], "raw": result[:2000]}

    # ------------------------------------------------------------------ 作業ディレクトリ外の検出
    _ABS_PATH_RE = None

    def _outside_paths(self, ctx: T.ToolContext, name: str, args: dict) -> list[str]:
        """ツール引数が作業ディレクトリ（ctx.project_dir）の外を指していれば、そのパス一覧を返す。"""
        import re
        if self._ABS_PATH_RE is None:
            self._ABS_PATH_RE = re.compile(r"(?<![\w@:.~/])(~/[^\s'\"`;|&<>)]*|/[^\s'\"`;|&<>)]+)")
        project = ctx.project_dir.resolve()

        def is_outside(p: Path) -> bool:
            try:
                p = p.expanduser().resolve()
            except OSError:
                return False
            return p != project and project not in p.parents

        found: list[str] = []
        for key in ("path", "cwd", "image", "out"):
            v = args.get(key)
            if isinstance(v, str) and v.strip():
                p = Path(v).expanduser()
                if not p.is_absolute():
                    p = project / p
                if is_outside(p):
                    found.append(v)
        if name == "run_command":
            cmd = str(args.get("command", ""))
            for m in self._ABS_PATH_RE.finditer(cmd):
                cand = m.group(1)
                # /dev/null, /usr/bin/… など明らかにシステム側の読み取り専用パスは対象外
                if cand.startswith(("/dev/", "/usr/", "/bin/", "/etc/", "/proc/", "/sys/", "/opt/", "/lib", "/tmp/")):
                    continue
                if is_outside(Path(cand)):
                    found.append(cand)
            # cd による移動（相対でも親方向なら外）
            for m in re.finditer(r"(?:^|[;&|]\s*)cd\s+([^\s;&|]+)", cmd):
                target = m.group(1).strip("'\"")
                if target in ("-",):
                    found.append("cd -")
                    continue
                p = Path(target).expanduser()
                if not p.is_absolute():
                    p = project / p
                if is_outside(p):
                    found.append(f"cd {target}")
        # 重複除去（順序維持）
        seen, out = set(), []
        for f in found:
            if f not in seen:
                seen.add(f); out.append(f)
        return out

    # ------------------------------------------------------------------ サブエージェント
    async def _spawn(self, parent: LoopState, session: Session, a: dict, parent_id: str,
                     emit: Emit, ask_approval: AskApproval, cancel: asyncio.Event) -> str:
        if not self.cfg.get("subagents.enabled", True):
            raise T.ToolError(t("サブエージェントは無効化されています"))
        max_depth = int(self.cfg.get("subagents.max_depth", 1))
        if parent.ctx.depth >= max_depth:
            raise T.ToolError(t(f"サブエージェントの深さ上限 ({max_depth}) に達しています。自分で作業してください"))
        mode = a.get("mode", "code")
        tool_names = list(T.READ_ONLY_TOOLS if mode == "explore" else T.CODE_TOOLS)
        if parent.ctx.depth + 1 < max_depth:
            tool_names.append("spawn_agent")
        model = self.sub_model or self.cfg.get(f"subagents.{mode}_model") or parent.model

        child_ctx = T.ToolContext(self.cfg, parent.ctx.project_dir, depth=parent.ctx.depth + 1, memory=self.memory,
                                  backup=parent.ctx.backup, verify=parent.ctx.verify, browser=parent.ctx.browser,
                                  files_dir=parent.ctx.files_dir, session_id=parent.ctx.session_id,
                                  repls=parent.ctx.repls, procs=parent.ctx.procs)
        system = build_system_prompt(parent.ctx.project_dir, self.cfg.workspace_root) + P("SUBAGENT").format(mode=mode)
        task = a["task"] + (f"\n\n## 補足情報\n{a['context']}" if a.get("context") else "")
        child = LoopState(messages=[{"role": "user", "content": task}], system=system,
                          tool_names=tool_names, ctx=child_ctx, model=model, usage=parent.usage)

        async def child_emit(ev: dict):
            await emit({"type": "sub", "parent": parent_id, "event": ev})

        await emit({"type": "subagent_start", "id": parent_id, "mode": mode, "task": a["task"], "model": model,
                    "is_sub_model": model != parent.model})
        result = await self._loop(child, session, child_emit, ask_approval, cancel,
                                  max_iter=int(self.cfg.get("subagents.max_iterations", 30)))
        if not result.strip():
            # 最終報告が無い場合は最後のツール結果を返す
            tails = [m["content"] for m in child.messages if m["role"] == "tool"]
            result = "(子エージェントは最終報告を返しませんでした)\n最後のツール結果:\n" + (tails[-1][:3000] if tails else "なし")
        n_tools = sum(1 for m in child.messages if m["role"] == "tool")
        return t(f"[子エージェント ({mode}) 完了: ツール呼び出し {n_tools} 回]") + "\n" + result

    # ------------------------------------------------------------------ 経験メモリ
    async def _recall(self, user_text: str, project: Path, tags: list[str], emit: Emit) -> str:
        """ユーザー入力に関連する経験を検索し、プロンプト注入用テキストを返す。"""
        if not self.memory or self.memory.count() == 0:
            return ""
        if len(user_text.strip()) < 8:  # 「はい」「OK」などの短い相づちには注入しない
            return ""
        try:
            hits = await self.memory.search(user_text, limit=int(self.cfg.get("memory.inject_top_k", 3)),
                                            tags=tags, project=str(project),
                                            min_score=float(self.cfg.get("memory.inject_min_score", 0.4)))
        except Exception as e:
            await emit({"type": "info", "text": f"経験メモリの検索に失敗: {e}"})
            return ""
        if not hits:
            return ""
        self.memory.touch([m.id for m in hits])
        await emit({"type": "memories_used", "items": [m.to_dict() for m in hits]})
        return "\n".join(f"- {m.to_prompt()}" for m in hits)

    async def _reflect(self, turn_messages: list[dict], project: Path, tags: list[str], emit: Emit) -> None:
        """今回のターンから教訓を抽出して保存する（memory.reflect: auto のとき）。"""
        if not self.memory or self.cfg.get("memory.reflect", "auto") != "auto":
            return
        n_tools = sum(1 for m in turn_messages if m["role"] == "tool")
        if n_tools < int(self.cfg.get("memory.reflect_min_tools", 3)):
            return
        await emit({"type": "status", "phase": "reflecting", "detail": "今回の作業から教訓を抽出して経験メモリに保存"})
        try:
            # 長すぎる記録は末尾（最新）側を優先して 24k 文字に抑える（Ollama のメモリ負荷を抑えるため）
            text = self._transcript(turn_messages)[-24_000:]
            hm = self._helper_model() if self.cfg.get("memory.reflect_with_sub", True) else None
            if hm:   # v1.6.1: 教訓抽出はサブ LLM に任せ、メイン LLM を次の入力のために空けておく
                raw = await self.llm.complete(P("REFLECT"), text, model=hm, options=await self._helper_options(hm, len(text)))
            else:
                raw = await self.llm.complete(P("REFLECT"), text)
            items = _parse_json_array(raw)
        except Exception as e:
            await emit({"type": "info", "text": f"教訓の抽出に失敗: {e}"})
            return
        saved = []
        for it in items[:5]:
            lesson = str(it.get("lesson", "")).strip()
            if not lesson:
                continue
            outcome = it.get("outcome", "info")
            outcome = outcome if outcome in ("success", "failure", "info") else "info"
            item_tags = [str(t) for t in (it.get("tags") or [])] or tags[:2]
            m, dup = await self.memory.add(lesson=lesson, situation=str(it.get("situation", ""))[:300],
                                           action=str(it.get("action", ""))[:300], outcome=outcome,
                                           tags=item_tags, project=str(project), source="auto",
                                           dedup_threshold=float(self.cfg.get("memory.dedup_threshold", 0.92)))
            if m:
                saved.append(m.to_dict())
        if saved:
            await emit({"type": "memories_saved", "items": saved})
        await emit({"type": "status", "phase": None})

    # ------------------------------------------------------------------ 圧縮
    def _estimate_tokens(self, messages: list[dict]) -> int:
        cpt = float(self.cfg.get("compaction.chars_per_token", 2.5))
        n = 0
        for m in messages:
            n += len(m.get("content") or "")
            for tc in m.get("tool_calls") or []:
                n += len(str(tc.get("args", "")))
        return int(n / cpt)

    def _context_info(self, st: LoopState) -> dict:
        est = max(self._estimate_tokens(st.messages), st.last_prompt_tokens)
        return {"estimated_tokens": est, "num_ctx": self.llm.num_ctx, "messages": len(st.messages)}

    # ------------------------------------------------------------------ 履歴圧縮（v1.6.1: サブ LLM による背景準備）
    @staticmethod
    def _cut_index(msgs: list[dict], keep: int) -> int:
        """要約で置き換える範囲の終端。assistant(tool_calls) と tool の対を分断しない位置にする。"""
        cut = len(msgs) - keep
        while cut > 1 and not (msgs[cut]["role"] == "user" or
                               (msgs[cut]["role"] == "assistant" and msgs[cut - 1]["role"] != "assistant")):
            cut -= 1
        return cut

    def _summary_budget(self) -> int:
        cpt = float(self.cfg.get("compaction.chars_per_token", 2.5))
        return max(12_000, int(self.llm.num_ctx * 0.4 * cpt))

    def _helper_model(self) -> str | None:
        """補助作業（背景要約・教訓抽出）に使うモデル。メインと同じなら None（背景では動かさない）。"""
        m = self.cfg.get("compaction.model") or self.sub_model
        return m if m and m != self.llm.model and self.llm.provider == "ollama" else None

    async def _helper_options(self, model: str, prompt_chars: int) -> dict:
        """補助モデル用の Ollama options。必要なだけの num_ctx にし、VRAM に載らないなら CPU で動かす
        （メインモデルを VRAM から追い出して再ロードさせないため）。"""
        from . import vram as V
        cpt = float(self.cfg.get("compaction.chars_per_token", 2.5))
        ctx = int(prompt_chars / cpt * 1.15) + 3072
        ctx = max(8192, min(((ctx + 1023) // 1024) * 1024, self.llm.num_ctx))
        opts: dict = {"num_ctx": ctx, "num_predict": 4096, "temperature": 0.2}
        dev = str(self.cfg.get("compaction.bg_device", "auto")).lower()
        if dev == "cpu":
            opts["num_gpu"] = 0
        elif dev == "auto":
            base = self.llm.base_url
            kv_type = str(self.cfg.get("llm.auto_ctx.kv_cache_type", "f16"))

            def fits() -> bool:
                if V._loaded_vram_mb(base, model) > 0:
                    return True                       # 既に GPU に載っている
                g = V.gpu_free_total_mb()
                if not g:
                    return True                       # GPU 情報なし → Ollama に任せる
                info, size = V._model_info(base, model)
                kvpt, _ = V._kv_bytes_per_token(info)
                need = size + int(ctx * kvpt * V.KV_TYPE_FACTOR.get(kv_type, 1.0) / 1048576) + 768
                return g[0] >= need
            try:
                if not await asyncio.to_thread(fits):
                    opts["num_gpu"] = 0
            except Exception:  # noqa: BLE001
                pass
        return opts

    @staticmethod
    def _bg_valid(msgs: list[dict], bg: dict) -> bool:
        cut = bg["cut"]
        return len(msgs) >= cut and msgs[0] is bg["first"] and msgs[cut - 1] is bg["last"]

    async def _start_bg_compact(self, st: LoopState, session: Session, emit: Emit) -> None:
        model = self._helper_model()
        if not model:
            return
        msgs = st.messages
        keep = int(self.cfg.get("compaction.keep_recent", 8))
        if len(msgs) <= keep + 2:
            return
        cut = self._cut_index(msgs, keep)
        if cut < 2 or self._estimate_tokens(msgs[:cut]) < 1000:
            return
        budget = self._summary_budget()
        transcript = self._transcript(msgs[:cut], limit=budget * 4)

        async def job() -> str:
            t0 = time.time()
            opts = await self._helper_options(model, min(len(transcript), budget))
            where = "CPU" if opts.get("num_gpu") == 0 else "GPU"
            summary = (await self._summarize_chunked(transcript, budget, model=model, options=opts)).strip()
            try:
                await emit({"type": "bg", "task": "compact", "state": "ready", "model": model,
                            "text": f"サブ LLM（{model} / {where}）が履歴の要約を準備しました（{time.time() - t0:.0f} 秒）。必要になった時点で待ち時間なしで圧縮します"})
            except Exception:  # noqa: BLE001
                pass
            return summary

        task = asyncio.create_task(job())
        task.add_done_callback(lambda tk: tk.cancelled() or tk.exception())   # 未取得の例外警告を抑える
        self._bg_compact[session.id] = {"task": task, "cut": cut, "first": msgs[0], "last": msgs[cut - 1],
                                        "model": model, "started": time.time()}
        await emit({"type": "bg", "task": "compact", "state": "running", "model": model,
                    "text": f"サブ LLM（{model}）がバックグラウンドで古い履歴の要約を準備しています（メインの作業はそのまま続きます）"})

    async def _compact(self, st: LoopState, session: Session, emit: Emit, force: bool = False) -> None:
        if not force and not self.cfg.get("compaction.enabled", True):
            return
        threshold = int(self.llm.num_ctx * float(self.cfg.get("compaction.threshold", 0.7)))
        est = max(self._estimate_tokens(st.messages), st.last_prompt_tokens)
        msgs = st.messages
        keep = int(self.cfg.get("compaction.keep_recent", 8))

        # ---- サブ LLM が背景で準備した要約
        bg = self._bg_compact.get(session.id) if st.ctx.depth == 0 else None
        if bg and not self._bg_valid(msgs, bg):
            bg["task"].cancel()
            self._bg_compact.pop(session.id, None)
            bg = None
        if not force and est < threshold:
            prepare = int(threshold * float(self.cfg.get("compaction.prepare_ratio", 0.75)))
            if (bg is None and st.ctx.depth == 0 and est >= prepare and self.cfg.get("compaction.background", True)
                    and not (st.compacted_len >= 0 and len(msgs) - st.compacted_len < 4)):
                await self._start_bg_compact(st, session, emit)
            return
        if bg is not None:
            task = bg["task"]
            hard = int(self.llm.num_ctx * float(self.cfg.get("compaction.hard_ratio", 0.9)))
            if not task.done() and not force and est < hard:
                return            # まだ余裕がある: 準備が終わるまでメインは作業を続ける
            if not task.done():
                await emit({"type": "status", "phase": "compacting", "detail": t("サブ LLM の要約を待っています")})
                try:
                    await asyncio.wait_for(asyncio.shield(task), timeout=float(self.cfg.get("compaction.bg_wait", 300)))
                except (asyncio.TimeoutError, Exception):  # noqa: BLE001
                    pass
            self._bg_compact.pop(session.id, None)
            summary = None
            if task.done() and not task.cancelled() and task.exception() is None:
                summary = task.result()
            else:
                task.cancel()
                await emit({"type": "bg", "task": "compact", "state": "failed", "model": bg["model"],
                            "text": "サブ LLM の要約が間に合わなかったため、メイン LLM で要約します"})
            if summary and self._bg_valid(msgs, bg):
                await self._apply_summary(st, session, emit, bg["cut"], summary, by=bg["model"])
                return

        if len(msgs) <= keep + 2 or (not force and st.compacted_len >= 0 and len(msgs) - st.compacted_len < 4):
            if force:
                await emit({"type": "info", "text": "履歴が短いため要約は不要です"})
            return
        cut = self._cut_index(msgs, keep)
        old = msgs[:cut]
        if not old:
            return
        if not force and self._estimate_tokens(old) < max(1000, threshold * 0.1):
            # 圧縮しても減らない（コンテキストの大半がシステムプロンプトとツール定義）。毎ステップ要約し続けるのを防ぐ
            if not st.ctx_warned:
                st.ctx_warned = True
                await emit({"type": "info", "text": f"コンテキストの大半がシステムプロンプトとツール定義で占められているため、履歴を圧縮しても減りません。設定でコンテキスト上限を増やしてください（現在 {self.llm.num_ctx:,} tokens）"})
            return

        await emit({"type": "info", "text": f"会話を続けられるように履歴を圧縮しています… (推定 {est:,} / {self.llm.num_ctx:,} tokens)"})
        await emit({"type": "status", "phase": "compacting", "detail": ""})
        # 要約リクエストが num_ctx を超えて Ollama が落ちないよう、1 回に渡す文字数を num_ctx の 4 割程度に抑え、
        # それより長い記録は分割して段階的に要約する
        budget = self._summary_budget()
        transcript = self._transcript(old, limit=budget * 4)
        try:
            summary = await self._summarize_chunked(transcript, budget)
        except Exception as e:
            await emit({"type": "error", "text": f"要約に失敗しました: {e}"})
            return
        await self._apply_summary(st, session, emit, cut, summary.strip() or "(要約なし)")

    async def _apply_summary(self, st: LoopState, session: Session, emit: Emit, cut: int, summary: str,
                             by: str | None = None) -> None:
        msgs = st.messages
        old, recent = msgs[:cut], msgs[cut:]
        # 以前の要約があれば統合済みなので置換、無ければ先頭に挿入
        summary_msg = {"role": "user", "kind": "summary", "ts": time.time(),
                       "content": t("【これまでの作業の要約（自動圧縮）】\n") + summary}
        ack = {"role": "assistant", "content": t("要約を確認しました。この内容を踏まえて作業を続けます。"), "tool_calls": [], "ts": time.time()}
        session.archive.append({"ts": time.time(), "messages": [m for m in old if m.get("kind") != "summary"]})
        msgs[:] = [summary_msg, ack] + recent
        st.last_prompt_tokens = 0
        st.compacted_len = len(msgs)
        if st.on_save:
            st.on_save()
        await emit({"type": "compacted", "summary": summary, "removed": len(old), "kept": len(recent), "by": by})
        if by:
            await emit({"type": "bg", "task": "compact", "state": "applied", "model": by,
                        "text": f"サブ LLM（{by}）が準備した要約で履歴を圧縮しました（待ち時間なし）"})

    async def _summarize_chunked(self, transcript: str, budget: int, model: str | None = None,
                                 options: dict | None = None) -> str:
        """budget 文字ごとに分割して要約し、複数になれば要約同士をもう一度まとめる。"""
        async def one(text: str) -> str:
            return await self.llm.complete(P("SUMMARY"), text, model=model, options=options)
        if len(transcript) <= budget:
            return await one(transcript)
        chunks = [transcript[i:i + budget] for i in range(0, len(transcript), budget)]
        parts = []
        for i, ch in enumerate(chunks, 1):
            parts.append(f"[部分 {i}/{len(chunks)} の要約]\n" + await one(ch))
        merged = "\n\n".join(parts)
        if len(merged) <= budget:
            return await one("以下は会話記録を分割して要約したものです。重複を除いて 1 つに統合してください。\n\n" + merged)
        return merged[-budget:]

    @staticmethod
    def _transcript(messages: list[dict], limit: int = 80_000) -> str:
        lines = []
        for m in messages:
            r = m["role"]
            if r == "user":
                lines.append(f"[USER]\n{m['content']}")
            elif r == "assistant":
                if m.get("content"):
                    lines.append(f"[ASSISTANT]\n{m['content']}")
                for tc in m.get("tool_calls") or []:
                    args = str(tc.get("args", ""))
                    lines.append(f"[TOOL CALL] {tc['name']} {args[:400]}")
            elif r == "tool":
                lines.append(f"[TOOL RESULT {m.get('name')}]\n{(m['content'] or '')[:1200]}")
        text = "\n\n".join(lines)
        return text[-limit:]

    # ---------------------------------------------------------------- 履歴
    def _history(self, messages: list[dict], session: Session | None = None, with_images: bool = True) -> list[dict]:
        """LLM に渡す履歴。古いツール結果は短縮し、画像は直近 2 件のユーザー発話分だけ base64 で添付する。"""
        msgs = [{k: v for k, v in m.items() if k not in ("ts", "kind", "text_attachments")} for m in messages]
        tool_idx = [i for i, m in enumerate(msgs) if m["role"] == "tool"]
        for i in tool_idx[:-6]:
            c = msgs[i]["content"]
            if len(c) > 1500:
                msgs[i]["content"] = c[:1500] + "\n...(省略)"
        img_idx = [i for i, m in enumerate(msgs) if m["role"] == "user" and m.get("images")]
        for n, i in enumerate(reversed(img_idx)):
            names = msgs[i].pop("images")
            b64s = [b for b in (self._image_b64(session, f) for f in names)] if (session and with_images and n < 2) else []
            b64s = [b for b in b64s if b]
            if b64s:
                msgs[i]["images"] = b64s
            else:
                msgs[i]["content"] = f"[画像 {len(names)} 枚を添付]\n" + msgs[i]["content"]
        return msgs
