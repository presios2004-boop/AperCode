"""ブラウザ操作ツール（v1.4.0）: browser_open / browser_read / browser_click / browser_type / browser_press /
browser_scroll / browser_eval / browser_screenshot / browser_console / browser_close

実体は codeagent/browser.py の Browser（Playwright）。ToolContext.browser として agent が注入する。
スクリーンショットはセッションのファイル置き場に保存し、[[screenshot:ファイル名]] マーカーを返す。
agent がこのマーカーを見て、画面にも表示し、vision 対応モデルなら LLM に画像として渡す。
"""
from __future__ import annotations

import json
import time
from urllib.parse import urlparse

from . import Tool, ToolContext, ToolError, register
from ..browser import INSTALL_HINT


def _b(ctx: ToolContext):
    if ctx.browser is None:
        raise ToolError(f"ブラウザ機能は無効か、Playwright が入っていません（{INSTALL_HINT} を実行し、config の browser.enabled を true に）")
    return ctx.browser


def _fmt_elements(items: list[dict]) -> str:
    if not items:
        return "(操作できる要素はありません)"
    rows = []
    for it in items:
        extra = f" href={it['href']}" if it.get("href") else ""
        typ = f"/{it['type']}" if it.get("type") else ""
        rows.append(f"[{it['idx']}] <{it['tag']}{typ}> {it['label']}{extra}")
    return "\n".join(rows)


async def browser_open(ctx: ToolContext, a: dict) -> str:
    url = str(a.get("url") or "").strip()
    if not url:
        raise ToolError("url は必須です")
    if "://" not in url:
        url = "http://" + url
    b = _b(ctx)
    try:
        info = await b.goto(url, str(a.get("wait") or "load"))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"ページを開けませんでした: {e}")
    text = await b.text(int(ctx.cfg.get("browser.max_text_chars", 6000)))
    con = b.console()
    out = [f"URL: {info['url']}  (HTTP {info['status']})", f"タイトル: {info['title']}", "", "## ページのテキスト", text]
    if con["page_errors"] or con["console"]:
        out += ["", "## コンソール（error / warning）"] + [f"- [{m['type']}] {m['text']}" for m in con["console"]]
        out += [f"- [pageerror] {e}" for e in con["page_errors"]]
    out += ["", "（操作できる要素の一覧は browser_read、見た目の確認は browser_screenshot）"]
    return "\n".join(out)


async def browser_read(ctx: ToolContext, a: dict) -> str:
    b = _b(ctx)
    info = await b.info()
    text = await b.text(int(a.get("max_chars") or ctx.cfg.get("browser.max_text_chars", 6000)))
    items = await b.elements(int(a.get("max_elements") or 80))
    return (f"URL: {info['url']}\nタイトル: {info['title']}\n\n## ページのテキスト\n{text}\n\n"
            f"## 操作できる要素（番号を browser_click / browser_type の target に使える）\n{_fmt_elements(items)}")


async def browser_click(ctx: ToolContext, a: dict) -> str:
    b = _b(ctx)
    try:
        r = await b.click(str(a.get("target") or ""))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"クリックできませんでした: {e}（browser_read で要素番号を確認してください）")
    con = b.console()
    err = "".join(f"\n- [pageerror] {e}" for e in con["page_errors"][-3:])
    return r + err


async def browser_type(ctx: ToolContext, a: dict) -> str:
    b = _b(ctx)
    try:
        return await b.type(str(a.get("target") or ""), str(a.get("text") or ""), bool(a.get("submit")))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"入力できませんでした: {e}（browser_read で要素番号を確認してください）")


async def browser_press(ctx: ToolContext, a: dict) -> str:
    return await _b(ctx).press(str(a.get("key") or "Enter"))


async def browser_scroll(ctx: ToolContext, a: dict) -> str:
    return await _b(ctx).scroll(str(a.get("direction") or "down"), int(a.get("amount") or 600))


async def browser_eval(ctx: ToolContext, a: dict) -> str:
    js = str(a.get("js") or "").strip()
    if not js:
        raise ToolError("js は必須です")
    return await _b(ctx).evaluate(js)


async def browser_screenshot(ctx: ToolContext, a: dict) -> str:
    b = _b(ctx)
    if ctx.files_dir is None:
        raise ToolError("スクリーンショットの保存先がありません")
    fname = f"shot_{int(time.time() * 1000)}.png"
    await b.screenshot(ctx.files_dir / fname, bool(a.get("full_page")))
    info = await b.info()
    return f"スクリーンショットを保存しました: {fname}（{info['url']}）\n[[screenshot:{fname}]]"


async def browser_console(ctx: ToolContext, a: dict) -> str:
    con = _b(ctx).console(("error", "warning", "log") if a.get("all") else ("error", "warning"))
    if not con["console"] and not con["page_errors"]:
        return f"コンソールにエラー・警告はありません（全 {con['total_console']} 件のログ）"
    lines = [f"- [{m['type']}] {m['text']}" for m in con["console"]] + [f"- [pageerror] {e}" for e in con["page_errors"]]
    return "\n".join(lines)


async def browser_close(ctx: ToolContext, a: dict) -> str:
    await _b(ctx).close()
    return "ブラウザを閉じました"


def is_local_url(url: str) -> bool:
    try:
        host = urlparse(url if "://" in url else "http://" + url).hostname or ""
    except Exception:  # noqa: BLE001
        return False
    return host in ("localhost", "127.0.0.1", "::1", "0.0.0.0") or host.endswith(".local")


BROWSER_TOOLS = ["browser_open", "browser_read", "browser_click", "browser_type", "browser_press", "browser_scroll",
                 "browser_eval", "browser_screenshot", "browser_console", "browser_close"]

register(Tool("browser_open",
              "ブラウザで URL を開き、ページのテキストとコンソールのエラーを返す。自分で作った Web アプリの動作確認"
              "（http://localhost:ポート）や、ドキュメント・Web ページの閲覧に使う。ページの状態は次の browser_* 呼び出しまで保持される。",
              {"type": "object", "properties": {
                  "url": {"type": "string"},
                  "wait": {"type": "string", "description": "load（既定）| domcontentloaded | networkidle"}},
               "required": ["url"]}, browser_open, lambda a: a.get("url", "")[:80]))
register(Tool("browser_read",
              "現在のページのテキストと、クリック・入力できる要素の一覧（番号付き）を返す。操作の前に呼ぶ。",
              {"type": "object", "properties": {"max_chars": {"type": "integer"}, "max_elements": {"type": "integer"}}, "required": []},
              browser_read, lambda a: ""))
register(Tool("browser_click",
              "要素をクリックする。target は browser_read の番号、ボタン/リンクの表示テキスト、または CSS セレクタ。",
              {"type": "object", "properties": {"target": {"type": "string"}}, "required": ["target"]},
              browser_click, lambda a: str(a.get("target", ""))[:60]))
register(Tool("browser_type",
              "入力欄に文字を入れる（既存の内容は置き換える）。submit=true で Enter も押す。",
              {"type": "object", "properties": {"target": {"type": "string"}, "text": {"type": "string"}, "submit": {"type": "boolean"}},
               "required": ["target", "text"]}, browser_type, lambda a: f"{str(a.get('target',''))[:30]} ← {str(a.get('text',''))[:30]}"))
register(Tool("browser_press", "キーを押す（Enter, Escape, Tab, ArrowDown, Control+a など）。",
              {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"]}, browser_press, lambda a: a.get("key", "")))
register(Tool("browser_scroll", "ページをスクロールする。",
              {"type": "object", "properties": {"direction": {"type": "string", "description": "down | up"}, "amount": {"type": "integer"}}, "required": []},
              browser_scroll, lambda a: a.get("direction", "down")))
register(Tool("browser_eval",
              "ページ内で JavaScript を実行して結果（JSON）を返す。DOM の存在確認（document.querySelector('canvas') !== null）、"
              "変数や状態の確認、WebSocket の readyState の確認などに使う。",
              {"type": "object", "properties": {"js": {"type": "string", "description": "式または (() => {...})() の形の関数呼び出し"}}, "required": ["js"]},
              browser_eval, lambda a: str(a.get("js", ""))[:80]))
register(Tool("browser_screenshot",
              "現在のページのスクリーンショットを撮って画面に表示する（vision 対応モデルなら画像として渡される）。"
              "見た目の確認（描画されているか、レイアウト崩れ）に使う。",
              {"type": "object", "properties": {"full_page": {"type": "boolean"}}, "required": []}, browser_screenshot, lambda a: ""))
register(Tool("browser_console", "ページのコンソール出力（error / warning。all=true で log も）と JS 例外を返す。",
              {"type": "object", "properties": {"all": {"type": "boolean"}}, "required": []}, browser_console, lambda a: ""))
register(Tool("browser_close", "ブラウザを閉じる。", {"type": "object", "properties": {}, "required": []}, browser_close, lambda a: ""))
