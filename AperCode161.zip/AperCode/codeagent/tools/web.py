"""Web 検索・ページ取得ツール: web_search / fetch_url

- web_search: DuckDuckGo（HTML/lite 版、API キー不要）→ Bing → Brave → Mojeek → Stack Exchange API →
  GitHub Issues API → Wikipedia API の順に自動フォールバック。ddgs パッケージがあれば最初に使う（403 回避に有効）。
  SearXNG（config の web.searxng_url）も指定可
- fetch_url : URL の本文をテキスト化して返す（HTML はタグを除去し、本文らしい部分を抽出）
どちらも読み取り専用。config の web.enabled で無効化できる。
"""
from __future__ import annotations

import html
import re
from html.parser import HTMLParser
from urllib.parse import parse_qs, quote_plus, urlparse

import httpx

from . import Tool, ToolContext, ToolError, register

UA = "Mozilla/5.0 (X11; Linux x86_64) AperCode/1.0 (+local coding agent)"
# 検索サイトはボット UA を弾くことがあるので、検索だけは一般的なブラウザ UA を使う
SEARCH_UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
             "Chrome/124.0.0.0 Safari/537.36")
SEARCH_HEADERS = {"User-Agent": SEARCH_UA, "Accept-Language": "ja,en;q=0.8",
                  "Accept": "text/html,application/xhtml+xml"}


def _cfg(ctx: ToolContext, key: str, default):
    return ctx.cfg.get(f"web.{key}", default)


# ------------------------------------------------------------------ 検索
async def _search_duckduckgo(query: str, n: int, timeout: float) -> list[dict]:
    url = "https://html.duckduckgo.com/html/"
    async with httpx.AsyncClient(timeout=timeout, headers=SEARCH_HEADERS, follow_redirects=True) as c:
        r = await c.get(url, params={"q": query, "kl": "jp-jp"})
        if r.status_code != 200:
            r = await c.post(url, data={"q": query, "kl": "jp-jp"})
        r.raise_for_status()
    text = r.text
    results = []
    # 結果ブロック: <a class="result__a" href="...">title</a> ... <a class="result__snippet" ...>snippet</a>
    for m in re.finditer(r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=<a[^>]*class="result__a"|$)',
                         text, re.S):
        href, title_html, rest = m.group(1), m.group(2), m.group(3)
        # リダイレクト形式 //duckduckgo.com/l/?uddg=<url>
        if "uddg=" in href:
            q = parse_qs(urlparse(href).query)
            href = q.get("uddg", [href])[0]
        sn = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', rest, re.S)
        snippet = _strip(sn.group(1)) if sn else ""
        results.append({"title": _strip(title_html), "url": href, "snippet": snippet})
        if len(results) >= n:
            break
    return results


async def _search_duckduckgo_lite(query: str, n: int, timeout: float) -> list[dict]:
    """html 版がブロックされた場合の代替（lite 版）。"""
    async with httpx.AsyncClient(timeout=timeout, headers=SEARCH_HEADERS, follow_redirects=True) as c:
        r = await c.post("https://lite.duckduckgo.com/lite/", data={"q": query, "kl": "jp-jp"})
        r.raise_for_status()
    text = r.text
    results = []
    links = re.findall(r'<a[^>]*class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', text, re.S)
    snippets = re.findall(r'<td[^>]*class="result-snippet"[^>]*>(.*?)</td>', text, re.S)
    for i, (href, title) in enumerate(links[:n]):
        if "uddg=" in href:
            href = parse_qs(urlparse(href).query).get("uddg", [href])[0]
        results.append({"title": _strip(title), "url": href,
                        "snippet": _strip(snippets[i]) if i < len(snippets) else ""})
    return results


async def _search_ddgs_package(query: str, n: int) -> list[dict] | None:
    """ddgs パッケージが入っていればそれを使う（任意依存）。"""
    try:
        from ddgs import DDGS  # type: ignore
    except ImportError:
        try:
            from duckduckgo_search import DDGS  # type: ignore
        except ImportError:
            return None
    import asyncio
    def run():
        with DDGS() as d:
            try:
                rows = d.text(query, max_results=n, region="jp-jp")
            except TypeError:
                rows = d.text(query, max_results=n)
            return [{"title": r.get("title", ""), "url": r.get("href", ""), "snippet": r.get("body", "")}
                    for r in rows]
    return await asyncio.get_event_loop().run_in_executor(None, run)


async def _search_bing(query: str, n: int, timeout: float) -> list[dict]:
    """Bing（HTML 版）。DuckDuckGo がブロックされたときの代替。"""
    async with httpx.AsyncClient(timeout=timeout, headers=SEARCH_HEADERS, follow_redirects=True) as c:
        r = await c.get("https://www.bing.com/search", params={"q": query, "setlang": "ja", "count": str(n)})
        r.raise_for_status()
    return _parse_bing(r.text, n)


def _parse_bing(text: str, n: int) -> list[dict]:
    results = []
    for m in re.finditer(r'<li class="b_algo"[^>]*>(.*?)</li>', text, re.S):
        block = m.group(1)
        a = re.search(r'<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', block, re.S)
        if not a:
            continue
        sn = re.search(r'<p[^>]*>(.*?)</p>', block, re.S)
        results.append({"title": _strip(a.group(2)), "url": html.unescape(a.group(1)),
                        "snippet": _strip(sn.group(1)) if sn else ""})
        if len(results) >= n:
            break
    return results


async def _search_brave(query: str, n: int, timeout: float) -> list[dict]:
    """Brave Search（HTML 版）。"""
    async with httpx.AsyncClient(timeout=timeout, headers=SEARCH_HEADERS, follow_redirects=True) as c:
        r = await c.get("https://search.brave.com/search", params={"q": query, "source": "web"})
        r.raise_for_status()
    return _parse_brave(r.text, n)


def _parse_brave(text: str, n: int) -> list[dict]:
    results = []
    # 結果: <div class="snippet ..."> <a href="URL"> ... <div class="title">T</div> ... <div class="snippet-description">S</div>
    for m in re.finditer(r'<div[^>]*class="snippet(?=[\s"])[^"]*"[^>]*>(.*?)(?=<div[^>]*class="snippet(?=[\s"])[^"]*"|$)', text, re.S):
        block = m.group(1)
        a = re.search(r'<a[^>]*href="(https?://[^"]+)"', block)
        t = re.search(r'class="[^"]*\btitle\b[^"]*"[^>]*>(.*?)</', block, re.S)
        if not a or not t:
            continue
        sn = re.search(r'class="[^"]*snippet-description[^"]*"[^>]*>(.*?)</div>', block, re.S)
        url = html.unescape(a.group(1))
        if "brave.com" in urlparse(url).netloc:
            continue
        results.append({"title": _strip(t.group(1)), "url": url, "snippet": _strip(sn.group(1)) if sn else ""})
        if len(results) >= n:
            break
    return results


async def _search_mojeek(query: str, n: int, timeout: float) -> list[dict]:
    """Mojeek（独立系。最後の砦）。"""
    async with httpx.AsyncClient(timeout=timeout, headers=SEARCH_HEADERS, follow_redirects=True) as c:
        r = await c.get("https://www.mojeek.com/search", params={"q": query})
        r.raise_for_status()
    results = []
    for m in re.finditer(r'<a[^>]*class="ob"[^>]*href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=<a[^>]*class="ob"|$)', r.text, re.S):
        sn = re.search(r'<p class="s">(.*?)</p>', m.group(3), re.S)
        results.append({"title": _strip(m.group(2)), "url": html.unescape(m.group(1)),
                        "snippet": _strip(sn.group(1)) if sn else ""})
        if len(results) >= n:
            break
    return results


# ---- ボット判定で 403 になりにくい JSON API（API キー不要）。プログラミング系の質問に強い
async def _search_stackexchange(query: str, n: int, timeout: float) -> list[dict]:
    async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA}) as c:
        r = await c.get("https://api.stackexchange.com/2.3/search/advanced",
                        params={"q": query, "site": "stackoverflow", "order": "desc", "sort": "relevance",
                                "pagesize": str(n), "filter": "withbody"})
        r.raise_for_status()
    out = []
    for it in r.json().get("items", [])[:n]:
        body = _strip(it.get("body", ""))[:300]
        ans = "（回答あり）" if it.get("is_answered") else ""
        out.append({"title": html.unescape(it.get("title", "")) + ans, "url": it.get("link", ""), "snippet": body})
    return out


async def _search_github(query: str, n: int, timeout: float) -> list[dict]:
    """GitHub Issues / Discussions 検索（未認証: 10 req/min）。エラー文の検索に有効。"""
    async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA, "Accept": "application/vnd.github+json"}) as c:
        r = await c.get("https://api.github.com/search/issues", params={"q": query, "per_page": str(n)})
        r.raise_for_status()
    out = []
    for it in r.json().get("items", [])[:n]:
        out.append({"title": it.get("title", ""), "url": it.get("html_url", ""),
                    "snippet": (it.get("body") or "")[:300].replace("\r", "")})
    return out


async def _search_wikipedia(query: str, n: int, timeout: float) -> list[dict]:
    """Wikipedia（概念・用語の説明向け）。日本語 → 英語の順。"""
    out = []
    async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA}) as c:
        for lang in ("ja", "en"):
            r = await c.get(f"https://{lang}.wikipedia.org/w/api.php",
                            params={"action": "query", "list": "search", "srsearch": query, "format": "json",
                                    "srlimit": str(n), "utf8": "1"})
            if r.status_code != 200:
                continue
            for it in r.json().get("query", {}).get("search", []):
                title = it.get("title", "")
                out.append({"title": title, "url": f"https://{lang}.wikipedia.org/wiki/{quote_plus(title.replace(' ', '_'))}",
                            "snippet": _strip(it.get("snippet", ""))})
            if len(out) >= n:
                break
    return out[:n]


async def _search_mdn(query: str, n: int, timeout: float) -> list[dict]:
    """MDN Web Docs（JavaScript / DOM / Web API / CSS / HTTP の公式リファレンス）。JSON API、ボット判定なし。"""
    out = []
    async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA}) as c:
        for locale in ("ja", "en-US"):
            r = await c.get("https://developer.mozilla.org/api/v1/search", params={"q": query, "locale": locale, "size": str(n)})
            if r.status_code != 200:
                continue
            for d in r.json().get("documents", [])[:n]:
                url = d.get("mdn_url", "")
                if url.startswith("/"):
                    url = "https://developer.mozilla.org" + url
                out.append({"title": d.get("title", ""), "url": url, "snippet": _strip(d.get("summary", ""))})
            if len(out) >= n:
                break
    return out[:n]


async def _search_searxng(base: str, query: str, n: int, timeout: float) -> list[dict]:
    async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA}) as c:
        r = await c.get(base.rstrip("/") + "/search", params={"q": query, "format": "json", "language": "ja"})
        r.raise_for_status()
    out = []
    for it in r.json().get("results", [])[:n]:
        out.append({"title": it.get("title", ""), "url": it.get("url", ""), "snippet": it.get("content", "")})
    return out


async def web_search(ctx: ToolContext, a: dict) -> str:
    if not _cfg(ctx, "enabled", True):
        raise ToolError("Web 検索は無効です (config.yaml web.enabled)")
    query = (a.get("query") or "").strip()
    if not query:
        raise ToolError("query は必須です")
    n = int(a.get("max_results") or _cfg(ctx, "max_results", 5))
    timeout = float(_cfg(ctx, "timeout", 20))
    provider = str(_cfg(ctx, "provider", "duckduckgo")).lower()
    searx = _cfg(ctx, "searxng_url", "")
    results: list[dict] = []
    errors: list[str] = []
    used = provider
    if provider == "searxng" and searx:
        try:
            results = await _search_searxng(searx, query, n, timeout)
        except httpx.HTTPError as e:
            errors.append(f"searxng: {e}")
    else:
        # 失敗したら次のエンジンへ（順序は config の web.engines で変更可）
        engines = {
            "ddgs": lambda: _search_ddgs_package(query, n),
            "duckduckgo": lambda: _search_duckduckgo(query, n, timeout),
            "duckduckgo_lite": lambda: _search_duckduckgo_lite(query, n, timeout),
            "bing": lambda: _search_bing(query, n, timeout),
            "brave": lambda: _search_brave(query, n, timeout),
            "mojeek": lambda: _search_mojeek(query, n, timeout),
            "stackexchange": lambda: _search_stackexchange(query, n, timeout),
            "github": lambda: _search_github(query, n, timeout),
            "wikipedia": lambda: _search_wikipedia(query, n, timeout),
            "mdn": lambda: _search_mdn(query, n, timeout),
        }
        order = _cfg(ctx, "engines", None) or ["ddgs", "duckduckgo", "duckduckgo_lite", "bing", "brave", "mojeek",
                                               "stackexchange", "github", "wikipedia"]
        if provider in engines and provider != "duckduckgo":
            order = [provider] + [e for e in order if e != provider]
        # ツール引数 engine で明示指定（例: mdn, stackexchange, github）されたら最優先
        want = str(a.get("engine") or "").strip().lower()
        if want in engines:
            order = [want] + [e for e in order if e != want]
        if searx:
            engines["searxng"] = lambda: _search_searxng(searx, query, n, timeout)
            order = order + ["searxng"]
        for name in order:
            fn = engines.get(name)
            if not fn:
                continue
            try:
                res = await fn()
                if res:
                    results = res
                    used = name
                    break
                if res is not None:
                    errors.append(f"{name}: 結果なし（ブロックされた可能性）")
            except httpx.HTTPStatusError as e:
                errors.append(f"{name}: HTTP {e.response.status_code}")
            except httpx.HTTPError as e:
                errors.append(f"{name}: {type(e).__name__}")
            except Exception as e:  # noqa: BLE001
                errors.append(f"{name}: {type(e).__name__}: {str(e)[:80]}")
    if not results and errors:
        raise ToolError("検索に失敗しました（すべてのエンジンで失敗）: " + " / ".join(errors) +
                        "\n対処: ネットワーク接続を確認する。.venv/bin/pip install ddgs で ddgs パッケージを入れる"
                        "（ブラウザ相当の TLS で検索サイトの 403 を回避できる）。config.yaml の web.searxng_url に"
                        "自前の SearXNG を設定する。それでも無理なら Web 検索なしで進める")
    if not results:
        return "検索結果がありません。別のキーワード（英語、エラーメッセージの一部、ライブラリ名など）で試してください"
    lines = [f"検索: {query}（{used}）"]
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r['title']}\n   {r['url']}\n   {r['snippet'][:300]}")
    lines.append("詳細を読むには fetch_url を使ってください")
    return "\n".join(lines)


# ------------------------------------------------------------------ 取得
class _TextExtractor(HTMLParser):
    """script/style/nav 等を除き、本文テキストを抽出する簡易パーサ。"""
    SKIP = {"script", "style", "noscript", "svg", "header", "footer", "nav", "aside", "form", "iframe"}
    BLOCK = {"p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "pre", "br", "tr", "section", "article",
             "blockquote", "td", "th", "dd", "dt"}

    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self._skip = 0
        self._pre = 0
        self.title = ""
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self._skip += 1
        if tag == "pre":
            self._pre += 1
        if tag == "title":
            self._in_title = True
        if tag in self.BLOCK:
            self.parts.append("\n")
        if tag == "code" and not self._pre:
            self.parts.append("`")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip:
            self._skip -= 1
        if tag == "pre" and self._pre:
            self._pre -= 1
            self.parts.append("\n")
        if tag == "title":
            self._in_title = False
        if tag in self.BLOCK:
            self.parts.append("\n")
        if tag == "code" and not self._pre:
            self.parts.append("`")

    def handle_data(self, data):
        if self._in_title:
            self.title += data
            return
        if self._skip:
            return
        self.parts.append(data if self._pre else re.sub(r"[ \t]+", " ", data))

    def text(self) -> str:
        t = "".join(self.parts)
        t = re.sub(r"\n[ \t]+", "\n", t)
        t = re.sub(r"\n{3,}", "\n\n", t)
        return t.strip()


def _strip(s: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", s)).strip()


async def fetch_url(ctx: ToolContext, a: dict) -> str:
    if not _cfg(ctx, "enabled", True):
        raise ToolError("Web アクセスは無効です (config.yaml web.enabled)")
    url = (a.get("url") or "").strip()
    if not re.match(r"^https?://", url):
        raise ToolError("http(s):// で始まる URL を指定してください")
    max_chars = int(a.get("max_chars") or _cfg(ctx, "fetch_max_chars", 12000))
    timeout = float(_cfg(ctx, "timeout", 20))
    try:
        async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": UA, "Accept-Language": "ja,en"},
                                     follow_redirects=True) as c:
            r = await c.get(url)
            r.raise_for_status()
    except httpx.HTTPError as e:
        raise ToolError(f"取得に失敗しました: {e}")
    ctype = r.headers.get("content-type", "")
    body = r.text
    if "html" in ctype or body.lstrip()[:15].lower().startswith(("<!doctype", "<html")):
        p = _TextExtractor()
        try:
            p.feed(body)
        except Exception:
            pass
        text = p.text()
        title = p.title.strip()
    else:
        text, title = body, ""
    head = f"URL: {str(r.url)}\n" + (f"タイトル: {title}\n" if title else "")
    if len(text) > max_chars:
        text = text[:max_chars] + f"\n... (省略: 全 {len(text)} 文字。必要なら max_chars を増やす)"
    return head + "\n" + text


register(Tool(
    "web_search",
    "Web を検索する（DuckDuckGo → Bing → … に自動フォールバック）。エラーメッセージの意味、ライブラリの使い方、設定方法など、"
    "手元の情報だけでは解決できないときに使う。エラー文をそのまま検索すると当たりやすい。"
    "JavaScript / DOM / WebSocket / fetch / CSS / HTTP の仕様や API の正しい使い方は engine=mdn（MDN 公式リファレンス）、"
    "プログラミングの Q&A は engine=stackexchange、ライブラリの既知の問題は engine=github を指定すると確実。",
    {"type": "object", "properties": {
        "query": {"type": "string", "description": "検索語（英語の方が結果が多い。エラー文はそのまま）"},
        "engine": {"type": "string", "description": "省略可: mdn | stackexchange | github | wikipedia | duckduckgo | bing | brave"},
        "max_results": {"type": "integer", "description": "既定 5"}},
     "required": ["query"]},
    web_search, lambda a: a.get("query", "")[:80]))

register(Tool(
    "fetch_url",
    "URL のページ本文をテキストで取得する。web_search の結果を詳しく読むとき、公式ドキュメントや"
    "GitHub の Issue / README を確認するときに使う。",
    {"type": "object", "properties": {
        "url": {"type": "string"},
        "max_chars": {"type": "integer", "description": "既定 12000"}},
     "required": ["url"]},
    fetch_url, lambda a: a.get("url", "")[:80]))
