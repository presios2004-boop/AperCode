"""repl ツール（v1.5.0）: 永続 Python / Node セッションでコードを実行する。"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register

MAX_OUT = 20_000


def _clip(s: str, n: int = MAX_OUT) -> str:
    return s if len(s) <= n else s[: n // 2] + "\n... (中略) ...\n" + s[-n // 2:]


async def repl(ctx: ToolContext, a: dict) -> str:
    if ctx.repls is None:
        raise ToolError("repl はこの環境では使えません")
    lang = str(a.get("language") or "python").lower()
    if lang in ("py", "python3"):
        lang = "python"
    if lang in ("js", "javascript", "nodejs"):
        lang = "node"
    if lang not in ("python", "node"):
        raise ToolError("language は python | node のどちらかです")
    if a.get("reset"):
        n = await ctx.repls.reset(ctx.session_id, lang)
        if not str(a.get("code") or "").strip():
            return f"{lang} の REPL をリセットしました（{n} 個停止）"
    code = str(a.get("code") or "")
    if not code.strip():
        st = ctx.repls.status(ctx.session_id)
        return "実行するコードがありません。状態: " + (", ".join(f"{s['language']}: {'起動中' if s['alive'] else '停止'} ({s['exe']}, {s['calls']} 回)" for s in st) or "REPL なし")
    r = ctx.repls.get(ctx.session_id, lang, ctx.project_dir)
    fresh = not r.alive()
    try:
        res = await r.run(code, float(a.get("timeout") or ctx.cfg.get("repl.timeout", 60)))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"REPL を起動できませんでした: {e}")
    parts = []
    if fresh:
        parts.append(f"（{lang} REPL を起動: {r.exe}、cwd={ctx.project_dir}。変数・import は次の repl 呼び出しに引き継がれる）")
    if res.get("stdout"):
        parts.append(_clip(res["stdout"].rstrip("\n")))
    if res.get("stderr"):
        parts.append("[stderr]\n" + _clip(res["stderr"].rstrip("\n")))
    if res.get("value") is not None:
        parts.append("=> " + _clip(str(res["value"]), 6000))
    if not res.get("ok"):
        parts.append("[error]\n" + _clip(str(res.get("error", "")), 6000))
        return "\n".join(parts)
    if len(parts) == (1 if fresh else 0):
        parts.append("(出力なし)")
    return "\n".join(parts)


register(Tool("repl",
              "永続的な Python / Node の REPL でコードを実行する。変数・import・関数定義は次の呼び出しに引き継がれる"
              "（run_command は毎回新しいプロセス）。データの探索、ライブラリの挙動確認、関数の単体実行、デバッグに使う。"
              "最後の式の値は => として返る。Python はプロジェクトの .venv があればそれを使う。reset=true で状態を捨てて再起動。",
              {"type": "object", "properties": {
                  "code": {"type": "string", "description": "実行するコード（複数行可）"},
                  "language": {"type": "string", "description": "python（既定）| node"},
                  "reset": {"type": "boolean", "description": "true で REPL を再起動してから実行"},
                  "timeout": {"type": "integer", "description": "秒（既定 60）"}},
               "required": ["code"]}, repl, lambda a: (a.get("language", "python") + ": " + str(a.get("code", "")).strip().splitlines()[0][:70]) if str(a.get("code", "")).strip() else "reset"))
