"""ask_cloud: 行き詰まったときにクラウド AI へ相談する（v1.2.4）。

- 会話全体ではなく「目的 / エラー / 試したこと / 関連コードの抜粋 / 質問」だけを送る
- 発動条件（cloud.require_failures）: 自動検証の差し戻し・テスト失敗・行き詰まり検知の合計がこの回数以上のときだけ使える
- 1 ターンの回数上限（cloud.max_per_turn）
- 送信前に秘密情報らしき文字列をマスク（cloud.mask_secrets）
- 承認は permissions.ask_cloud（既定 ask）
"""
from __future__ import annotations

import platform
from pathlib import Path

from . import Tool, ToolContext, ToolError, register
from ..cloud import CloudClient, CloudSettings, ASK_SYSTEM, build_prompt, mask_secrets


def _excerpt(ctx: ToolContext, spec: str, max_lines: int) -> str:
    """'path' または 'path:10-80' 形式でファイルの抜粋を返す。"""
    spec = spec.strip()
    rng = None
    if ":" in spec and "-" in spec.rsplit(":", 1)[-1]:
        p, r = spec.rsplit(":", 1)
        try:
            a, b = r.split("-", 1)
            rng = (max(1, int(a)), int(b))
            spec = p
        except ValueError:
            rng = None
    path = ctx.resolve(spec)
    if not path.is_file():
        return f"### {spec}\n(ファイルがありません)"
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if rng:
        sel = lines[rng[0] - 1:rng[1]]
        start = rng[0]
    else:
        sel, start = lines[:max_lines], 1
    body = "\n".join(f"{i:4d}| {l}" for i, l in enumerate(sel, start))
    note = f"\n... (省略: 全 {len(lines)} 行。範囲は path:開始-終了 で指定可)" if len(lines) > len(sel) + (start - 1) else ""
    try:
        rel = path.relative_to(ctx.project_dir)
    except ValueError:
        rel = path
    return f"### {rel}\n```\n{body}{note}\n```"


async def ask_cloud(ctx: ToolContext, a: dict) -> str:
    cfg = ctx.cfg
    if not cfg.get("cloud.enabled", False):
        raise ToolError("クラウド相談は無効です（画面左の「クラウド相談」で API キーを設定し有効化してください）")
    s = CloudSettings.from_cfg(cfg)
    if not s.ready:
        raise ToolError("クラウド相談の設定が不完全です（プロバイダ・モデル・API キーを確認してください）")
    vs = ctx.verify
    # ---- 発動条件: まずローカルで粘った後だけ
    need = int(cfg.get("cloud.require_failures", 1))
    failures = 0
    if vs is not None:
        failures = vs.stuck_count + vs.test_rounds + sum(vs.check_failures.values()) + vs.cloud_denied
    if failures < need:
        raise ToolError(f"まだクラウド相談は使えません（失敗・行き詰まり {failures} 回 / 必要 {need} 回）。"
                        "先にエラー文を読み直し、search_memory と web_search で解決策を探して試してください")
    max_per_turn = int(cfg.get("cloud.max_per_turn", 2))
    if vs is not None and vs.cloud_calls >= max_per_turn:
        raise ToolError(f"このターンのクラウド相談は上限（{max_per_turn} 回）に達しました。得られたヒントを基に自分で進めるか、"
                        "試したこと・分かったことを整理してユーザーに報告してください")
    goal = str(a.get("goal") or "").strip()
    error = str(a.get("error") or "").strip()
    tried = str(a.get("tried") or "").strip()
    if not goal or not tried:
        raise ToolError("goal（目的）と tried（試したことと結果）は必須です。丸投げではなく相談になるように書いてください")
    files = a.get("files") or []
    if isinstance(files, str):
        files = [f for f in files.split(",") if f.strip()]
    max_lines = int(cfg.get("cloud.max_file_lines", 200))
    code = "\n\n".join(_excerpt(ctx, f, max_lines) for f in files[:6])
    env = f"OS: {platform.platform()}; project: {ctx.project_dir.name}"
    prompt = build_prompt(goal, error, tried, code, str(a.get("question") or ""), env)
    masked = 0
    if cfg.get("cloud.mask_secrets", True):
        prompt, masked = mask_secrets(prompt)
    if vs is not None:
        vs.cloud_calls += 1
    try:
        answer = await CloudClient(s).ask(ASK_SYSTEM, prompt, max_tokens=int(cfg.get("cloud.max_tokens", 4096)))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"クラウド相談に失敗: {e}")
    head = f"[クラウド相談: {s.describe()} / 送信 {len(prompt):,} 文字" + (f", 秘密情報 {masked} 件をマスク" if masked else "") + "]\n"
    tail = ("\n\n（上記はヒントです。そのまま信用せず、確認方法を実行して裏を取り、修正後は必ずテストで検証してください。"
            "解決したら原因と対処を save_memory に「（参考: クラウド相談）」を付けて保存してください）")
    return head + answer + tail


register(Tool(
    "ask_cloud",
    "行き詰まったときにクラウドの強い AI に相談してヒントをもらう。search_memory と web_search を試しても解決しない"
    "場合にだけ使う（失敗が一定回数に達するまでは使えない）。会話全体ではなく、目的・エラー・試したこと・関連コードの"
    "抜粋だけを送る。返ってくるのは原因の仮説と修正案であり、実装と検証は自分で行う。",
    {"type": "object", "properties": {
        "goal": {"type": "string", "description": "何を実現しようとしているか（1〜3 文）"},
        "error": {"type": "string", "description": "エラー全文・スタックトレース・症状"},
        "tried": {"type": "string", "description": "試したことと、それぞれの結果（必須）"},
        "files": {"type": "array", "items": {"type": "string"},
                  "description": "関連ファイル（最大 6。'path' または 'path:開始行-終了行'。先頭 200 行までが送られる）"},
        "question": {"type": "string", "description": "特に聞きたいこと（任意）"}},
     "required": ["goal", "tried"]},
    ask_cloud,
    lambda a: f"{str(a.get('goal',''))[:60]} / files={len(a.get('files') or [])}"))
