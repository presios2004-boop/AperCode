"""process_* ツール（v1.5.0）: サーバーなどのバックグラウンドプロセスを起動・監視・停止する。"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register


def _pm(ctx: ToolContext):
    if ctx.procs is None:
        raise ToolError("process ツールはこの環境では使えません")
    return ctx.procs


def _fmt(p, pm, lines: int = 0) -> str:
    state = "実行中" if p.running else f"終了 (exit {p.proc.returncode})"
    s = f"[{p.id}] {p.name}  {state}  pid={p.pid}  port={p.port or '-'}  cwd={p.cwd}\n    $ {p.command}"
    if lines:
        tail = pm.tail(p, lines)
        if tail:
            s += "\n" + "\n".join("    " + ln for ln in tail.splitlines())
    return s


async def process_start(ctx: ToolContext, a: dict) -> str:
    pm = _pm(ctx)
    cmd = str(a.get("command") or "").strip()
    if not cmd:
        raise ToolError("command は必須です")
    cwd = ctx.resolve(a["cwd"]) if a.get("cwd") else ctx.project_dir
    if not cwd.is_dir():
        raise ToolError(f"cwd がありません: {cwd}")
    port = int(a["port"]) if a.get("port") else None
    try:
        p, note = await pm.start(ctx.session_id, cmd, cwd, str(a.get("name") or ""), port,
                                 float(a.get("wait") or ctx.cfg.get("process.wait", 15)))
    except RuntimeError as e:
        raise ToolError(str(e))
    tail = pm.tail(p, 30)
    out = f"起動しました: [{p.id}] {p.name}  pid={p.pid}  {note}\n（停止は process_stop、ログは process_logs id={p.id}）"
    if tail:
        out += "\n--- ログ（先頭） ---\n" + tail
    if not p.running:
        raise ToolError(out)
    return out


async def process_status(ctx: ToolContext, a: dict) -> str:
    pm = _pm(ctx)
    pm.forget_finished(ctx.session_id)
    procs = pm.list(ctx.session_id if not a.get("all") else None)
    if a.get("id"):
        procs = [p for p in procs if p.id == a["id"]]
        if not procs:
            raise ToolError(f"プロセス {a['id']} はありません")
    if not procs:
        return "このセッションで起動したプロセスはありません"
    return "\n".join(_fmt(p, pm, 3) for p in procs)


async def process_logs(ctx: ToolContext, a: dict) -> str:
    pm = _pm(ctx)
    p = pm.get(str(a.get("id") or ""))
    if p is None:
        procs = pm.list(ctx.session_id)
        if len(procs) == 1 and not a.get("id"):
            p = procs[0]
        else:
            raise ToolError(f"id を指定してください（process_status で確認）: {[q.id for q in procs]}")
    text = pm.tail(p, int(a.get("lines") or 100), a.get("grep"))
    state = "実行中" if p.running else f"終了 (exit {p.proc.returncode})"
    return f"[{p.id}] {p.name}  {state}\n" + (text or "(ログはまだありません)")


async def process_stop(ctx: ToolContext, a: dict) -> str:
    pm = _pm(ctx)
    if a.get("all"):
        n = await pm.stop_all(ctx.session_id)
        return f"{n} 個のプロセスを停止しました"
    pid_id = str(a.get("id") or "")
    if not pid_id:
        procs = [p for p in pm.list(ctx.session_id) if p.running]
        if len(procs) == 1:
            pid_id = procs[0].id
        else:
            raise ToolError(f"id を指定してください: {[q.id for q in procs]}")
    try:
        return await pm.stop(pid_id)
    except RuntimeError as e:
        raise ToolError(str(e))


register(Tool("process_start",
              "サーバーなど長時間動くコマンドをバックグラウンドで起動し、ログをファイルに記録する（run_command で & するより確実）。"
              "port を渡すと待ち受け開始まで待ってから返る。Web アプリの動作確認は process_start → browser_open → process_logs → process_stop の順。",
              {"type": "object", "properties": {
                  "command": {"type": "string"},
                  "cwd": {"type": "string", "description": "作業ディレクトリ（省略時はプロジェクト）"},
                  "name": {"type": "string", "description": "表示名（任意）"},
                  "port": {"type": "integer", "description": "待ち受けを確認するポート（任意）"},
                  "wait": {"type": "integer", "description": "ポートが開くまで待つ秒数（既定 15）"}},
               "required": ["command"]}, process_start, lambda a: a.get("command", "")[:80]))
register(Tool("process_status", "起動したプロセスの一覧と状態（実行中 / 終了コード）を返す。",
              {"type": "object", "properties": {"id": {"type": "string"}, "all": {"type": "boolean", "description": "他セッションの分も含める"}}, "required": []},
              process_status, lambda a: a.get("id", "")))
register(Tool("process_logs", "プロセスのログ（stdout/stderr）の末尾を返す。grep で絞り込める。",
              {"type": "object", "properties": {"id": {"type": "string"}, "lines": {"type": "integer", "description": "既定 100"},
                                                "grep": {"type": "string", "description": "正規表現で絞り込み"}}, "required": []},
              process_logs, lambda a: a.get("id", "")))
register(Tool("process_stop", "プロセスを停止する（SIGTERM → 5 秒後 SIGKILL）。all=true でこのセッションの全プロセス。",
              {"type": "object", "properties": {"id": {"type": "string"}, "all": {"type": "boolean"}}, "required": []},
              process_stop, lambda a: "all" if a.get("all") else a.get("id", "")))
