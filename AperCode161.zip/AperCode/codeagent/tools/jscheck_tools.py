"""check_js ツール（v1.5.0）: JavaScript / HTML を静的に検査し、ブラウザで実行して例外・404・API の形を確かめる。"""
from __future__ import annotations

import asyncio
from pathlib import Path

from . import Tool, ToolContext, ToolError, register
from .. import jscheck as J
from .browser_tools import is_local_url


async def check_js(ctx: ToolContext, a: dict) -> str:
    path = str(a.get("path") or "").strip()
    url = str(a.get("url") or "").strip()
    libs = [str(u) for u in (a.get("libraries") or []) if str(u).strip()]
    probes = [str(x) for x in (a.get("probes") or []) if str(x).strip()]
    wait_ms = int(a.get("wait") or 1500)
    if not path and not url and not libs:
        raise ToolError("path（.js / .html）、url、libraries のいずれかを指定してください")
    out: list[str] = []
    p: Path | None = None
    if path:
        p = ctx.resolve(path)
        if not p.is_file():
            raise ToolError(f"ファイルがありません: {p}")
        ext = p.suffix.lower()
        if ext in (".html", ".htm"):
            st = await J.check_html_file(p, ctx.project_dir)
        elif ext in (".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx"):
            st = await J.check_js_file(p, ctx.project_dir)
        else:
            raise ToolError("path は .js / .mjs / .html のいずれかです")
        out.append(f"## 静的検査: {p.name}\n" + J.format_static(st))
        if ext not in (".html", ".htm") and not url:
            if a.get("run"):
                out.append("（.js 単体はブラウザで実行しません。HTML から読み込んで path に HTML を渡すか、url を指定）")
            return "\n\n".join(out)
    if ctx.browser is None:
        out.append("実行検査: Playwright が無いため省略（pip install playwright && python -m playwright install chromium）")
        return "\n\n".join(out)
    if a.get("run") is False:
        return "\n\n".join(out)
    try:
        if url:
            if not is_local_url(url) and str(ctx.cfg.get("browser.external_sites", "ask")) == "deny":
                raise ToolError("外部サイトは browser.external_sites で禁止されています")
            res = await asyncio.wait_for(ctx.browser.check_page(url, wait_ms, probes), wait_ms / 1000 + 60)
        elif p is not None:
            serve_root = ctx.project_dir if ctx.project_dir in p.parents else p.parent
            with J.ServeDir(serve_root) as srv:
                rel = p.relative_to(serve_root).as_posix()
                res = await asyncio.wait_for(ctx.browser.check_page(f"http://127.0.0.1:{srv.port}/{rel}", wait_ms, probes),
                                             wait_ms / 1000 + 60)
        else:
            res = await asyncio.wait_for(ctx.browser.check_page(None, wait_ms, probes, html=J.html_for_libraries(libs)),
                                         wait_ms / 1000 + 60)
            res["url"] = "（空ページに libraries を読み込み）"
    except ToolError:
        raise
    except asyncio.TimeoutError:
        raise ToolError("実行検査がタイムアウトしました")
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"実行検査に失敗しました: {e}")
    out.append("## 実行検査（ブラウザ）\n" + J.format_runtime(res))
    return "\n\n".join(out)


register(Tool("check_js",
              "JavaScript / HTML を検査してエラーを返す。静的検査（構文、import/require や <script src> の存在、CDN URL）に加え、"
              "ブラウザで実際に開いて JS 例外・console.error・404 などの失敗リクエストを集める。"
              "probes に JS 式（例: \"typeof ForceGraph3D\", \"ForceGraph3D.toString()\", \"document.querySelector('canvas')\"）を渡すと"
              "型・値・関数のソース冒頭を返すので、ライブラリの初期化の書き方（Lib(el) か Lib()(el) か）や要素の存在を実装前・修正後に確かめられる。"
              "libraries に CDN の URL だけを渡すと、空ページに読み込んで probes を評価する（実装前の API 確認）。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": ".html または .js のパス"},
                  "url": {"type": "string", "description": "起動中のアプリの URL（例: http://localhost:8000）"},
                  "libraries": {"type": "array", "items": {"type": "string"}, "description": "空ページに読み込むスクリプト URL"},
                  "probes": {"type": "array", "items": {"type": "string"}, "description": "読み込み後に評価する JS 式"},
                  "wait": {"type": "integer", "description": "読み込み後に待つミリ秒（既定 1500）"},
                  "run": {"type": "boolean", "description": "false で静的検査のみ"}},
               "required": []}, check_js,
              lambda a: a.get("path") or a.get("url") or ("libs: " + ", ".join(a.get("libraries") or [])[:60])))
