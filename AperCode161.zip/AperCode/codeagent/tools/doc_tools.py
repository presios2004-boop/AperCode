"""read_document ツール（v1.5.0）: PDF / Word / Excel / PowerPoint / CSV をテキストで読む。"""
from __future__ import annotations

from . import Tool, ToolContext, ToolError, register
from ..docread import read_document as _read, SUPPORTED


async def read_document(ctx: ToolContext, a: dict) -> str:
    p = ctx.resolve(str(a.get("path") or ""))
    if not p.is_file():
        raise ToolError(f"ファイルがありません: {p}")
    max_chars = int(a.get("max_chars") or ctx.cfg.get("documents.max_chars", 12000))
    try:
        text, method = await _read(p, pages=a.get("pages"), sheet=a.get("sheet"),
                                   max_rows=int(a.get("max_rows") or 500))
    except RuntimeError as e:
        raise ToolError(str(e))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"読み取りに失敗しました: {e}")
    text = text.strip()
    total = len(text)
    if total > max_chars:
        text = text[:max_chars] + f"\n... (省略: 全 {total:,} 文字。pages / sheet / max_chars で範囲を絞れる)"
    return f"{p.name}  ({method}, {total:,} 文字)\n\n{text or '(テキストが抽出できませんでした。画像 PDF の可能性)'}"


register(Tool("read_document",
              "PDF / Word (.docx) / Excel (.xlsx) / PowerPoint (.pptx) / OpenDocument / CSV をテキストにして読む。"
              "仕様書・データファイルの内容確認に使う。PDF は pages（例: 1-3）、Excel は sheet で範囲を絞れる。",
              {"type": "object", "properties": {
                  "path": {"type": "string"},
                  "pages": {"type": "string", "description": "PDF のページ範囲（例: 1-5, 8）"},
                  "sheet": {"type": "string", "description": "Excel のシート名（省略時は全シート）"},
                  "max_chars": {"type": "integer", "description": "既定 12000"},
                  "max_rows": {"type": "integer", "description": "表の最大行数（既定 500）"}},
               "required": ["path"]}, read_document, lambda a: a.get("path", "")))

__all__ = ["SUPPORTED"]
