"""バックグラウンドプロセス管理（v1.5.0）: サーバーなど長時間動くプロセスを起動・監視・停止する。

run_command で `cmd &` すると停止やログ取得が ad-hoc になり、放置プロセスが残りやすい。
ProcessManager はプロセスグループごとに起動し、出力をログファイルに落とし、
ポートの待ち受けを確認でき、サーバー終了時にまとめて止める。
"""
from __future__ import annotations

import asyncio
import os
import signal
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Proc:
    id: str
    name: str
    command: str
    cwd: str
    log: Path
    port: int | None
    session_id: str
    proc: asyncio.subprocess.Process
    started: float = field(default_factory=time.time)

    @property
    def running(self) -> bool:
        return self.proc.returncode is None

    @property
    def pid(self) -> int:
        return self.proc.pid


async def port_open(port: int, host: str = "127.0.0.1", timeout: float = 0.5) -> bool:
    try:
        r, w = await asyncio.wait_for(asyncio.open_connection(host, port), timeout)
        w.close()
        try:
            await w.wait_closed()
        except Exception:  # noqa: BLE001
            pass
        return True
    except Exception:  # noqa: BLE001
        return False


class ProcessManager:
    def __init__(self, log_root: Path):
        self.log_root = log_root
        self._procs: dict[str, Proc] = {}
        self._seq = 0

    async def start(self, session_id: str, command: str, cwd: Path, name: str = "", port: int | None = None,
                    wait: float = 15, env: dict | None = None) -> tuple[Proc, str]:
        """起動して (Proc, 状態メモ) を返す。port があれば待ち受け開始まで最大 wait 秒待つ。"""
        if port and await port_open(port):
            raise RuntimeError(f"ポート {port} は既に使われています（process_status で確認するか、別のポートを使う）")
        self._seq += 1
        pid_name = name or command.split()[0].rsplit("/", 1)[-1][:20]
        pid_id = f"p{self._seq}"
        self.log_root.mkdir(parents=True, exist_ok=True)
        log = self.log_root / f"proc_{pid_id}_{int(time.time())}.log"
        fh = open(log, "wb")
        proc = await asyncio.create_subprocess_shell(
            command, cwd=str(cwd), stdout=fh, stderr=asyncio.subprocess.STDOUT, stdin=asyncio.subprocess.DEVNULL,
            start_new_session=True, env={**os.environ, "PYTHONUNBUFFERED": "1", **(env or {})})
        fh.close()
        p = Proc(pid_id, pid_name, command, str(cwd), log, port, session_id, proc)
        self._procs[pid_id] = p
        note = ""
        deadline = time.time() + max(wait, 0.5)
        while time.time() < deadline:
            await asyncio.sleep(0.3)
            if not p.running:
                note = f"起動直後に終了しました (exit {proc.returncode})"
                break
            if port and await port_open(port):
                note = f"ポート {port} で待ち受け中"
                break
            if not port and time.time() - p.started > 1.5:
                note = "実行中"
                break
        else:
            note = f"ポート {port} の待ち受けを {wait} 秒待ちましたが開きません（ログを確認）" if port else "実行中"
        return p, note

    def get(self, pid_id: str) -> Proc | None:
        return self._procs.get(pid_id)

    def list(self, session_id: str | None = None) -> list[Proc]:
        return [p for p in self._procs.values() if session_id is None or p.session_id == session_id]

    def tail(self, p: Proc, lines: int = 60, grep: str | None = None) -> str:
        try:
            text = p.log.read_text("utf-8", errors="replace")
        except FileNotFoundError:
            return ""
        rows = text.splitlines()
        if grep:
            import re
            try:
                rows = [r for r in rows if re.search(grep, r)]
            except re.error:
                rows = [r for r in rows if grep in r]
        return "\n".join(rows[-lines:])

    async def stop(self, pid_id: str, timeout: float = 5) -> str:
        p = self._procs.get(pid_id)
        if p is None:
            raise RuntimeError(f"プロセス {pid_id} はありません")
        if not p.running:
            return f"{pid_id} は既に終了しています (exit {p.proc.returncode})"
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            await asyncio.wait_for(p.proc.wait(), timeout)
        except asyncio.TimeoutError:
            try:
                os.killpg(os.getpgid(p.pid), signal.SIGKILL)
            except ProcessLookupError:
                pass
            await p.proc.wait()
            return f"{pid_id} を強制終了しました (SIGKILL)"
        return f"{pid_id} を停止しました (exit {p.proc.returncode})"

    async def stop_all(self, session_id: str | None = None) -> int:
        n = 0
        for p in self.list(session_id):
            if p.running:
                await self.stop(p.id)
                n += 1
        return n

    def forget_finished(self, session_id: str | None = None, keep: int = 10) -> None:
        done = [p for p in self.list(session_id) if not p.running]
        for p in done[:-keep]:
            self._procs.pop(p.id, None)
