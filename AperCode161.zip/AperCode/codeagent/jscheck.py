"""JavaScript / HTML の検査（v1.5.0、check_js ツールと write 後の自動検証で使う）。

静的検査（node があれば）:
  - .js/.mjs/.cjs: node --check（構文）、import/require のパッケージが node_modules か組み込みに存在するか
  - .html: <script> のインライン JS を個別に node --check、<script src> の相対パスが存在するか、
           CDN の URL が既知のホストで .js を指しているか
実行検査（Playwright があれば、check_js ツールのみ）:
  - ページを実際にブラウザで開き、JS 例外・console.error・失敗したリクエスト（404 など）を集める
  - probes（JS 式）を評価して型・値・関数のソース冒頭を返す → ライブラリの初期化の書き方や存在確認に使う
  - libraries（スクリプト URL）だけを空ページに読み込んで probes を評価 → ライブラリの API を実装前に確かめる
"""
from __future__ import annotations

import asyncio
import html as _html
import http.server
import re
import shutil
import socketserver
import tempfile
import threading
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

NODE_BUILTINS = {"fs", "path", "os", "http", "https", "url", "util", "events", "stream", "crypto", "child_process", "net",
                 "zlib", "readline", "assert", "buffer", "querystring", "dns", "tls", "cluster", "worker_threads", "module",
                 "process", "timers", "vm", "string_decoder", "perf_hooks", "async_hooks", "fs/promises", "stream/promises",
                 "timers/promises", "test", "dgram", "v8", "inspector", "tty", "punycode", "repl", "constants", "console"}

SCRIPT_RE = re.compile(r"<script\b([^>]*)>(.*?)</script>", re.S | re.I)
ATTR_RE = re.compile(r"""([a-zA-Z-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))""")


@dataclass
class StaticResult:
    ok: bool = True
    notes: list[str] = field(default_factory=list)      # 問題点
    info: list[str] = field(default_factory=list)       # 補足（検査した内容）
    scripts_local: list[str] = field(default_factory=list)
    scripts_remote: list[str] = field(default_factory=list)


def _attrs(s: str) -> dict[str, str]:
    return {m.group(1).lower(): (m.group(2) or m.group(3) or m.group(4) or "") for m in ATTR_RE.finditer(s)}


async def _node_check_source(src: str, label: str, module: bool) -> str | None:
    """構文エラーなら node の出力を返す。"""
    if not shutil.which("node"):
        return None
    with tempfile.NamedTemporaryFile("w", suffix=".mjs" if module else ".js", delete=False, encoding="utf-8") as f:
        f.write(src)
        tmp = f.name
    try:
        proc = await asyncio.create_subprocess_exec("node", "--check", tmp, stdout=asyncio.subprocess.PIPE,
                                                    stderr=asyncio.subprocess.STDOUT)
        out, _ = await asyncio.wait_for(proc.communicate(), 60)
        if proc.returncode != 0:
            text = out.decode("utf-8", "replace").replace(tmp, label)
            lines = [ln for ln in text.splitlines() if not ln.startswith("    at ") and not ln.startswith("Node.js v")]
            return "\n".join(lines).strip()[:2000]
        return None
    finally:
        Path(tmp).unlink(missing_ok=True)


def _imports(src: str) -> list[str]:
    specs = re.findall(r"""(?:^|[^\w.])import\s+(?:[\w*{}\s,$]+\s+from\s+)?["']([^"']+)["']""", src, re.M)
    specs += re.findall(r"""(?:^|[^\w.])require\(\s*["']([^"']+)["']\s*\)""", src)
    specs += re.findall(r"""(?:^|[^\w.])import\(\s*["']([^"']+)["']\s*\)""", src)
    return specs


def _pkg_name(spec: str) -> str:
    if spec.startswith("@"):
        return "/".join(spec.split("/")[:2])
    return spec.split("/")[0]


async def check_js_file(p: Path, project: Path) -> StaticResult:
    r = StaticResult()
    src = p.read_text("utf-8", errors="replace")
    module = p.suffix.lower() == ".mjs" or bool(re.search(r"^\s*(import|export)\b", src, re.M))
    err = await _node_check_source(src, str(p), module)
    if err:
        r.ok = False
        r.notes.append("構文エラー:\n" + err)
    r.info.append("node --check")
    missing: list[str] = []
    for spec in _imports(src):
        if spec.startswith((".", "/", "http://", "https://", "node:", "data:")):
            if spec.startswith("."):
                target = (p.parent / spec)
                cands = [target] + [target.with_suffix(target.suffix + ext) for ext in (".js", ".mjs", ".ts", ".json")] + [target / "index.js"]
                if not any(c.exists() for c in cands):
                    missing.append(f"{spec}（相対パスのファイルが無い）")
            continue
        name = _pkg_name(spec)
        if name in NODE_BUILTINS:
            continue
        found = False
        for base in (p.parent, project):
            d = base
            for _ in range(6):
                if (d / "node_modules" / name).exists():
                    found = True
                    break
                if d == d.parent:
                    break
                d = d.parent
            if found:
                break
        if not found:
            missing.append(f"{name}（node_modules に無い。npm install {name} が必要か、CDN の <script> で読む前提なら import を使わない）")
    if missing:
        r.ok = False
        r.notes.append("解決できない import / require:\n- " + "\n- ".join(missing))
    return r


async def check_html_file(p: Path, project: Path) -> StaticResult:
    r = StaticResult()
    src = p.read_text("utf-8", errors="replace")
    inline_n = 0
    for i, m in enumerate(SCRIPT_RE.finditer(src), 1):
        a = _attrs(m.group(1))
        typ = a.get("type", "").lower()
        if typ and typ not in ("text/javascript", "application/javascript", "module", "text/babel"):
            continue  # JSON-LD / テンプレート等
        if "src" in a:
            u = a["src"].strip()
            if u.startswith(("http://", "https://", "//")):
                r.scripts_remote.append(u)
                if not re.search(r"\.(m?js)(\?|#|$)", u) and "unpkg.com" not in u and "jsdelivr" in u and "/dist/" not in u:
                    r.info.append(f"CDN の URL が .js で終わっていません（ディレクトリ指定の可能性）: {u}")
            elif u.startswith("data:"):
                pass
            else:
                r.scripts_local.append(u)
                local = (p.parent / u.split("?")[0].lstrip("/")) if not u.startswith("/") else (project / u.split("?")[0].lstrip("/"))
                if not local.exists():
                    r.ok = False
                    r.notes.append(f"<script src=\"{u}\"> のファイルがありません（{local}）")
            continue
        body = m.group(2)
        if not body.strip() or typ == "text/babel":
            continue
        inline_n += 1
        err = await _node_check_source(_html.unescape(body) if "&lt;" in body else body,
                                       f"{p.name}:<script #{i}>", typ == "module")
        if err:
            r.ok = False
            line0 = src[:m.start(2)].count("\n") + 1
            r.notes.append(f"インライン <script> #{i}（{p.name} の {line0} 行目から）の構文エラー:\n" + err)
    if shutil.which("node"):
        r.info.append(f"node --check（インライン script {inline_n} 個）")
    if r.scripts_local:
        r.info.append("ローカル script: " + ", ".join(r.scripts_local))
    if r.scripts_remote:
        r.info.append("外部 script: " + ", ".join(r.scripts_remote[:8]))
    return r


def format_static(r: StaticResult) -> str:
    lines = []
    if r.notes:
        lines += r.notes
    else:
        lines.append("静的検査: 問題なし")
    if r.info:
        lines.append("（検査内容: " + "; ".join(r.info) + "）")
    return "\n".join(lines)


# ------------------------------------------------------------------ ローカル HTTP 配信（file:// だと module / fetch が動かないため）
class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):  # noqa: D401
        pass


class ServeDir:
    """ディレクトリを 127.0.0.1 の空きポートで配信する（with で使う）。"""

    def __init__(self, directory: Path):
        self.directory = directory
        self.httpd: socketserver.TCPServer | None = None
        self.port = 0

    def __enter__(self):
        handler = lambda *a, **k: _Quiet(*a, directory=str(self.directory), **k)  # noqa: E731
        socketserver.TCPServer.allow_reuse_address = True
        self.httpd = socketserver.TCPServer(("127.0.0.1", 0), handler)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        return self

    def __exit__(self, *exc):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()


def format_runtime(res: dict) -> str:
    lines = []
    if res.get("url"):
        lines.append(f"URL: {res['url']}" + (f"  (HTTP {res['status']})" if res.get("status") else "") +
                     (f"  タイトル: {res['title']}" if res.get("title") else ""))
    probs = 0
    if res.get("page_errors"):
        probs += len(res["page_errors"])
        lines.append("JS 例外:\n- " + "\n- ".join(res["page_errors"][:10]))
    errs = [m for m in res.get("console", []) if m["type"] == "error"]
    warns = [m for m in res.get("console", []) if m["type"] == "warning"]
    if errs:
        probs += len(errs)
        lines.append("console.error:\n- " + "\n- ".join(m["text"] for m in errs[:10]))
    if warns:
        lines.append("console.warn:\n- " + "\n- ".join(m["text"] for m in warns[:5]))
    if res.get("network_errors"):
        probs += len(res["network_errors"])
        lines.append("失敗したリクエスト（script/画像/API の URL 誤りの可能性）:\n- " + "\n- ".join(res["network_errors"][:10]))
    if res.get("probes"):
        rows = []
        for pr in res["probes"]:
            if "error" in pr:
                rows.append(f"- {pr['expr']} → エラー: {pr['error']}")
            elif pr.get("type") == "function":
                rows.append(f"- {pr['expr']} → function: {pr['preview']}")
            else:
                extra = f" keys={pr['keys']}" if pr.get("keys") else ""
                ctor = f" ({pr['ctor']})" if pr.get("ctor") else ""
                rows.append(f"- {pr['expr']} → {pr.get('type')}{ctor}: {pr.get('value')}{extra}")
        lines.append("probe の結果:\n" + "\n".join(rows))
    lines.insert(0, "実行検査: 問題なし（JS 例外・console.error・失敗リクエストなし）" if probs == 0 else f"実行検査: 問題 {probs} 件")
    return "\n".join(lines)


def html_for_libraries(urls: list[str]) -> str:
    tags = "\n".join(f'<script src="{_html.escape(u)}"></script>' if not u.endswith((".mjs",)) and "esm" not in u
                     else f'<script type="module">import * as m from "{_html.escape(u)}"; window.__esm = m;</script>' for u in urls)
    return f"<!doctype html><html><head><meta charset='utf-8'></head><body><div id='app'></div><canvas id='c'></canvas>{tags}</body></html>"
