"""永続 REPL（v1.5.0）: Python / Node のプロセスをセッション単位で保持し、変数や import を持ち越して実行する。

run_command は毎回新しいプロセスなので状態を持ち越せない。repl ツールはワーカープロセスを 1 本立てて
stdin/stdout の JSON 行で code を送り、stdout・stderr・最後の式の値・例外を返す。
  - Python: プロジェクトの .venv/bin/python があればそれを使う（無ければ AperCode と同じ python）
  - Node: node が PATH にあれば使う。require はプロジェクトの node_modules から解決
タイムアウトしたらワーカーを kill して作り直す（状態は失われる）。
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
import time
from pathlib import Path

PY_WORKER = r'''
import sys, json, io, ast, traceback, contextlib, os
ns = {"__name__": "__main__", "__builtins__": __builtins__}
sys.path.insert(0, os.getcwd())
out_real = sys.stdout
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    req = json.loads(line)
    code = req.get("code", "")
    buf_out, buf_err = io.StringIO(), io.StringIO()
    res = {"ok": True, "value": None}
    try:
        with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
            tree = ast.parse(code, mode="exec")
            last = tree.body[-1] if tree.body and isinstance(tree.body[-1], ast.Expr) else None
            if last is not None:
                tree.body = tree.body[:-1]
            if tree.body:
                exec(compile(tree, "<repl>", "exec"), ns)
            if last is not None:
                val = eval(compile(ast.Expression(last.value), "<repl>", "eval"), ns)
                if val is not None:
                    ns["_"] = val
                    res["value"] = repr(val)
    except SystemExit:
        res["ok"] = False
        res["error"] = "SystemExit"
    except BaseException as e:
        res["ok"] = False
        tb = [f for f in traceback.extract_tb(e.__traceback__) if f.filename != "<string>"]
        res["error"] = "Traceback (most recent call last):\n" + "".join(traceback.format_list(tb)) + "".join(traceback.format_exception_only(type(e), e))
    res["stdout"] = buf_out.getvalue()
    res["stderr"] = buf_err.getvalue()
    out_real.write(json.dumps(res, ensure_ascii=False) + "\n")
    out_real.flush()
'''

NODE_WORKER = r'''
const vm = require("vm"), readline = require("readline"), util = require("util"), path = require("path");
const { createRequire } = require("module");
const req = createRequire(path.join(process.cwd(), "repl.js"));
const logs = [];
const ctx = { require: req, console: {}, process, Buffer, setTimeout, setInterval, clearTimeout, clearInterval, URL, URLSearchParams, TextEncoder, TextDecoder, fetch: global.fetch, __dirname: process.cwd(), module: { exports: {} } };
for (const k of ["log", "info", "debug", "warn", "error"]) ctx.console[k] = (...a) => logs.push(a.map(x => typeof x === "string" ? x : util.inspect(x)).join(" "));
ctx.exports = ctx.module.exports;
vm.createContext(ctx);
const rl = readline.createInterface({ input: process.stdin });
let chain = Promise.resolve();
rl.on("line", (line) => {
  chain = chain.then(async () => {
    if (!line.trim()) return;
    const r = JSON.parse(line); logs.length = 0;
    const res = { ok: true, value: null };
    try {
      let v = vm.runInContext(r.code, ctx, { filename: "<repl>" });
      if (v && typeof v.then === "function") v = await v;
      if (v !== undefined) { ctx._ = v; res.value = util.inspect(v, { depth: 3, maxArrayLength: 50 }); }
    } catch (e) { res.ok = false; res.error = (e && e.stack) ? String(e.stack) : String(e); }
    res.stdout = logs.join("\n"); res.stderr = "";
    process.stdout.write(JSON.stringify(res) + "\n");
  });
});
'''


def python_for(project: Path) -> str:
    for cand in (project / ".venv" / "bin" / "python", project / "venv" / "bin" / "python",
                 project / ".venv" / "Scripts" / "python.exe"):
        if cand.exists():
            return str(cand)
    return sys.executable


class Repl:
    def __init__(self, language: str, project: Path):
        self.language = language
        self.project = project
        self.proc: asyncio.subprocess.Process | None = None
        self.exe = ""
        self.started = 0.0
        self.calls = 0
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        if self.language == "node":
            node = shutil.which("node")
            if not node:
                raise RuntimeError("node が PATH にありません")
            self.exe = node
            args = [node, "-e", NODE_WORKER]
        else:
            self.exe = python_for(self.project)
            args = [self.exe, "-u", "-c", PY_WORKER]
        self.proc = await asyncio.create_subprocess_exec(
            *args, cwd=str(self.project), stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
        self.started = time.time()
        self.calls = 0

    def alive(self) -> bool:
        return self.proc is not None and self.proc.returncode is None

    async def stop(self) -> None:
        p, self.proc = self.proc, None
        if p and p.returncode is None:
            try:
                p.kill()
                await asyncio.wait_for(p.wait(), 5)
            except Exception:  # noqa: BLE001
                pass

    async def run(self, code: str, timeout: float = 60) -> dict:
        async with self._lock:
            if not self.alive():
                await self.start()
            assert self.proc and self.proc.stdin and self.proc.stdout
            self.proc.stdin.write((json.dumps({"code": code}) + "\n").encode())
            await self.proc.stdin.drain()
            try:
                line = await asyncio.wait_for(self.proc.stdout.readline(), timeout)
            except asyncio.TimeoutError:
                await self.stop()
                return {"ok": False, "error": f"タイムアウト {timeout}s（REPL を再起動しました。変数などの状態は失われました）",
                        "stdout": "", "stderr": "", "value": None, "restarted": True}
            self.calls += 1
            if not line:
                err = b""
                if self.proc.stderr:
                    try:
                        err = await asyncio.wait_for(self.proc.stderr.read(4000), 1)
                    except Exception:  # noqa: BLE001
                        pass
                await self.stop()
                return {"ok": False, "error": "REPL プロセスが終了しました: " + err.decode("utf-8", "replace"),
                        "stdout": "", "stderr": "", "value": None, "restarted": True}
            try:
                return json.loads(line.decode("utf-8", "replace"))
            except json.JSONDecodeError:
                return {"ok": False, "error": "REPL の応答を解釈できません: " + line.decode("utf-8", "replace")[:500],
                        "stdout": "", "stderr": "", "value": None}


class ReplManager:
    """セッション ID × 言語 ごとに REPL を保持する。"""

    def __init__(self):
        self._repls: dict[tuple[str, str], Repl] = {}

    def get(self, session_id: str, language: str, project: Path) -> Repl:
        key = (session_id, language)
        r = self._repls.get(key)
        if r is None or r.project != project:
            if r is not None:
                asyncio.ensure_future(r.stop())
            r = Repl(language, project)
            self._repls[key] = r
        return r

    async def reset(self, session_id: str, language: str | None = None) -> int:
        n = 0
        for key in list(self._repls):
            if key[0] == session_id and (language is None or key[1] == language):
                await self._repls.pop(key).stop()
                n += 1
        return n

    async def close_all(self) -> None:
        for r in list(self._repls.values()):
            await r.stop()
        self._repls.clear()

    def status(self, session_id: str) -> list[dict]:
        return [{"language": k[1], "alive": r.alive(), "exe": r.exe, "calls": r.calls}
                for k, r in self._repls.items() if k[0] == session_id]
