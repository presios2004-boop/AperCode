"""ドキュメント読み取り（v1.5.0）: PDF / Word / Excel / PowerPoint / CSV をテキストにする。

外部ライブラリは任意。無い場合の順序:
  PDF   : pdftotext（poppler-utils）→ pypdf → エラー
  docx  : zip 内の word/document.xml を直接読む（依存なし）
  xlsx  : openpyxl → zip 内の XML を直接読む（依存なし・数式は結果値のみ）
  pptx  : zip 内の ppt/slides/slideN.xml を直接読む（依存なし）
  csv/tsv/txt/md : そのまま
"""
from __future__ import annotations

import asyncio
import csv
import io
import re
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

SUPPORTED = (".pdf", ".docx", ".xlsx", ".xlsm", ".pptx", ".csv", ".tsv", ".txt", ".md", ".odt", ".ods")


def _parse_pages(spec: str | None, n: int) -> list[int]:
    if not spec:
        return list(range(n))
    out: list[int] = []
    for part in str(spec).split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            a = int(a) if a.strip() else 1
            b = int(b) if b.strip() else n
            out += list(range(a - 1, min(b, n)))
        else:
            i = int(part) - 1
            if 0 <= i < n:
                out.append(i)
    return sorted(set(i for i in out if 0 <= i < n))


async def _read_pdf(p: Path, pages: str | None) -> tuple[str, str]:
    if shutil.which("pdftotext"):
        args = ["pdftotext", "-layout"]
        if pages:
            m = re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*", str(pages))
            if m:
                args += ["-f", m.group(1), "-l", m.group(2)]
            elif str(pages).strip().isdigit():
                args += ["-f", str(pages).strip(), "-l", str(pages).strip()]
        proc = await asyncio.create_subprocess_exec(*args, str(p), "-", stdout=asyncio.subprocess.PIPE,
                                                    stderr=asyncio.subprocess.PIPE)
        out, err = await asyncio.wait_for(proc.communicate(), 120)
        if proc.returncode == 0:
            return out.decode("utf-8", "replace"), "pdftotext"
    try:
        from pypdf import PdfReader  # type: ignore
    except ImportError:
        raise RuntimeError("PDF を読むには poppler-utils（pdftotext）か pypdf が必要です: sudo apt install poppler-utils または pip install pypdf")
    r = PdfReader(str(p))
    idx = _parse_pages(pages, len(r.pages))
    parts = [f"--- page {i + 1} ---\n{(r.pages[i].extract_text() or '')}" for i in idx]
    return "\n".join(parts), "pypdf"


_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
_S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _read_docx(p: Path) -> tuple[str, str]:
    with zipfile.ZipFile(p) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    lines: list[str] = []
    body = root.find(_W + "body")
    for el in (body if body is not None else root):
        if el.tag == _W + "p":
            lines.append("".join(t.text or "" for t in el.iter(_W + "t")))
        elif el.tag == _W + "tbl":
            for tr in el.iter(_W + "tr"):
                cells = ["".join(t.text or "" for t in tc.iter(_W + "t")) for tc in tr.iter(_W + "tc")]
                lines.append(" | ".join(cells))
            lines.append("")
    return "\n".join(lines), "docx-xml"


def _read_pptx(p: Path) -> tuple[str, str]:
    out: list[str] = []
    with zipfile.ZipFile(p) as z:
        names = sorted([n for n in z.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)],
                       key=lambda n: int(re.findall(r"\d+", n)[-1]))
        for n in names:
            root = ET.fromstring(z.read(n))
            texts: list[str] = []
            for para in root.iter(_A + "p"):
                s = "".join(t.text or "" for t in para.iter(_A + "t"))
                if s.strip():
                    texts.append(s)
            num = re.findall(r"\d+", n)[-1]
            out.append(f"--- slide {num} ---\n" + "\n".join(texts))
    return "\n\n".join(out), "pptx-xml"


def _col_to_idx(col: str) -> int:
    n = 0
    for ch in col:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def _read_xlsx_xml(p: Path, sheet: str | None, max_rows: int) -> tuple[str, str]:
    with zipfile.ZipFile(p) as z:
        shared: list[str] = []
        if "xl/sharedStrings.xml" in z.namelist():
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).iter(_S + "si"):
                shared.append("".join(t.text or "" for t in si.iter(_S + "t")))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        sheets = [(s.get("name"), i + 1) for i, s in enumerate(wb.iter(_S + "sheet"))]
        chosen = [s for s in sheets if not sheet or s[0] == sheet]
        if not chosen:
            raise RuntimeError(f"シート {sheet!r} がありません。シート: {[s[0] for s in sheets]}")
        out: list[str] = []
        for name, i in chosen:
            path = f"xl/worksheets/sheet{i}.xml"
            if path not in z.namelist():
                continue
            root = ET.fromstring(z.read(path))
            rows: list[str] = []
            for row in root.iter(_S + "row"):
                cells: dict[int, str] = {}
                for c in row.iter(_S + "c"):
                    ref = c.get("r") or "A"
                    col = _col_to_idx(re.match(r"[A-Z]+", ref).group(0))
                    v = c.find(_S + "v")
                    val = v.text if v is not None and v.text is not None else ""
                    if c.get("t") == "s" and val.isdigit():
                        val = shared[int(val)] if int(val) < len(shared) else val
                    elif c.get("t") == "inlineStr":
                        val = "".join(t.text or "" for t in c.iter(_S + "t"))
                    cells[col] = val
                if cells:
                    width = max(cells) + 1
                    rows.append("\t".join(cells.get(k, "") for k in range(width)))
                if len(rows) >= max_rows:
                    rows.append(f"... (先頭 {max_rows} 行まで)")
                    break
            out.append(f"=== sheet: {name} ===\n" + "\n".join(rows))
    return "\n\n".join(out), "xlsx-xml"


def _read_xlsx(p: Path, sheet: str | None, max_rows: int) -> tuple[str, str]:
    try:
        import openpyxl  # type: ignore
    except ImportError:
        return _read_xlsx_xml(p, sheet, max_rows)
    wb = openpyxl.load_workbook(str(p), read_only=True, data_only=True)
    names = wb.sheetnames
    chosen = [n for n in names if not sheet or n == sheet]
    if not chosen:
        raise RuntimeError(f"シート {sheet!r} がありません。シート: {names}")
    out: list[str] = []
    for n in chosen:
        ws = wb[n]
        rows: list[str] = []
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i >= max_rows:
                rows.append(f"... (先頭 {max_rows} 行まで)")
                break
            rows.append("\t".join("" if v is None else str(v) for v in row))
        out.append(f"=== sheet: {n} ===\n" + "\n".join(rows))
    return "\n\n".join(out), "openpyxl"


def _read_odf(p: Path) -> tuple[str, str]:
    with zipfile.ZipFile(p) as z:
        root = ET.fromstring(z.read("content.xml"))
    text = "".join(root.itertext())
    return re.sub(r"\n{3,}", "\n\n", text), "odf-xml"


async def read_document(p: Path, *, pages: str | None = None, sheet: str | None = None,
                        max_rows: int = 500) -> tuple[str, str]:
    """(テキスト, 使った方法) を返す。"""
    ext = p.suffix.lower()
    if ext == ".pdf":
        return await _read_pdf(p, pages)
    if ext == ".docx":
        return _read_docx(p)
    if ext in (".xlsx", ".xlsm"):
        return _read_xlsx(p, sheet, max_rows)
    if ext == ".pptx":
        return _read_pptx(p)
    if ext in (".odt", ".ods"):
        return _read_odf(p)
    if ext in (".csv", ".tsv"):
        raw = p.read_text("utf-8", errors="replace")
        rows = list(csv.reader(io.StringIO(raw), delimiter="\t" if ext == ".tsv" else ","))
        lines = ["\t".join(r) for r in rows[:max_rows]]
        if len(rows) > max_rows:
            lines.append(f"... (全 {len(rows)} 行、先頭 {max_rows} 行まで)")
        return "\n".join(lines), "csv"
    if ext in (".txt", ".md"):
        return p.read_text("utf-8", errors="replace"), "text"
    raise RuntimeError(f"対応していない形式です: {ext}（対応: {', '.join(SUPPORTED)}）")
