"""クラウド AI への「相談」クライアント（v1.2.4）。

ローカル LLM が行き詰まったとき、状況をまとめてクラウドの強いモデルにヒントを求めるために使う。
会話全体を渡すのではなく、目的・エラー・試したこと・関連コードの抜粋だけを 1 回の単発リクエストで送る。

対応プロバイダ:
  anthropic  : Claude (Messages API)
  gemini     : Google Gemini (generateContent)
  openai     : OpenAI (Chat Completions)
  openai 互換: deepseek / groq / mistral / openrouter / xai / custom（base_url を指定）
API キーは config の cloud.api_key、無ければプロバイダごとの環境変数から読む。
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass

import httpx

# プロバイダのプリセット。models は UI のプルダウン用（手入力も可）
PROVIDERS: dict[str, dict] = {
    "anthropic": {"label": "Anthropic Claude", "env": "ANTHROPIC_API_KEY", "base_url": "https://api.anthropic.com",
                  "models": ["claude-sonnet-4-5", "claude-opus-4-1", "claude-haiku-4-5"]},
    "gemini": {"label": "Google Gemini", "env": "GEMINI_API_KEY", "base_url": "https://generativelanguage.googleapis.com",
               "models": ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.0-flash"]},
    "openai": {"label": "OpenAI", "env": "OPENAI_API_KEY", "base_url": "https://api.openai.com/v1",
               "models": ["gpt-5", "gpt-5-mini", "gpt-4.1", "o4-mini"]},
    "deepseek": {"label": "DeepSeek", "env": "DEEPSEEK_API_KEY", "base_url": "https://api.deepseek.com/v1",
                 "models": ["deepseek-chat", "deepseek-reasoner"]},
    "groq": {"label": "Groq", "env": "GROQ_API_KEY", "base_url": "https://api.groq.com/openai/v1",
             "models": ["llama-3.3-70b-versatile", "openai/gpt-oss-120b", "qwen/qwen3-32b"]},
    "mistral": {"label": "Mistral", "env": "MISTRAL_API_KEY", "base_url": "https://api.mistral.ai/v1",
                "models": ["mistral-large-latest", "codestral-latest"]},
    "openrouter": {"label": "OpenRouter", "env": "OPENROUTER_API_KEY", "base_url": "https://openrouter.ai/api/v1",
                   "models": ["anthropic/claude-sonnet-4.5", "google/gemini-2.5-pro", "openai/gpt-5", "deepseek/deepseek-chat"]},
    "xai": {"label": "xAI Grok", "env": "XAI_API_KEY", "base_url": "https://api.x.ai/v1",
            "models": ["grok-4", "grok-3-mini"]},
    "custom": {"label": "OpenAI 互換（カスタム URL）", "env": "CLOUD_API_KEY", "base_url": "",
               "models": []},
}

# 送信前にマスクする秘密情報らしきもの
_SECRET_PATTERNS = [
    r"(?i)(api[_-]?key|secret|token|password|passwd|authorization)\s*[:=]\s*['\"]?([A-Za-z0-9_\-./+=]{12,})",
    r"\bsk-[A-Za-z0-9_\-]{16,}\b", r"\bsk-ant-[A-Za-z0-9_\-]{16,}\b", r"\bAIza[0-9A-Za-z_\-]{30,}\b",
    r"\bgh[pousr]_[A-Za-z0-9]{30,}\b", r"\bxox[baprs]-[A-Za-z0-9\-]{10,}\b",
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----",
]


def mask_secrets(text: str) -> tuple[str, int]:
    """秘密情報らしき文字列を <masked> に置き換える。(結果, 置換数)"""
    n = 0
    for pat in _SECRET_PATTERNS:
        def _rep(m):
            nonlocal n
            n += 1
            if m.lastindex and m.lastindex >= 2:
                return m.group(0).replace(m.group(2), "<masked>")
            return "<masked>"
        text = re.sub(pat, _rep, text)
    return text, n


@dataclass
class CloudSettings:
    provider: str = "anthropic"
    model: str = ""
    api_key: str = ""
    base_url: str = ""
    timeout: float = 120.0

    @classmethod
    def from_cfg(cls, cfg) -> "CloudSettings":
        prov = str(cfg.get("cloud.provider", "anthropic") or "anthropic").lower()
        preset = PROVIDERS.get(prov, PROVIDERS["custom"])
        key = str(cfg.get("cloud.api_key", "") or "") or os.environ.get(preset["env"], "")
        if not key and prov == "gemini":
            key = os.environ.get("GOOGLE_API_KEY", "")
        model = str(cfg.get("cloud.model", "") or "") or (preset["models"][0] if preset["models"] else "")
        base = str(cfg.get("cloud.base_url", "") or "") or preset["base_url"]
        return cls(provider=prov, model=model, api_key=key, base_url=base.rstrip("/"),
                   timeout=float(cfg.get("cloud.timeout", 120)))

    @property
    def ready(self) -> bool:
        return bool(self.api_key and self.model and (self.base_url or self.provider in ("anthropic", "gemini")))

    def describe(self) -> str:
        return f"{PROVIDERS.get(self.provider, {}).get('label', self.provider)} / {self.model}"


class CloudClient:
    def __init__(self, s: CloudSettings):
        self.s = s

    async def ask(self, system: str, prompt: str, max_tokens: int = 4096) -> str:
        s = self.s
        if not s.api_key:
            raise RuntimeError(f"API キーが設定されていません（cloud.api_key または環境変数 "
                               f"{PROVIDERS.get(s.provider, PROVIDERS['custom'])['env']}）")
        async with httpx.AsyncClient(timeout=httpx.Timeout(s.timeout, connect=15.0)) as c:
            if s.provider == "anthropic":
                r = await c.post(f"{s.base_url or 'https://api.anthropic.com'}/v1/messages",
                                 headers={"x-api-key": s.api_key, "anthropic-version": "2023-06-01",
                                          "content-type": "application/json"},
                                 json={"model": s.model, "max_tokens": max_tokens, "system": system,
                                       "messages": [{"role": "user", "content": prompt}]})
                self._raise(r)
                data = r.json()
                return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
            if s.provider == "gemini":
                base = s.base_url or "https://generativelanguage.googleapis.com"
                r = await c.post(f"{base}/v1beta/models/{s.model}:generateContent",
                                 headers={"x-goog-api-key": s.api_key, "content-type": "application/json"},
                                 json={"system_instruction": {"parts": [{"text": system}]},
                                       "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                                       "generationConfig": {"maxOutputTokens": max_tokens, "temperature": 0.2}})
                self._raise(r)
                data = r.json()
                cands = data.get("candidates") or []
                if not cands:
                    raise RuntimeError(f"Gemini から応答がありません: {str(data)[:300]}")
                parts = (cands[0].get("content") or {}).get("parts") or []
                return "".join(p.get("text", "") for p in parts).strip()
            # OpenAI 互換
            if not s.base_url:
                raise RuntimeError("cloud.base_url が設定されていません（custom プロバイダ）")
            headers = {"Authorization": f"Bearer {s.api_key}", "content-type": "application/json"}
            if s.provider == "openrouter":
                headers["HTTP-Referer"] = "https://github.com/apercode"
                headers["X-Title"] = "AperCode"
            body = {"model": s.model, "messages": [{"role": "system", "content": system},
                                                    {"role": "user", "content": prompt}],
                    "max_tokens": max_tokens, "temperature": 0.2}
            r = await c.post(f"{s.base_url}/chat/completions", headers=headers, json=body)
            if r.status_code == 400 and "max_tokens" in r.text:
                body.pop("max_tokens", None)
                body["max_completion_tokens"] = max_tokens   # 新しい OpenAI モデル向け
                body.pop("temperature", None)
                r = await c.post(f"{s.base_url}/chat/completions", headers=headers, json=body)
            self._raise(r)
            data = r.json()
            choices = data.get("choices") or []
            if not choices:
                raise RuntimeError(f"応答がありません: {str(data)[:300]}")
            msg = choices[0].get("message") or {}
            return str(msg.get("content") or "").strip()

    @staticmethod
    def _raise(r: httpx.Response) -> None:
        if r.status_code >= 400:
            txt = r.text[:400]
            hint = ""
            if r.status_code in (401, 403):
                hint = "（API キーが無効か、権限がありません）"
            elif r.status_code == 404:
                hint = "（モデル名が間違っている可能性）"
            elif r.status_code == 429:
                hint = "（レート制限または残高不足）"
            raise RuntimeError(f"クラウド API エラー {r.status_code}{hint}: {txt}")

    async def test(self) -> str:
        """接続テスト: 短い応答を返す。"""
        return await self.ask("You are a connectivity test. Reply with exactly: OK", "ping", max_tokens=16)


ASK_SYSTEM = """You are a senior software engineer acting as an escalation point for a local coding agent that is stuck.
The agent cannot see you and will implement your advice itself, so be concrete and verifiable.
Reply in Japanese. Structure:
1. 原因の仮説（確度の高い順に最大 3 つ。それぞれ根拠を 1 行）
2. 確認方法（各仮説を確かめるコマンドやコード）
3. 修正案（unified diff またはコード断片。ファイルパスを明示）
4. それでも直らない場合の次の一手
Do not restate the problem. Do not pad. If information is missing, say exactly what to gather."""


def build_prompt(goal: str, error: str, tried: str, code: str, question: str, env: str) -> str:
    parts = [f"## 目的\n{goal.strip()}"]
    if env:
        parts.append(f"## 環境\n{env.strip()}")
    if error:
        parts.append(f"## エラー / 症状\n```\n{error.strip()[:6000]}\n```")
    if tried:
        parts.append(f"## 試したことと結果\n{tried.strip()[:3000]}")
    if code:
        parts.append(f"## 関連コード（抜粋）\n{code[:20000]}")
    if question:
        parts.append(f"## 質問\n{question.strip()[:1000]}")
    return "\n\n".join(parts)
