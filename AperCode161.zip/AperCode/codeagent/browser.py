"""ブラウザ操作（Playwright）v1.4.0。

LLM が Web ページ／自分で作った Web アプリを実際に開いて確認するためのブラウザ。
  - browser.mode: headed（ウィンドウを表示。ユーザーが操作を見られる）/ headless
  - browser.channel: chromium（Playwright 同梱）| chrome | msedge | firefox（PC にインストール済みのもの）
  - browser.cdp_url: 起動済みの Chrome に接続する場合（例: http://127.0.0.1:9222。chrome --remote-debugging-port=9222）
1 サーバーにつき 1 ブラウザ・1 ページを保持し、ツール呼び出しをまたいで状態（ログイン等）を引き継ぐ。
Playwright が無い環境ではツール自体を隠す（is_available）。
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from pathlib import Path
from typing import Any


def is_available() -> bool:
    try:
        import playwright  # noqa: F401
        return True
    except ImportError:
        return False


INSTALL_HINT = "pip install playwright && python -m playwright install chromium"


class Browser:
    def __init__(self, cfg):
        self.cfg = cfg
        self._pw = None
        self._browser = None
        self._context = None
        self._page = None
        self._console: list[dict] = []
        self._errors: list[str] = []
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------ 起動 / 終了
    async def page(self):
        async with self._lock:
            if self._page is not None and not self._page.is_closed():
                return self._page
            await self._launch()
            return self._page

    async def _launch(self):
        from playwright.async_api import async_playwright
        if self._pw is None:
            self._pw = await async_playwright().start()
        mode = str(self.cfg.get("browser.mode", "headed")).lower()
        channel = str(self.cfg.get("browser.channel", "chromium")).lower()
        cdp = str(self.cfg.get("browser.cdp_url", "") or "")
        vw, vh = [int(x) for x in str(self.cfg.get("browser.viewport", "1280x800")).lower().split("x")]
        if cdp:
            self._browser = await self._pw.chromium.connect_over_cdp(cdp)
            self._context = self._browser.contexts[0] if self._browser.contexts else await self._browser.new_context()
        else:
            kw: dict[str, Any] = {"headless": mode != "headed"}
            if channel == "firefox":
                self._browser = await self._pw.firefox.launch(**kw)
            else:
                if channel in ("chrome", "msedge", "chrome-beta", "msedge-beta"):
                    kw["channel"] = channel
                self._browser = await self._pw.chromium.launch(**kw)
            self._context = await self._browser.new_context(viewport={"width": vw, "height": vh},
                                                            locale=str(self.cfg.get("browser.locale", "ja-JP")))
        self._context.set_default_timeout(float(self.cfg.get("browser.timeout", 20)) * 1000)
        self._page = await self._context.new_page()
        self._console.clear()
        self._errors.clear()
        self._page.on("console", lambda m: self._console.append({"type": m.type, "text": m.text[:500], "ts": time.time()}))
        self._page.on("pageerror", lambda e: self._errors.append(str(e)[:800]))

    async def close(self):
        async with self._lock:
            try:
                if self._context is not None and not self.cfg.get("browser.cdp_url"):
                    await self._context.close()
                if self._browser is not None and not self.cfg.get("browser.cdp_url"):
                    await self._browser.close()
            except Exception:  # noqa: BLE001
                pass
            self._page = self._context = self._browser = None
            if self._pw is not None:
                try:
                    await self._pw.stop()
                except Exception:  # noqa: BLE001
                    pass
                self._pw = None

    # ------------------------------------------------------------ 操作
    async def goto(self, url: str, wait: str = "load") -> dict:
        p = await self.page()
        self._console.clear()
        self._errors.clear()
        resp = await p.goto(url, wait_until=wait if wait in ("load", "domcontentloaded", "networkidle", "commit") else "load")
        await p.wait_for_timeout(300)
        return {"status": resp.status if resp else None, "url": p.url, "title": await p.title()}

    async def text(self, max_chars: int = 8000) -> str:
        p = await self.page()
        t = await p.evaluate("""() => {
            const skip = new Set(['SCRIPT','STYLE','NOSCRIPT','SVG','TEMPLATE']);
            function walk(n, out){
              if(n.nodeType===3){const s=n.nodeValue.replace(/\\s+/g,' ').trim(); if(s) out.push(s); return;}
              if(n.nodeType!==1 || skip.has(n.tagName)) return;
              const st = getComputedStyle(n); if(st.display==='none'||st.visibility==='hidden') return;
              if(/^(P|DIV|LI|TR|H[1-6]|SECTION|ARTICLE|PRE|BR|TD|TH|BUTTON|LABEL)$/.test(n.tagName)) out.push('\\n');
              for(const c of n.childNodes) walk(c, out);
            }
            const out=[]; walk(document.body, out);
            return out.join(' ').replace(/[ \\t]+\\n/g,'\\n').replace(/\\n{3,}/g,'\\n\\n').trim();
        }""")
        return t[:max_chars] + (f"\n... (省略: 全 {len(t):,} 文字)" if len(t) > max_chars else "")

    async def elements(self, limit: int = 80) -> list[dict]:
        """クリック・入力できる要素の一覧（番号付き）。"""
        p = await self.page()
        items = await p.evaluate("""(limit) => {
            const sel = 'a[href],button,input,select,textarea,[role=button],[role=link],[onclick],[contenteditable=true]';
            const out=[]; let i=0;
            for (const el of document.querySelectorAll(sel)) {
              const r = el.getBoundingClientRect(); if (r.width===0 || r.height===0) continue;
              const st = getComputedStyle(el); if (st.display==='none'||st.visibility==='hidden') continue;
              const label = (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('name') || el.id || '').replace(/\\s+/g,' ').trim().slice(0,80);
              el.setAttribute('data-apercode-idx', String(i));
              out.push({idx:i, tag:el.tagName.toLowerCase(), type:el.getAttribute('type')||'', label, href:(el.getAttribute('href')||'').slice(0,120), id: el.id||''});
              if (++i >= limit) break;
            }
            return out;
        }""", limit)
        return items

    async def _locator(self, target: str):
        p = await self.page()
        target = str(target).strip()
        if re.fullmatch(r"\d+", target):
            return p.locator(f"[data-apercode-idx='{target}']").first
        if target.startswith(("css=", "#", ".", "//", "xpath=")) or "[" in target or ">" in target:
            return p.locator(target.replace("css=", "", 1)).first
        # テキスト一致（ボタン・リンク・ラベル）
        loc = p.get_by_role("button", name=target)
        if await loc.count():
            return loc.first
        loc = p.get_by_role("link", name=target)
        if await loc.count():
            return loc.first
        loc = p.get_by_text(target, exact=False)
        if await loc.count():
            return loc.first
        return p.locator(target).first

    async def click(self, target: str) -> str:
        loc = await self._locator(target)
        await loc.click()
        p = await self.page()
        await p.wait_for_timeout(500)
        return f"clicked {target!r} → {p.url}"

    async def type(self, target: str, text: str, submit: bool = False) -> str:
        loc = await self._locator(target)
        await loc.fill(text)
        if submit:
            await loc.press("Enter")
            p = await self.page()
            await p.wait_for_timeout(500)
        return f"typed into {target!r}" + (" and pressed Enter" if submit else "")

    async def press(self, key: str) -> str:
        p = await self.page()
        await p.keyboard.press(key)
        await p.wait_for_timeout(300)
        return f"pressed {key}"

    async def scroll(self, direction: str = "down", amount: int = 600) -> str:
        p = await self.page()
        dy = amount if direction == "down" else -amount
        await p.mouse.wheel(0, dy)
        await p.wait_for_timeout(200)
        return f"scrolled {direction}"

    async def evaluate(self, js: str) -> str:
        p = await self.page()
        try:
            res = await p.evaluate(js)
        except Exception as e:  # noqa: BLE001
            return f"JS error: {e}"
        try:
            s = json.dumps(res, ensure_ascii=False, default=str)
        except Exception:  # noqa: BLE001
            s = str(res)
        return s[:8000]

    async def screenshot(self, path: Path, full_page: bool = False) -> Path:
        p = await self.page()
        path.parent.mkdir(parents=True, exist_ok=True)
        await p.screenshot(path=str(path), full_page=full_page)
        return path

    def console(self, kinds: tuple[str, ...] = ("error", "warning")) -> dict:
        msgs = [m for m in self._console if m["type"] in kinds]
        return {"console": msgs[-30:], "page_errors": self._errors[-20:], "total_console": len(self._console)}

    async def info(self) -> dict:
        p = await self.page()
        return {"url": p.url, "title": await p.title()}

    # ------------------------------------------------------------ 検証用（check_js）
    async def check_page(self, url: str | None, wait_ms: int = 1500, probes: list[str] | None = None,
                         html: str | None = None) -> dict:
        """別ページで開き、コンソールエラー・JS 例外・失敗したリクエスト・probe の評価結果を集めて閉じる。
        LLM が操作中のページには影響しない。"""
        await self.page()  # ブラウザ起動
        assert self._context is not None
        pg = await self._context.new_page()
        console: list[dict] = []
        errors: list[str] = []
        net: list[str] = []
        pg.on("console", lambda m: console.append({"type": m.type, "text": m.text[:500]}))
        pg.on("pageerror", lambda e: errors.append(str(e)[:800]))
        pg.on("requestfailed", lambda r: net.append(f"{r.method} {r.url[:200]} → 失敗: {r.failure or ''}"))
        pg.on("response", lambda r: net.append(f"{r.request.method} {r.url[:200]} → HTTP {r.status}") if r.status >= 400 else None)
        result: dict[str, Any] = {"url": url, "status": None, "title": ""}
        try:
            if html is not None:
                await pg.set_content(html, wait_until="load")
            elif url:
                resp = await pg.goto(url, wait_until="load")
                result["status"] = resp.status if resp else None
            await pg.wait_for_timeout(wait_ms)
            result["title"] = await pg.title()
            result["url"] = pg.url if url else None
            out_probes: list[dict] = []
            for expr in probes or []:
                try:
                    r = await pg.evaluate("""(expr) => { try { const v = (0, eval)(expr);
                        if (typeof v === 'function') return {type: 'function', preview: String(v).slice(0, 300)};
                        if (v && typeof v === 'object') { let s; try { s = JSON.stringify(v); } catch (e) { s = Object.prototype.toString.call(v); }
                          return {type: Array.isArray(v) ? 'array' : 'object', ctor: v.constructor && v.constructor.name, value: String(s).slice(0, 500),
                                  keys: Object.keys(v).slice(0, 40)}; }
                        return {type: typeof v, value: String(v).slice(0, 500)}; } catch (e) { return {error: String(e)}; } }""", expr)
                except Exception as e:  # noqa: BLE001
                    r = {"error": str(e)[:300]}
                out_probes.append({"expr": expr, **r})
            result["probes"] = out_probes
        finally:
            try:
                await pg.close()
            except Exception:  # noqa: BLE001
                pass
        result["console"] = [m for m in console if m["type"] in ("error", "warning")]
        result["page_errors"] = errors
        result["network_errors"] = net
        return result
