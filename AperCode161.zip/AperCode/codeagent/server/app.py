"""FastAPI サーバー: REST（セッション管理）+ WebSocket（チャット）"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from .. import __version__
from ..agent import Agent
from ..config import Config, expand
from .. import browser as B
from ..llm import LLMClient
from ..session import Session, SessionStore
from ..vram import estimate_num_ctx
from ..cloud import PROVIDERS, CloudSettings, CloudClient
from ..config import USER_CONFIG_PATH
from .. import i18n
from ..i18n import t

STATIC = Path(__file__).parent / "static"


class NewSession(BaseModel):
    project_dir: str | None = None
    create: bool = False          # True なら存在しないディレクトリを作成する


class PathIn(BaseModel):
    path: str


class BrowserOpen(BaseModel):
    url: str = ""


class SetModel(BaseModel):
    model: str | None = None          # メインモデル
    sub_model: str | None = None      # サブエージェント／レビュー用（"" でメインと同じ）


class SettingsIn(BaseModel):
    language: str | None = None        # auto | ja | en
    prompt_language: str | None = None # auto | ja | en
    values: dict | None = None         # v1.6.0: 設定画面の値（ドット区切りキー → 値）
    reset: list[str] | None = None     # v1.6.0: ユーザー設定から消して既定に戻すキー


# 設定画面（v1.6.0）で変更できるキーと型・許容値。ここに無いキーは受け付けない
SETTING_KEYS: dict[str, tuple] = {
    "llm.temperature": ("float", 0.0, 2.0),
    "llm.num_ctx": ("int", 2048, 1_000_000),
    "llm.auto_ctx.enabled": ("bool",),
    "llm.auto_ctx.kv_cache_type": ("enum", "f16", "q8_0", "q4_0"),
    "llm.auto_ctx.reserve_mb": ("int", 0, 65536),
    "llm.num_predict": ("int", 0, 1_000_000),
    "llm.think": ("enum", "auto", "on", "off"),
    "llm.keep_alive": ("str",),
    "llm.timeout": ("int", 30, 86400),
    "llm.tool_mode": ("enum", "native", "json"),
    "llm.max_iterations": ("int", 5, 1000),
    "compaction.threshold": ("float", 0.3, 0.95),
    "compaction.keep_recent": ("int", 2, 100),
    "compaction.background": ("bool",),
    "compaction.prepare_ratio": ("float", 0.3, 0.95),
    "compaction.bg_device": ("enum", "auto", "gpu", "cpu"),
    "memory.reflect_with_sub": ("bool",),
    "stuck.repeat_calls": ("int", 2, 20),
    "stuck.consecutive_errors": ("int", 2, 20),
    "stuck.no_progress_calls": ("int", 0, 100),
    "cloud.require_failures": ("int", 0, 20),
    "cloud.max_per_turn": ("int", 0, 20),
    "verify.enabled": ("bool",),
    "verify.max_fix_rounds": ("int", 0, 10),
    "verify.review.enabled": ("bool",),
    "verify.review.min_changed_lines": ("int", 0, 100000),
    "subagents.enabled": ("bool",),
    "browser.mode": ("enum", "headed", "headless"),
    "browser.external_sites": ("enum", "ask", "allow", "deny"),
    "repl.timeout": ("int", 5, 3600),
}


SETTING_DEFAULTS: dict = {
    "llm.temperature": 0.2, "llm.num_ctx": 32768, "llm.auto_ctx.enabled": True, "llm.auto_ctx.kv_cache_type": "f16",
    "llm.auto_ctx.reserve_mb": 1024, "llm.num_predict": 0, "llm.think": "auto", "llm.keep_alive": "30m", "llm.timeout": 600,
    "llm.tool_mode": "native", "llm.max_iterations": 40, "compaction.threshold": 0.7, "compaction.keep_recent": 8,
    "compaction.background": True, "compaction.prepare_ratio": 0.75, "compaction.bg_device": "auto", "memory.reflect_with_sub": True,
    "stuck.repeat_calls": 3, "stuck.consecutive_errors": 3, "stuck.no_progress_calls": 12, "cloud.require_failures": 1,
    "cloud.max_per_turn": 2, "verify.enabled": True, "verify.max_fix_rounds": 3, "verify.review.enabled": True,
    "verify.review.min_changed_lines": 50, "subagents.enabled": True, "browser.mode": "headed", "browser.external_sites": "ask",
    "repl.timeout": 60,
}


def _coerce(key: str, v):
    spec = SETTING_KEYS[key]
    kind = spec[0]
    if kind == "bool":
        return bool(v) if not isinstance(v, str) else v.lower() in ("1", "true", "on", "yes")
    if kind == "int":
        n = int(float(v))
        return max(spec[1], min(spec[2], n))
    if kind == "float":
        f = float(v)
        return max(spec[1], min(spec[2], f))
    if kind == "enum":
        return v if v in spec[1:] else spec[1]
    return str(v)


class CloudIn(BaseModel):
    enabled: bool | None = None
    provider: str | None = None
    model: str | None = None
    api_key: str | None = None        # "" で消去、None で変更なし
    base_url: str | None = None


class MemoryIn(BaseModel):
    lesson: str
    situation: str = ""
    action: str = ""
    outcome: str = "info"
    tags: list[str] = []
    project: str = ""
    verified: int = 0


class MemoryPatch(BaseModel):
    lesson: str | None = None
    situation: str | None = None
    action: str | None = None
    outcome: str | None = None
    tags: list[str] | None = None
    project: str | None = None
    verified: int | None = None


def create_app(cfg: Config) -> FastAPI:
    app = FastAPI(title="AperCode", version=__version__)
    i18n.set_language(str(cfg.get("ui.language", "auto")))
    from ..prompts import set_prompt_language
    set_prompt_language(str(cfg.get("llm.prompt_language", "auto")))
    llm = LLMClient(cfg)
    store = SessionStore(cfg.sessions_dir)
    agent = Agent(cfg, llm, store)
    running: dict[str, asyncio.Task] = {}
    # UI で選んだメインモデルを記憶しておく（config.yaml より優先。state.json の model を消せば config に戻る）
    _saved_model = cfg.state().get("model")
    if _saved_model and _saved_model != llm.model:
        print("AperCode: " + t(f"モデル {_saved_model} を使用（前回 UI で選択。config.yaml の値に戻すには ~/.apercode/state.json の model を削除）"))
        llm.model = _saved_model
    ctx_info: dict = {"num_ctx": llm.num_ctx, "reason": t("設定値"), "auto": False}

    def apply_auto_ctx():
        """VRAM の空きからコンテキストサイズを決めて llm.num_ctx に反映する（config の auto_ctx.enabled のとき）。"""
        nonlocal ctx_info
        if not cfg.get("llm.auto_ctx.enabled", True) or llm.provider != "ollama":
            ctx_info = {"num_ctx": llm.num_ctx, "reason": t("設定値（自動調整オフ）"), "auto": False}
            return
        est = estimate_num_ctx(llm.base_url, llm.model, int(cfg.get("llm.num_ctx", 32768)),
                               min_ctx=int(cfg.get("llm.auto_ctx.min", 8192)),
                               max_ctx=int(cfg.get("llm.auto_ctx.max", 0)) or None,
                               reserve_mb=int(cfg.get("llm.auto_ctx.reserve_mb", 1024)),
                               kv_cache_type=str(cfg.get("llm.auto_ctx.kv_cache_type", "f16")),
                               ram_offload_ratio=float(cfg.get("llm.auto_ctx.ram_offload_ratio", 0.0)))
        llm.num_ctx = est.num_ctx
        ctx_info = {**est.to_dict(), "reason": t(est.reason), "auto": True}
        print(f"AperCode: num_ctx={est.num_ctx:,} ({t(est.reason)})")

    @app.on_event("startup")
    async def _startup():
        await asyncio.get_event_loop().run_in_executor(None, apply_auto_ctx)

    @app.get("/")
    async def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/config")
    async def get_config():
        return {"version": __version__, "model": llm.model, "sub_model": agent.sub_model or "",
                "language": i18n.get_language(), "language_setting": str(cfg.get("ui.language", "auto")),
                "prompt_language": str(cfg.get("llm.prompt_language", "auto")),
                "provider": llm.provider, "tool_mode": llm.tool_mode,
                "num_ctx": llm.num_ctx, "ctx_info": ctx_info,
                "workspace": str(cfg.workspace_root), "default_project": str(cfg.default_project),
                "recent_projects": [r for r in cfg.state().get("recent_projects", []) if Path(r).is_dir()],
                "permissions": cfg.get("permissions", {})}

    @app.post("/api/shutdown")
    async def shutdown_server():
        """ローカルからのみ: 古いサーバープロセスを終了させる（app.py がバージョン不一致時に使う）。"""
        import os, signal, asyncio as _a
        loop = _a.get_event_loop()
        loop.call_later(0.3, lambda: os.kill(os.getpid(), signal.SIGTERM))
        return {"ok": True, "version": __version__}

    @app.get("/api/models")
    async def models():
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.get(f"{llm.base_url}/api/tags")
                return {"models": [m["name"] for m in r.json().get("models", [])]}
        except Exception as e:
            return {"models": [], "error": str(e)}

    @app.post("/api/model")
    async def set_model(body: SetModel):
        st = cfg.state()
        if body.model is not None and body.model != llm.model:
            llm.model = body.model
            st["model"] = body.model
            cfg.save_state(st)
            await asyncio.get_event_loop().run_in_executor(None, apply_auto_ctx)
        if body.sub_model is not None:
            agent.sub_model = body.sub_model.strip() or None
            st["sub_model"] = agent.sub_model or ""
            cfg.save_state(st)
        return {"model": llm.model, "sub_model": agent.sub_model or "", "num_ctx": llm.num_ctx, "ctx_info": ctx_info}

    @app.post("/api/ctx/recalc")
    async def ctx_recalc():
        await asyncio.get_event_loop().run_in_executor(None, apply_auto_ctx)
        return {"num_ctx": llm.num_ctx, "ctx_info": ctx_info}

    # ---------------------------------------------------------------- 表示言語（v1.3.0）
    def _save_user_cfg(section: str, values: dict) -> None:
        import yaml
        user: dict = {}
        if USER_CONFIG_PATH.exists():
            try:
                user = yaml.safe_load(USER_CONFIG_PATH.read_text(encoding="utf-8")) or {}
            except Exception:  # noqa: BLE001
                user = {}
        cur = dict(user.get(section) or {})
        cur.update(values)
        user[section] = cur
        USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        USER_CONFIG_PATH.write_text(yaml.safe_dump(user, allow_unicode=True, sort_keys=False), encoding="utf-8")
        cfg.data[section] = {**(cfg.data.get(section) or {}), **cur}

    def _user_cfg_read() -> dict:
        import yaml
        if USER_CONFIG_PATH.exists():
            try:
                return yaml.safe_load(USER_CONFIG_PATH.read_text(encoding="utf-8")) or {}
            except Exception:  # noqa: BLE001
                return {}
        return {}

    def _user_cfg_write(user: dict) -> None:
        import yaml
        USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        USER_CONFIG_PATH.write_text(yaml.safe_dump(user, allow_unicode=True, sort_keys=False), encoding="utf-8")

    def _reload_cfg() -> None:
        """config.yaml（基本）＋ ~/.apercode/config.yaml（ユーザー上書き）を読み直して cfg.data を差し替える。"""
        from ..config import _deep_merge
        base = Config.load(cfg.path).data
        cfg.data = _deep_merge(base, _user_cfg_read())

    def _settings_view() -> dict:
        user = _user_cfg_read()

        def _in_user(key: str) -> bool:
            cur = user
            for part in key.split("."):
                if not isinstance(cur, dict) or part not in cur:
                    return False
                cur = cur[part]
            return True
        return {"values": {k: (cfg.get(k) if cfg.get(k) is not None else SETTING_DEFAULTS.get(k)) for k in SETTING_KEYS},
                "overridden": [k for k in SETTING_KEYS if _in_user(k)],
                "num_ctx_effective": llm.num_ctx, "ctx_info": ctx_info, "user_config": str(USER_CONFIG_PATH)}

    @app.get("/api/settings")
    async def get_settings():
        return _settings_view()

    @app.post("/api/settings")
    async def set_settings(body: SettingsIn):
        if body.values or body.reset:
            user = _user_cfg_read()
            for k in (body.reset or []):
                if k in SETTING_KEYS:
                    parts = k.split(".")
                    cur = user
                    for part in parts[:-1]:
                        cur = cur.get(part) if isinstance(cur, dict) else None
                        if cur is None:
                            break
                    if isinstance(cur, dict):
                        cur.pop(parts[-1], None)
            for k, v in (body.values or {}).items():
                if k not in SETTING_KEYS:
                    continue
                try:
                    v = _coerce(k, v)
                except (TypeError, ValueError):
                    continue
                parts = k.split(".")
                cur = user
                for part in parts[:-1]:
                    if not isinstance(cur.get(part), dict):
                        cur[part] = {}
                    cur = cur[part]
                cur[parts[-1]] = v
            _user_cfg_write(user)
            _reload_cfg()
            llm.apply_settings()
            i18n.set_language(str(cfg.get("ui.language", "auto")))
            # num_ctx: 自動調整が有効なら計算し直し、無効なら設定値をそのまま使う
            if cfg.get("llm.auto_ctx.enabled", True):
                apply_auto_ctx()
            else:
                llm.num_ctx = int(cfg.get("llm.num_ctx", 32768))
                apply_auto_ctx()
            return _settings_view()
        if body.language is not None:
            v = body.language if body.language in ("auto", "ja", "en") else "auto"
            _save_user_cfg("ui", {"language": v})
            i18n.set_language(v)
        if body.prompt_language is not None:
            v = body.prompt_language if body.prompt_language in ("auto", "ja", "en") else "auto"
            _save_user_cfg("llm", {"prompt_language": v})
            set_prompt_language(v)
        return {"language": i18n.get_language(), "language_setting": str(cfg.get("ui.language", "auto")),
                "prompt_language": str(cfg.get("llm.prompt_language", "auto"))}

    # ---------------------------------------------------------------- クラウド相談（v1.2.4）
    def _cloud_view() -> dict:
        s = CloudSettings.from_cfg(cfg)
        key = s.api_key
        return {"enabled": bool(cfg.get("cloud.enabled", False)), "provider": s.provider, "model": s.model,
                "base_url": str(cfg.get("cloud.base_url", "") or ""),
                "api_key_set": bool(key), "api_key_hint": (key[:4] + "…" + key[-4:]) if len(key) > 10 else ("設定済み" if key else ""),
                "api_key_from_env": bool(key) and not bool(cfg.get("cloud.api_key")),
                "ready": s.ready, "providers": {k: {"label": v["label"], "models": v["models"], "env": v["env"],
                                                    "base_url": v["base_url"]} for k, v in PROVIDERS.items()},
                "require_failures": int(cfg.get("cloud.require_failures", 1)), "max_per_turn": int(cfg.get("cloud.max_per_turn", 2))}

    # ---- ブラウザ（v1.4.1）: 画面のボタンから起動。LLM と同じブラウザを共有する
    @app.get("/api/browser")
    async def browser_get():
        b = getattr(agent, "browser", None)
        st = cfg.state()
        return {"available": b is not None, "open": bool(b and b._page is not None and not b._page.is_closed()),
                "url": (b._page.url if b and b._page is not None and not b._page.is_closed() else ""),
                "last_url": st.get("browser_url", "http://localhost:8000"),
                "mode": str(cfg.get("browser.mode", "headed")), "hint": B.INSTALL_HINT}

    @app.post("/api/browser/open")
    async def browser_open(body: BrowserOpen):
        b = getattr(agent, "browser", None)
        if b is None:
            return {"ok": False, "error": t("ブラウザ機能は無効か、Playwright が入っていません（{h} を実行し、config の browser.enabled を true に）").replace("{h}", B.INSTALL_HINT)}
        url = body.url.strip() or "about:blank"
        if url != "about:blank" and "://" not in url:
            url = "http://" + url
        try:
            info = await b.goto(url) if url != "about:blank" else (await b.page(), {"url": url, "title": ""})[1]
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": t(f"ページを開けませんでした: {e}")}
        st = cfg.state()
        st["browser_url"] = body.url.strip() or st.get("browser_url", "")
        cfg.save_state(st)
        return {"ok": True, "url": info["url"], "title": info.get("title", "")}

    @app.post("/api/browser/close")
    async def browser_close():
        b = getattr(agent, "browser", None)
        if b is not None:
            await b.close()
        return {"ok": True}

    @app.get("/api/cloud")
    async def cloud_get():
        return _cloud_view()

    @app.post("/api/cloud")
    async def cloud_set(body: CloudIn):
        """~/.apercode/config.yaml の cloud: に保存し、メモリ上の設定も更新する。"""
        import yaml
        user: dict = {}
        if USER_CONFIG_PATH.exists():
            try:
                user = yaml.safe_load(USER_CONFIG_PATH.read_text(encoding="utf-8")) or {}
            except Exception:  # noqa: BLE001
                user = {}
        cur = dict(user.get("cloud") or {})
        for k in ("enabled", "provider", "model", "api_key", "base_url"):
            v = getattr(body, k)
            if v is not None:
                cur[k] = v
        user["cloud"] = cur
        USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        USER_CONFIG_PATH.write_text(yaml.safe_dump(user, allow_unicode=True, sort_keys=False), encoding="utf-8")
        try:
            USER_CONFIG_PATH.chmod(0o600)   # API キーを含むので本人のみ読める
        except OSError:
            pass
        cfg.data["cloud"] = {**(cfg.data.get("cloud") or {}), **cur}
        return _cloud_view()

    @app.post("/api/cloud/test")
    async def cloud_test():
        s = CloudSettings.from_cfg(cfg)
        if not s.ready:
            raise HTTPException(400, t("設定が不完全です（プロバイダ・モデル・API キー）"))
        try:
            out = await CloudClient(s).test()
        except Exception as e:  # noqa: BLE001
            raise HTTPException(400, str(e))
        return {"ok": True, "reply": out[:200], "target": s.describe()}

    @app.get("/api/sessions")
    async def list_sessions():
        return store.list()

    @app.post("/api/sessions")
    async def new_session(body: NewSession):
        pdir = expand(body.project_dir) if body.project_dir else cfg.default_project
        if not cfg.in_workspace(pdir):
            raise HTTPException(400, t(f"ワークスペース外です: {pdir}\n（許可範囲: {cfg.workspace_root}。config.yaml の workspace.root で変更できます）"))
        if pdir.exists() and not pdir.is_dir():
            raise HTTPException(400, t(f"ディレクトリではありません: {pdir}"))
        if not pdir.exists():
            if not body.create:
                # UI 側で「作成しますか？」を出すための応答
                return JSONResponse(status_code=404, content={"code": "not_found", "path": str(pdir),
                                                              "detail": t(f"ディレクトリがありません: {pdir}")})
            try:
                pdir.mkdir(parents=True)
            except OSError as e:
                raise HTTPException(400, t(f"作成できません: {e}"))
        cfg.remember_project(pdir)
        s = Session.new(str(pdir))
        store.save(s)
        return s.summary()

    # ---------------------------------------------------------------- ディレクトリ選択
    @app.get("/api/fs/list")
    async def fs_list(path: str = ""):
        """ワークスペース内のディレクトリ一覧（ディレクトリ選択ダイアログ用）。"""
        p = expand(path) if path else cfg.default_project
        if not cfg.in_workspace(p):
            p = cfg.workspace_root
        while not p.is_dir() and p != p.parent:
            p = p.parent
        dirs = []
        try:
            for c in sorted(p.iterdir(), key=lambda c: c.name.lower()):
                if c.is_dir() and not c.name.startswith(".") and c.name not in ("node_modules", "__pycache__"):
                    dirs.append(c.name)
        except PermissionError:
            pass
        root = cfg.workspace_root
        parent = str(p.parent) if p != root and root in p.parents else None
        return {"path": str(p), "parent": parent, "dirs": dirs, "root": str(root), "home": str(Path.home()),
                "recent": [r for r in cfg.state().get("recent_projects", []) if Path(r).is_dir()]}

    @app.post("/api/fs/mkdir")
    async def fs_mkdir(body: PathIn):
        p = expand(body.path)
        if not cfg.in_workspace(p):
            raise HTTPException(400, t(f"ワークスペース外です: {p}"))
        try:
            p.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise HTTPException(400, t(f"作成できません: {e}"))
        return {"path": str(p)}

    @app.get("/api/sessions/{sid}")
    async def get_session(sid: str):
        s = store.load(sid)
        if not s:
            raise HTTPException(404)
        return {"summary": s.summary(), "messages": s.messages, "usage": s.usage,
                "context": {"estimated_tokens": max(agent._estimate_tokens(s.messages), s.last_prompt_tokens),
                            "num_ctx": llm.num_ctx, "messages": len(s.messages)}}

    @app.get("/api/sessions/{sid}/files/{name}")
    async def session_file(sid: str, name: str):
        p = (store.root / f"{sid}_files" / Path(name).name)
        if not p.is_file():
            raise HTTPException(404)
        return FileResponse(p)

    @app.delete("/api/sessions/{sid}")
    async def delete_session(sid: str):
        store.delete(sid)
        return {"ok": True}

    # ---------------------------------------------------------------- 経験メモリ
    def _mem():
        if agent.memory is None:
            raise HTTPException(400, t("経験メモリは無効です (config.yaml memory.enabled)"))
        return agent.memory

    @app.get("/api/memory")
    async def memory_list(q: str = "", limit: int = 100, outcome: str | None = None, verified: int | None = None):
        mem = _mem()
        if q.strip():
            items = await mem.search(q, limit=limit, min_score=0.0)
        else:
            items = mem.list(limit=limit, outcome=outcome or None, verified=verified)
        return {"items": [m.to_dict() for m in items], "count": mem.count(), "tags": mem.all_tags()[:40],
                "embed_model": mem.embedder.model, "embed_available": mem.embedder.available}

    @app.post("/api/memory")
    async def memory_add(body: MemoryIn):
        mem = _mem()
        m, dup = await mem.add(lesson=body.lesson, situation=body.situation, action=body.action,
                               outcome=body.outcome, tags=body.tags, project=body.project, source="manual",
                               verified=body.verified, dedup_threshold=float(cfg.get("memory.dedup_threshold", 0.92)))
        if dup:
            raise HTTPException(409, f"類似のメモリが既にあります (#{dup.id}): {dup.lesson}")
        return m.to_dict()

    @app.patch("/api/memory/{mid}")
    async def memory_update(mid: int, body: MemoryPatch):
        m = await _mem().update(mid, **body.model_dump())
        if not m:
            raise HTTPException(404)
        return m.to_dict()

    @app.delete("/api/memory/{mid}")
    async def memory_delete(mid: int):
        return {"ok": _mem().delete(mid)}

    @app.post("/api/memory/reindex")
    async def memory_reindex():
        n = await _mem().reindex()
        return {"reindexed": n, "embed_available": _mem().embedder.available}

    @app.websocket("/ws/{sid}")
    async def ws(websocket: WebSocket, sid: str):
        await websocket.accept()
        session = store.load(sid)
        if not session:
            await websocket.send_json({"type": "error", "text": t("セッションがありません")})
            await websocket.close()
            return
        pending: dict[str, asyncio.Future] = {}
        send_lock = asyncio.Lock()

        _TX = ("text", "detail", "reason", "always_label", "task", "caption")

        def _translate(ev: dict) -> dict:
            if i18n.get_language() == "ja":
                return ev
            ev = dict(ev)
            for k in _TX:
                if isinstance(ev.get(k), str):
                    ev[k] = t(ev[k])
            if ev.get("type") == "sub" and isinstance(ev.get("event"), dict):
                ev["event"] = _translate(ev["event"])
            return ev

        async def emit(ev: dict):
            try:
                payload = _translate(ev)
            except Exception:  # noqa: BLE001  翻訳の失敗は送信を止めない
                import traceback
                traceback.print_exc()
                payload = ev
            try:
                async with send_lock:
                    await websocket.send_json(payload)
            except Exception:
                # クライアント切断後の送信。処理を止めて静かに無視する（次の接続で履歴から復元される）
                agent.cancel(sid)

        async def ask_approval(req: dict) -> str:
            fut: asyncio.Future = asyncio.get_event_loop().create_future()
            pending[req["id"]] = fut
            await emit({"type": "approval_request", **req})
            try:
                return await fut
            finally:
                pending.pop(req["id"], None)

        try:
            while True:
                raw = await websocket.receive_text()
                msg = json.loads(raw)
                mtype = msg.get("type")
                if mtype == "user":
                    if sid in running and not running[sid].done():
                        await emit({"type": "error", "text": t("前の処理が実行中です")})
                        continue
                    session = store.load(sid) or session

                    async def _run(session=session, text=msg["text"], atts=msg.get("attachments") or []):
                        try:
                            await agent.run(session, text, emit, ask_approval, attachments=atts)
                        except Exception as e:  # noqa: BLE001
                            import traceback
                            traceback.print_exc()
                            await emit({"type": "error", "text": t(f"内部エラー: {e}")})
                    running[sid] = asyncio.create_task(_run())
                elif mtype == "approval":
                    fut = pending.get(msg["id"])
                    if fut and not fut.done():
                        fut.set_result(msg.get("decision", "deny"))
                elif mtype == "compact":
                    if sid in running and not running[sid].done():
                        await emit({"type": "error", "text": t("処理中は要約できません")})
                        continue
                    session = store.load(sid) or session
                    running[sid] = asyncio.create_task(agent.compact_now(session, emit))
                elif mtype == "cancel":
                    agent.cancel(sid)
                    for fut in pending.values():
                        if not fut.done():
                            fut.set_result("deny")
        except WebSocketDisconnect:
            for fut in pending.values():
                if not fut.done():
                    fut.set_result("deny")

    @app.on_event("shutdown")
    async def shutdown():
        try:
            await agent.repls.close_all()
            await agent.procs.stop_all()
        except Exception:  # noqa: BLE001
            pass
        if getattr(agent, "browser", None) is not None:
            try:
                await agent.browser.close()
            except Exception:  # noqa: BLE001
                pass
        await llm.close()

    return app
