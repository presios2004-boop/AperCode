# Changelog

## 1.6.1 (2026-09-25)

- サブ LLM による背景要約: 履歴が圧縮開始（`compaction.threshold`）の 75%（`compaction.prepare_ratio`）に達した時点で、サブ LLM がバックグラウンドで古い履歴の要約を作り始める。メイン LLM はその間も作業を続け、圧縮が必要になった瞬間に準備済みの要約へ待ち時間なしで差し替える。準備が間に合わず `compaction.hard_ratio`（num_ctx の 90%）を超えたときだけ完了を待ち、失敗・タイムアウトならメイン LLM で従来どおり要約する
- サブ LLM の実行場所 `compaction.bg_device: auto | gpu | cpu`: auto は空き VRAM にサブ LLM（必要な num_ctx 分の KV を含む）が載るなら GPU、載らなければ CPU で動かし、メイン LLM を VRAM から追い出さない。num_ctx も要約に必要な分だけにする
- 教訓抽出（経験メモリ）もサブ LLM で実行（`memory.reflect_with_sub`）。メイン LLM を次の入力のために空けておく
- ヘッダーに「サブ: 要約準備中… / 要約準備済み」、チャットに紫色の進捗行を表示。設定画面に「バックグラウンド要約」「準備開始の割合」「サブ LLM の実行場所」「教訓抽出をサブ LLM で」を追加
- コンテキストの大半がシステムプロンプトとツール定義で埋まっていて圧縮しても減らない場合に、毎ステップ要約し続けていた問題を修正（1 回だけ「コンテキスト上限を増やしてください」と表示）
- サブ LLM 未設定（メインと同じ）の場合は背景要約は行わず、従来どおり（同じモデルへの同時リクエストはメインの応答を遅らせるため）

## 1.6.0 (2026-09-23)

- 設定画面: 画面左の「設定」から LLM パラメータ（思考モード `think`、生成トークン上限 `num_predict`、temperature、応答待ち秒数、keep_alive、tool_mode、ツール上限）、コンテキスト（自動調整・上限・KV 型・予備メモリ・圧縮）、行き詰まり検知のしきい値（同一呼び出し・連続エラー・進捗なし）、クラウド相談の条件、検証・レビュー・サブエージェント・ブラウザの設定を変更できる。`~/.apercode/config.yaml` に保存され、即時反映。「すべて既定に戻す」で `config.yaml` の値に戻る。`GET/POST /api/settings`
- 思考モード対応: Ollama の `thinking` をチャットに折りたたみ表示（🧠 思考 (n 文字)）。`llm.think: auto | on | off`、`llm.num_predict`、`llm.timeout` を追加
- 思考だけで終わって本文もツール呼び出しも無い応答は、結論かツール呼び出しを求めて差し戻す（最大 2 回）。「思考中に止まる」対策
- coder 系モデル対策: (1) 本文に JSON で書かれたツール呼び出し（```json / ```tool_call / <tool_call>）を native モードでも解析して実行 (2) コードブロックをチャットに書くだけでファイルに書いていない応答は、write_file / edit_file で書くよう差し戻す（1 回） (3) システムプロンプトに「コードは必ずファイルに書く」を追加
- 行き詰まり検知のしきい値を設定化: `stuck.repeat_calls`（既定 3）、`stuck.consecutive_errors`（既定 3）

## 1.5.1 (2026-09-23)

- チャットの色分け: メイン LLM の回答（青の左線）、サブ LLM の子エージェント / レビュー（紫の左線＋「サブ LLM · モデル名 · mode」バッジ。メインと同じモデルなら「メイン LLM」）、Web 検索（緑＋「🔍 Web 検索」）、クラウド相談（橙＋「☁ クラウド AI に相談 · プロバイダ / モデル」）。ログ上部に凡例
- 状態表示に「クラウド AI に相談中」「ブラウザ操作中」を追加（Web 検索・サブエージェント・クラウド相談は色付き）
- `subagent_start` イベントに `model` / `is_sub_model` を追加

## 1.5.0 (2026-09-23)

- `repl` ツール: 永続 Python / Node セッション。変数・import を引き継ぎ、最後の式の値を返す。プロジェクトの `.venv` を優先。タイムアウトで再起動。`run_command` と同じ扱い（既定 ask、危険コマンド検知あり）
- `process_start` / `process_status` / `process_logs` / `process_stop`: バックグラウンドプロセス管理。ログをファイルに記録、`port` の待ち受け確認、AperCode 終了時に一括停止
- `read_document` ツール: PDF / docx / xlsx / pptx / odt / ods / csv をテキスト化（docx・pptx・xlsx は依存なしで読める）
- `check_js` ツール: JavaScript / HTML の静的検査（構文、import/require と `<script src>` の解決）と、ブラウザでの実行検査（JS 例外・console.error・404）。`probes` でライブラリの初期化の形や要素の存在を確認、`libraries` で CDN のライブラリを実装前に検査
- 自動検証に `.html`（インライン script の構文、`<script src>` の存在）と `.js` の import 解決を追加
- システムプロンプト（日英）に補助ツールの使いどころを追加。Web アプリの確認は `process_start` → `browser_open` / `check_js` → `process_stop` の順に
- 進捗なし検知: `repl` / `process_start` / `check_js` の成功は進捗として数える
- 英語表示: 文の途中に埋め込まれたメッセージも翻訳されるように（`i18n.t` の改善）
- `config.yaml`: `repl.timeout`、`process.wait`、`documents.max_chars`、`permissions.repl` などを追加

## 1.4.1 (2026-09-23)

- 画面左に「ブラウザ」ボタンを追加: URL を入力して設定のブラウザ（`browser:`）を起動できる。LLM が browser_* ツールで使うブラウザと同じもので、開いたページを引き継いで確認に使える。ボタンの ● はブラウザ起動中の印。ダイアログから閉じることもでき、URL は `~/.apercode/state.json` に記憶される
- API: `GET /api/browser`、`POST /api/browser/open`、`POST /api/browser/close`

## 1.4.0 (2026-09-23)

- ブラウザ機能（Playwright、任意導入）: `browser_open` / `browser_read` / `browser_click` / `browser_type` / `browser_press` / `browser_scroll` / `browser_eval` / `browser_screenshot` / `browser_console` / `browser_close` を追加。LLM が自分で作った Web アプリやドキュメントを実際のブラウザで開き、コンソールのエラー・DOM の存在・見た目を確認できる。Playwright が無い環境ではツールは自動で隠れる
- スクリーンショットはチャットに表示（クリックで拡大）され、履歴にも残る。vision 対応モデルには画像として渡す
- `config.yaml` に `browser:` を追加（`mode: headed | headless`、`channel: chromium | chrome | msedge | firefox`、`cdp_url`、`viewport`、`timeout`、`locale`、`max_text_chars`、`external_sites`）。`localhost` 以外のサイトを開くときは承認（「常に許可」可）
- システムプロンプト（日英）に「Web アプリはサーバー起動 → browser_open → browser_eval で存在確認 → browser_screenshot で見た目確認 → 操作確認、の順で実機確認してから完了報告する」を追加
- `requirements.txt` に `playwright`（任意）を追加。導入後 `python -m playwright install chromium`

## 1.3.0 (2026-09-22)

- 表示言語の切り替え（日本語 / 英語）: `ui.language: auto | ja | en`（auto は OS の言語に合わせる。既定）。画面左下のプルダウンでも変更でき、`~/.apercode/config.yaml` に保存される
- 英語表示では、画面の文言、承認ダイアログ、検証結果、行き詰まりの差し戻し文、ツールの結果・エラー文、ツールの説明（LLM に渡すスキーマ）が英語になる。`codeagent/i18n.py` に日英辞書を集約（他言語の追加はこの辞書と `index.html` の `I18N_EN` に相当する辞書を足すだけ）
- システムプロンプトの英語版を追加。`llm.prompt_language: auto | ja | en`（auto は表示言語に合わせる）。英語プロンプトでも回答はユーザーの入力言語に合わせる指示付き
- 内部エラーがサーバーログに出るように（以前はターンが無言で終わっていた）

## 1.2.6 (2026-09-22)

- 進捗なし検知: ファイル変更・テスト・相談をせずに調査系ツールだけを `stuck.no_progress_calls`（既定 12）回続けたら、仮説と検証結果の整理・未確認の層（表示／初期化／ライブラリの呼び出し方／環境）の確認・ask_cloud を促す差し戻しを行う。行き詰まり回数に加算されるのでクラウド相談のしきい値に到達する
- `cloud.require_failures` の既定を 2 → 1 に変更（エラーが出ない不具合では失敗回数が積み上がらないため）
- システムプロンプト: 「エラーが出ないのに動かないときは、まず存在確認（DOM 要素・canvas・プロセス・ポート・ログ行）」「同じ仮説を 2 回否定されたら別の層を疑う」「ライブラリの初期化・呼び出し方はそのバージョンの README を読んで確認する」を追加

## 1.2.5 (2026-09-22)

- 圧縮時に LLM が落ちる問題: 要約リクエストに渡す文字数を `num_ctx` の 4 割程度に制限し、長い記録は分割して段階的に要約するように変更（以前は最大 80k 文字を一度に送っていた）
- 失敗・行き詰まり回数を次のターンに持ち越す（`session.stuck_carry`）: LLM エラーやテスト失敗のまま終わった場合、次の「続けて」でもクラウド相談の発動条件がリセットされない。解決すれば 0 に戻る
- LLM エラーも行き詰まり 1 回として数える
- `web_search` に `engine` 引数を追加（mdn / stackexchange / github / wikipedia / duckduckgo / bing / brave）。MDN Web Docs の検索エンジンを追加
- システムプロンプト: JavaScript / DOM / WebSocket / fetch / CSS / HTTP は記憶で書かずに MDN を検索して仕様を読んでから書く、ブラウザ JS の不具合はまず console.error / onerror / onclose の code で事実を集める、を追加

## 1.2.4 (2026-09-22)

- クラウド相談（`ask_cloud` ツール）: ローカル LLM が Web 検索でも解決できないとき、目的・エラー・試したこと・関連コードの抜粋だけをクラウド AI に送ってヒント（原因仮説・確認方法・修正案）を受け取る。実装と検証はローカル側
- 対応プロバイダ: Anthropic / Gemini / OpenAI / DeepSeek / Groq / Mistral / OpenRouter / xAI / OpenAI 互換（カスタム URL）。画面の「クラウド相談」からプロバイダ・モデル（プルダウンまたは手入力）・API キーを設定、接続テスト可。`~/.apercode/config.yaml` に保存（600）
- 安全弁: 失敗回数がしきい値（`cloud.require_failures`）に達するまで使えない、1 ターンの上限、送信前の承認、秘密情報のマスク、無効時はツールを LLM に見せない
- 行き詰まり検知・テスト失敗の差し戻し文とシステムプロンプトに ask_cloud の使い方を追加

## 1.2.3 (2026-09-22)

- チャットのコードブロックに言語ラベルと「コピー」ボタンを表示（クラウド AI のチャットと同様）。生成途中で閉じフェンスが無い間もブロックとして表示
- チャット欄の右クリックメニューを追加: 選択範囲をコピー / コードブロックをコピー / このメッセージをコピー
- システムプロンプトに「コードは言語名付きのコードフェンスで囲む」を追加
- ヘッダーの tokens in/out とコンテキスト使用量を、ターン完了時だけでなく LLM 呼び出しごとにリアルタイム更新

## 1.2.2 (2026-09-22)

- 画面でメインモデルとサブモデル（サブエージェント・コードレビュー用）を別々に選べるプルダウンを追加。ヘッダーに組み合わせを表示
- 選択したモデルは `~/.apercode/state.json` に記憶し、次回起動時に復元（config.yaml より優先。削除で config の値に戻る）
- `/api/model` が `sub_model` を受け付け、`/api/config` が `sub_model` を返す

## 1.2.1.1 (2026-09-21)

- Web 検索: DuckDuckGo が失敗（403・結果なし）した場合に Bing → Brave → Mojeek → Stack Exchange API → GitHub Issues API → Wikipedia API へ自動フォールバック。requirements.txt に `ddgs`（ブラウザ相当の TLS で 403 を回避）を追加。検索用にブラウザ UA を使用。失敗時のエラーにエンジンごとの理由を表示。`web.engines` で順序を変更可
- 画面: Web 検索中は「Web 検索中」、経験メモリ操作中は「経験メモリを操作中」と表示
- 専用ウィンドウ（pywebview）でチャット画面のテキストが選択・コピーできなかったのを修正（`text_select=True`）
- 画面: 経験メモリへの保存と履歴の圧縮は「何をしているか」だけを表示し、内容（教訓の本文・要約文）は表示しない。セッション再表示時の要約も 1 行に

## 1.2.1 (2026-09-21)

- テストの保護（assertion weakening 対策）: ターン内でテストが失敗した後は、既存テストファイルへの write_file / edit_file とテストパスを書き換えるシェルコマンドを「常時許可」の対象外にして毎回承認（`verify.lock_tests: ask`）、または拒否（`deny`）。新規テストの追加は許可
- テストが通った時点で、ターン開始時から変更・削除された既存テストを検出して検証結果に「⚠ 既存テスト変更」として表示
- テストが失敗したまま何も変更せずに完了報告しようとした場合は再実行せず差し戻す。差し戻し文で「通っていないのに PASS と報告しない」ことを明示
- システムプロンプトに「テスト失敗後はテストを書き換えない」を追加。`verify.test_patterns` で対象パターンを変更可

## 1.2.0 (2026-09-21)

- 生成コードの検証レイヤー（`verify.*`）
  - write_file / edit_file 直後の自動チェック（構文・lint・型。Python/JS/TS/Go/Rust/シェル/C/JSON/YAML。外部ツールは入っていれば使う）。NG は LLM に差し戻し
  - `run_tests` ツールと、完了報告前のテスト自動実行（pytest/unittest/npm test/go test/cargo test/make test を自動判定、`backup/` は除外）。失敗は差し戻し（上限 `max_fix_rounds`）。テストが無ければ作成を促す
  - 変更行数が閾値以上のとき、読み取り専用の子エージェントが diff をレビューし、high/medium の指摘を親に戻す（最大 `review.max_rounds` 回）
  - 画面に検証イベント（✓/✗）と完了時の「検証結果」サマリを表示。`verifying` ステータス追加
- システムプロンプトに「検証」節を追加。requirements.txt に `ruff` と `pytest` を追加

## 1.1.8 (2026-09-21)

- コンテキストサイズの自動調整: 起動時・モデル切替時に空き VRAM（無ければ RAM）とモデル構造から KV キャッシュに載るトークン数を見積もり、`llm.num_ctx` を上限に `num_ctx` を自動決定（`llm.auto_ctx.*`）。画面と `/api/config` に根拠を表示
- `/api/ctx/recalc` で再計算可能
- 複数 GPU 環境では全 GPU の空き VRAM を合算して見積もる（以前は 1 枚分のみ）

## 1.1.7 (2026-09-21)

- 教訓抽出（振り返り）を応答完了後のバックグラウンド処理に変更（タイムアウト付き、失敗しても会話に影響しない）。記録を 24k 文字に制限
- Ollama: チャットモデルの `keep_alive`（既定 30m）を送信、埋め込みは `keep_alive: 2m` + truncate で VRAM の奪い合いを軽減
- Ollama が一時的に応答しない場合の自動再試行（`llm.connect_retries`）。切断時のエラーメッセージを明確化

## 1.1.6 (2026-09-20)

- 行き詰まり検知: 同じツール呼び出しの 3 回以上の繰り返し、または 3 回連続の失敗を検知したら、Web 検索など別アプローチを促す指示を履歴に差し込む（1 ターン最大 3 回）
- ツール呼び出し上限到達時に黙って止まらず、状況報告（完了・未完了・問題・次の手順）を生成。「続けて」で再開可能

## 1.1.5 (2026-09-20)

- 「このセッションでは編集・実行を常に許可」: 一度押せばコード生成・編集・テスト実行（write_file / edit_file / run_command / mt5_* / make_icon）を確認なしで継続。セッションに保存され再起動後も有効
- 取り返しのつかない操作（rm, git reset --hard, sudo, dd, kill, drop table, pip uninstall, curl|sh, restore_backup など）は常時許可の対象外で毎回確認。`permissions.dangerous_commands` で調整可能

## 1.1.4 (2026-09-20)

- 作業ディレクトリの外に触れるツール呼び出し（絶対パス・`~/`・`../`・run_command 内の `cd` や絶対パス）は、読み取り専用ツールでもユーザーの承認を求めるように。`permissions.outside_project`（ask / allow / deny）を追加
- 承認ダイアログに理由（⚠ 作業ディレクトリの外へのアクセス: パス）を表示

## 1.1.3 (2026-09-20)

- 作業ディレクトリの取り違え対策: システムプロンプト先頭で現在の作業ディレクトリを明示し、経験メモリ由来の別プロジェクトのパスに従わないよう指示
- app.py: 起動時に既存サーバーのバージョンを確認し、古いサーバーが残っていれば停止して起動し直す（/api/shutdown を追加）
- 作業ディレクトリ欄を変更して送信すると自動で新しいセッションを開始。セッション未選択時の送信でも自動作成
- 経験メモリの自動注入を厳格化（類似度の正規化、閾値 0.40、上位 3 件、短い入力は対象外）。「参照した経験」を折りたたみ表示

## 1.1.2 (2026-09-20)

- 変更前ファイルの自動バックアップ: write_file / edit_file の直前に `backup/<日時>/` へ退避。list_backups / restore_backup ツール、保持日数による自動整理
- make_icon ツール / CLI（Pillow）: PNG 一式・.ico・.svg のアプリアイコン生成
- GTK 専用ウィンドウでモデル選択プルダウンが白く塗りつぶされる問題を修正（select を独自描画）
- 依存に pillow を追加

## 1.1.0 (2026-09-20)

- web_search / fetch_url ツール（DuckDuckGo / SearXNG）と「行き詰まったときの手順」をシステムプロンプトに追加
- save_memory に出典 URL を付けられるように。振り返りでも Web 由来の解決策に URL を含める
- 専用ウィンドウを GTK バックエンド優先に変更（OS の日本語入力が使える）。setup_linux_window.sh を追加
- IME 変換確定の Enter で送信されてしまう問題を修正
- ディレクトリ選択ダイアログ、存在しないディレクトリの作成確認

## 1.0.0 (2026-09-20)

初回リリース。

- Ollama（ローカル LLM）/ Anthropic API 対応のコーディングエージェント
- ツール: read_file / write_file / edit_file / list_dir / glob / grep / run_command
- MT5 (wine) 向けツール: mt5_compile / mt5_backtest
- Web UI（承認ダイアログ、ツール実行の可視化、状態表示、画像・テキスト添付、右クリックメニュー）
- コンテキスト自動圧縮（要約による置き換え）
- サブエージェント（explore / code モード）
- 経験メモリ（SQLite FTS5 + 埋め込みベクトルのハイブリッド検索、自動抽出、管理画面）
- デスクトップ起動（app.py / install_desktop.sh）
- 作業ディレクトリ選択ダイアログ、存在しない場合の作成確認
