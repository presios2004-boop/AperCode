"""v2.11.10 の回帰テスト: 今日の日付を LLM に伝え、依頼の相対的な日時（過去 5 年など）を具体的な日付にして指示書に書く。"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from codeagent import brief as BR

NOW = datetime(2026, 10, 8, 14, 30, tzinfo=timezone(timedelta(hours=9)))


def test_time_anchor_ranges():
    a = BR.time_anchor("過去5年の日銀会合の日程を調べ、直近1年間で BT。来月の FOMC と年末までに対応", NOW)
    assert "「過去5年」= 2021-10-08 〜 2026-10-08" in a and "「直近1年間」= 2025-10-08 〜 2026-10-08" in a
    assert "「来月」= 2026-11-01 〜 2026-11-30" in a and "「年末」= 2026-12-31" in a
    assert BR.time_anchor("過去五年", NOW) == ["「過去五年」= 2021-10-08 〜 2026-10-08"]
    assert BR.time_anchor("past 3 months", NOW) == ["「past 3 months」= 2026-07-08 〜 2026-10-08"]
    assert BR.time_anchor("会合前後3営業日の EA を作る", NOW) == []           # イベント基準の表現は対象外
    assert BR.time_anchor("calc.py を直して", NOW) == []


def test_brief_gets_date_anchor_and_prompt_has_today(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "了解しました")], proj, {"brief.clarify": "off"})
    h.run(agent, s, "過去5年の日銀会合の日程を公式サイトで調べて md にまとめてください")
    brief = BR.read(BR.path_for(proj, s.id))
    today = datetime.now().astimezone().date()
    assert "## 日時の基準" in brief and f"「過去5年」= {today.replace(year=today.year - 5).isoformat()} 〜 {today.isoformat()}" in brief
    assert "## 今日の日付" in llm.systems[0] and today.isoformat() in llm.systems[0]
    assert any("具体的な日付にして指示書に書きました" in e.get("text", "") for e in h.of("brief"))
