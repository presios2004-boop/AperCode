"""v2.11.1 の回帰テスト: ツール呼び出しの書式崩れの自動やり直し、Web 調査中の行き詰まり上限の緩和。"""
from __future__ import annotations

import uuid

from codeagent import tools as T

XML_ERR = "XML syntax error on line 19: element <function> closed by </parameter>"


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def _nudges(store, s):
    return [m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge"]


def test_tool_format_error_is_retried(h):
    proj = h.project(with_test=False)
    script = [("raise", XML_ERR), ("tools", [call("list_dir")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False})
    h.run(agent, s, "一覧して")
    assert not h.of("error")
    assert any("書式が崩れていた" in e["text"] for e in h.of("info"))
    assert any("書式が崩れていて読み取れません" in n for n in _nudges(store, s))
    assert [e for e in h.of("tool_result") if e.get("name") == "list_dir"]


def test_tool_format_error_gives_up_after_two_retries(h):
    proj = h.project(with_test=False)
    script = [("raise", XML_ERR)] * 3 + [("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False})
    h.run(agent, s, "一覧して")
    errs = h.of("error")
    assert len(errs) == 1 and "XML syntax error" in errs[0]["text"]


def _web(monkeypatch):
    async def handler(ctx, a):
        return f"検索: {a.get('query')}\n1. 結果\n   https://example.com/{uuid.uuid4().hex[:6]}\n   ドル円の見通し"
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", handler)


def _search_script(n):
    return [("tools", [call("web_search", query=f"USDJPY forecast {i}")]) for i in range(n)] + [("text", "done")]


def test_web_research_relaxes_no_progress_limit(h, monkeypatch):
    _web(monkeypatch)
    proj = h.project(with_test=False)
    over = {"phases.enabled": False, "security.ask_on_injection": False, "llm.max_iterations": 60}
    agent, llm, store, s = h.make(_search_script(20), proj, over)
    h.run(agent, s, "ドル円の見通しを調べて")
    assert not [n for n in _nudges(store, s) if "【システム】" in n and "回続けています" in n]


def test_web_research_nudge_asks_to_record_sources(h, monkeypatch):
    _web(monkeypatch)
    proj = h.project(with_test=False)
    over = {"phases.enabled": False, "security.ask_on_injection": False, "llm.max_iterations": 60, "stuck.research_calls": 15}
    agent, llm, store, s = h.make(_search_script(16), proj, over)
    h.run(agent, s, "ドル円の見通しを調べて")
    ns = [n for n in _nudges(store, s) if "資料を読むだけで記録をせずに 15 回" in n]
    assert ns and "research_note" in ns[0] and "DOM" not in ns[0]


def test_non_web_investigation_keeps_default_limit(h):
    proj = h.project(with_test=False, files={f"d{i}/a.txt": "x" for i in range(14)})
    script = [("tools", [call("list_dir", path=f"d{i}")]) for i in range(14)] + [("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "llm.max_iterations": 60})
    h.run(agent, s, "調べて")
    assert any("調査だけを 12 回" in n for n in _nudges(store, s))


def test_research_note_counts_as_progress(h, monkeypatch):
    _web(monkeypatch)
    proj = h.project(with_test=False)
    note = {"topic": "USDJPY", "source": {"institution": "BankA", "url": "https://example.com/a", "published": "2026-10-01", "type": "bank"},
            "stance": "up", "quotes": ["ドル円の見通し"]}
    script = (_search_script(10)[:-1] + [("tools", [call("research_note", **note)])] + _search_script(10))
    over = {"phases.enabled": False, "security.ask_on_injection": False, "llm.max_iterations": 60, "stuck.research_calls": 12}
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "ドル円の見通しを調べて")
    assert not [n for n in _nudges(store, s) if "回続けています" in n]
