"""v2.11.7 の回帰テスト: 成果物の削除の確認、前の依頼の削除を計画に持ち込まない、大きなファイルを除いたスナップショット。"""
from __future__ import annotations

import asyncio
import uuid
from pathlib import Path

import pytest

from codeagent import agent as A
from codeagent import autonomy as AU
from codeagent import deletion as DEL
from codeagent import sandbox
from codeagent.phases import PhaseState
from codeagent.tools import ToolError
from codeagent.tools import phase_tools as PT

needs_bwrap = pytest.mark.skipif(not sandbox.available(), reason="bubblewrap が使えない環境")
AUTO = {"autonomy.enabled": True, "sandbox.mode": "auto", "phases.enabled": False}


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def _mk(root: Path, files):
    for f in files:
        (root / f).parent.mkdir(parents=True, exist_ok=True)
        (root / f).write_text("x")


def test_targets_and_protection(tmp_path):
    _mk(tmp_path, ["EA/A.mq5", "EA/A.ex5", "EA/notes.md", "bt_reports/r1.htm", "bt_reports/r1.png", "__pycache__/m.pyc", "tmp/scratch.py"])
    pre = DEL.scan(tmp_path)
    t = DEL.targets(f"cd {tmp_path} && rm -f EA/*.mq5 EA/*.ex5 && rm -f bt_reports/* && echo ok", tmp_path)
    assert {p.name for p in t} == {"A.mq5", "A.ex5", "r1.htm", "r1.png"}
    assert DEL.protected(t, tmp_path, pre) == ["EA/A.ex5", "EA/A.mq5", "bt_reports/r1.htm", "bt_reports/r1.png"]
    assert DEL.check("run_command", {"command": "rm -rf __pycache__ tmp"}, tmp_path, pre) == []     # キャッシュ・一時フォルダは確認しない
    assert DEL.check("run_command", {"command": "find . -name '*.md' -delete"}, tmp_path, pre) == ["EA/notes.md"]
    assert DEL.check("run_command", {"command": "python3 -c \"import os; os.remove('EA/A.mq5')\""}, tmp_path, pre) == ["EA/A.mq5"]
    assert DEL.check("repl", {"code": "import shutil\nshutil.rmtree('bt_reports')"}, tmp_path, pre) == ["bt_reports/r1.htm", "bt_reports/r1.png"]
    assert DEL.check("run_command", {"command": "ls EA && cat EA/notes.md"}, tmp_path, pre) == []
    _mk(tmp_path, ["work/new.csv"])                                     # このターンで作ったファイル（一時ファイル）
    assert DEL.check("run_command", {"command": "rm work/new.csv"}, tmp_path, pre) == []


@needs_bwrap
def test_deleting_deliverables_asks_even_in_autonomy(h):
    proj = h.project(with_test=False, files={"EA/Main.mq5": "void OnTick(){}\n", "bt_reports/r.htm": "<html>"})
    reqs = []

    async def approve(req):
        reqs.append(req)
        return "deny"
    h.approve = approve
    script = [("tools", [call("write_file", path="work/tmp.txt", content="一時")]),
              ("tools", [call("run_command", command="rm -f work/tmp.txt")]),                    # 今回作ったもの → 確認なし
              ("tools", [call("run_command", command="rm -f EA/*.mq5 bt_reports/*")]),           # 前からある成果物 → 確認
              ("text", "done")]
    agent, llm, store, s = h.make(script, proj, AUTO)
    h.run(agent, s, "EA を作り直して")
    assert len(reqs) == 1 and "成果物の削除" in reqs[0]["reason"] and "EA/Main.mq5" in reqs[0]["reason"]
    assert not reqs[0]["always"]                                          # 「常に許可」は出さない
    assert (proj / "EA" / "Main.mq5").exists() and (proj / "bt_reports" / "r.htm").exists() and not (proj / "work" / "tmp.txt").exists()
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "run_command"][-1]
    assert "成果物の削除を拒否" in out and "持ち込まない" in out


def test_set_plan_rejects_delete_not_in_latest_request():
    class Ctx:
        phase = PhaseState(active=True, phase="plan")
        request = "以下の方法で EA を作成する。各結果はファイルにして残す"
    ctx = Ctx()
    steps = ["EA を 3 つ作成", "直近 1 年の BT をしてスコアを記録し、EA ソースと BT 結果を削除"]
    with pytest.raises(ToolError, match="最新の依頼には削除の指示がありません"):
        asyncio.run(PT.set_plan(ctx, {"steps": steps}))
    assert "登録しました" in asyncio.run(PT.set_plan(ctx, {"steps": steps}))   # 確認の上で出し直したものは通す（1 回だけ差し戻す）
    ctx2 = Ctx()
    ctx2.phase = PhaseState(active=True, phase="plan")
    ctx2.request = "テストで作ったファイルは削除して"
    assert "登録しました" in asyncio.run(PT.set_plan(ctx2, {"steps": ["作ったファイルを削除する"]}))


def test_digest_marks_executed_requests():
    msgs = [{"role": "user", "content": "今回の作業で作成した各ファイルは削除"},
            {"role": "assistant", "content": "", "tool_calls": [{"name": "run_command", "args": {"command": "rm -f a"}}]},
            {"role": "assistant", "content": "削除しました"},
            {"role": "user", "content": "以下の方法で EA を作成する。ファイルにして残す"}]
    d = A.Agent._conversation_digest(msgs)
    assert "ユーザー（この依頼は実行済み）: 今回の作業で作成した各ファイルは削除" in d
    assert "ユーザー: 以下の方法で EA を作成する" in d and "指示書に含めない" in d
    assert A.Agent._latest_request(msgs + [{"role": "user", "content": "続けて"}]) .startswith("以下の方法で EA")


def test_snapshot_skips_large_files_and_restore_keeps_them(tmp_path, monkeypatch):
    monkeypatch.setattr(AU, "_data_root", lambda: tmp_path / "data")
    proj = tmp_path / "proj"
    _mk(proj, ["EA/A.mq5"])
    (proj / "data.csv").write_bytes(b"0" * 300_000)                     # 大きな価格データ
    meta = AU.snapshot(proj, "t", "s", max_mb=0.2, max_file_mb=0.1)
    assert not meta.get("skipped") and meta["excluded"] == ["data.csv"]
    (proj / "EA" / "A.mq5").unlink()
    AU.restore(proj, meta["id"])
    assert (proj / "EA" / "A.mq5").exists() and (proj / "data.csv").stat().st_size == 300_000
