"""v2.11.9 の回帰テスト: 既存のファイル（以前の調査結果など）を使うかどうかが指示書に無ければ、作業前にユーザーに聞く。"""
from __future__ import annotations

from codeagent import brief as BR

FILES = {"research/USDJPY/boj_m15_analysis.md": "# 分析", "research/USDJPY/events.json": "[]", "EA/RangeMeanRevert.mq5": "void OnTick(){}",
         "skills/x/SKILL.md": "s", "backup/20261008/EA/a.mq5": "x"}


def test_parse_existing_and_overview(h):
    raw = "前置き\nEXISTING: research/USDJPY/ に以前の調査結果があります。使いますか、新しく調査し直しますか？\nQUESTION: x?\nEXISTING: もう一つ"
    assert BR.parse_existing(raw) == ["research/USDJPY/ に以前の調査結果があります。使いますか、新しく調査し直しますか？"]
    q, a = BR.parse_clarify(raw)
    assert all("以前の調査結果" not in x for x in q)                        # 通常の質問とは分ける
    proj = h.project(with_test=False, files=FILES)
    ov = BR.existing_overview(proj)
    assert "research/USDJPY/ … 2 件" in ov and "EA/RangeMeanRevert.mq5" in ov
    assert "skills" not in ov and "backup" not in ov


def test_existing_question_is_asked_even_in_assume_mode(h):
    proj = h.project(with_test=False, files=FILES)
    agent, llm, store, s = h.make([("text", "了解しました")], proj, {"brief.clarify": "assume"})   # 自律モードと同じく質問で止めない設定
    seen = []
    orig = llm.complete

    async def complete(system, text, *a, **k):
        seen.append(text)
        return await orig(system, text, *a, **k)
    llm.complete = complete
    llm.clarify = ("EXISTING: research/USDJPY/ に以前の調査結果があります。使いますか、新しく調査し直しますか？\n"
                   "QUESTION: 時間足は？\nASSUME: 結果は md にする")
    h.run(agent, s, "USDJPY の日銀会合前後の値動きを調べて EA を作ってください")
    s2 = store.load(s.id)
    assert llm.systems == [] and s2.clarify_pending                        # 作業を始めずに質問で止まる
    msg = s2.messages[-1]["content"]
    assert "以前の調査結果があります" in msg and "時間足" not in msg      # 既存ファイルの質問だけは聞く。ほかは仮定
    assert "（未確認）時間足は？" in BR.read(BR.path_for(proj, s.id))
    assert any("既存のファイル" in x and "research/USDJPY/" in x for x in seen)   # 点検に作業ディレクトリの概要を渡している


def test_existing_question_off(h):
    proj = h.project(with_test=False, files=FILES)
    agent, llm, store, s = h.make([("text", "了解しました")], proj, {"brief.clarify": "assume", "brief.ask_existing": False})
    llm.clarify = "EXISTING: research/USDJPY/ を使いますか？"
    h.run(agent, s, "USDJPY の日銀会合前後の値動きを調べて EA を作ってください")
    assert llm.systems and not store.load(s.id).clarify_pending


# ---------------------------------------------------------------- v2.11.11: 範囲の解釈が分かれる点
def test_scope_question_is_asked_even_in_assume_mode(h):
    raw = ("SCOPE: 手順 2 の値動きの調査は、10 月会合だけですか、過去 5 年のすべての会合ですか？\n"
           "QUESTION: 時間足は？\nSCOPE: 二つ目の質問です\nSCOPE: 三つ目の質問です")
    assert BR.parse_scope(raw)[0].startswith("手順 2 の値動き") and len(BR.parse_scope(raw)) == 2
    assert "範囲の解釈" in BR.CLARIFY_PROMPT and "10 月会合だけか" in BR.CLARIFY_PROMPT and "Scope" in BR.CLARIFY_PROMPT_EN
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "了解しました")], proj, {"brief.clarify": "assume"})
    llm.clarify = raw
    h.run(agent, s, "最終目標は 10 月日銀会合の EA。過去 5 年分の日銀会合を調べ、1 で調べた期間の前後 3 営業日の値動きを調査する")
    s2 = store.load(s.id)
    assert llm.systems == [] and s2.clarify_pending
    msg = s2.messages[-1]["content"]
    assert "10 月会合だけですか、過去 5 年のすべての会合ですか" in msg and "時間足" not in msg


def test_scope_question_off(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "了解しました")], proj, {"brief.clarify": "assume", "brief.ask_scope": False})
    llm.clarify = "SCOPE: 10 月会合だけですか、すべてですか？"
    h.run(agent, s, "最終目標は 10 月日銀会合の EA。過去 5 年分の日銀会合を調べて値動きを調査する")
    assert llm.systems and not store.load(s.id).clarify_pending
