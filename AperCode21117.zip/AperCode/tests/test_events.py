"""v2.11.5 の回帰テスト: イベントの日程（event_calendar）と、過去のイベントの前後でまとめてバックテスト（mt5_event_backtest）。"""
from __future__ import annotations

import json
import os
import shutil
import stat
import uuid
from pathlib import Path

import pytest

from codeagent import mql5_basic as MB
from codeagent import research as R
from codeagent import tools as T
from codeagent.tools import mt5 as MT5

FED = "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def test_events_need_full_date_and_source(tmp_path):
    with pytest.raises(R.ResearchError, match="YYYY-MM-DD"):
        R.save_events(tmp_path, "USDJPY", [{"date": "2025-09", "kind": "FOMC", "source": FED}])
    with pytest.raises(R.ResearchError, match="source"):
        R.save_events(tmp_path, "USDJPY", [{"date": "2025-09-17", "kind": "FOMC"}])
    p, evs, warns = R.save_events(tmp_path, "USDJPY", [{"date": "2025-09-17", "kind": "fomc", "source": FED},
                                                       {"date": "2025-07-31", "kind": "BOJ", "source": "https://www.boj.or.jp/x"}],
                                  fetched={FED: "..."})
    assert [e["date"] for e in evs] == ["2025-07-31", "2025-09-17"] and evs[1]["kind"] == "FOMC"
    assert len(warns) == 1 and "boj.or.jp" in warns[0]                   # 読んでいない出典は警告
    _, evs, _ = R.save_events(tmp_path, "USDJPY", [{"date": "2025-09-17", "kind": "FOMC", "name": "9月会合", "source": FED}])
    assert len(evs) == 2 and evs[1]["name"] == "9月会合"                  # 同じ日付・種類は上書き
    assert [e["date"] for e in R.select_events(evs, "FOMC")] == ["2025-09-17"]


def test_event_calendar_tool_checks_sources_read(h, monkeypatch):
    async def handler(ctx, a):
        return "FOMC meeting calendars: September 16-17"
    T.load_builtin()
    monkeypatch.setattr(T.get("fetch_url"), "handler", handler)
    proj = h.project(with_test=False)
    script = [("tools", [call("fetch_url", url=FED)]),
              ("tools", [call("event_calendar", action="add", topic="USDJPY",
                              events=[{"date": "2025-09-17", "kind": "FOMC", "source": FED}])]),
              ("tools", [call("event_calendar", topic="USDJPY", kind="FOMC")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "security.ask_on_injection": False})
    h.run(agent, s, "FOMC の日程を記録して")
    add, lst = [e["output"] for e in h.of("tool_result") if e.get("name") == "event_calendar"]
    assert "全 1 件" in add and "⚠" not in add, add
    assert "| 2025-09-17 |" in lst and "FOMC" in lst


def test_metrics_parse_ja_and_en():
    ja = "総損益: 1 234.50\nプロフィットファクター: 1.35\n取引数: 12\n証拠金最大ドローダウン: 210.00 (2.10%)"
    en = "Total Net Profit: -56.10\nProfit Factor: 0.80\nTotal Trades: 4\nEquity Drawdown Maximal: 99.00 (0.99%)"
    assert MT5._metrics(ja) == {"net": 1234.5, "pf": 1.35, "trades": 12, "dd": 210.0}
    assert MT5._metrics(en) == {"net": -56.1, "pf": 0.8, "trades": 4, "dd": 99.0}


def test_basic_check_flags_event_ea_pitfalls():
    ids = [x["id"] for x in MB.check("input datetime InpActiveFrom = 0;\nvoid OnTick(){ MqlCalendarValue v[]; CalendarValueHistory(v, 0, 0); }")]
    assert "CALENDAR_IN_TESTER" in ids and "WINDOW_BLOCKS_TESTER" in ids
    ok = "input datetime InpActiveFrom = 0;\nbool InWindow(){ if(MQLInfoInteger(MQL_TESTER)) return true; return TimeCurrent() >= InpActiveFrom; }\n"
    assert "WINDOW_BLOCKS_TESTER" not in [x["id"] for x in MB.check(ok)]


@pytest.fixture
def fake_terminal(h, monkeypatch, tmp_path):
    prefix = Path.home() / f".apercode_mt5test_{uuid.uuid4().hex[:6]}"
    term = prefix / "drive_c" / "Program Files" / "MT5"
    (term / "MQL5" / "Experts").mkdir(parents=True)
    (term / "terminal64.exe").write_text("")
    bindir = tmp_path / "bin"
    bindir.mkdir()
    wine = bindir / "wine"   # 偽の terminal64: 9 月の窓は勝ち、それ以外は負け。2025-03 の窓はレポートを作らない
    wine.write_text("#!/usr/bin/env python3\nimport os, re, sys\n"
                    "cfg = next(a[8:] for a in sys.argv if a.startswith('/config:'))\n"
                    "ini = open(os.environ['WINEPREFIX'] + '/drive_c/' + cfg.split('\\\\', 1)[1].replace('\\\\', '/'), encoding='utf-8').read()\n"
                    "name = re.search(r'Report=(.+)', ini).group(1).strip()\n"
                    "frm = re.search(r'FromDate=(\\S+)', ini).group(1)\n"
                    "open('ranges.log', 'a').write(frm + '-' + re.search(r'ToDate=(\\S+)', ini).group(1) + '\\n')\n"
                    "if frm.startswith('2025.03'): sys.exit(1)\n"
                    "net, tr = ('120.00', '3') if frm[5:7] == '09' else ('-40.00', '2')\n"
                    "html = f'<table><tr><td>総損益:</td><td><b>{net}</b></td></tr><tr><td>プロフィットファクター:</td><td><b>1.5</b></td></tr>"
                    "<tr><td>取引数:</td><td><b>{tr}</b></td></tr></table>'\n"
                    "open(name + '.htm', 'wb').write(html.encode('utf-16'))\n")
    wine.chmod(wine.stat().st_mode | stat.S_IEXEC)
    monkeypatch.setenv("PATH", f"{bindir}:{os.environ['PATH']}")
    over = {"phases.enabled": False, "mt5.wine_prefix": str(prefix), "mt5.terminal_dir": "drive_c/Program Files/MT5",
            "mt5.mql5_dir": "drive_c/Program Files/MT5/MQL5", "permissions.mt5_event_backtest": "allow",
            "verify.create_missing_tests": False}
    yield over, term
    shutil.rmtree(prefix, ignore_errors=True)


def test_event_backtest_runs_each_window_and_summarises(h, fake_terminal):
    over, term = fake_terminal
    proj = h.project(with_test=False, files={"ea/Ev.mq5": "void OnTick(){}\n", "ea/Ev.ex5": "EX5"})
    R.save_events(proj, "USDJPY", [{"date": d, "kind": "FOMC", "source": FED} for d in
                                   ("2025-03-19", "2025-06-18", "2025-07-30", "2025-09-17", "2099-01-01")]
                  + [{"date": "2025-07-31", "kind": "BOJ", "source": FED}])
    script = [("tools", [call("mt5_event_backtest", path="ea/Ev.mq5", topic="USDJPY", kind="FOMC", days_before=1, days_after=2)]),
              ("text", "done")]
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "過去の FOMC で検証して")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "mt5_event_backtest"][0]
    ranges = (term / "ranges.log").read_text().split()
    assert ranges == ["2025.03.18-2025.03.21", "2025.06.17-2025.06.20", "2025.07.29-2025.08.01", "2025.09.16-2025.09.19"], ranges
    assert "まだ終わっていないため除外: 2099-01-01" in out                 # 未来のイベントは除外、BOJ は kind で除外
    assert "窓の数: 4（テストできた 3・取引があった 3）" in out, out
    assert "勝った窓 / 負けた窓: 1 / 2" in out and "損益の合計: 40.00（取引数の合計 7）" in out
    assert "最も悪い窓: 2025-06-18" in out and "| 失敗 |" in out
    assert "統計的な裏付けは弱い" in out
    saved = sorted((proj / "bt_reports").glob("event_Ev_*.json"))
    data = json.loads(saved[-1].read_text())
    assert data["window_pf"] == 1.5 and data["traded"] == 3


def test_event_backtest_needs_events(h, fake_terminal):
    over, _ = fake_terminal
    proj = h.project(with_test=False, files={"ea/Ev.mq5": "void OnTick(){}\n", "ea/Ev.ex5": "EX5"})
    agent, llm, store, s = h.make([("tools", [call("mt5_event_backtest", path="ea/Ev.mq5")]), ("text", "done")], proj, over)
    h.run(agent, s, "検証して")
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "mt5_event_backtest"][0]
    assert "検証するイベントがありません" in out
