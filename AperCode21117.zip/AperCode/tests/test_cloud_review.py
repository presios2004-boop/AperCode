"""v2.11.6 の回帰テスト: クラウド AI による最終レビュー（失敗したらサブ LLM）、ask_cloud の使える条件、ユーザーからの相談の依頼。"""
from __future__ import annotations

import json
import uuid

from codeagent import agent as A
from codeagent import cloud as C
from codeagent import tools as T

CLOUD = {"cloud.enabled": True, "cloud.provider": "anthropic", "cloud.model": "claude-test", "cloud.api_key": "sk-test"}


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


def _nudges(store, s):
    return [m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge"]


def test_cloud_request_regex():
    for t in ("クラウドAIと相談して", "この件はクラウド AI に聞いてみて", "Claudeに相談して進めて", "外部AIと連携して確認して",
              "クラウドにレビューしてもらって", "please consult the cloud about this"):
        assert A.CLOUD_REQUEST_RE.search(t), t
    for t in ("クラウドのストレージに保存して", "EA を作って", "相談に乗ってください"):
        assert not A.CLOUD_REQUEST_RE.search(t), t


def test_final_review_uses_cloud_for_all_code(h, monkeypatch):
    sent = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        sent.append((system, prompt))
        return 'ok\n{"ok": false, "issues": [{"file": "ea/A.mq5", "line": 3, "severity": "high", "problem": "SL がない", "fix": "SL を付ける"}]}'
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False)
    script = [("tools", [call("write_file", path="ea/A.mq5", content="void OnTick()\n{\n   int x = 1;\n}\n")]),
              ("tools", [call("write_file", path="notes.md", content="# メモ\n")]),
              ("text", "完了しました"), ("text", "直さず報告します")]
    agent, llm, store, s = h.make(script, proj, {**CLOUD, "phases.enabled": False, "verify.create_missing_tests": False,
                                                 "verify.review.enabled": True, "mt5.basic_check": False})
    h.run(agent, s, "EA を書いて")
    assert len(sent) == 1
    system, prompt = sent[0]
    assert "ea/A.mq5" in prompt and "int x = 1" in prompt and "notes.md" not in prompt      # EA も対象、文書は送らない
    assert "Japanese" in system
    ns = [n for n in _nudges(store, s) if "【レビュー指摘】" in n]
    assert ns and "クラウド AI のレビュー" in ns[0] and "SL がない" in ns[0]
    assert [e for e in h.of("verify") if e.get("kind") == "review" and "クラウド AI" in e.get("text", "")]
    assert not [e for e in h.of("subagent_start") if e.get("mode") == "review"]


def test_cloud_review_failure_falls_back_to_sub_llm(h, monkeypatch):
    async def boom(self, system, prompt, max_tokens=4096):
        raise RuntimeError("クラウド API エラー 529")
    monkeypatch.setattr(C.CloudClient, "ask", boom)
    proj = h.project(with_test=False)
    py = "".join(f"V{i} = {i}\n" for i in range(80))
    script = [("tools", [call("write_file", path="big.py", content=py)]), ("text", "完了"),
              ("text", '{"ok": true, "issues": []}'), ("text", "完了")]
    agent, llm, store, s = h.make(script, proj, {**CLOUD, "phases.enabled": False, "verify.create_missing_tests": False,
                                                 "verify.review.enabled": True})
    h.run(agent, s, "書いて")
    assert any("サブ LLM でレビューを行いました" in e["text"] for e in h.of("info"))
    assert [e for e in h.of("subagent_start") if e.get("mode") == "review"]


def test_cloud_review_off_or_not_configured_uses_sub_llm(h, monkeypatch):
    called = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        called.append(1)
        return '{"ok": true, "issues": []}'
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False)
    py = "".join(f"V{i} = {i}\n" for i in range(80))
    for n, over in enumerate(({**CLOUD, "verify.review.cloud": "off"}, {"cloud.enabled": False})):
        h.events.clear()
        script = [("tools", [call("write_file", path=f"b{n}.py", content=py)]), ("text", "完了"),
                  ("text", '{"ok": true, "issues": []}'), ("text", "完了")]
        agent, llm, store, s = h.make(script, proj, {**over, "phases.enabled": False, "verify.create_missing_tests": False,
                                                     "verify.review.enabled": True})
        h.run(agent, s, "書いて")
        assert [e for e in h.of("subagent_start") if e.get("mode") == "review"]
    assert not called


def _ask(goal="EA の改善案"):
    return call("ask_cloud", goal=goal, tried="移動平均の期間を変えた")


def test_ask_cloud_allowed_when_user_asks_or_after_searching(h, monkeypatch):
    async def fake_ask(self, system, prompt, max_tokens=4096):
        return "案: ATR でフィルタする"
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)

    async def web(ctx, a):
        return f"検索: {a.get('query')}\n1. 結果\n   https://example.com/x\n   短い説明"
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", web)
    proj = h.project(with_test=False)
    over = {**CLOUD, "phases.enabled": False, "permissions.ask_cloud": "allow", "security.ask_on_injection": False,
            "security.taint_guard": False}
    # 1) 失敗も検索もなし → 使えない
    agent, llm, store, s = h.make([("tools", [_ask()]), ("text", "done")], proj, over)
    h.run(agent, s, "EA のアイデアを出して")
    assert "まだクラウド相談は使えません" in [e["output"] for e in h.of("tool_result") if e.get("name") == "ask_cloud"][0]
    # 2) ユーザーが求めた → すぐ使える。説明にもその旨が入る
    h.events.clear()
    agent, llm, store, s = h.make([("tools", [_ask()]), ("text", "done")], proj, over)
    h.run(agent, s, "EA のアイデアについてクラウドAIと相談して")
    assert "案: ATR でフィルタする" in [e["output"] for e in h.of("tool_result") if e.get("name") == "ask_cloud"][0]
    assert "ユーザーはこの依頼でクラウド AI との相談を求めている" in llm.systems[0]
    # 3) Web で 3 回調べた → 使える
    h.events.clear()
    script = [("tools", [call("web_search", query=f"q{i}")]) for i in range(3)] + [("tools", [_ask()]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "EA のアイデアを出して")
    assert "案: ATR でフィルタする" in [e["output"] for e in h.of("tool_result") if e.get("name") == "ask_cloud"][0]


def test_user_asks_cloud_but_not_configured(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, {"cloud.enabled": False, "phases.enabled": False})
    h.run(agent, s, "クラウドAIと相談して決めて")
    assert "クラウド相談が設定されていない" in llm.systems[0]
    assert "ask_cloud" not in llm.toolsets[0]


# ---------------------------------------------------------------- v2.11.8: 用途別のモデル
def test_role_models_resolve_with_default():
    class Cfg:
        def __init__(self, d):
            self.d = d

        def get(self, k, default=None):
            cur = self.d
            for p in k.split("."):
                if not isinstance(cur, dict) or p not in cur:
                    return default
                cur = cur[p]
            return cur
    cfg = Cfg({"cloud": {"provider": "anthropic", "model": "claude-sonnet-5-5", "api_key": "k",
                         "models": {"consult": "claude-haiku-5-5", "chat": "", "review": " "}}})
    assert C.CloudSettings.from_cfg(cfg, "consult").model == "claude-haiku-5-5"
    assert C.CloudSettings.from_cfg(cfg, "chat").model == "claude-sonnet-5-5"
    assert C.CloudSettings.from_cfg(cfg, "review").model == "claude-sonnet-5-5"
    assert C.CloudSettings.from_cfg(cfg).model == "claude-sonnet-5-5"


def test_review_and_consult_use_their_models(h, monkeypatch):
    used = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        used.append(self.s.model)
        return '{"ok": true, "issues": []}' if "final review" in system else "ヒント"
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False)
    over = {**CLOUD, "cloud.models": {"consult": "claude-haiku-5-5", "chat": "", "review": "claude-opus-5-5"},
            "phases.enabled": False, "verify.create_missing_tests": False, "verify.review.enabled": True,
            "permissions.ask_cloud": "allow", "security.taint_guard": False}
    script = [("tools", [call("ask_cloud", goal="g", tried="t")]), ("tools", [call("write_file", path="a.py", content="x = 1\n")]),
              ("text", "完了"), ("text", "完了")]
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "クラウドAIと相談して a.py を作って")
    assert used == ["claude-haiku-5-5", "claude-opus-5-5"]


def test_cloud_api_saves_role_models(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from codeagent.config import Config
    from codeagent.server import app as APP
    from pathlib import Path
    monkeypatch.setattr(APP, "USER_CONFIG_PATH", tmp_path / "user.yaml")
    root = Path(__file__).resolve().parents[1]
    cfg = Config.load(root / "config.yaml" if (root / "config.yaml").exists() else root / "config.example.yaml")
    for k, v in {("memory", "enabled"): False, ("browser", "enabled"): False, ("peer", "enabled"): False,
                 ("server", "sessions_dir"): str(tmp_path / "sessions"), ("workspace", "default_project"): str(tmp_path / "w"),
                 ("llm", "base_url"): "http://127.0.0.1:9"}.items():
        cfg.data.setdefault(k[0], {})[k[1]] = v
    c = TestClient(APP.create_app(cfg))
    r = c.post("/api/cloud", json={"provider": "anthropic", "model": "claude-sonnet-5-5", "api_key": "sk-test-123456789",
                                   "models": {"consult": "claude-haiku-5-5", "chat": "", "review": ""}})
    assert r.status_code == 200, r.text
    v = r.json()
    assert v["models"]["consult"] == "claude-haiku-5-5" and v["role_models"]["review"] == "claude-sonnet-5-5" and v["ready"]
    assert not v["enabled"]
    v = c.post("/api/cloud", json={"enabled": True}).json()                     # 画面上部のスイッチ
    assert v["enabled"] and v["models"]["consult"] == "claude-haiku-5-5"
    assert "claude-haiku-5-5" in (tmp_path / "user.yaml").read_text()


# ---------------------------------------------------------------- v2.11.12: 本文が空の応答（思考で上限を使い切り）
def _mock_anthropic(monkeypatch, responses):
    import httpx
    sent = []

    def handler(request):
        body = json.loads(request.content)
        sent.append(body["max_tokens"])
        return httpx.Response(200, json=responses[min(len(sent) - 1, len(responses) - 1)])
    real = httpx.AsyncClient

    class Client(real):
        def __init__(self, *a, **k):
            k["transport"] = httpx.MockTransport(handler)
            super().__init__(*a, **k)
    monkeypatch.setattr(httpx, "AsyncClient", Client)
    return sent


def test_empty_thinking_only_response_is_retried(monkeypatch):
    import asyncio
    empty = {"content": [{"type": "thinking", "thinking": "..."}], "stop_reason": "max_tokens"}
    ok = {"content": [{"type": "thinking", "thinking": "..."}, {"type": "text", "text": "ヒントです"}], "stop_reason": "end_turn"}
    sent = _mock_anthropic(monkeypatch, [empty, ok])
    s = C.CloudSettings(provider="anthropic", model="claude-haiku-5-5", api_key="k", base_url="https://api.anthropic.com")
    assert asyncio.run(C.CloudClient(s).ask("sys", "p", max_tokens=4096)) == "ヒントです"
    assert sent == [4096, 16384]


def test_empty_response_raises_clear_error(monkeypatch):
    import asyncio
    import pytest
    empty = {"content": [{"type": "thinking", "thinking": "..."}], "stop_reason": "max_tokens"}
    _mock_anthropic(monkeypatch, [empty, empty])
    s = C.CloudSettings(provider="anthropic", model="claude-haiku-5-5", api_key="k", base_url="https://api.anthropic.com")
    with pytest.raises(RuntimeError, match="本文がありませんでした.*stop_reason=max_tokens.*thinking"):
        asyncio.run(C.CloudClient(s).ask("sys", "p", max_tokens=4096))


# ---------------------------------------------------------------- v2.11.14: cloud_review（LLM が頼むコードレビュー）
def test_cloud_review_tool_uses_review_model(h, monkeypatch):
    used = []

    async def fake_ask(self, system, prompt, max_tokens=4096):
        used.append((self.s.model, prompt))
        return ('検討しました\n{"ok": false, "issues": [{"file": "ea/A.mq5", "line": 7, "severity": "high", '
                '"problem": "SL が逆", "fix": "Buy は price - sl"}]}')
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False, files={"ea/A.mq5": "void OnTick()\n{\n   double sl = 1;\n}\n"})
    over = {**CLOUD, "cloud.models": {"consult": "claude-haiku-5-5", "chat": "claude-haiku-5-5", "review": "claude-sonnet-5-5"},
            "phases.enabled": False, "permissions.cloud_review": "allow", "security.taint_guard": False, "cloud.review_max_per_turn": 1}
    script = [("tools", [call("cloud_review", files=["ea/A.mq5"], task="日銀会合の EA", focus="SL の向き")]),
              ("tools", [call("cloud_review", files=["ea/A.mq5"], task="再レビュー")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "EA をクラウドAIでレビューして")
    outs = [e["output"] for e in h.of("tool_result") if e.get("name") == "cloud_review"]
    assert used[0][0] == "claude-sonnet-5-5" and "double sl = 1" in used[0][1] and "SL の向き" in used[0][1]
    assert "claude-sonnet-5-5" in outs[0] and "[high] ea/A.mq5:7 SL が逆" in outs[0] and "Buy は price - sl" in outs[0]
    assert "上限（1 回）" in outs[1] and len(used) == 1
    assert "cloud_review を使う" in llm.systems[0]


def test_cloud_review_hidden_when_cloud_off(h):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, {"cloud.enabled": False, "phases.enabled": False})
    h.run(agent, s, "こんにちは")
    assert "cloud_review" not in llm.toolsets[0]


# ---------------------------------------------------------------- v2.11.15: 外部レビューができないとき
def _boom(monkeypatch):
    async def boom(self, system, prompt, max_tokens=4096):
        raise RuntimeError("クラウド API エラー 529")
    monkeypatch.setattr(C.CloudClient, "ask", boom)


def test_external_review_failure_notifies_and_forces_sub_review(h, monkeypatch):
    _boom(monkeypatch)
    proj = h.project(with_test=False)
    script = [("tools", [call("write_file", path="ea/A.mq5", content="void OnTick()\n{\n   int x = 1;\n}\n")]), ("text", "完了"),
              ("text", '{"ok": true, "issues": []}'), ("text", "完了")]
    agent, llm, store, s = h.make(script, proj, {**CLOUD, "phases.enabled": False, "verify.create_missing_tests": False,
                                                 "verify.review.enabled": True, "mt5.basic_check": False})
    h.run(agent, s, "EA を書いて")
    notes = h.of("notice")
    assert notes and "外部レビューができませんでした。そのためサブ LLM でレビューを行いました" in notes[0]["text"] and "529" in notes[0]["text"]
    assert [e for e in h.of("subagent_start") if e.get("mode") == "review"]          # 4 行の EA でもサブ LLM がレビュー
    assert any("サブ LLM（外部レビューの代わり）" in e.get("text", "") for e in h.of("verify"))


def test_desktop_fallback_then_sub_review(h, monkeypatch, tmp_path):
    _boom(monkeypatch)
    skills = tmp_path / "skills" / "claude-desktop-chat"
    skills.mkdir(parents=True)
    (skills / "SKILL.md").write_text("---\nname: claude-desktop-chat\ndescription: Claude デスクトップとチャットする\n---\n手順\n")
    proj = h.project(with_test=False)
    script = [("tools", [call("write_file", path="a.py", content="x = 1\n")]), ("text", "完了"),
              ("text", "Claude デスクトップを開けませんでした。完了します"),
              ("text", '{"ok": true, "issues": []}'), ("text", "完了")]
    agent, llm, store, s = h.make(script, proj, {**CLOUD, "phases.enabled": False, "verify.create_missing_tests": False,
                                                 "verify.review.enabled": True, "cloud.desktop_fallback": True,
                                                 "skills.dir": str(tmp_path / "skills")})
    h.run(agent, s, "a.py を作って")
    nudges = [m["content"] for m in store.load(s.id).messages if m.get("kind") == "nudge"]
    assert any("【外部レビュー】" in n and "claude-desktop-chat" in n and "a.py" in n for n in nudges)
    assert h.of("notice") and "Claude デスクトップでもレビューを依頼できませんでした" in h.of("notice")[0]["text"]
    assert [e for e in h.of("subagent_start") if e.get("mode") == "review"]


def test_cloud_review_tool_failure_runs_sub_review(h, monkeypatch):
    _boom(monkeypatch)
    proj = h.project(with_test=False, files={"ea/A.mq5": "void OnTick(){}\n"})
    script = [("tools", [call("cloud_review", files=["ea/A.mq5"], task="EA")]),
              ('text', '{"ok": false, "issues": [{"file": "ea/A.mq5", "line": 1, "severity": "medium", "problem": "発注がない", "fix": "CTrade で発注"}]}'),
              ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {**CLOUD, "phases.enabled": False, "permissions.cloud_review": "allow",
                                                 "security.taint_guard": False})
    h.run(agent, s, "EA をクラウドAIでレビューして")
    tool = [m["content"] for m in store.load(s.id).messages if m["role"] == "tool" and m.get("name") == "cloud_review"][0]
    assert "529" in tool and "サブ LLM でレビューしました" in tool and "発注がない" in tool
    assert h.of("notice")


# ---------------------------------------------------------------- v2.11.16: cloud_review は確認なし
def test_cloud_review_runs_without_approval_even_after_web(h, monkeypatch):
    async def fake_ask(self, system, prompt, max_tokens=4096):
        return '{"ok": true, "issues": []}'
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)

    async def web(ctx, a):
        return "検索: x\n1. 結果\n   https://example.com/x\n   説明"
    T.load_builtin()
    monkeypatch.setattr(T.get("web_search"), "handler", web)
    reqs = []

    async def approve(req):
        reqs.append(req)
        return "deny"
    h.approve = approve
    proj = h.project(with_test=False, files={"ea/A.mq5": "void OnTick(){}\n"})
    outside = proj.parent / "secret.txt"
    outside.write_text("x")
    script = [("tools", [call("web_search", query="mql5")]), ("tools", [call("cloud_review", files=["ea/A.mq5"], task="EA")]),
              ("tools", [call("cloud_review", files=[str(outside)], task="EA")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {**CLOUD, "phases.enabled": False, "security.ask_on_injection": False})
    h.run(agent, s, "EA をレビューして")
    assert not [r for r in reqs if r["name"] == "cloud_review"]             # 外部の内容を読んだ後でも確認しない
    outs = [e["output"] for e in h.of("tool_result") if e.get("name") == "cloud_review"]
    assert "指摘なし" in outs[0] and "作業ディレクトリの外" in outs[1] and not h.of("notice")


# ---------------------------------------------------------------- v2.11.17: レビューの指摘を確認済みの教訓として保存
class _FakeStore:
    def __init__(self):
        self.added = []

    async def add(self, **k):
        self.added.append(k)
        return object(), None

    def count(self):
        return 0


def test_review_issues_saved_as_verified_lessons(h, monkeypatch):
    async def fake_ask(self, system, prompt, max_tokens=4096):
        return ('{"ok": false, "issues": ['
                '{"file": "ea/A.mq5", "line": 7, "severity": "high", "problem": "OANDA の USDJPY は 3 桁表示なので pips は _Point*10", "fix": "pips × _Point × 10 で換算する"},'
                '{"file": "ea/A.mq5", "line": 9, "severity": "low", "problem": "変数名がわかりにくい", "fix": "名前を変える"}]}')
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False, files={"ea/A.mq5": "void OnTick(){}\n"})
    agent, llm, store, s = h.make([("tools", [call("cloud_review", files=["ea/A.mq5"], task="日銀会合の EA")]), ("text", "done")],
                                  proj, {**CLOUD, "phases.enabled": False})
    fake = _FakeStore()
    agent.memory = fake
    h.run(agent, s, "EA をレビューして")
    assert len(fake.added) == 1                                             # low は保存しない
    a = fake.added[0]
    assert a["verified"] == 1 and "untrusted" not in a["tags"] and {"mql5", "review", "high"} <= set(a["tags"])
    assert a["lesson"].startswith("MQL5 のコードでの注意: OANDA の USDJPY") and "claude-test" in a["lesson"]
    out = [e["output"] for e in h.of("tool_result") if e.get("name") == "cloud_review"][0]
    assert "確認済みの教訓として経験メモリに保存しました" in out


def test_review_lessons_off(h, monkeypatch):
    async def fake_ask(self, system, prompt, max_tokens=4096):
        return '{"ok": false, "issues": [{"file": "a.py", "line": 1, "severity": "high", "problem": "None を返す場合の処理がない", "fix": "None を確認する"}]}'
    monkeypatch.setattr(C.CloudClient, "ask", fake_ask)
    proj = h.project(with_test=False, files={"a.py": "x = 1\n"})
    agent, llm, store, s = h.make([("tools", [call("cloud_review", files=["a.py"], task="t")]), ("text", "done")],
                                  proj, {**CLOUD, "phases.enabled": False, "memory.review_lessons": "off"})
    fake = _FakeStore()
    agent.memory = fake
    h.run(agent, s, "レビューして")
    assert not fake.added
