"""v2.11.2 の回帰テスト: mt5_compile の後の構造検査（必ず実行・違反は差し戻し・合格までバックテスト不可）。"""
from __future__ import annotations

import os
import shutil
import stat
import uuid
from pathlib import Path

import pytest

from codeagent import sandbox
from codeagent.tools import mt5 as MT5

needs_bwrap = pytest.mark.skipif(not sandbox.available(), reason="bubblewrap が使えない環境")

# 偽の検査スクリプト: 本物の check.py と同じ JSON を返す（"BAD" を含む EA は違反）
FAKE_CHECK = (
    "import json, sys\n"
    "src = open(sys.argv[1], encoding='utf-8').read()\n"
    "open(sys.argv[1] + '.args', 'w').write(' '.join(sys.argv[2:]))\n"
    "v = [{'id': 'NO_NEW_BAR_CHECK', 'problem': '新バー確定チェックがない', 'fix': 'static datetime を入れる'}] if 'BAD' in src else []\n"
    "print(json.dumps([{'file': sys.argv[1], 'ok': not v, 'mtf': {}, 'violations': v}]))\n"
    "sys.exit(1 if v else 0)\n")


def call(tool, **args):
    return {"id": uuid.uuid4().hex[:8], "name": tool, "args": args}


@pytest.fixture
def mt5env(h, monkeypatch, tmp_path):
    prefix = Path.home() / f".apercode_mt5test_{uuid.uuid4().hex[:6]}"
    term = prefix / "drive_c" / "Program Files" / "MT5"
    (term / "MQL5" / "Experts").mkdir(parents=True)
    (term / "MetaEditor64.exe").write_text("")
    (term / "terminal64.exe").write_text("")
    (prefix / "system.reg").write_text("WINE REGISTRY")
    bindir = tmp_path / "bin"
    bindir.mkdir()
    wine = bindir / "wine"
    wine.write_text("#!/usr/bin/env python3\nimport os, sys\n"
                    "if any(a.startswith('/config:') for a in sys.argv): sys.exit('terminal should not run')\n"
                    "src = next(a[9:] for a in sys.argv if a.startswith('/compile:')).replace('\\\\', '/')\n"
                    "base = os.path.splitext(src)[0]\n"
                    "open(base + '.log', 'wb').write('Result: 0 errors, 0 warnings'.encode('utf-16'))\n"
                    "open(base + '.ex5', 'wb').write(b'EX5')\n")
    wine.chmod(wine.stat().st_mode | stat.S_IEXEC)
    monkeypatch.setenv("PATH", f"{bindir}:{os.environ['PATH']}")
    skills = tmp_path / "skills"
    sk = skills / "mql5-structure-check"
    sk.mkdir(parents=True)
    (sk / "SKILL.md").write_text("---\nname: mql5-structure-check\ndescription: EA の構造検査\n---\n手順\n")
    (sk / "check.py").write_text(FAKE_CHECK)
    MT5._STRUCT_STATE.clear()
    over = {"phases.enabled": False, "mt5.wine_prefix": str(prefix), "mt5.terminal_dir": "drive_c/Program Files/MT5",
            "mt5.mql5_dir": "drive_c/Program Files/MT5/MQL5", "permissions.mt5_compile": "allow",
            "permissions.mt5_backtest": "allow", "skills.dir": str(skills)}
    yield over, skills
    shutil.rmtree(prefix, ignore_errors=True)


def _out(h, name):
    return [e["output"] for e in h.of("tool_result") if e.get("name") == name]


@needs_bwrap
def test_violation_is_sent_back_and_blocks_backtest_until_fixed(h, mt5env):
    over, _ = mt5env
    proj = h.project(with_test=False, files={"ea/Main.mq5": "// BAD\nvoid OnTick(){}\n"})
    script = [("tools", [call("mt5_compile", path="ea/Main.mq5", mtf="single", tf="H1")]),
              ("tools", [call("mt5_backtest", path="ea/Main.mq5")]),
              ("tools", [call("write_file", path="ea/Main.mq5", content="// fixed\nvoid OnTick(){}\n")]),
              ("tools", [call("mt5_compile", path="ea/Main.mq5")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "EA をコンパイルして")
    c1, c2 = _out(h, "mt5_compile")
    assert "構造検査 違反 1 件（1/5 回目）" in c1 and "NO_NEW_BAR_CHECK" in c1 and "edit_file" in c1, c1
    assert "合格するまで mt5_backtest は使えません" in c1
    assert "構造検査に違反したまま" in _out(h, "mt5_backtest")[0]
    assert "✅ 構造検査 合格" in c2 and c2.startswith("[成功]"), c2
    assert not MT5._STRUCT_STATE[next(iter(MT5._STRUCT_STATE))]["blocked"]
    args = (proj / ".apercode" / "structure_check" / "Main.mq5.args").read_text()
    assert args.startswith("--json") and "--mtf single" in args and "--tf H1" in args


@needs_bwrap
def test_gives_up_blocking_after_max_rounds(h, mt5env):
    over, _ = mt5env
    proj = h.project(with_test=False, files={"ea/Main.mq5": "// BAD\nvoid OnTick(){}\n"})
    script = [("tools", [call("mt5_compile", path="ea/Main.mq5")]) for _ in range(3)] + [("text", "done")]
    agent, llm, store, s = h.make(script, proj, {**over, "mt5.structure_max_rounds": 2, "stuck.repeat_calls": 9})
    h.run(agent, s, "EA をコンパイルして")
    outs = _out(h, "mt5_compile")
    assert "（2/2 回目）" in outs[1] and "上限（2 回）を超えました" in outs[2]
    assert not any(v["blocked"] for v in MT5._STRUCT_STATE.values())


@needs_bwrap
def test_non_ea_and_missing_skill_are_not_blocked(h, mt5env):
    over, skills = mt5env
    proj = h.project(with_test=False, files={"ind/Ind.mq5": "// BAD\nint OnCalculate(){return 0;}\n",
                                             "ea/Main.mq5": "// BAD\nvoid OnTick(){}\n"})
    shutil.rmtree(skills / "mql5-structure-check")
    script = [("tools", [call("mt5_compile", path="ind/Ind.mq5")]), ("tools", [call("mt5_compile", path="ea/Main.mq5")]),
              ("text", "done")]
    agent, llm, store, s = h.make(script, proj, over)
    h.run(agent, s, "コンパイルして")
    ind, ea = _out(h, "mt5_compile")
    assert "構造検査" not in ind and ind.startswith("[成功]")
    assert ea.startswith("[成功]") and "構造検査" not in ea and "mql5-structure-check" not in ea, ea   # v2.11.4: スキルが無ければ触れない
    assert "EA の基本チェック" in ea and "NO_ORDER" in ea


@needs_bwrap
def test_structure_check_on_blocks_when_skill_missing(h, mt5env):
    over, skills = mt5env
    shutil.rmtree(skills / "mql5-structure-check")
    proj = h.project(with_test=False, files={"ea/Main.mq5": "void OnTick(){}\n"})
    agent, llm, store, s = h.make([("tools", [call("mt5_compile", path="ea/Main.mq5")]), ("text", "done")], proj,
                                  {**over, "mt5.structure_check": "on"})
    h.run(agent, s, "コンパイルして")
    assert "❌ 構造検査を実行できませんでした" in _out(h, "mt5_compile")[0]


# ---------------------------------------------------------------- v2.11.3: 保存した時点で検査・EA はレビューしない
@needs_bwrap
def test_structure_is_checked_when_ea_is_saved(h, mt5env):
    over, _ = mt5env
    proj = h.project(with_test=False)
    script = [("tools", [call("write_file", path="ea/Main.mq5", content="// BAD\nvoid OnTick(){}\n")]),
              ("tools", [call("edit_file", path="ea/Main.mq5", old_string="// BAD", new_string="// fixed")]),
              ("tools", [call("write_file", path="ind/Ind.mq5", content="// BAD\nint OnCalculate(){return 0;}\n")]),
              ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {**over, "verify.create_missing_tests": False})
    h.run(agent, s, "EA を書いて")
    tool = [m["content"] for m in store.load(s.id).messages if m["role"] == "tool"]
    w, e, ind = tool[0], tool[1], tool[2]
    assert "構造検査（保存時）" in w and "❌ 違反 1 件: NO_NEW_BAR_CHECK" in w and "コンパイルの前に" in w, w
    assert "✅ 合格" in e, e
    assert "構造検査" not in ind                                         # インジケーターは検査しない
    assert [v for v in h.of("verify") if "EA のチェック（保存時）" in v.get("text", "")]
    assert not MT5._STRUCT_STATE                                         # 保存時の検査は差し戻しの回数に数えない


@needs_bwrap
def test_save_check_reuses_options_given_to_compile(h, mt5env):
    over, _ = mt5env
    proj = h.project(with_test=False, files={"ea/Main.mq5": "void OnTick(){}\n"})
    script = [("tools", [call("mt5_compile", path="ea/Main.mq5", mtf="mtf", tf="H4")]),
              ("tools", [call("edit_file", path="ea/Main.mq5", old_string="void", new_string="// x\nvoid")]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {**over, "verify.create_missing_tests": False})
    h.run(agent, s, "EA を直して")
    args = (proj / ".apercode" / "structure_check" / "Main.mq5.args").read_text()
    assert "--mtf mtf" in args and "--tf H4" in args, args


def test_review_skips_mql_files(h):
    proj = h.project(with_test=False)
    ea = "void OnTick()\n{\n" + "".join(f"   double v{i} = {i};\n" for i in range(80)) + "}\n"
    script = [("tools", [call("write_file", path="ea/Big.mq5", content=ea)]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "verify.create_missing_tests": False,
                                                 "verify.review.enabled": True, "verify.review.min_changed_lines": 50})
    h.run(agent, s, "EA を書いて")
    assert not [e for e in h.of("subagent_start") if e.get("mode") == "review"]
    h.events.clear()
    py = "".join(f"V{i} = {i}\n" for i in range(80))
    agent, llm, store, s = h.make([("tools", [call("write_file", path="big.py", content=py)]), ("text", "done")] + [("text", '{"ok": true, "issues": []}')] * 3,
                                  proj, {"phases.enabled": False, "verify.create_missing_tests": False, "verify.review.enabled": True,
                                         "verify.review.min_changed_lines": 50})
    h.run(agent, s, "書いて")
    assert [e for e in h.of("subagent_start") if e.get("mode") == "review"]       # Python は従来どおりレビューする


# ---------------------------------------------------------------- v2.11.4: スキルが無い環境（一般のユーザー）
def test_basic_check_without_skill_on_save(h):
    proj = h.project(with_test=False)
    bad = ("#include <Trade/Trade.mqh>\nCTrade trade;\nint h;\n"
           "void OnTick(){ h=iMA(_Symbol,_Period,20,0,MODE_EMA,PRICE_CLOSE); double b[]; CopyBuffer(h,0,0,2,b);"
           " if(b[0]>b[1]) trade.Buy(0.1, _Symbol, 0, 0, 0); }\n")
    good = ("#include <Trade/Trade.mqh>\nCTrade trade;\ninput long InpMagic = 1;\nint h;\n"
            "int OnInit(){ trade.SetExpertMagicNumber(InpMagic); h=iMA(_Symbol,_Period,20,0,MODE_EMA,PRICE_CLOSE);"
            " if(h==INVALID_HANDLE) return(INIT_FAILED); return(INIT_SUCCEEDED); }\n"
            "void OnDeinit(const int r){ IndicatorRelease(h); }\n"
            "void OnTick(){ static datetime last=0; datetime t=iTime(_Symbol,_Period,0); if(t==last) return; last=t;\n"
            " if(PositionsTotal()>0) return; double b[]; if(CopyBuffer(h,0,1,2,b)<2) return;\n"
            " double sl=SymbolInfoDouble(_Symbol,SYMBOL_BID)-0.5; if(b[0]>b[1]) trade.Buy(0.1,_Symbol,0,sl,0); }\n")
    script = [("tools", [call("write_file", path="ea/A.mq5", content=bad)]),
              ("tools", [call("write_file", path="ea/B.mq5", content=good)]), ("text", "done")]
    agent, llm, store, s = h.make(script, proj, {"phases.enabled": False, "verify.create_missing_tests": False,
                                                 "skills.dir": str(h.root / "noskills")})
    h.run(agent, s, "EA を書いて")
    a, b = [m["content"] for m in store.load(s.id).messages if m["role"] == "tool"]
    for x in ("NO_ONINIT", "NO_MAGIC", "NO_POSITION_CHECK", "NO_STOP_LOSS", "NO_NEW_BAR_CHECK", "HANDLE_LEAK", "NO_HANDLE_CHECK",
              "NO_CLOSED_BAR_REF"):
        assert x in a, (x, a)
    assert "構造検査" not in a and "参考" in a
    assert "✅ EA の基本の形は揃っています" in b, b


def test_structure_rules_in_prompt_only_with_skill(h, tmp_path):
    proj = h.project(with_test=False)
    agent, llm, store, s = h.make([("text", "ok")], proj, {"phases.enabled": False, "skills.dir": str(tmp_path / "none")})
    h.run(agent, s, "こんにちは")
    assert "InpExecutionTF" not in llm.systems[-1] and "EA の基本の形" in llm.systems[-1]
    sk = tmp_path / "skills" / "mql5-structure-check"
    sk.mkdir(parents=True)
    (sk / "SKILL.md").write_text("---\nname: mql5-structure-check\ndescription: EA の構造検査\n---\n手順\n")
    (sk / "check.py").write_text("print('[]')\n")
    agent, llm, store, s = h.make([("text", "ok")], proj, {"phases.enabled": False, "skills.dir": str(tmp_path / "skills")})
    h.run(agent, s, "こんにちは")
    assert "EA の構造検査（スキル mql5-structure-check）" in llm.systems[-1] and "InpExecutionTF" in llm.systems[-1]
