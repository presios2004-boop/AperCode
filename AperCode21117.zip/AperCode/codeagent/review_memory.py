"""クラウド AI のレビューの指摘を、確認済みの教訓として経験メモリに保存する（v2.11.17）。

クラウド AI の返答は外部の内容なので、通常の振り返りでは「未確認」の教訓になり、ユーザーが確認するまでプロンプトに入らない。
レビューの指摘は AperCode の成長に役立つので、ユーザーの設定（memory.review_lessons）で、確認済みとして直接保存する。
"""
from __future__ import annotations

from pathlib import Path

EXT_TAGS = {".mq5": ["mql5", "ea"], ".mqh": ["mql5"], ".mq4": ["mql4", "ea"], ".py": ["python"], ".js": ["javascript"],
            ".mjs": ["javascript"], ".ts": ["typescript"], ".tsx": ["typescript", "react"], ".jsx": ["javascript", "react"],
            ".html": ["html"], ".css": ["css"], ".sh": ["shell"], ".go": ["go"], ".rs": ["rust"], ".java": ["java"],
            ".c": ["c"], ".cpp": ["cpp"], ".cs": ["csharp"], ".sql": ["sql"]}
LANG_LABEL = {".mq5": "MQL5", ".mqh": "MQL5", ".mq4": "MQL4", ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
              ".tsx": "TypeScript", ".jsx": "JavaScript", ".html": "HTML", ".css": "CSS", ".sh": "シェル"}
SEVERITY_RANK = {"high": 3, "medium": 2, "low": 1}


async def save_review_lessons(store, cfg, issues: list[dict], project: str | Path, model: str = "", task: str = "") -> list[str]:
    """指摘（high / medium）を確認済みの教訓として保存する。保存した教訓の文面のリスト（重複は除く）。"""
    if store is None or str(cfg.get("memory.review_lessons", "cloud")).lower() in ("off", "false", "0"):
        return []
    min_rank = SEVERITY_RANK.get(str(cfg.get("memory.review_min_severity", "medium")).lower(), 2)
    limit = int(cfg.get("memory.review_max_lessons", 10) or 10)
    saved: list[str] = []
    for it in issues:
        if len(saved) >= limit:
            break
        sev = str(it.get("severity") or "medium").lower()
        if SEVERITY_RANK.get(sev, 2) < min_rank:
            continue
        problem = str(it.get("problem") or "").strip()
        fix = str(it.get("fix") or "").strip()
        if len(problem) < 6:
            continue
        ext = Path(str(it.get("file") or "")).suffix.lower()
        lang = LANG_LABEL.get(ext, "")
        lesson = (f"{lang} のコードでの注意: " if lang else "") + problem + (f" → 対処: {fix}" if fix else "")
        lesson += f"（クラウド AI のレビューの指摘{'・' + model if model else ''}）"
        tags = ["review", "cloud-review", sev] + EXT_TAGS.get(ext, [])
        try:
            m, dup = await store.add(lesson=lesson[:800], situation=str(task or "")[:300], action=fix[:400], outcome="failure",
                                     tags=tags, project=str(project), source="cloud_review", verified=1,
                                     dedup_threshold=float(cfg.get("memory.dedup_threshold", 0.92)))
        except Exception:  # noqa: BLE001  保存できなくても作業は止めない
            continue
        if m is not None and not dup:
            saved.append(lesson)
    return saved
