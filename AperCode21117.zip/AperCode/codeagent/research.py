"""相場分析（v2.11.0）: 集めた資料から、根拠付きでシナリオを作る仕組み。

LLM に任せるのは「資料を 1 本ずつ読んで、決まった形（ノート）に書き出す」ことと「集計結果を見てシナリオを書く」ことだけ。
資料を並べて比べる・数える・計算するのは、このモジュール（ハーネス）が行う。
  1. research_note     … 資料 1 本 → ノート（発行元・日付・見通し・目標水準・根拠・イベント・原文の引用）。
                           引用は、このセッションで実際に読んだ本文に含まれているかを確かめる（作り話を防ぐ）
  2. research_summary  … ノートを集計（見通しの票数と重み付きの合意、目標水準の中央値とばらつき、よく挙がる根拠、
                           イベントの日程、資料どうしの食い違い、古い資料・引用を確かめられなかった資料）
  3. market_stats      … 価格データ（CSV）から、変動率・レンジ・トレンドの強さ・相場の型・よく止まる水準を計算し、
                           目標水準までの距離を ATR で測る（資料の主張を数字で確かめる）
  4. research_scenarios… メイン／リスクのシナリオを決まった型で保存（前提・発動条件・否定条件・相場の型・期間・戦略・根拠のノート）
置き場: <作業ディレクトリ>/research/<テーマ>/（notes/*.json, summary.md, scenarios.md）、価格は market_data/
"""
from __future__ import annotations

import csv
import json
import math
import re
import statistics as stats
import time
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path

STANCES = {"up": 1, "down": -1, "range": 0, "neutral": 0}
STANCE_JA = {"up": "上昇", "down": "下落", "range": "レンジ", "neutral": "中立"}
SOURCE_WEIGHT = {"official": 1.0, "bank": 1.0, "analyst": 1.0, "broker": 0.8, "media": 0.7, "blog": 0.4, "other": 0.5}
CONVICTION_WEIGHT = {"high": 1.0, "medium": 0.7, "low": 0.4}
HALF_LIFE_DAYS = 30
REGIMES = ("trend_up", "trend_down", "range", "high_volatility")
REGIME_JA = {"trend_up": "上昇トレンド", "trend_down": "下降トレンド", "range": "レンジ", "high_volatility": "急変・高ボラ"}
STRATEGY_HINT = {
    "trend_up": "順張り（押し目買い・ブレイクアウト）。移動平均の向き・高値更新を条件に、ATR でストップ",
    "trend_down": "順張り（戻り売り・ブレイクアウト）。移動平均の向き・安値更新を条件に、ATR でストップ",
    "range": "逆張り（レンジの上下限付近で反転を狙う）。レンジを抜けたら損切り・停止",
    "high_volatility": "ロットを小さく、イベント前は手仕舞い・新規停止。ストップは広めの ATR、急変後の戻りを狙う場合は確認を待つ",
}


class ResearchError(ValueError):
    pass


def _slug(s: str) -> str:
    s = re.sub(r"[^\w.-]+", "_", unicodedata.normalize("NFKC", s or "").strip()).strip("_")
    return s[:60] or "topic"


def topic_dir(project: Path, topic: str) -> Path:
    return Path(project) / "research" / _slug(topic)


def _norm(s: str) -> str:
    """引用の照合用: 全角半角・空白・記号の違いを無視する。"""
    s = unicodedata.normalize("NFKC", s or "").casefold()
    return re.sub(r"[\s　「」『』\"'“”‘’()（）.,、。・:：;；!！?？-]+", "", s)


def _date(s) -> datetime | None:
    if not s:
        return None
    s = str(s).strip().replace("/", "-").replace(".", "-")
    for fmt in ("%Y-%m-%d", "%Y-%m", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s[:len(fmt) + 2].strip(), fmt)
        except ValueError:
            continue
    m = re.match(r"(\d{4})\D+(\d{1,2})(?:\D+(\d{1,2}))?", s)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3) or 1))
        except ValueError:
            return None
    return None


def _num(v) -> float | None:
    try:
        return float(str(v).replace(",", "").replace("円", "").strip())
    except (TypeError, ValueError):
        return None


# ------------------------------------------------------------------ 1. ノート
def save_note(project: Path, note: dict, fetched: dict | None = None) -> tuple[Path, dict, list[str]]:
    """資料 1 本のノートを検証して保存する。(パス, 保存した内容, 注意) を返す。"""
    topic = str(note.get("topic") or "").strip()
    if not topic:
        raise ResearchError("topic（例: USDJPY）は必須です")
    src = dict(note.get("source") or {})
    if not (src.get("institution") or src.get("title")):
        raise ResearchError("source.institution（発行元）か source.title が必要です")
    if not (src.get("url") or src.get("path")):
        raise ResearchError("source.url（Web）か source.path（ファイル）が必要です（どこから読んだか）")
    stance = str(note.get("stance") or "").lower()
    if stance not in STANCES:
        raise ResearchError("stance は up（上昇）/ down（下落）/ range（レンジ）/ neutral（方向感なし）のどれか。topic の価格についての見通し")
    warns: list[str] = []
    stype = str(src.get("type") or "other").lower()
    if stype not in SOURCE_WEIGHT:
        warns.append(f"source.type「{stype}」は不明のため other として扱います（official/bank/analyst/broker/media/blog）")
        stype = "other"
    src["type"] = stype
    pub = _date(src.get("published"))
    if not pub:
        warns.append("source.published（発行日）が読めません。古さを判定できないため、集計では重みを下げます")
    conv = str(note.get("conviction") or "medium").lower()
    if conv not in CONVICTION_WEIGHT:
        conv = "medium"
    targets = []
    for t in note.get("targets") or []:
        lv = _num(t.get("level") if isinstance(t, dict) else t)
        if lv is None:
            continue
        targets.append({"level": lv, "by": str(t.get("by") or "") if isinstance(t, dict) else "",
                        "kind": str(t.get("kind") or "target") if isinstance(t, dict) else "target"})
    drivers = []
    for d in note.get("drivers") or []:
        if isinstance(d, str):
            d = {"factor": d}
        f = str(d.get("factor") or "").strip()
        if f:
            dr = str(d.get("effect") or d.get("direction") or "").lower()
            drivers.append({"factor": f[:80], "effect": dr if dr in STANCES else "", "note": str(d.get("note") or "")[:200]})
    events = []
    for e in note.get("events") or []:
        if isinstance(e, dict) and (e.get("name") or e.get("date")):
            events.append({"date": str(e.get("date") or ""), "name": str(e.get("name") or "")[:100],
                           "impact": str(e.get("impact") or "")[:100]})
    quotes = [str(q).strip() for q in note.get("quotes") or [] if str(q).strip()]
    if not quotes:
        raise ResearchError("quotes（見通しの根拠になる原文の引用。1〜5 個、資料の文をそのまま）は必須です")
    # 引用が、実際に読んだ本文にあるか
    key = str(src.get("url") or src.get("path"))
    body = ""
    for k, v in (fetched or {}).items():
        if k == key or k.rstrip("/") == key.rstrip("/") or (key and key in k) or (k and k in key):
            body += "\n" + v
    nb = _norm(body)
    checked = []
    for q in quotes[:8]:
        ok = bool(nb) and _norm(q)[:120] in nb
        checked.append({"text": q[:400], "found": ok})
    found = sum(1 for c in checked if c["found"])
    if not body:
        warns.append("この資料の本文をこのセッションで読んだ記録がないため、引用を確かめられませんでした（fetch_url / read_document で読んでから書く）")
    elif found < len(checked):
        warns.append(f"引用 {len(checked) - found} 個が本文に見つかりません。原文どおりに直すか、外してください（言い換えは引用にしない）")
    data = {"id": "", "topic": topic, "source": src, "stance": stance, "horizon": str(note.get("horizon") or "")[:40],
            "conviction": conv, "targets": targets, "drivers": drivers, "events": events, "quotes": checked,
            "quotes_verified": found, "summary": str(note.get("summary") or "")[:1200],
            "saved": time.strftime("%Y-%m-%d %H:%M")}
    d = topic_dir(project, topic) / "notes"
    d.mkdir(parents=True, exist_ok=True)
    base = _slug(f"{src.get('institution') or src.get('title')}_{(pub or datetime.now()).strftime('%Y%m%d')}")
    path, i = d / f"{base}.json", 1
    same = [p for p in d.glob(f"{base}*.json") if json.loads(p.read_text(encoding="utf-8")).get("source", {}).get("url") == src.get("url")
            and src.get("url")]
    if same:
        path = same[0]                                   # 同じ資料なら上書き
    while path.exists() and not same:
        i += 1
        path = d / f"{base}_{i}.json"
    data["id"] = path.stem
    path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    return path, data, warns


def load_notes(project: Path, topic: str) -> list[dict]:
    d = topic_dir(project, topic) / "notes"
    out = []
    for p in sorted(d.glob("*.json")) if d.is_dir() else []:
        try:
            out.append(json.loads(p.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            continue
    return out


# ------------------------------------------------------------------ 2. 集計
def _weight(n: dict, now: datetime) -> tuple[float, float]:
    """(重み, 何日前か)。発行元の種類 × 確信度 × 新しさ（半減期 30 日）× 引用を確かめられた割合。"""
    pub = _date(n.get("source", {}).get("published"))
    age = (now - pub).days if pub else 60
    w = SOURCE_WEIGHT.get(n.get("source", {}).get("type", "other"), 0.5) * CONVICTION_WEIGHT.get(n.get("conviction"), 0.7)
    w *= 0.5 ** (max(age, 0) / HALF_LIFE_DAYS)
    q = n.get("quotes") or []
    w *= 0.5 + 0.5 * (n.get("quotes_verified", 0) / len(q)) if q else 0.5
    return w, age


def summarize(project: Path, topic: str, now: datetime | None = None, max_age_days: int = 120) -> tuple[dict, str]:
    now = now or datetime.now()
    notes = load_notes(project, topic)
    if not notes:
        raise ResearchError(f"テーマ {topic} のノートがありません。資料を読んで research_note で書き出してください")
    rows, stale = [], []
    for n in notes:
        w, age = _weight(n, now)
        (stale if age > max_age_days else rows).append((n, w, age))
    use = rows or [(n, w, a) for n, w, a in stale]
    tally = {k: 0 for k in STANCES}
    score = wsum = 0.0
    for n, w, _ in use:
        tally[n["stance"]] += 1
        score += STANCES[n["stance"]] * w
        wsum += w
    consensus = score / wsum if wsum else 0.0
    lean = "up" if consensus > 0.2 else "down" if consensus < -0.2 else "range"
    agreement = (max(tally["up"], tally["down"], tally["range"] + tally["neutral"]) / len(use)) if use else 0
    levels = [t["level"] for n, _, _ in use for t in n.get("targets", []) if t.get("kind", "target") == "target"]
    lv = {}
    if levels:
        lv = {"n": len(levels), "median": stats.median(levels), "min": min(levels), "max": max(levels),
              "spread": max(levels) - min(levels)}
        if len(levels) >= 4:
            q = stats.quantiles(levels, n=4)
            lv["q1"], lv["q3"] = q[0], q[2]
    sr = sorted({round(t["level"], 2) for n, _, _ in use for t in n.get("targets", []) if t.get("kind") in ("support", "resistance")})
    drv: dict[str, dict] = {}
    for n, w, _ in use:
        for d in n.get("drivers", []):
            k = _norm(d["factor"])[:24] or d["factor"]
            e = drv.setdefault(k, {"factor": d["factor"], "count": 0, "up": 0, "down": 0, "range": 0, "sources": []})
            e["count"] += 1
            if d.get("effect") in ("up", "down"):
                e[d["effect"]] += 1
            elif d.get("effect") in ("range", "neutral"):
                e["range"] += 1
            e["sources"].append(n["id"])
    drivers = sorted(drv.values(), key=lambda x: -x["count"])[:15]
    events = []
    for n, _, _ in use:
        for e in n.get("events", []):
            events.append({**e, "source": n["id"]})
    events.sort(key=lambda e: (_date(e["date"]) or datetime.max, e["name"]))
    ups = [n["id"] for n, _, _ in use if n["stance"] == "up"]
    downs = [n["id"] for n, _, _ in use if n["stance"] == "down"]
    conflicts = []
    if ups and downs:
        conflicts.append(f"見通しが割れています: 上昇 {len(ups)} 本（{', '.join(ups[:4])}）／下落 {len(downs)} 本（{', '.join(downs[:4])}）")
    for d in drivers:
        if d["up"] and d["down"]:
            conflicts.append(f"同じ要因「{d['factor']}」の効き方の評価が割れています（上昇 {d['up']}・下落 {d['down']}）")
    if lv and lv.get("median") and lv["spread"] > 0.06 * lv["median"]:
        conflicts.append(f"目標水準のばらつきが大きい（{lv['min']:g}〜{lv['max']:g}）")
    unverified = [n["id"] for n, _, _ in use if n.get("quotes") and n.get("quotes_verified", 0) == 0]
    types = {}
    for n, _, _ in use:
        types[n["source"]["type"]] = types.get(n["source"]["type"], 0) + 1
    data = {"topic": topic, "generated": now.strftime("%Y-%m-%d %H:%M"), "notes": len(notes), "used": len(use),
            "stale": [n["id"] for n, _, _ in stale], "source_types": types, "tally": tally,
            "consensus": round(consensus, 3), "lean": lean, "agreement": round(agreement, 2), "targets": lv,
            "support_resistance": sr[:20], "drivers": drivers, "events": events[:30], "conflicts": conflicts,
            "unverified": unverified,
            "weights": [{"id": n["id"], "weight": round(w, 3), "age_days": a, "stance": n["stance"]} for n, w, a in use]}
    d = topic_dir(project, topic)
    (d / "summary.json").write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    md = _summary_md(data)
    (d / "summary.md").write_text(md, encoding="utf-8")
    return data, md


def _summary_md(s: dict) -> str:
    L = [f"# 相場資料の集計: {s['topic']}（{s['generated']}）", "",
         f"- 資料: {s['used']} 本を集計（全 {s['notes']} 本。古すぎて除外: {len(s['stale'])} 本）。種類: " +
         ", ".join(f"{k} {v}" for k, v in s["source_types"].items()),
         f"- 見通しの票: " + " / ".join(f"{STANCE_JA[k]} {v}" for k, v in s["tally"].items() if v),
         f"- 重み付きの合意: {s['consensus']:+.2f}（+1 = 全員上昇、-1 = 全員下落）→ 傾き: **{STANCE_JA[s['lean']]}**、"
         f"一致度 {s['agreement']:.0%}"]
    t = s["targets"]
    if t:
        L.append(f"- 目標水準: 中央値 {t['median']:g}（{t['min']:g}〜{t['max']:g}、{t['n']} 件" +
                 (f"、四分位 {t['q1']:g}〜{t['q3']:g}" if "q1" in t else "") + "）")
    if s["support_resistance"]:
        L.append("- 資料が挙げた支持線・抵抗線: " + ", ".join(f"{x:g}" for x in s["support_resistance"]))
    L += ["", "## よく挙がる要因（多い順）"]
    for d in s["drivers"]:
        eff = " / ".join(f"{STANCE_JA[k]} {d[k]}" for k in ("up", "down", "range") if d[k])
        L.append(f"- {d['factor']}: {d['count']} 本" + (f"（効き方: {eff}）" if eff else ""))
    if s["events"]:
        L += ["", "## イベントの日程"]
        L += [f"- {e['date'] or '日付不明'} {e['name']}" + (f"（{e['impact']}）" if e["impact"] else "") + f" ← {e['source']}"
              for e in s["events"]]
    if s["conflicts"]:
        L += ["", "## 食い違い（リスクシナリオの材料）"] + [f"- {c}" for c in s["conflicts"]]
    if s["unverified"]:
        L += ["", "## 注意", f"- 引用を本文で確かめられなかった資料（重みを下げています）: {', '.join(s['unverified'])}"]
    L += ["", "## 資料ごとの重み", "| ノート | 見通し | 何日前 | 重み |", "|---|---|---|---|"]
    L += [f"| {w['id']} | {STANCE_JA[w['stance']]} | {w['age_days']} | {w['weight']} |" for w in s["weights"]]
    L += ["", "次は: market_stats で価格データと照らし合わせ、research_scenarios でメインとリスクのシナリオを書く"]
    return "\n".join(L) + "\n"


# ------------------------------------------------------------------ 3. 価格データ
def load_rates(path: Path) -> list[dict]:
    """CSV を読む。AperCode の書き出し（time,open,high,low,close,...）と、MT5 の画面からの書き出し（<DATE> <TIME> <OPEN> ...）の両方。"""
    text = Path(path).read_bytes()
    for enc in ("utf-8-sig", "utf-16", "cp932"):
        try:
            text = text.decode(enc)
            break
        except (UnicodeDecodeError, AttributeError):
            continue
    if isinstance(text, bytes):
        text = text.decode("latin-1")
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if not lines:
        raise ResearchError(f"空のファイルです: {path}")
    delim = "\t" if lines[0].count("\t") > lines[0].count(",") else ","
    head = [h.strip().strip("<>").lower() for h in next(csv.reader([lines[0]], delimiter=delim))]
    rows = []
    for rec in csv.reader(lines[1:], delimiter=delim):
        r = dict(zip(head, rec))
        ts = r.get("time") or r.get("datetime") or r.get("date", "")
        if "date" in r and "time" in r and r.get("date") and ":" in r.get("time", ""):
            ts = f"{r['date']} {r['time']}"
        dt = _date(ts) if not re.match(r"\d{4}\D\d{2}\D\d{2}\D\d{2}:\d{2}", ts) else \
            datetime.strptime(re.sub(r"\D", "-", ts[:16])[:16], "%Y-%m-%d-%H-%M")
        try:
            o, h, lo, c = (float(r[k]) for k in ("open", "high", "low", "close"))
        except (KeyError, ValueError):
            continue
        if dt:
            rows.append({"t": dt, "o": o, "h": h, "l": lo, "c": c})
    rows.sort(key=lambda x: x["t"])
    if len(rows) < 30:
        raise ResearchError(f"価格データが少なすぎます（{len(rows)} 本）。最低 30 本、できれば数百本以上")
    return rows


def _atr(rows: list[dict], n: int = 14) -> list[float]:
    trs, out = [], []
    for i, r in enumerate(rows):
        pc = rows[i - 1]["c"] if i else r["c"]
        trs.append(max(r["h"] - r["l"], abs(r["h"] - pc), abs(r["l"] - pc)))
        out.append(sum(trs[-n:]) / min(len(trs), n))
    return out


def _er(closes: list[float]) -> float:
    """効率比（0 = 行ったり来たり、1 = 一直線）。トレンドの強さの目安。"""
    if len(closes) < 2:
        return 0.0
    path = sum(abs(closes[i] - closes[i - 1]) for i in range(1, len(closes)))
    return abs(closes[-1] - closes[0]) / path if path else 0.0


def _regime(seg: list[dict], atr: float, vol_hi: float) -> str:
    closes = [r["c"] for r in seg]
    er = _er(closes)
    rng = max(r["h"] for r in seg) - min(r["l"] for r in seg)
    seg_atr = statistics_mean([r["h"] - r["l"] for r in seg])
    if vol_hi and seg_atr > vol_hi:
        return "high_volatility"
    if er >= 0.3:
        return "trend_up" if closes[-1] > closes[0] else "trend_down"
    return "range" if rng else "range"


def statistics_mean(xs):
    return sum(xs) / len(xs) if xs else 0.0


def _pip(price: float) -> float:
    return 0.01 if price > 20 else 0.0001


def _levels(rows: list[dict], atr: float, w: int = 10, top: int = 6) -> list[tuple[float, int]]:
    """よく止まった水準（局所的な高値・安値を ATR の半分の幅でまとめ、触れた回数が多い順）。"""
    piv = []
    for i in range(w, len(rows) - w):
        win = rows[i - w:i + w + 1]
        if rows[i]["h"] == max(r["h"] for r in win):
            piv.append(rows[i]["h"])
        if rows[i]["l"] == min(r["l"] for r in win):
            piv.append(rows[i]["l"])
    piv.sort()
    groups: list[list[float]] = []
    for p in piv:
        if groups and p - groups[-1][-1] <= atr * 0.5:
            groups[-1].append(p)
        else:
            groups.append([p])
    lv = sorted(((statistics_mean(g), len(g)) for g in groups), key=lambda x: -x[1])
    return lv[:top]


def market_stats(path: Path, topic: str = "", project: Path | None = None) -> tuple[dict, str]:
    rows = load_rates(path)
    last = rows[-1]
    atrs = _atr(rows)
    atr = atrs[-1]
    pip = _pip(last["c"])
    gaps = sorted((rows[i]["t"] - rows[i - 1]["t"]).total_seconds() for i in range(1, len(rows)))
    bar_sec = gaps[len(gaps) // 2] or 3600
    tf = {60: "M1", 300: "M5", 900: "M15", 1800: "M30", 3600: "H1", 14400: "H4", 86400: "D1", 604800: "W1"}.get(int(bar_sec), f"{bar_sec / 60:.0f}分")
    per_year = 365 * 86400 / bar_sec * (5 / 7 if bar_sec < 86400 else 1)
    rets = [math.log(rows[i]["c"] / rows[i - 1]["c"]) for i in range(1, len(rows)) if rows[i - 1]["c"] > 0]

    def since(days):
        t0 = last["t"] - timedelta(days=days)
        return [r for r in rows if r["t"] >= t0]
    windows = {}
    for label, days in (("1週", 7), ("1か月", 30), ("3か月", 91), ("6か月", 182)):
        seg = since(days)
        if len(seg) >= 5 and (rows[0]["t"] <= last["t"] - timedelta(days=days * 0.9)):
            hi, lo = max(r["h"] for r in seg), min(r["l"] for r in seg)
            windows[label] = {"change_pct": round((last["c"] / seg[0]["c"] - 1) * 100, 2), "high": hi, "low": lo,
                              "range_pips": round((hi - lo) / pip), "pos_in_range": round((last["c"] - lo) / (hi - lo) * 100) if hi > lo else 50,
                              "er": round(_er([r["c"] for r in seg]), 2)}
    vol = stats.pstdev(rets[-int(min(len(rets), per_year / 12 * 3)):]) * math.sqrt(per_year) * 100 if len(rets) > 10 else 0
    ma50 = statistics_mean([r["c"] for r in rows[-50:]])
    ma200 = statistics_mean([r["c"] for r in rows[-200:]]) if len(rows) >= 200 else None
    # 月ごとの相場の型
    months: dict[str, list[dict]] = {}
    for r in rows:
        months.setdefault(r["t"].strftime("%Y-%m"), []).append(r)
    bar_ranges = sorted(r["h"] - r["l"] for r in rows)
    vol_hi = bar_ranges[int(len(bar_ranges) * 0.85)] if bar_ranges else 0
    regimes = []
    for m, seg in months.items():
        if len(seg) >= 10:
            reg = _regime(seg, atr, vol_hi)
            regimes.append({"month": m, "regime": reg, "change_pct": round((seg[-1]["c"] / seg[0]["o"] - 1) * 100, 2),
                            "range_pips": round((max(r["h"] for r in seg) - min(r["l"] for r in seg)) / pip),
                            "er": round(_er([r["c"] for r in seg]), 2)})
    levels = _levels(rows[-min(len(rows), 1500):], atr)
    day_atr = atr * math.sqrt(86400 / bar_sec) if bar_sec < 86400 else atr
    data = {"file": str(path), "timeframe": tf, "bars": len(rows), "from": rows[0]["t"].strftime("%Y-%m-%d"),
            "to": last["t"].strftime("%Y-%m-%d %H:%M"), "last": last["c"], "atr14": atr, "atr14_pips": round(atr / pip, 1),
            "daily_atr_pips_est": round(day_atr / pip, 1), "realized_vol_pct": round(vol, 1), "ma50": ma50, "ma200": ma200,
            "windows": windows, "regimes": regimes, "levels": [{"level": round(lv, 3), "touches": n} for lv, n in levels]}
    # 資料の目標水準までの距離
    if project and topic:
        sj = topic_dir(project, topic) / "summary.json"
        if sj.exists():
            s = json.loads(sj.read_text(encoding="utf-8"))
            t = s.get("targets") or {}
            if t.get("median"):
                data["target_check"] = {k: {"level": t[k], "distance_pips": round((t[k] - last["c"]) / pip),
                                            "daily_atrs": round((t[k] - last["c"]) / (day_atr or 1), 1)}
                                        for k in ("median", "min", "max", "q1", "q3") if k in t}
    md = _stats_md(data)
    out = Path(path).with_name(Path(path).stem + "_stats.md")
    out.write_text(md, encoding="utf-8")
    data["report"] = str(out)
    return data, md


def _stats_md(d: dict) -> str:
    L = [f"# 価格データの分析: {Path(d['file']).name}", "",
         f"- 足: {d['timeframe']}、{d['bars']} 本（{d['from']} 〜 {d['to']}）、最新値 {d['last']:g}",
         f"- ATR(14): {d['atr14_pips']} pips（1 日あたりの目安 {d['daily_atr_pips_est']} pips）、実現ボラティリティ（年率） {d['realized_vol_pct']}%",
         f"- 移動平均: MA50 {d['ma50']:.3f}" + (f" / MA200 {d['ma200']:.3f}（{'MA50 が上' if d['ma50'] > d['ma200'] else 'MA50 が下'}）" if d["ma200"] else ""),
         "", "## 期間ごと", "| 期間 | 変化率 | 高値 | 安値 | 値幅 (pips) | レンジ内の位置 | 効率比 |", "|---|---|---|---|---|---|---|"]
    for k, w in d["windows"].items():
        L.append(f"| {k} | {w['change_pct']:+.2f}% | {w['high']:g} | {w['low']:g} | {w['range_pips']} | {w['pos_in_range']}% | {w['er']} |")
    L += ["", "（効率比: 0.3 以上ならトレンド寄り、それ未満は行ったり来たり＝レンジ寄り）", "", "## 月ごとの相場の型",
          "| 月 | 型 | 変化率 | 値幅 (pips) | 効率比 |", "|---|---|---|---|---|"]
    L += [f"| {r['month']} | {REGIME_JA[r['regime']]} | {r['change_pct']:+.2f}% | {r['range_pips']} | {r['er']} |" for r in d["regimes"]]
    L += ["", "## よく止まった水準（触れた回数が多い順）"] + [f"- {x['level']:g}（{x['touches']} 回）" for x in d["levels"]]
    if d.get("target_check"):
        L += ["", "## 資料の目標水準までの距離"]
        L += [f"- {k}: {v['level']:g} → {v['distance_pips']:+d} pips（1 日の値幅の {v['daily_atrs']:+g} 日分）" for k, v in d["target_check"].items()]
    L += ["", "## 相場の型と戦略の対応（EA を作るときの目安）"] + [f"- {REGIME_JA[k]}: {v}" for k, v in STRATEGY_HINT.items()]
    return "\n".join(L) + "\n"


# ------------------------------------------------------------------ 4. シナリオ
SCEN_FIELDS = ("name", "premise", "triggers", "invalidation", "regime", "horizon", "strategy", "evidence")


def save_scenarios(project: Path, topic: str, scenarios: list[dict]) -> tuple[Path, str, list[str]]:
    if not scenarios:
        raise ResearchError("scenarios が空です（メインとリスクの 2 つ以上）")
    notes = {n["id"] for n in load_notes(project, topic)}
    warns, out = [], []
    roles = set()
    for i, s in enumerate(scenarios, 1):
        role = str(s.get("role") or ("main" if i == 1 else "risk")).lower()
        roles.add(role)
        miss = [f for f in ("premise", "triggers", "invalidation", "regime", "strategy") if not s.get(f)]
        if miss:
            raise ResearchError(f"シナリオ {i} に必要な項目がありません: {', '.join(miss)}")
        reg = str(s["regime"]).lower()
        if reg not in REGIMES:
            raise ResearchError(f"regime は {' / '.join(REGIMES)} のどれか（シナリオ {i}）")
        ev = [str(x) for x in s.get("evidence") or []]
        bad = [x for x in ev if x not in notes]
        if not ev:
            warns.append(f"シナリオ {i}: evidence（根拠のノート ID）がありません")
        if bad:
            warns.append(f"シナリオ {i}: 存在しないノート ID: {', '.join(bad)}")
        out.append({"role": role, "name": str(s.get("name") or role), "probability": s.get("probability"),
                    "premise": str(s["premise"]), "triggers": _list(s["triggers"]), "invalidation": _list(s["invalidation"]),
                    "regime": reg, "horizon": str(s.get("horizon") or ""), "strategy": str(s["strategy"]),
                    "ea_params": s.get("ea_params") or {}, "evidence": ev})
    if "main" not in roles or "risk" not in roles:
        warns.append("role が main と risk の両方そろっていません")
    d = topic_dir(project, topic)
    d.mkdir(parents=True, exist_ok=True)
    (d / "scenarios.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    L = [f"# シナリオ: {topic}（{time.strftime('%Y-%m-%d %H:%M')}）", ""]
    for s in out:
        L += [f"## {'メイン' if s['role'] == 'main' else 'リスク' if s['role'] == 'risk' else s['role']}: {s['name']}" +
              (f"（確率の目安 {s['probability']}）" if s.get("probability") not in (None, "") else ""), "",
              f"- 前提: {s['premise']}", f"- 発動条件: " + " / ".join(s["triggers"]),
              f"- 否定される条件（EA を止める・切り替える）: " + " / ".join(s["invalidation"]),
              f"- 相場の型: {REGIME_JA[s['regime']]}（目安の戦略: {STRATEGY_HINT[s['regime']]}）",
              f"- 期間: {s['horizon'] or '—'}", f"- 戦略: {s['strategy']}"]
        if s["ea_params"]:
            L.append("- EA の設定の目安: " + ", ".join(f"{k}={v}" for k, v in s["ea_params"].items()))
        L += [f"- 根拠: {', '.join(s['evidence']) or '—'}", ""]
    md = "\n".join(L)
    path = d / "scenarios.md"
    path.write_text(md, encoding="utf-8")
    return path, md, warns


def _list(v) -> list[str]:
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v if str(x).strip()]
    return [x.strip() for x in re.split(r"[\n;／]", str(v)) if x.strip()]


# ------------------------------------------------------------------ v2.11.5: イベントの日程（過去の会合での検証に使う）
EVENT_KINDS = ("FOMC", "BOJ", "ECB", "BOE", "CPI", "NFP", "GDP", "INTERVENTION", "OTHER")


def events_path(project: Path, topic: str) -> Path:
    return topic_dir(project, topic) / "events.json"


def load_events(project: Path, topic: str) -> list[dict]:
    p = events_path(project, topic)
    if not p.is_file():
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def save_events(project: Path, topic: str, events: list, fetched: dict | None = None) -> tuple[Path, list[dict], list[str]]:
    """イベントを追加・更新する（同じ日付・種類は上書き）。各イベント: date（YYYY-MM-DD）, kind, name, time, source（URL など）, note。
    出典が、その会話で実際に読んだ URL・ファイルでなければ警告する。"""
    topic = str(topic or "").strip()
    if not topic:
        raise ResearchError("topic が必要です（例: USDJPY）")
    if not isinstance(events, list) or not events:
        raise ResearchError("events（イベントのリスト）が必要です")
    have = {(e.get("date"), e.get("kind")): e for e in load_events(project, topic)}
    warns: list[str] = []
    keys = set((fetched or {}).keys())
    added = 0
    for i, e in enumerate(events, 1):
        if not isinstance(e, dict):
            raise ResearchError(f"events[{i}] はオブジェクトにしてください")
        d = _date(e.get("date")) if re.match(r"\s*\d{4}\D\d{1,2}\D\d{1,2}", str(e.get("date") or "")) else None
        if d is None:
            raise ResearchError(f"events[{i}].date は YYYY-MM-DD にしてください（{e.get('date')!r}）")
        kind = str(e.get("kind") or "OTHER").strip().upper()
        if kind not in EVENT_KINDS:
            warns.append(f"events[{i}].kind「{kind}」は不明のため OTHER として扱います（{' / '.join(EVENT_KINDS)}）")
            kind = "OTHER"
        src = str(e.get("source") or "").strip()
        if not src:
            raise ResearchError(f"events[{i}].source（日程を確かめた URL または資料）が必要です。日付を記憶で書かない")
        if src not in keys and not any(src.rstrip("/") == k.rstrip("/") for k in keys):
            warns.append(f"events[{i}] の出典 {src} は、この会話で読んだ URL・ファイルにありません（日付を確かめてください）")
        rec = {"date": d.strftime("%Y-%m-%d"), "kind": kind, "name": str(e.get("name") or kind)[:120],
               "time": str(e.get("time") or "")[:20], "source": src[:500], "note": str(e.get("note") or "")[:300]}
        have[(rec["date"], kind)] = rec
        added += 1
    out = sorted(have.values(), key=lambda x: x["date"])
    p = events_path(project, topic)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    return p, out, warns


def select_events(events: list[dict], kind: str = "", since: str = "", until: str = "", limit: int = 0) -> list[dict]:
    kinds = {k.strip().upper() for k in str(kind or "").replace("/", ",").split(",") if k.strip()}
    out = [e for e in events if (not kinds or e.get("kind") in kinds)
           and (not since or e.get("date", "") >= since) and (not until or e.get("date", "") <= until)]
    return out[-limit:] if limit else out


def events_md(topic: str, events: list[dict]) -> str:
    if not events:
        return f"{topic}: イベントはまだありません（event_calendar の action=add で出典つきで追加する）"
    lines = [f"# {topic} のイベント（{len(events)} 件）", "", "| 日付 | 時刻 | 種類 | 名前 | 出典 |", "|---|---|---|---|---|"]
    lines += [f"| {e['date']} | {e.get('time', '')} | {e['kind']} | {e.get('name', '')} | {e.get('source', '')[:80]} |" for e in events]
    return "\n".join(lines)
