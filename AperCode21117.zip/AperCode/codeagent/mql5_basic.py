"""EA（.mq5）の基本チェック（v2.11.4、AperCode 組み込み。v2.11.5 で期間限定・イベント向けの項目を追加）。

スキル mql5-structure-check を入れていない環境でも、EA として最低限の形（発注・マジックナンバー・SL・
ポジション数の確認・ハンドルの確認と解放・新バー判定・確定足の参照）が揃っているかを確かめる。
誤検出で作業を止めないよう、結果は「参考」としてツールの結果に添えるだけで、差し戻しはしない。
"""
from __future__ import annotations

import re

# 指標ハンドルを作る関数（i で始まる組み込み指標と iCustom）
_IND = (r"i(?:MA|RSI|MACD|ATR|ADX|ADXWilder|Bands|Stochastic|CCI|SAR|Ichimoku|Envelopes|Momentum|WPR|OBV|AO|AC|"
        r"Alligator|DeMarker|Force|RVI|StdDev|Custom|BearsPower|BullsPower|MFI|Volumes|DEMA|TEMA|FrAMA|AMA|VIDyA|"
        r"TriX|Fractals|Gator|BWMFI|Osma|OsMA|Chaikin|AD)")


def strip_code(code: str) -> str:
    """コメントと文字列リテラルを取り除く（URL の // などで誤検出しないよう 1 文字ずつ読む）。"""
    out: list[str] = []
    i, n = 0, len(code)
    while i < n:
        c = code[i]
        if c in "\"'":
            j = i + 1
            while j < n and code[j] != c and code[j] != "\n":
                j += 2 if code[j] == "\\" else 1
            out.append(c + c)
            i = j + 1
        elif code.startswith("//", i):
            while i < n and code[i] != "\n":
                i += 1
        elif code.startswith("/*", i):
            k = code.find("*/", i + 2)
            i = n if k < 0 else k + 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _global(src: str) -> str:
    out, depth = [], 0
    for ch in src:
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth = max(0, depth - 1)
        elif depth == 0:
            out.append(ch)
    return "".join(out)


def _args(text: str, start: int) -> list[str]:
    """text[start] が '(' の呼び出しの引数を、括弧の入れ子を考えて分ける。"""
    depth, cur, out = 0, [], []
    for ch in text[start:]:
        if ch == "(":
            depth += 1
            if depth == 1:
                continue
        elif ch == ")":
            depth -= 1
            if depth == 0:
                break
        elif ch == "," and depth == 1:
            out.append("".join(cur).strip())
            cur = []
            continue
        cur.append(ch)
    if "".join(cur).strip():
        out.append("".join(cur).strip())
    return out


def check(code: str) -> list[dict]:
    """[{id, problem, fix}]。空なら基本の形は揃っている。"""
    src = strip_code(code or "")
    glob = _global(src)
    v: list[dict] = []

    def add(i, p, f):
        v.append({"id": i, "problem": p, "fix": f})

    if not re.search(r"\bOnInit\s*\(", src):
        add("NO_ONINIT", "OnInit() がない。指標ハンドルの作成や設定の確認をする場所がない。",
            "int OnInit() { /* ハンドル作成・入力値の確認 */ return(INIT_SUCCEEDED); } を追加する")

    uses_ctrade = re.search(r"\bCTrade\b", src) is not None
    orders = [m for m in re.finditer(r"\b(\w+)\s*\.\s*(Buy|Sell)\s*\(", src)] if uses_ctrade else []
    has_order = bool(orders) or re.search(r"\bOrderSend(?:Async)?\s*\(", src) is not None \
        or (uses_ctrade and re.search(r"\.\s*PositionOpen\s*\(", src) is not None)
    if not has_order:
        add("NO_ORDER", "発注する処理が見つからない（CTrade の Buy / Sell、OrderSend がない）。このままでは売買しない。",
            "#include <Trade/Trade.mqh> と CTrade trade; を置き、シグナルが出たら trade.Buy(lot, _Symbol, price, sl, tp) / "
            "trade.Sell(...) で発注する")
    else:
        if not re.search(r"SetExpertMagicNumber\s*\(|\.\s*magic\s*=", src):
            add("NO_MAGIC", "マジックナンバーを設定していない。手動の取引や他の EA のポジションと区別できない。",
                "input long InpMagic = 123456; を宣言し、OnInit で trade.SetExpertMagicNumber(InpMagic); を呼ぶ")
        if not re.search(r"\bPositions?Total\s*\(|\bPositionSelect(?:ByTicket)?\s*\(|\bPositionGetTicket\s*\(|"
                         r"\bPositionGet(?:Integer|Double|String)\s*\(|CPositionInfo", src):
            add("NO_POSITION_CHECK", "保有中のポジションを確認していない。シグナルのたびに新しく発注し、ポジションが増え続ける。",
                "発注の前に、この EA（マジックナンバー・銘柄）のポジション数を PositionsTotal() と PositionGetTicket(i) で数え、"
                "上限（例: 1）に達していれば発注しない")
        no_sl = []
        for m in orders:
            a = _args(src, src.index("(", m.end() - 1))
            if len(a) < 4 or re.fullmatch(r"0(\.0*)?", a[3] or ""):
                no_sl.append(f"{m.group(1)}.{m.group(2)}")
        if no_sl and not re.search(r"\.\s*PositionModify\s*\(", src):
            add("NO_STOP_LOSS", f"SL を付けずに発注している: {', '.join(sorted(set(no_sl)))}。相場が逆に動いたときの損失に上限がない。",
                "SL 価格を計算して渡す（例: ATR や固定 pips から sl を求め、trade.Buy(lot, _Symbol, ask, sl, tp)）。"
                "成行で SL を付けられない場合は、約定後に trade.PositionModify で設定する")

    has_time = re.search(r"\biTime\s*\(|\bCopyTime\s*\(|\bCopyRates\s*\(|SERIES_LASTBAR_DATE|\.\s*time\b", src)
    has_var = re.search(r"\bstatic\s+datetime\s+\w+", src) or re.search(r"\bdatetime\s+\w+\s*(=|;)", glob)
    if re.search(r"\bOnTick\s*\(", src) and not (has_time and has_var):
        add("NO_NEW_BAR_CHECK", "新しいバーの確定を確かめていない。毎ティック判定するため、同じバーの中で何度も売買しうる。",
            "毎ティックの判定を意図していなければ、OnTick の冒頭に入れる: static datetime last = 0; "
            "datetime t = iTime(_Symbol, _Period, 0); if(t == last) return; last = t;")

    created = re.findall(r"(\w+)\s*=\s*" + _IND + r"\s*\(", src)
    if created:
        released = set(re.findall(r"IndicatorRelease\s*\(\s*(\w+)\s*\)", src))
        leak = sorted(set(created) - released)
        if leak:
            add("HANDLE_LEAK", f"OnDeinit() で解放していない指標ハンドルがある: {', '.join(leak)}",
                "void OnDeinit(const int reason) { IndicatorRelease(ハンドル); ... } で全てのハンドルを解放する")
        if "INVALID_HANDLE" not in src:
            add("NO_HANDLE_CHECK", "指標ハンドルの作成に失敗したかを確かめていない。失敗すると以後の CopyBuffer が全て失敗する。",
                "OnInit で if(handle == INVALID_HANDLE) { Print(\"...\"); return(INIT_FAILED); } を入れる")

    # v2.11.5: 期間限定・イベント向けの EA
    if re.search(r"\bCalendar(?:Value|Event|Country)\w*\s*\(", src):
        add("CALENDAR_IN_TESTER", "経済指標カレンダーの関数（Calendar...）を使っている。ストラテジーテスターでは動かないため、バックテストでは"
            "イベントを検出できず、ライブと違う動きになる。",
            "イベントの日時は input（例: input datetime InpEventTime）や日付のリストで持たせる。"
            "過去のイベントでの検証は mt5_event_backtest で行う")
    if re.search(r"\binput\s+datetime\s+\w+", src) and "MQL_TESTER" not in src:
        add("WINDOW_BLOCKS_TESTER", "input datetime で稼働期間を決めているが、テスター中の扱いがない。過去のイベントの窓でバックテストすると"
            "期間外になり、1 回も取引しない。",
            "期間の判定で、テスター中は期間制限を無視する（テスターの期間がそのまま窓になる）: "
            "bool InWindow(){ if(MQLInfoInteger(MQL_TESTER)) return true; datetime now = TimeCurrent(); "
            "return (InpActiveFrom == 0 || now >= InpActiveFrom) && (InpActiveTo == 0 || now <= InpActiveTo); }")

    starts = []
    for m in re.finditer(r"\bCopy(?:Buffer|Close|Open|High|Low|Rates|Time)\s*\(", src):
        parts = _args(src, m.end() - 1)
        if len(parts) >= 4:
            starts.append(parts[-3])
    if starts:
        if all(s == "0" for s in starts):
            add("NO_CLOSED_BAR_REF", "値の取得が全て start_pos=0（形成中のバー）。未確定の値はティックごとに変わり、シグナルが出たり消えたりする。",
                "判定に使う値は確定したバーから取る（start_pos=1）: CopyBuffer(handle, 0, 1, 3, buf); "
                "（ArraySetAsSeries(buf, true) なら buf[0] が直近の確定足）")
    return v


def format_report(viol: list[dict]) -> str:
    if not viol:
        return "✅ EA の基本の形は揃っています"
    lines = [f"⚠ {len(viol)} 件: " + ", ".join(x["id"] for x in viol), ""]
    for i, x in enumerate(viol, 1):
        lines += [f"【{i}: {x['id']}】", f"問題: {x['problem']}", f"直し方: {x['fix']}", ""]
    lines.append("（AperCode 組み込みの基本チェック。参考として表示しています。妥当なものは、戦略ロジックを変えずに該当箇所だけを直す。"
                 "意図した設計なら直さなくてよい）")
    return "\n".join(lines)
