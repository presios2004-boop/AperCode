"""ask_cloud: 行き詰まったときにクラウド AI へ相談する（v1.2.4）。

- 会話全体ではなく「目的 / エラー / 試したこと / 関連コードの抜粋 / 質問」だけを送る
- 発動条件（cloud.require_failures）: 自動検証の差し戻し・テスト失敗・行き詰まり検知の合計がこの回数以上のときだけ使える
- 1 ターンの回数上限（cloud.max_per_turn）
- 送信前に秘密情報らしき文字列をマスク（cloud.mask_secrets）
- 承認は permissions.ask_cloud（既定 ask）
"""
from __future__ import annotations

import platform
from pathlib import Path

from . import Tool, ToolContext, ToolError, register
from ..cloud import CloudClient, CloudSettings, ASK_SYSTEM, build_prompt, mask_secrets


def _excerpt(ctx: ToolContext, spec: str, max_lines: int) -> str:
    """'path' または 'path:10-80' 形式でファイルの抜粋を返す。"""
    spec = spec.strip()
    rng = None
    if ":" in spec and "-" in spec.rsplit(":", 1)[-1]:
        p, r = spec.rsplit(":", 1)
        try:
            a, b = r.split("-", 1)
            rng = (max(1, int(a)), int(b))
            spec = p
        except ValueError:
            rng = None
    path = ctx.resolve(spec)
    if not path.is_file():
        return f"### {spec}\n(ファイルがありません)"
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if rng:
        sel = lines[rng[0] - 1:rng[1]]
        start = rng[0]
    else:
        sel, start = lines[:max_lines], 1
    body = "\n".join(f"{i:4d}| {l}" for i, l in enumerate(sel, start))
    note = f"\n... (省略: 全 {len(lines)} 行。範囲は path:開始-終了 で指定可)" if len(lines) > len(sel) + (start - 1) else ""
    try:
        rel = path.relative_to(ctx.project_dir)
    except ValueError:
        rel = path
    return f"### {rel}\n```\n{body}{note}\n```"


async def ask_cloud(ctx: ToolContext, a: dict) -> str:
    cfg = ctx.cfg
    if not cfg.get("cloud.enabled", False):
        raise ToolError("クラウド相談は無効です（「設定」→「☁ クラウド AI の設定」で API キーを設定し、左のパネルの「☁ クラウド AI」をオンにしてください）")
    s = CloudSettings.from_cfg(cfg, "consult")
    if not s.ready:
        raise ToolError("クラウド相談の設定が不完全です（プロバイダ・モデル・API キーを確認してください）")
    vs = ctx.verify
    # ---- 発動条件: まずローカルで粘った後だけ
    need = int(cfg.get("cloud.require_failures", 1))
    failures = 0
    if vs is not None:
        failures = vs.stuck_count + vs.test_rounds + sum(vs.check_failures.values()) + vs.cloud_denied
    # v2.11.6: ユーザーが相談を求めたとき、Web で一定回数調べたとき（十分な情報が無い・アイデアが尽きた）も使える
    user_asked = bool(getattr(vs, "user_cloud", False))
    searched = int(getattr(vs, "web_calls", 0) or 0)
    search_need = int(cfg.get("cloud.search_before", 3))
    if failures < need and not user_asked and not (search_need > 0 and searched >= search_need):
        raise ToolError(f"まだクラウド相談は使えません（失敗・行き詰まり {failures} 回 / 必要 {need} 回、Web の調査 {searched} 回 / 必要 {search_need} 回）。"
                        "先にエラー文を読み直し、search_memory と web_search で解決策や情報を探して試してください")
    max_per_turn = int(cfg.get("cloud.max_per_turn", 2))
    if vs is not None and vs.cloud_calls >= max_per_turn:
        raise ToolError(f"このターンのクラウド相談は上限（{max_per_turn} 回）に達しました。得られたヒントを基に自分で進めるか、"
                        "試したこと・分かったことを整理してユーザーに報告してください")
    goal = str(a.get("goal") or "").strip()
    error = str(a.get("error") or "").strip()
    tried = str(a.get("tried") or "").strip()
    if not goal or not tried:
        raise ToolError("goal（目的）と tried（試したことと結果）は必須です。丸投げではなく相談になるように書いてください")
    files = a.get("files") or []
    if isinstance(files, str):
        files = [f for f in files.split(",") if f.strip()]
    max_lines = int(cfg.get("cloud.max_file_lines", 200))
    code = "\n\n".join(_excerpt(ctx, f, max_lines) for f in files[:6])
    env = f"OS: {platform.platform()}; project: {ctx.project_dir.name}"
    prompt = build_prompt(goal, error, tried, code, str(a.get("question") or ""), env)
    masked = 0
    if cfg.get("cloud.mask_secrets", True):
        prompt, masked = mask_secrets(prompt)
    if vs is not None:
        vs.cloud_calls += 1
    try:
        answer = await CloudClient(s).ask(ASK_SYSTEM, prompt, max_tokens=int(cfg.get("cloud.max_tokens", 16000)))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"クラウド相談に失敗: {e}")
    head = f"[クラウド相談: {s.describe()} / 送信 {len(prompt):,} 文字" + (f", 秘密情報 {masked} 件をマスク" if masked else "") + "]\n"
    tail = ("\n\n（上記はヒントです。そのまま信用せず、確認方法を実行して裏を取り、修正後は必ずテストで検証してください。"
            "解決したら原因と対処を save_memory に「（参考: クラウド相談）」を付けて保存してください）")
    return head + answer + tail


async def cloud_review(ctx: ToolContext, a: dict) -> str:
    """v2.11.14: クラウド AI に、指定したファイルのコードレビューを頼む（最終レビュー用のモデル）。"""
    from ..cloud import REVIEW_SYSTEM, build_review_prompt, parse_review_json
    from ..prompts import prompt_language
    cfg = ctx.cfg
    if not cfg.get("cloud.enabled", False):
        raise ToolError("クラウド AI は無効です（「設定」→「☁ クラウド AI の設定」で API キーを設定し、左のパネルの「☁ クラウド AI」をオンにしてください）")
    s = CloudSettings.from_cfg(cfg, "review")
    if not s.ready:
        raise ToolError("クラウド AI の設定が不完全です（プロバイダ・モデル・API キーを確認してください）")
    vs = ctx.verify
    limit = int(cfg.get("cloud.review_max_per_turn", 3))
    used = int(getattr(vs, "cloud_review_calls", 0) or 0) if vs is not None else 0
    if used >= limit:
        raise ToolError(f"このターンのクラウド AI のレビューは上限（{limit} 回）に達しました。指摘を直した結果は、完了前の最終レビューで確かめられます")
    files = a.get("files") or []
    if isinstance(files, str):
        files = [f for f in files.split(",") if f.strip()]
    if not files:
        raise ToolError("files（レビューするファイル）を 1 つ以上指定してください")
    contents: dict[str, str] = {}
    for f in files[:8]:
        import re as _re
        p = ctx.resolve(_re.sub(r":\d+-\d+$", "", str(f)))
        if not p.is_file():
            raise ToolError(f"ファイルがありません: {f}")
        try:                                     # v2.11.16: 確認なしで送るので、作業ディレクトリの中のファイルだけにする
            p.resolve().relative_to(Path(ctx.project_dir).resolve())
        except ValueError:
            raise ToolError(f"作業ディレクトリの外のファイルはレビューに送れません: {f}")
        raw = p.read_bytes()
        txt = raw.decode("utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else raw.decode("utf-8", errors="replace")
        try:
            rel = str(p.relative_to(ctx.project_dir))
        except ValueError:
            rel = str(p)
        contents[rel] = txt
    task = str(a.get("task") or "").strip() or "(未記入)"
    if a.get("focus"):
        task += "\n\n## 特に見てほしい点\n" + str(a["focus"]).strip()
    maxc = int(cfg.get("verify.review.cloud_max_chars", 60000) or 60000)
    prompt = build_review_prompt(task, "(差分ではなく、下のファイル全体をレビューする)", contents, maxc)
    masked = 0
    if cfg.get("cloud.mask_secrets", True):
        prompt, masked = mask_secrets(prompt)
    if vs is not None:
        vs.cloud_review_calls = used + 1
    system = REVIEW_SYSTEM.replace("{lang}", "English" if prompt_language() == "en" else "Japanese")
    try:
        text = await CloudClient(s).ask(system, prompt, max_tokens=int(cfg.get("cloud.max_tokens", 16000)))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"クラウド AI のレビューに失敗: {e}")
    data = parse_review_json(text)
    head = f"[クラウド AI のレビュー: {s.describe()} / 送信 {len(prompt):,} 文字" + (f", 秘密情報 {masked} 件をマスク" if masked else "") + "]\n"
    if data is None:
        return head + text[-6000:] + "\n\n（決まった形の結果を読み取れませんでした。上の文章から指摘を読み取ってください）"
    issues = data["issues"]
    if not issues:
        return head + "指摘なし（ok: " + str(data.get("ok")) + "）"
    body = "\n".join(f"- [{i.get('severity', '?')}] {i.get('file', '')}" + (f":{i['line']}" if i.get("line") else "")
                     + f" {i.get('problem', '')}\n  対処案: {i.get('fix', '')}" for i in issues)
    # v2.11.17: 指摘を確認済みの教訓として経験メモリに保存する（次の作業から参照される）
    from ..review_memory import save_review_lessons
    saved = await save_review_lessons(getattr(ctx, "memory", None), cfg, issues, ctx.project_dir, s.model, task)
    note = f"\n（指摘 {len(saved)} 件を確認済みの教訓として経験メモリに保存しました）" if saved else ""
    return (head + f"指摘 {len(issues)} 件（ok: {data.get('ok')}）\n{body}\n\n"
            "（妥当な指摘は直し、コンパイル・テストで確かめる。妥当でない指摘は理由を完了報告に書く）" + note)


register(Tool(
    "cloud_review",
    "クラウド AI（最終レビュー用のモデル）に、指定したファイルのコードレビューを頼む。バグ・ロジックの誤り・要件の取りこぼし・"
    "セキュリティ・リソースの扱い（EA なら注文・SL/TP・ポジション管理・確定足・ハンドル）を見て、指摘を返す。"
    "ユーザーが「クラウド AI でレビュー」を求めたとき、作ったコードを完成前に確かめたいときに使う（行き詰まりの相談は ask_cloud）。",
    {"type": "object", "properties": {
        "files": {"type": "array", "items": {"type": "string"}, "description": "レビューするファイル（最大 8。ファイル全体を送る）"},
        "task": {"type": "string", "description": "何を作ったか・満たすべき要件（ユーザーの依頼の要点）"},
        "focus": {"type": "string", "description": "特に見てほしい点（任意）"}},
     "required": ["files", "task"]},
    cloud_review,
    lambda a: f"{', '.join(str(x) for x in (a.get('files') or [])[:4])} / {str(a.get('task', ''))[:50]}"))


register(Tool(
    "ask_cloud",
    "クラウドの強い AI に相談してヒントをもらう。行き詰まったとき、アイデアが尽きたとき、Web 検索で十分な情報が得られないとき、"
    "ユーザーがクラウド AI との相談を求めたときに使う（失敗や Web の調査が一定回数に達するまでは使えない。ユーザーが求めたときはすぐ使える）。"
    "会話全体ではなく、目的・エラー（または調べたこと）・試したこと・関連コードの抜粋だけを送る。返ってくるのは仮説と案であり、実装と検証は自分で行う。"
    "コードのレビューを頼むときは cloud_review を使う（レビュー用のモデルが使われる）。",
    {"type": "object", "properties": {
        "goal": {"type": "string", "description": "何を実現しようとしているか（1〜3 文）"},
        "error": {"type": "string", "description": "エラー全文・スタックトレース・症状（情報やアイデアの相談なら、調べて分かったこと・足りないこと）"},
        "tried": {"type": "string", "description": "試したことと、それぞれの結果（必須）"},
        "files": {"type": "array", "items": {"type": "string"},
                  "description": "関連ファイル（最大 6。'path' または 'path:開始行-終了行'。先頭 200 行までが送られる）"},
        "question": {"type": "string", "description": "特に聞きたいこと（任意）"}},
     "required": ["goal", "tried"]},
    ask_cloud,
    lambda a: f"{str(a.get('goal',''))[:60]} / files={len(a.get('files') or [])}"))
