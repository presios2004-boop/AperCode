"""MT5 (wine) 向けツール: mt5_compile / mt5_backtest

前提: WINEPREFIX 配下に MetaTrader 5 がインストールされ、MetaEditor64.exe / terminal64.exe が存在すること。
"""
from __future__ import annotations

import asyncio
import json
import re
import shutil
import time
from pathlib import Path

from ..config import expand
from . import Tool, ToolContext, ToolError, register
from .shell import run_shell


def _mt5_paths(ctx: ToolContext) -> dict[str, Path]:
    cfg = ctx.cfg
    prefix = expand(cfg.get("mt5.wine_prefix", "~/.wine_mt5"))
    terminal_dir = prefix / cfg.get("mt5.terminal_dir")
    mql5_dir = prefix / cfg.get("mt5.mql5_dir")
    return {"prefix": prefix, "terminal_dir": terminal_dir, "mql5_dir": mql5_dir,
            "metaeditor": terminal_dir / "MetaEditor64.exe", "terminal": terminal_dir / "terminal64.exe"}


def _to_win(prefix: Path, p: Path) -> str:
    """WINEPREFIX/drive_c/... を C:\\... に変換する。"""
    rel = p.resolve().relative_to((prefix / "drive_c").resolve())
    return "C:\\" + str(rel).replace("/", "\\")


def _read_win_text(p: Path) -> str:
    raw = p.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):          # MetaEditor のログは UTF-16（BOM 付き）
        return raw.decode("utf-16", errors="replace")
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig", errors="replace")
    for enc in ("utf-8", "cp932", "utf-16"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def _place_source(ctx: ToolContext, src: Path, mql5_dir: Path) -> Path:
    """ソースが MQL5 フォルダ外なら MQL5/Experts/AperCode/ にコピーして、その先のパスを返す。"""
    if mql5_dir.resolve() in src.resolve().parents:
        return src
    dest_dir = mql5_dir / "Experts" / "AperCode"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / src.name
    shutil.copy2(src, dest)
    # 同階層の .mqh も一緒にコピー（インクルード用）
    for inc in src.parent.glob("*.mqh"):
        shutil.copy2(inc, dest_dir / inc.name)
    return dest


def _portable(ctx: ToolContext, paths: dict) -> bool:
    """MT5 がポータブル（データフォルダがインストール先の中）か。mt5.portable で明示も可（既定は自動判定）。"""
    v = ctx.cfg.get("mt5.portable", "auto")
    if isinstance(v, bool):
        return v
    try:
        return paths["terminal_dir"].resolve() in paths["mql5_dir"].resolve().parents
    except OSError:
        return False


def _running_metaeditor(prefix: Path) -> list[str]:
    """この WINEPREFIX で動いている MetaEditor（起動中の画面があると、コンパイルの依頼がそちらに渡って何もしないことがある）。"""
    import os
    out = []
    for d in Path("/proc").iterdir() if Path("/proc").is_dir() else []:
        if not d.name.isdigit():
            continue
        try:
            cmd = (d / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            if "metaeditor64.exe" not in cmd.lower():
                continue
            env = (d / "environ").read_bytes()
            if f"WINEPREFIX={prefix}".encode() in env or b"WINEPREFIX=" not in env:
                out.append(d.name)
        except OSError:
            continue
    return out


async def _compile_placed(ctx: ToolContext, paths: dict, placed: Path, timeout: int) -> tuple[bool, str, int, str, bool]:
    """MT5 フォルダの中に置いた .mq5 をコンパイルする。(成功, ログ, 終了コード, 出力, MetaEditor が既に起動中)"""
    log = placed.with_suffix(".log")
    ex5 = placed.with_suffix(".ex5")
    for f in (log, ex5):
        if f.exists():
            f.unlink()
    if _portable(ctx, paths):
        target = str(placed.resolve().relative_to(paths["terminal_dir"].resolve())).replace("/", "\\")
        cmd = f'wine MetaEditor64.exe /portable /compile:"{target}" /log'
    else:
        cmd = f'wine MetaEditor64.exe /compile:"{_to_win(paths["prefix"], placed)}" /log'
    env = {"WINEPREFIX": str(paths["prefix"]), "WINEDEBUG": "-all"}
    busy = bool(_running_metaeditor(paths["prefix"]))
    t0 = time.time()
    # v2.10.5: wine は WINEPREFIX 全体を使うので、サンドボックスの外で動かす（コマンドは AperCode が組み立てたもの）
    code, out = await run_shell(cmd, str(paths["terminal_dir"]), timeout=timeout, env=env, sandboxed=False)
    for _ in range(20):                          # 書き出しを少し待つ
        if log.exists() or ex5.exists():
            break
        await _sleep(0.5)
    text = _read_win_text(log).strip() if log.exists() else ""
    errs = re.findall(r"(\d+)\s+errors?", text)
    made = ex5.exists() and ex5.stat().st_mtime >= t0 - 2
    return made and (not errs or errs[-1] == "0"), text, code, out, busy


async def mt5_compile(ctx: ToolContext, a: dict) -> str:
    """v2.10.6: これまで動いていた方法（/portable・MT5 フォルダからの相対パス・/log で .mq5 の隣にログ）に合わせた。
    以前は絶対パスと /log:"パス" で呼んでいて、ポータブル版の MT5 では画面が開いたまま終わらず、ログも作られなかった。"""
    paths = _mt5_paths(ctx)
    if not paths["metaeditor"].exists():
        raise ToolError(f"MetaEditor64.exe が見つかりません: {paths['metaeditor']}（config.yaml の mt5 設定を確認）")
    src = ctx.resolve(a["path"])
    if src.suffix.lower() not in (".mq5", ".mq4"):
        raise ToolError("拡張子は .mq5 である必要があります")
    if not src.exists():
        raise ToolError(f"ファイルがありません: {src}")
    placed = _place_source(ctx, src, paths["mql5_dir"])
    ex5 = placed.with_suffix(".ex5")
    ok, text, code, out, busy = await _compile_placed(ctx, paths, placed, int(a.get("timeout", 180)))
    made = ex5.exists()
    errs = re.findall(r"(\d+)\s+errors?", text)
    warns = re.findall(r"(\d+)\s+warnings?", text)
    head = f"[{'成功' if ok else '失敗'}] errors={errs[-1] if errs else ('0' if made else '?')} " \
           f"warnings={warns[-1] if warns else '?'}（MetaEditor の終了コード {code}）"
    result = [head]
    if text:
        result.append(text[-6000:])
    elif code == -1:
        result.append(f"MetaEditor が終わりませんでした（タイムアウト）。{out[-500:]}")
    else:
        result.append("MetaEditor のコンパイルログがありません。" + (out[-1000:] if out.strip() else ""))
    if not made and busy:
        result.append("⚠ MetaEditor が既に起動しています。起動中の MetaEditor を閉じてから、もう一度 mt5_compile を実行してください"
                      "（MT5・wine の再インストールや設定変更はしないこと）")
    if made:
        result.append(f"出力: {ex5}")
        if placed != src:
            shutil.copy2(ex5, src.with_suffix(".ex5"))
            result.append(f"コピー: {src.with_suffix('.ex5')}")
    if made and ok:
        # v2.11.2: コンパイルが通った EA は必ず構造検査する。違反があればコンパイルエラーと同じく差し戻す
        note, failed = await _structure_gate(ctx, src, ex5, a)
        if note:
            result.append(note)
        if failed:
            raise ToolError("\n".join(result))
    return "\n".join(result)


# ------------------------------------------------------------------ v2.11.2: EA の構造検査（mt5_compile の後に必ず）
STRUCT_SKILL = "mql5-structure-check"
_STRUCT_STATE: dict[str, dict] = {}          # .ex5 のパス → {"fails": 違反で差し戻した回数, "blocked": バックテストを止めているか}
_STRUCT_OPTS: dict[str, dict] = {}           # v2.11.3: EA 名 → 前回の mtf / tf（保存時の検査とコンパイル時の検査で同じ条件を使う）


def _is_ea(src: Path) -> bool:
    if src.suffix.lower() != ".mq5":
        return False
    try:
        code = src.read_bytes()
        text = code.decode("utf-16") if code[:2] in (b"\xff\xfe", b"\xfe\xff") else code.decode("utf-8", errors="replace")
    except (OSError, UnicodeDecodeError):
        return False
    return re.search(r"\bOnTick\s*\(", text) is not None


def _viol_text(viol: list) -> list[str]:
    lines: list[str] = []
    for i, v in enumerate(viol, 1):
        lines += [f"【違反{i}: {v.get('id', '?')}】", f"問題: {v.get('problem', '')}", f"修正: {v.get('fix', '')}", ""]
    return lines


def skill_state(cfg) -> str:
    """v2.11.4: 構造検査のスキルの状態。ok / untrusted / missing（入っていない）。"""
    if not cfg.get("skills.enabled", True):
        return "missing"
    try:
        from .. import skills as SK
        sk = next((x for x in SK.list_skills(cfg) if x["name"] == STRUCT_SKILL), None)
    except Exception:  # noqa: BLE001
        return "missing"
    if sk is None or "check.py" not in sk["files"]:
        return "missing"
    return sk["status"]


def structure_skill_ready(cfg) -> bool:
    """構造検査のスキルが入っていて使える（LLM への説明に構造検査の決まりを足すか）。"""
    return str(cfg.get("mt5.structure_check", "auto")).lower() not in ("off", "false", "0") and skill_state(cfg) == "ok"


_SKILL_COVERS = {"NO_NEW_BAR_CHECK", "HANDLE_LEAK", "NO_CLOSED_BAR_REF"}   # スキルの検査と重なる基本チェック


def _basic(ctx: ToolContext, src: Path, skill_ran: bool) -> list | None:
    """v2.11.4: AperCode 組み込みの EA の基本チェック（スキルが無くても動く。参考として表示するだけ）。"""
    if not ctx.cfg.get("mt5.basic_check", True):
        return None
    from .. import mql5_basic as MB
    try:
        code = src.read_bytes()
        text = code.decode("utf-16") if code[:2] in (b"\xff\xfe", b"\xfe\xff") else code.decode("utf-8", errors="replace")
    except (OSError, UnicodeDecodeError):
        return None
    v = MB.check(text)
    return [x for x in v if x["id"] not in _SKILL_COVERS] if skill_ran else v


def _basic_note(basic: list | None, title: str) -> str:
    if basic is None:
        return ""
    from .. import mql5_basic as MB
    return f"\n\n## {title}\n" + MB.format_report(basic)


async def structure_on_write(ctx: ToolContext, src: Path) -> tuple[str, bool | None]:
    """v2.11.3: EA を write_file / edit_file で保存した直後の検査（差し戻しの回数には数えない）。(ツール結果に足す文, 問題なしか | None=検査しない)
    v2.11.4: スキルが無くても、組み込みの基本チェックは行う。スキルが入っていなければ構造検査には触れない。"""
    if not _is_ea(src):
        return "", None
    mode = str(ctx.cfg.get("mt5.structure_check", "auto")).lower()
    note, ok, ran = "", None, False
    if mode not in ("off", "false", "0"):
        viol, why = await _run_structure_check(ctx, src, _STRUCT_OPTS.get(src.stem.lower(), {}))
        if viol is not None:
            ran, ok = True, not viol
            if not viol:
                note = "\n\n## 構造検査（保存時）\n✅ 合格。mt5_compile へ進んでよい"
            else:
                note = ("\n\n## 構造検査（保存時）\n" + f"❌ 違反 {len(viol)} 件: " + ", ".join(v.get("id", "?") for v in viol) + "\n\n"
                        + "\n".join(_viol_text(viol))
                        + "コンパイルの前に、戦略ロジックは変えずに違反ごとの「修正」のとおり該当箇所だけを edit_file で直すこと"
                          "（直すと再び検査される）。このまま mt5_compile しても構造検査で差し戻される")
        elif why != "missing":
            note = f"\n\n## 構造検査（保存時）\n⚠ 構造検査を実行できませんでした: {why}"
    basic = _basic(ctx, src, ran)
    if basic is not None and (basic or not ran):
        note += _basic_note(basic, "EA の基本チェック（保存時）")
        if ok is None:
            ok = not basic
        elif basic:
            ok = False
    return note, ok


async def _run_structure_check(ctx: ToolContext, src: Path, a: dict) -> tuple[list | None, str]:
    """スキル mql5-structure-check の check.py をサンドボックスで実行する。(違反のリスト | None=検査できず, 説明)
    スキルが入っていなければ (None, "missing")。"""
    from .. import skills as SK
    from .. import sandbox
    state = skill_state(ctx.cfg)
    if state == "missing":
        return None, "missing"
    work = Path(ctx.project_dir) / ".apercode" / "structure_check"
    work.mkdir(parents=True, exist_ok=True)
    copy = work / src.name                       # MT5 のフォルダはサンドボックスから見えないことがあるので、作業ディレクトリに写す
    shutil.copy2(src, copy)
    args = [str(copy), "--json"]
    mtf = str(a.get("mtf") or ctx.cfg.get("mt5.structure_mtf", "") or "").strip().lower()
    if mtf in ("single", "mtf"):
        args += ["--mtf", mtf]
    if a.get("tf"):
        args += ["--tf", str(a["tf"]).upper().replace("PERIOD_", "")]
    if a.get("oanda") or ctx.cfg.get("mt5.structure_oanda", False):
        args.append("--oanda")
    try:
        argv = SK.script_argv(ctx.cfg, STRUCT_SKILL, "check.py", args, Path(ctx.project_dir))
        full = sandbox.wrap(argv, ctx.project_dir, ctx.project_dir)
    except (SK.SkillError, sandbox.SandboxError) as e:
        return None, str(e)
    proc = await asyncio.create_subprocess_exec(*full, cwd=str(ctx.project_dir), stdout=asyncio.subprocess.PIPE,
                                                stderr=asyncio.subprocess.PIPE, env=sandbox.env_for(ctx.project_dir))
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=60)
    except asyncio.TimeoutError:
        proc.kill()
        return None, "構造検査が 60 秒で終わりませんでした"
    try:
        data = json.loads(out.decode("utf-8", errors="replace"))
        return [v for r in data for v in r.get("violations", [])], ""
    except (ValueError, AttributeError, TypeError):
        return None, (err or out).decode("utf-8", errors="replace").strip()[-800:] or f"終了コード {proc.returncode}"


async def _structure_gate(ctx: ToolContext, src: Path, ex5: Path, a: dict) -> tuple[str, bool]:
    """(結果に足す文, 差し戻すか)。構造検査（スキル）は違反で差し戻す。基本チェック（組み込み）は参考の表示だけ。"""
    if not _is_ea(src):
        return "", False                         # EA ではない（インジケーター・スクリプト）
    mode = str(ctx.cfg.get("mt5.structure_check", "auto")).lower()
    if mode in ("off", "false", "0"):
        return _basic_note(_basic(ctx, src, False), "EA の基本チェック").strip(), False
    key = str(ex5)
    st = _STRUCT_STATE.setdefault(key, {"fails": 0, "blocked": False})
    opts = _STRUCT_OPTS.setdefault(src.stem.lower(), {})   # 前回の mtf / tf を覚えておき、直した後の再コンパイルで省略されても同じ条件で検査する
    opts.update({k: a[k] for k in ("mtf", "tf", "oanda") if a.get(k)})
    viol, why = await _run_structure_check(ctx, src, opts)
    basic_note = _basic_note(_basic(ctx, src, viol is not None), "EA の基本チェック")
    if viol is None:
        st["blocked"] = False
        if mode == "on":                         # 必須なのに検査できない → 差し戻す
            st["blocked"] = True
            reason = f"スキル {STRUCT_SKILL} が入っていません" if why == "missing" else why
            return f"❌ 構造検査を実行できませんでした（mt5.structure_check: on）: {reason}" + basic_note, True
        if why == "missing":                     # v2.11.4: スキルを入れていない環境では構造検査に触れない（基本チェックだけ）
            return basic_note.strip(), False
        return f"⚠ 構造検査を実行できませんでした: {why}" + basic_note, False
    if not viol:
        st.update(fails=0, blocked=False)
        return "✅ 構造検査 合格" + basic_note, False
    st["fails"] += 1
    limit = int(ctx.cfg.get("mt5.structure_max_rounds", 5) or 5)
    lines = [f"❌ 構造検査 違反 {len(viol)} 件（{st['fails']}/{limit} 回目）: " + ", ".join(v.get("id", "?") for v in viol), ""]
    lines += _viol_text(viol)
    if st["fails"] > limit:
        st["blocked"] = False
        lines.append(f"⚠ 構造検査の差し戻しが上限（{limit} 回）を超えました。バックテストはできますが、残っている違反と、直せなかった理由をユーザーに報告すること")
        return "\n".join(lines) + basic_note, False
    st["blocked"] = True
    lines.append("コンパイルは通ったが、構造の要件に違反しているため差し戻します。戦略ロジックは変えずに、違反ごとの「修正」のとおり"
                 "該当箇所だけを edit_file で直し（ファイル全体を書き直さない）、もう一度 mt5_compile を実行すること。"
                 "合格するまで mt5_backtest は使えません")
    return "\n".join(lines) + basic_note, True


# ------------------------------------------------------------------ v2.11.0: 価格データの書き出し
EXPORT_SCRIPT = r"""//+------------------------------------------------------------------+
//| AperCode_ExportRates.mq5 （AperCode が自動で置くスクリプト）        |
//| MQL5/Files/apercode_export_request.txt の指定で価格を CSV に書き出し、 |
//| 終わったらターミナルを閉じる                                        |
//+------------------------------------------------------------------+
#property script_show_inputs false

ENUM_TIMEFRAMES TfFrom(string s)
  {
   if(s=="M1") return PERIOD_M1;   if(s=="M5") return PERIOD_M5;   if(s=="M15") return PERIOD_M15;
   if(s=="M30") return PERIOD_M30; if(s=="H1") return PERIOD_H1;   if(s=="H4") return PERIOD_H4;
   if(s=="D1") return PERIOD_D1;   if(s=="W1") return PERIOD_W1;   if(s=="MN1") return PERIOD_MN1;
   return PERIOD_H1;
  }

void Done(string status)
  {
   int h=FileOpen("apercode_export_done.txt",FILE_WRITE|FILE_TXT|FILE_ANSI);
   if(h!=INVALID_HANDLE) { FileWriteString(h,status); FileClose(h); }
  }

void OnStart()
  {
   string sym=_Symbol, out="apercode_rates.csv";
   ENUM_TIMEFRAMES tf=PERIOD_H1;
   int bars=3000;
   datetime from=0, to=0;
   int h=FileOpen("apercode_export_request.txt",FILE_READ|FILE_TXT|FILE_ANSI);
   if(h!=INVALID_HANDLE)
     {
      while(!FileIsEnding(h))
        {
         string ln=FileReadString(h);
         int p=StringFind(ln,"=");
         if(p<0) continue;
         string k=StringSubstr(ln,0,p), v=StringSubstr(ln,p+1);
         StringTrimLeft(v); StringTrimRight(v);
         if(k=="symbol") sym=v;
         else if(k=="period") tf=TfFrom(v);
         else if(k=="bars") bars=(int)StringToInteger(v);
         else if(k=="from") from=StringToTime(v);
         else if(k=="to") to=StringToTime(v);
         else if(k=="out") out=v;
        }
      FileClose(h);
     }
   SymbolSelect(sym,true);
   MqlRates r[];
   ArraySetAsSeries(r,false);
   int got=-1;
   for(int i=0;i<60;i++)                      // 履歴の読み込みを待つ（最大 60 秒）
     {
      if(from>0) got=CopyRates(sym,tf,from,(to>0?to:TimeCurrent()),r);
      else got=CopyRates(sym,tf,0,bars,r);
      if(got>0 && (from>0 || got>=bars)) break;
      Sleep(1000);
     }
   if(got<=0)
     {
      Done("error "+IntegerToString(GetLastError())+" "+sym);
      TerminalClose(0);
      return;
     }
   int digits=(int)SymbolInfoInteger(sym,SYMBOL_DIGITS);
   int f=FileOpen(out,FILE_WRITE|FILE_TXT|FILE_ANSI);
   if(f==INVALID_HANDLE) { Done("error open "+out); TerminalClose(0); return; }
   FileWriteString(f,"time,open,high,low,close,tick_volume,spread
");
   for(int i=0;i<got;i++)
      FileWriteString(f,TimeToString(r[i].time,TIME_DATE|TIME_MINUTES)+","+DoubleToString(r[i].open,digits)+","+
                      DoubleToString(r[i].high,digits)+","+DoubleToString(r[i].low,digits)+","+DoubleToString(r[i].close,digits)+","+
                      IntegerToString(r[i].tick_volume)+","+IntegerToString(r[i].spread)+"
");
   FileClose(f);
   Done("ok "+IntegerToString(got));
   TerminalClose(0);
  }
"""
TIMEFRAMES = ("M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN1")


async def market_data(ctx: ToolContext, a: dict) -> str:
    """MT5 から価格（OHLC）を CSV に書き出し、作業ディレクトリの market_data/ に置く。"""
    paths = _mt5_paths(ctx)
    if not paths["terminal"].exists():
        raise ToolError(f"terminal64.exe が見つかりません: {paths['terminal']}（config.yaml の mt5 設定を確認）")
    sym = re.sub(r"[^\w.#-]", "", str(a.get("symbol") or ctx.cfg.get("mt5.tester.symbol", "USDJPY")))
    tf = str(a.get("period") or "H1").upper()
    if tf not in TIMEFRAMES:
        raise ToolError(f"period は {' / '.join(TIMEFRAMES)} のどれか")
    bars = max(50, min(int(a.get("bars") or 3000), 200000))
    frm, to = str(a.get("from_date") or "").strip(), str(a.get("to_date") or "").strip()
    for v in (frm, to):
        if v and not re.fullmatch(r"\d{4}\.\d{2}\.\d{2}", v):
            raise ToolError("from_date / to_date は YYYY.MM.DD")
    scripts = paths["mql5_dir"] / "Scripts" / "AperCode"
    scripts.mkdir(parents=True, exist_ok=True)
    src = scripts / "AperCode_ExportRates.mq5"
    notes = []
    if not src.exists() or src.read_text(encoding="utf-8", errors="replace") != EXPORT_SCRIPT or not src.with_suffix(".ex5").exists():
        src.write_text(EXPORT_SCRIPT, encoding="utf-8")
        ok, text, code, out, busy = await _compile_placed(ctx, paths, src, 180)
        if not ok:
            raise ToolError("書き出し用スクリプトのコンパイルに失敗しました（MT5・wine の再インストールや設定変更はしないこと）\n"
                            + (text[-1500:] or out[-800:]) + ("\n起動中の MetaEditor を閉じてから再実行してください" if busy else ""))
        notes.append("書き出し用スクリプトを準備しました")
    files = paths["mql5_dir"] / "Files"
    files.mkdir(parents=True, exist_ok=True)
    out_name = f"apercode_{sym}_{tf}.csv"
    for f in (files / out_name, files / "apercode_export_done.txt"):
        if f.exists():
            f.unlink()
    req = [f"symbol={sym}", f"period={tf}", f"bars={bars}", f"out={out_name}"]
    if frm:
        req.append(f"from={frm}")
    if to:
        req.append(f"to={to}")
    (files / "apercode_export_request.txt").write_text("\n".join(req) + "\n", encoding="ascii")
    ini_dir = paths["prefix"] / "drive_c" / "apercode"           # 空白を含まない場所（v2.10.8）
    ini_dir.mkdir(parents=True, exist_ok=True)
    ini = ini_dir / "apercode_export.ini"
    ini.write_text("\n".join(["[StartUp]", "Script=AperCode\\AperCode_ExportRates", f"Symbol={sym}", f"Period={tf}",
                              "ShutdownTerminal=1", ""]), encoding="utf-8")
    cmd = f'wine terminal64.exe{" /portable" if _portable(ctx, paths) else ""} /config:"{_to_win(paths["prefix"], ini)}"'
    env = {"WINEPREFIX": str(paths["prefix"]), "WINEDEBUG": "-all"}
    t0 = time.time()
    code, out = await run_shell(cmd, str(paths["terminal_dir"]), timeout=int(a.get("timeout", 300)), env=env, sandboxed=False)
    csv_src = files / out_name
    done = files / "apercode_export_done.txt"
    status = done.read_text(errors="replace").strip() if done.exists() else ""
    if not csv_src.exists():
        hint = _terminal_log_hint(paths["terminal_dir"], t0)
        raise ToolError(f"価格データを書き出せませんでした（終了コード {code}、状態: {status or '不明'}）\n"
                        + (f"MT5 のログ（今回の分）:\n{hint}\n" if hint else "")
                        + "MT5・wine の再インストールや設定変更はせず、この内容をユーザーに報告すること")
    dest = ctx.project_dir / "market_data"
    dest.mkdir(parents=True, exist_ok=True)
    target = dest / f"{sym}_{tf}.csv"
    shutil.copy2(csv_src, target)
    lines = target.read_text(errors="replace").splitlines()
    rng = f"{lines[1].split(',')[0]} 〜 {lines[-1].split(',')[0]}" if len(lines) > 2 else ""
    return "\n".join(notes + [f"価格データを書き出しました: {target}（{max(len(lines) - 1, 0)} 本、{rng}）",
                               "分析は market_stats（path に上のファイル）で行う"])


async def _sleep(sec: float) -> None:
    import asyncio
    await asyncio.sleep(sec)


def _parse_report(html: str) -> str:
    """v2.10.7: ストラテジーテスターのレポートから「項目: 値」をすべて抜き出す（日本語・英語どちらの MT5 でも）。
    取引の一覧（注文・約定の表）の手前までを読む。"""
    cut = len(html)
    for mark in ("<b>注文</b>", "<b>Orders</b>", ">注文<", ">Orders<"):
        i = html.find(mark)
        if i != -1:
            cut = min(cut, i)
    text = re.sub(r"<[^>]+>", "\n", html[:cut])
    lines = [ln.strip().replace("\xa0", " ") for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]
    rows, i = [], 0
    while i < len(lines):
        ln = lines[i]
        if ln.endswith(":") and len(ln) <= 60 and i + 1 < len(lines) and not lines[i + 1].endswith(":"):
            val = lines[i + 1]
            j = i + 2                              # パラメータのように値が何行も続くもの
            if ln.rstrip(":") in ("パラメータ", "Inputs", "Parameters"):
                while j < len(lines) and not lines[j].endswith(":") and "=" in lines[j]:
                    val += ", " + lines[j]
                    j += 1
            rows.append(f"{ln} {val}")
            i = j
            continue
        i += 1
    return "\n".join(rows) if rows else "(指標を抽出できませんでした。レポートを直接確認してください)"


def _terminal_log_hint(terminal_dir: Path, since: float) -> str:
    """今回の実行で MT5 が書いたログのうち、設定・テスターに関係する行（エラーの手がかり）。"""
    logs = sorted((terminal_dir / "logs").glob("2*.log"))
    if not logs:
        return ""
    try:
        text = _read_win_text(logs[-1])
    except OSError:
        return ""
    since_hms = time.strftime("%H:%M:%S", time.localtime(since - 2))
    rows = []
    for ln in text.splitlines():
        parts = ln.split("\t")
        hms = parts[2][:8] if len(parts) > 3 else ""
        if hms and hms >= since_hms and re.search(r"config|Tester|cannot|error|failed|LiveUpdate|launched", ln, re.I):
            rows.append("\t".join(parts[2:]))
    return "\n".join(rows[-15:])


def _copy_report(ctx: ToolContext, report: Path) -> Path:
    """v2.10.7: レポート（.htm と画像）を作業ディレクトリの bt_reports/ にコピーする。
    MT5 のフォルダはサンドボックスや read_file から見えないので、LLM が読めるようにする。"""
    dest = ctx.project_dir / "bt_reports"
    dest.mkdir(parents=True, exist_ok=True)
    for f in report.parent.glob(report.stem + "*"):
        if f.is_file() and f.suffix.lower() in (".htm", ".html", ".xml", ".png"):
            shutil.copy2(f, dest / f.name)
    return dest / report.name


def _prepare_ex5(ctx: ToolContext, paths: dict, path: str) -> Path:
    """バックテストする .ex5 を MT5 の Experts の中に用意して、そのパスを返す。"""
    src = ctx.resolve(path)
    ex5 = src if src.suffix == ".ex5" else src.with_suffix(".ex5")
    placed = _place_source(ctx, src if src.suffix == ".mq5" else src.with_suffix(".mq5"), paths["mql5_dir"]) \
        if src.with_suffix(".mq5").exists() else None
    placed_ex5 = (placed.with_suffix(".ex5") if placed else ex5)
    if ex5.exists() and placed and not placed_ex5.exists():
        shutil.copy2(ex5, placed_ex5)
    if not placed_ex5.exists():
        raise ToolError(f"コンパイル済み .ex5 がありません: {placed_ex5}。先に mt5_compile を実行してください")
    if (_STRUCT_STATE.get(str(placed_ex5)) or {}).get("blocked"):
        raise ToolError("この EA は構造検査に違反したままです。mt5_compile の出力にある違反を直して、もう一度 mt5_compile で合格させてから"
                        "バックテストしてください")
    return placed_ex5


async def _run_backtest(ctx: ToolContext, paths: dict, placed_ex5: Path, a: dict, timeout: int) -> dict:
    """ストラテジーテスターを 1 回動かす。{"ok", "report", "summary", "copied", "md", "code", "out", "hint", "ini"}"""
    t = ctx.cfg.get("mt5.tester", {})
    experts_dir = paths["mql5_dir"] / "Experts"
    expert_rel = str(placed_ex5.relative_to(experts_dir)).replace("/", "\\")
    report_name = f"AperCode_{placed_ex5.stem}_{int(time.time() * 1000)}"
    # v2.10.8: 設定ファイルは空白を含まない場所（C:\apercode\）に置く。"Program Files" のように空白があると、wine が引数全体を
    # 引用符で囲み、MT5 が /config: のパスの最後に " が付いたものとして読んで「cannot load config」になっていた
    ini_dir = paths["prefix"] / "drive_c" / "apercode"
    ini_dir.mkdir(parents=True, exist_ok=True)
    ini = ini_dir / "apercode_tester.ini"
    ini_text = "\n".join([
        "[Tester]",
        f"Expert={expert_rel}",
        f"Symbol={a.get('symbol') or t.get('symbol', 'USDJPY')}",
        f"Period={a.get('period') or t.get('period', 'H1')}",
        f"Model={a.get('model', t.get('model', 1))}",
        f"FromDate={a.get('from_date') or t.get('from', '2024.01.01')}",
        f"ToDate={a.get('to_date') or t.get('to', '2024.12.31')}",
        f"Deposit={t.get('deposit', 1000000)}",
        f"Leverage={t.get('leverage', 25)}",
        "Optimization=0",
        "Visual=0",
        f"Report={report_name}",
        "ReplaceReport=1",
        "ShutdownTerminal=1",
        "",
    ])
    if a.get("set_file"):
        ini_text += f"ExpertParameters={a['set_file']}\n"
    ini.write_text(ini_text, encoding="utf-8")
    cmd = f'wine terminal64.exe{" /portable" if _portable(ctx, paths) else ""} /config:"{_to_win(paths["prefix"], ini)}"'
    env = {"WINEPREFIX": str(paths["prefix"]), "WINEDEBUG": "-all"}
    t0 = time.time()
    code, out = await run_shell(cmd, str(paths["terminal_dir"]), timeout=timeout, env=env, sandboxed=False)
    report = next((paths["terminal_dir"] / f"{report_name}{ext}" for ext in (".htm", ".html", ".xml")
                   if (paths["terminal_dir"] / f"{report_name}{ext}").exists()), paths["terminal_dir"] / f"{report_name}.htm")
    res = {"ok": report.exists(), "report": report, "code": code, "out": out, "ini": ini, "summary": "", "copied": None, "md": None, "hint": ""}
    if not report.exists():
        res["hint"] = _terminal_log_hint(paths["terminal_dir"], t0)
        return res
    res["summary"] = _parse_report(_read_win_text(report))
    copied = _copy_report(ctx, report)
    md = copied.with_suffix(".md")
    md.write_text(f"# バックテスト結果: {placed_ex5.stem}\n\n元のレポート: {report}\n\n" +
                  "\n".join(f"- {r}" for r in res["summary"].splitlines()) + "\n", encoding="utf-8")
    res.update(copied=copied, md=md)
    return res


async def mt5_backtest(ctx: ToolContext, a: dict) -> str:
    paths = _mt5_paths(ctx)
    if not paths["terminal"].exists():
        raise ToolError(f"terminal64.exe が見つかりません: {paths['terminal']}")
    placed_ex5 = _prepare_ex5(ctx, paths, a["path"])
    r = await _run_backtest(ctx, paths, placed_ex5, a, int(a.get("timeout", 1800)))
    if not r["ok"]:
        hint = r["hint"]
        return (f"バックテストのレポートが見つかりません (exit {r['code']})。\n"
                f"ini: {r['ini']}\n" + (f"MT5 のログ（今回の分）:\n{hint}\n" if hint else
                                       f"ログ: {paths['terminal_dir']}/logs/ および Tester/logs/ を確認してください\n") +
                "MT5・wine の再インストールや設定変更はせず、この内容をユーザーに報告すること\n" + r["out"][-800:])
    copied, md = r["copied"], r["md"]
    pngs = sorted(p.name for p in copied.parent.glob(copied.stem + "*.png"))
    return (f"レポート（作業ディレクトリにコピー済み。read_file / read_document で読める）:\n"
            f"- 指標の一覧: {md}\n- レポート本体: {copied}\n" +
            (f"- グラフ画像: {', '.join(pngs)}\n" if pngs else "") +
            f"\n## 指標\n{r['summary']}")


# ------------------------------------------------------------------ v2.11.5: 過去のイベント（会合など）でまとめてバックテスト
_METRIC_LABELS = {
    "net": ("総損益", "Total Net Profit"),
    "pf": ("プロフィットファクター", "Profit Factor"),
    "trades": ("取引数", "Total Trades"),
    "dd": ("証拠金最大ドローダウン", "Equity Drawdown Maximal"),
}


def _metrics(summary: str) -> dict:
    """レポートの「項目: 値」から主な数値を取り出す（日本語・英語の MT5 どちらでも）。"""
    out: dict = {}
    for ln in summary.splitlines():
        if ":" not in ln:
            continue
        label, val = ln.split(":", 1)
        label = label.strip()
        for k, names in _METRIC_LABELS.items():
            if k not in out and any(label == n for n in names):
                m = re.search(r"-?\d[\d\s,]*(?:\.\d+)?", val.replace("\u00a0", " "))
                if m:
                    try:
                        out[k] = float(re.sub(r"[\s,]", "", m.group(0)))
                    except ValueError:
                        pass
    if "trades" in out:
        out["trades"] = int(out["trades"])
    return out


def _windows(ctx: ToolContext, a: dict) -> tuple[list[dict], list[str]]:
    """検証する窓 [{date, name, kind, from, to}]。events（日付のリスト）か、topic の events.json から選ぶ。"""
    from datetime import date, datetime, timedelta
    from .. import research as R
    notes: list[str] = []
    evs: list[dict] = []
    for e in a.get("events") or []:
        if isinstance(e, str):
            evs.append({"date": e, "name": e, "kind": ""})
        elif isinstance(e, dict) and e.get("date"):
            evs.append({"date": str(e["date"]), "name": str(e.get("name") or e["date"]), "kind": str(e.get("kind") or "")})
    if not evs and a.get("topic"):
        evs = R.select_events(R.load_events(ctx.project_dir, str(a["topic"])), str(a.get("kind") or ""))
    if not evs:
        raise ToolError("検証するイベントがありません。events に日付（YYYY-MM-DD）を渡すか、event_calendar で topic にイベントを記録してから"
                        " topic（と kind）を指定する")
    before = max(0, int(a.get("days_before", 2)))
    after = max(0, int(a.get("days_after", 2)))
    today = date.today()
    out = []
    for e in evs:
        try:
            d = datetime.strptime(str(e["date"]).replace(".", "-").replace("/", "-")[:10], "%Y-%m-%d").date()
        except ValueError:
            notes.append(f"日付を読めないため除外: {e['date']}")
            continue
        if d + timedelta(days=after) >= today:
            notes.append(f"まだ終わっていないため除外: {d}（{e.get('name', '')}）")
            continue
        out.append({"date": d.isoformat(), "name": e.get("name") or d.isoformat(), "kind": e.get("kind") or "",
                    "from": (d - timedelta(days=before)).strftime("%Y.%m.%d"), "to": (d + timedelta(days=after)).strftime("%Y.%m.%d")})
    out.sort(key=lambda w: w["date"])
    limit = int(ctx.cfg.get("mt5.event_backtest_max", 20) or 20)
    if len(out) > limit:
        notes.append(f"イベントが {len(out)} 件あるため、新しい {limit} 件だけを検証（mt5.event_backtest_max）")
        out = out[-limit:]
    return out, notes


def _fmt(v, nd=2) -> str:
    return "-" if v is None else (f"{v:,.{nd}f}" if isinstance(v, float) else str(v))


async def mt5_event_backtest(ctx: ToolContext, a: dict) -> str:
    """過去の同じ種類のイベントの前後だけを、1 つずつバックテストして集計する。"""
    paths = _mt5_paths(ctx)
    if not paths["terminal"].exists():
        raise ToolError(f"terminal64.exe が見つかりません: {paths['terminal']}")
    placed_ex5 = _prepare_ex5(ctx, paths, a["path"])
    wins, notes = _windows(ctx, a)
    if not wins:
        raise ToolError("検証できる過去のイベントがありません。\n" + "\n".join(notes))
    per = int(a.get("timeout_each", 600))
    rows = []
    for w in wins:
        r = await _run_backtest(ctx, paths, placed_ex5, {**a, "from_date": w["from"], "to_date": w["to"]}, per)
        m = _metrics(r["summary"]) if r["ok"] else {}
        rows.append({**w, "ok": r["ok"], **m, "report": str(r["md"]) if r["md"] else "",
                     "error": "" if r["ok"] else (r["hint"] or r["out"][-300:] or f"exit {r['code']}")})
    done = [x for x in rows if x["ok"]]
    traded = [x for x in done if (x.get("trades") or 0) > 0]
    total_net = sum(x.get("net") or 0.0 for x in done)
    total_trades = sum(x.get("trades") or 0 for x in done)
    plus = [x for x in traded if (x.get("net") or 0) > 0]
    minus = [x for x in traded if (x.get("net") or 0) < 0]
    worst = min(traded, key=lambda x: x.get("net") or 0.0) if traded else None
    best = max(traded, key=lambda x: x.get("net") or 0.0) if traded else None
    gp = sum(x["net"] for x in plus)
    gl = -sum(x["net"] for x in minus)
    summary = {"ea": placed_ex5.stem, "symbol": a.get("symbol") or ctx.cfg.get("mt5.tester.symbol", ""),
               "period": a.get("period") or ctx.cfg.get("mt5.tester.period", ""), "days_before": int(a.get("days_before", 2)),
               "days_after": int(a.get("days_after", 2)), "windows": len(rows), "completed": len(done), "traded": len(traded),
               "plus": len(plus), "minus": len(minus), "total_net": round(total_net, 2), "total_trades": total_trades,
               "window_pf": round(gp / gl, 2) if gl > 0 else None,
               "avg_net": round(total_net / len(traded), 2) if traded else None,
               "worst": {"date": worst["date"], "net": worst.get("net")} if worst else None,
               "best": {"date": best["date"], "net": best.get("net")} if best else None, "rows": rows, "notes": notes}
    warns = []
    if len(done) < len(rows):
        warns.append(f"{len(rows) - len(done)} 件の窓でバックテストのレポートが作られませんでした（各行の error を確認）")
    if done and len(traded) <= len(done) // 2:
        warns.append(f"{len(done)} 件中 {len(done) - len(traded)} 件の窓で取引がありません。EA の期間制限（input datetime）がテスター中も効いていないか"
                     "（MQLInfoInteger(MQL_TESTER) のときは期間制限を無視する）、エントリー条件が厳しすぎないかを確かめる")
    if total_trades < int(ctx.cfg.get("mt5.event_min_trades", 30)):
        warns.append(f"取引数の合計が {total_trades} 回と少なく、結果の統計的な裏付けは弱い。イベントの数を増やすか、結論を控えめにすること")
    summary["warnings"] = warns
    dest = Path(ctx.project_dir) / "bt_reports"
    dest.mkdir(parents=True, exist_ok=True)
    stem = f"event_{placed_ex5.stem}_{time.strftime('%Y%m%d_%H%M%S')}"
    (dest / f"{stem}.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    L = [f"# イベント窓のバックテスト: {placed_ex5.stem}", "",
         f"各イベントの {summary['days_before']} 日前〜{summary['days_after']} 日後だけを 1 回ずつテスト（{summary['symbol']} {summary['period']}）", "",
         "| # | イベント | 期間 | 取引数 | 損益 | PF | 最大DD |", "|---|---|---|---|---|---|---|"]
    for i, x in enumerate(rows, 1):
        if x["ok"]:
            L.append(f"| {i} | {x['date']} {x['name'] if x['name'] != x['date'] else ''} | {x['from']}〜{x['to']} | {x.get('trades', '-')} | "
                     f"{_fmt(x.get('net'))} | {_fmt(x.get('pf'))} | {_fmt(x.get('dd'))} |")
        else:
            L.append(f"| {i} | {x['date']} {x['name'] if x['name'] != x['date'] else ''} | {x['from']}〜{x['to']} | 失敗 | - | - | - |")
    L += ["", "## 集計",
          f"- 窓の数: {len(rows)}（テストできた {len(done)}・取引があった {len(traded)}）",
          f"- 勝った窓 / 負けた窓: {len(plus)} / {len(minus)}" + (f"（勝った窓の割合 {len(plus) / len(traded):.0%}）" if traded else ""),
          f"- 損益の合計: {_fmt(round(total_net, 2))}（取引数の合計 {total_trades}）",
          f"- 窓ごとの PF（勝った窓の損益合計 ÷ 負けた窓の損失合計）: {_fmt(summary['window_pf'])}",
          f"- 1 窓あたりの平均損益: {_fmt(summary['avg_net'])}",
          f"- 最も悪い窓: {worst['date']}（{_fmt(worst.get('net'))}）" if worst else "- 最も悪い窓: -",
          f"- 最も良い窓: {best['date']}（{_fmt(best.get('net'))}）" if best else "- 最も良い窓: -"]
    if warns or notes:
        L += ["", "## 注意"] + [f"- ⚠ {w}" for w in warns] + [f"- {n}" for n in notes]
    md = "\n".join(L) + "\n"
    (dest / f"{stem}.md").write_text(md, encoding="utf-8")
    return f"（保存: {dest / (stem + '.md')} と .json。各窓のレポートは bt_reports/ の AperCode_{placed_ex5.stem}_*）\n\n" + md


register(Tool("mt5_compile",
              "MQL5 ソース (.mq5) を MetaEditor (wine) でコンパイルし、エラー/警告を返す。EA を書いたら必ず実行して確認する。"
              "コンパイルが通った EA は AperCode がチェックする（基本の形の確認。構造検査のスキルが入っていれば構造検査もして、違反は差し戻す）。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": ".mq5 ファイルのパス"},
                  "mtf": {"type": "string", "description": "構造検査（スキル mql5-structure-check があるとき）: single（単一足の EA。InpHigherTF を宣言しない）/ mtf（上位足必須。InpHigherTF を宣言して実際に使う）。省略可"},
                  "tf": {"type": "string", "description": "構造検査（スキルがあるとき）: 執行足（例: H1）。InpExecutionTF がこの値か確かめる。省略可"},
                  "timeout": {"type": "integer"}},
               "required": ["path"]}, mt5_compile, lambda a: a.get("path", "")))

register(Tool("market_data",
              "MT5 から価格データ（始値・高値・安値・終値）を CSV に書き出し、作業ディレクトリの market_data/ に置く。"
              "相場の分析（market_stats）や、資料の主張の確認に使う。",
              {"type": "object", "properties": {
                  "symbol": {"type": "string", "description": "銘柄（既定は mt5.tester.symbol）"},
                  "period": {"type": "string", "description": "M1/M5/M15/M30/H1/H4/D1/W1/MN1（既定 H1）"},
                  "bars": {"type": "integer", "description": "本数（既定 3000。from_date を指定したときは使わない）"},
                  "from_date": {"type": "string", "description": "YYYY.MM.DD（任意）"},
                  "to_date": {"type": "string", "description": "YYYY.MM.DD（任意）"},
                  "timeout": {"type": "integer"}}},
              market_data, lambda a: f"{a.get('symbol', '')} {a.get('period', 'H1')} {a.get('bars') or a.get('from_date') or ''}"))

register(Tool("mt5_event_backtest",
              "期間限定・イベント向けの EA を、過去の同じ種類のイベント（FOMC・日銀会合など）の前後だけで 1 回ずつバックテストし、"
              "窓ごとの損益・取引数と、勝った窓の割合・最も悪い窓・合計を集計する。1 回の短い期間の結果だけで判断しないために使う。"
              "イベントは events（日付のリスト）か、event_calendar で記録した topic と kind で指定する。時間がかかる。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": ".mq5 または .ex5 のパス"},
                  "events": {"type": "array", "items": {"type": "string"}, "description": "イベントの日付 YYYY-MM-DD のリスト（topic を使うなら省略）"},
                  "topic": {"type": "string", "description": "event_calendar のテーマ（例: USDJPY）"},
                  "kind": {"type": "string", "description": "イベントの種類で絞る（例: FOMC、BOJ、FOMC,BOJ）"},
                  "days_before": {"type": "integer", "description": "イベントの何日前からテストするか（既定 2）"},
                  "days_after": {"type": "integer", "description": "イベントの何日後までテストするか（既定 2）"},
                  "symbol": {"type": "string"}, "period": {"type": "string", "description": "M1/M5/M15/M30/H1/H4/D1"},
                  "model": {"type": "integer", "description": "0=every tick,1=1min OHLC,2=open only,4=real ticks"},
                  "set_file": {"type": "string", "description": "パラメータ .set ファイル名（任意）"},
                  "timeout_each": {"type": "integer", "description": "1 窓あたりの秒数（既定 600）"}},
               "required": ["path"]}, mt5_event_backtest,
              lambda a: f"{a.get('path', '')} {a.get('kind') or ''} {len(a.get('events') or []) or a.get('topic') or ''}"))

register(Tool("mt5_backtest",
              "コンパイル済み EA をストラテジーテスターでバックテストし、主要指標（純利益・PF・DD 等）を返す。時間がかかる。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": ".mq5 または .ex5 のパス"},
                  "symbol": {"type": "string"}, "period": {"type": "string", "description": "M1/M5/M15/H1/H4/D1"},
                  "from_date": {"type": "string", "description": "YYYY.MM.DD"},
                  "to_date": {"type": "string", "description": "YYYY.MM.DD"},
                  "model": {"type": "integer", "description": "0=every tick,1=1min OHLC,2=open only,4=real ticks"},
                  "set_file": {"type": "string", "description": "パラメータ .set ファイル名（任意）"},
                  "timeout": {"type": "integer"}},
               "required": ["path"]}, mt5_backtest, lambda a: a.get("path", "")))
