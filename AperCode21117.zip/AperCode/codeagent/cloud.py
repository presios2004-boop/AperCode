"""クラウド AI への「相談」クライアント（v1.2.4）。

ローカル LLM が行き詰まったとき、状況をまとめてクラウドの強いモデルにヒントを求めるために使う。
会話全体を渡すのではなく、目的・エラー・試したこと・関連コードの抜粋だけを 1 回の単発リクエストで送る。

対応プロバイダ（公開版）: anthropic（Claude, Messages API）のみ。
API キーは config の cloud.api_key、無ければ環境変数 ANTHROPIC_API_KEY から読む。
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass

import httpx

# プロバイダのプリセット。models は UI のプルダウン用（手入力も可）
PROVIDERS: dict[str, dict] = {
    # 公開版は動作確認済みの Anthropic（Claude API）だけに対応する
    "anthropic": {"label": "Anthropic Claude", "env": "ANTHROPIC_API_KEY", "base_url": "https://api.anthropic.com",
                  "models": ["claude-sonnet-5-5", "claude-opus-5-5", "claude-fable-5-1", "claude-haiku-5-5"]},
}

# 送信前にマスクする秘密情報らしきもの
_SECRET_PATTERNS = [
    r"(?i)(api[_-]?key|secret|token|password|passwd|authorization)\s*[:=]\s*['\"]?([A-Za-z0-9_\-./+=]{12,})",
    r"\bsk-[A-Za-z0-9_\-]{16,}\b", r"\bsk-ant-[A-Za-z0-9_\-]{16,}\b", r"\bAIza[0-9A-Za-z_\-]{30,}\b",
    r"\bgh[pousr]_[A-Za-z0-9]{30,}\b", r"\bxox[baprs]-[A-Za-z0-9\-]{10,}\b",
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----",
]


def mask_secrets(text: str) -> tuple[str, int]:
    """秘密情報らしき文字列を <masked> に置き換える。(結果, 置換数)"""
    n = 0
    for pat in _SECRET_PATTERNS:
        def _rep(m):
            nonlocal n
            n += 1
            if m.lastindex and m.lastindex >= 2:
                return m.group(0).replace(m.group(2), "<masked>")
            return "<masked>"
        text = re.sub(pat, _rep, text)
    return text, n


@dataclass
class CloudSettings:
    provider: str = "anthropic"
    model: str = ""
    api_key: str = ""
    base_url: str = ""
    timeout: float = 120.0
    max_tokens_cap: int = 32000          # v2.11.12: 本文が空（思考で使い切り）のときにやり直す上限

    @classmethod
    def from_cfg(cls, cfg, role: str = "") -> "CloudSettings":
        """role: consult（ask_cloud）/ chat（cloud_chat）/ review（最終レビュー）。cloud.models.<role> があればそのモデルを使う（v2.11.8）。"""
        prov = "anthropic"                    # 公開版は Claude のみ（他のプロバイダが設定されていても Claude を使う）
        preset = PROVIDERS[prov]
        key = str(cfg.get("cloud.api_key", "") or "") or os.environ.get(preset["env"], "")
        if not key and prov == "gemini":
            key = os.environ.get("GOOGLE_API_KEY", "")
        model = str(cfg.get("cloud.model", "") or "") or (preset["models"][0] if preset["models"] else "")
        if role in ROLES:
            model = str((cfg.get("cloud.models", {}) or {}).get(role) or "").strip() or model
        base = str(cfg.get("cloud.base_url", "") or "") or preset["base_url"]
        return cls(provider=prov, model=model, api_key=key, base_url=base.rstrip("/"),
                   timeout=float(cfg.get("cloud.timeout", 300)),
                   max_tokens_cap=int(cfg.get("cloud.max_tokens_cap", 32000) or 32000))

    @property
    def ready(self) -> bool:
        return bool(self.api_key and self.model and (self.base_url or self.provider in ("anthropic", "gemini")))

    def describe(self) -> str:
        return f"{PROVIDERS.get(self.provider, {}).get('label', self.provider)} / {self.model}"


ROLES = ("consult", "chat", "review")
ROLE_LABEL = {"consult": "相談", "chat": "会話", "review": "レビュー"}


class CloudClient:
    def __init__(self, s: CloudSettings):
        self.s = s

    async def ask(self, system: str, prompt: str, max_tokens: int = 4096) -> str:
        s = self.s
        if not s.api_key:
            raise RuntimeError(f"API キーが設定されていません（cloud.api_key または環境変数 "
                               f"{PROVIDERS.get(s.provider, PROVIDERS['anthropic'])['env']}）")
        async with httpx.AsyncClient(timeout=httpx.Timeout(s.timeout, connect=15.0)) as c:
            if s.provider == "anthropic":
                # v2.11.12: 思考（adaptive thinking）が既定でオンのモデル（Haiku 5.5 など）は、思考に max_tokens を使い切ると
                # 本文が空のまま終わる（stop_reason=max_tokens）。そのときは上限を広げて 1 回だけやり直し、それでも空ならエラーにする
                limit = max(int(max_tokens), 256)
                for attempt in range(2):
                    r = await c.post(f"{s.base_url or 'https://api.anthropic.com'}/v1/messages",
                                     headers={"x-api-key": s.api_key, "anthropic-version": "2023-06-01",
                                              "content-type": "application/json"},
                                     json={"model": s.model, "max_tokens": limit, "system": system,
                                           "messages": [{"role": "user", "content": prompt}]})
                    self._raise(r)
                    data = r.json()
                    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
                    if text:
                        return text
                    stop = data.get("stop_reason")
                    kinds = sorted({str(b.get("type")) for b in data.get("content", [])})
                    if stop == "max_tokens" and attempt == 0 and limit < s.max_tokens_cap:
                        limit = min(max(limit * 4, 16000), s.max_tokens_cap)
                        continue
                    raise RuntimeError(f"クラウド AI の応答に本文がありませんでした（stop_reason={stop}、含まれていたもの: {', '.join(kinds) or 'なし'}、"
                                       f"max_tokens={limit}）。思考で上限を使い切った可能性があります。cloud.max_tokens を増やすか、別のモデルを試してください")
            if s.provider == "gemini":
                base = s.base_url or "https://generativelanguage.googleapis.com"
                r = await c.post(f"{base}/v1beta/models/{s.model}:generateContent",
                                 headers={"x-goog-api-key": s.api_key, "content-type": "application/json"},
                                 json={"system_instruction": {"parts": [{"text": system}]},
                                       "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                                       "generationConfig": {"maxOutputTokens": max_tokens, "temperature": 0.2}})
                self._raise(r)
                data = r.json()
                cands = data.get("candidates") or []
                if not cands:
                    raise RuntimeError(f"Gemini から応答がありません: {str(data)[:300]}")
                parts = (cands[0].get("content") or {}).get("parts") or []
                return "".join(p.get("text", "") for p in parts).strip()
            # OpenAI 互換
            if not s.base_url:
                raise RuntimeError("cloud.base_url が設定されていません（custom プロバイダ）")
            headers = {"Authorization": f"Bearer {s.api_key}", "content-type": "application/json"}
            if s.provider == "openrouter":
                headers["HTTP-Referer"] = "https://github.com/apercode"
                headers["X-Title"] = "AperCode"
            body = {"model": s.model, "messages": [{"role": "system", "content": system},
                                                    {"role": "user", "content": prompt}],
                    "max_tokens": max_tokens, "temperature": 0.2}
            r = await c.post(f"{s.base_url}/chat/completions", headers=headers, json=body)
            if r.status_code == 400 and "max_tokens" in r.text:
                body.pop("max_tokens", None)
                body["max_completion_tokens"] = max_tokens   # 新しい OpenAI モデル向け
                body.pop("temperature", None)
                r = await c.post(f"{s.base_url}/chat/completions", headers=headers, json=body)
            self._raise(r)
            data = r.json()
            choices = data.get("choices") or []
            if not choices:
                raise RuntimeError(f"応答がありません: {str(data)[:300]}")
            msg = choices[0].get("message") or {}
            return str(msg.get("content") or "").strip()

    @staticmethod
    def _raise(r: httpx.Response) -> None:
        if r.status_code >= 400:
            txt = r.text[:400]
            hint = ""
            if r.status_code in (401, 403):
                hint = "（API キーが無効か、権限がありません）"
            elif r.status_code == 404:
                hint = "（モデル名が間違っている可能性）"
            elif r.status_code == 429:
                hint = "（レート制限または残高不足）"
            raise RuntimeError(f"クラウド API エラー {r.status_code}{hint}: {txt}")

    async def test(self) -> str:
        """接続テスト: 短い応答を返す。"""
        return await self.ask("You are a connectivity test. Reply with exactly: OK", "ping", max_tokens=2048)


ASK_SYSTEM = """You are a senior software engineer acting as an escalation point for a local coding agent that is stuck.
The agent cannot see you and will implement your advice itself, so be concrete and verifiable.
Reply in Japanese. Structure:
1. 原因の仮説（確度の高い順に最大 3 つ。それぞれ根拠を 1 行）
2. 確認方法（各仮説を確かめるコマンドやコード）
3. 修正案（unified diff またはコード断片。ファイルパスを明示）
4. それでも直らない場合の次の一手
Do not restate the problem. Do not pad. If information is missing, say exactly what to gather."""


def build_prompt(goal: str, error: str, tried: str, code: str, question: str, env: str) -> str:
    parts = [f"## 目的\n{goal.strip()}"]
    if env:
        parts.append(f"## 環境\n{env.strip()}")
    if error:
        parts.append(f"## エラー / 症状\n```\n{error.strip()[:6000]}\n```")
    if tried:
        parts.append(f"## 試したことと結果\n{tried.strip()[:3000]}")
    if code:
        parts.append(f"## 関連コード（抜粋）\n{code[:20000]}")
    if question:
        parts.append(f"## 質問\n{question.strip()[:1000]}")
    return "\n\n".join(parts)


# v2.11.6: 完了前の最終レビュー（AperCode が作った変更を、クラウド AI が 1 回で読んで指摘する）
REVIEW_SYSTEM = """You are a senior code reviewer doing the final review of changes made by a local coding agent before it reports
completion. You receive the task, a unified diff and the current content of the changed files. You cannot run code.
Review critically for: bugs and logic errors, boundary conditions, unhandled errors, mismatches with callers (arguments, return
values, renamed or undefined references), requirements in the task that the change misses, security problems (injection, missing
path validation, hard-coded secrets), resource leaks, infinite loops and clear performance problems. For MQL5 / trading code also
check order handling (SL/TP, position count, magic number), use of the forming bar vs closed bars, and indicator handle handling.
Do not comment on style, naming, comments or minor refactors. Be concrete: name the file and line, say what goes wrong and how to fix it.
Write "problem" and "fix" in {lang}.
Output only one JSON object at the end (you may write brief reasoning before it):
{"ok": true|false, "issues": [{"file": "path", "line": number or null, "severity": "high|medium|low", "problem": "...", "fix": "..."}]}
"ok" is true only when there is no high or medium issue. Use [] when there are no issues."""


def build_review_prompt(task: str, diff: str, files: dict[str, str], max_chars: int = 60000) -> str:
    """タスク・diff・変更後のファイル全体（入るだけ）を 1 つの文章にする。"""
    parts = [f"## Task\n{(task or '(unknown)').strip()[:3000]}", f"## Diff\n```diff\n{diff}\n```"]
    used = sum(len(p) for p in parts)
    for path, text in files.items():
        block = f"## Current content: {path}\n```\n" + "\n".join(f"{i:4d}| {l}" for i, l in enumerate(text.splitlines(), 1)) + "\n```"
        if used + len(block) > max_chars:
            parts.append(f"## Current content: {path}\n(omitted: too long)")
            continue
        parts.append(block)
        used += len(block)
    return "\n\n".join(parts)


def parse_review_json(text: str) -> dict | None:
    """レビューの応答から最後の {"ok": ..., "issues": [...]} を取り出す。無ければ None。"""
    import json as _json
    import re as _re
    objs = list(_re.finditer(r"\{[^{}]*\"ok\"[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", text or "", _re.S))
    for m in reversed(objs):
        try:
            data = _json.loads(m.group(0))
        except _json.JSONDecodeError:
            continue
        if isinstance(data, dict) and "ok" in data:
            data["issues"] = [i for i in (data.get("issues") or []) if isinstance(i, dict)]
            return data
    return None
