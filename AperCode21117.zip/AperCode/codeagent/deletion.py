"""成果物の削除の確認（v2.11.7）。

自律モードでも「ターンの開始前からあったファイル」（前の作業の成果物）を消すコマンドは、ユーザーに確認する。
作業のために今回のターンで作ったファイル（一時ファイル）や、キャッシュ・ビルドの生成物は確認しない。

コマンドを実行する前に、rm / unlink / rmdir / find -delete / git clean と、Python の os.remove・shutil.rmtree・
Path.unlink などを読み取り、消える可能性のあるファイルを推定する。推定なので、変数で組み立てたパスなどは拾えない。
"""
from __future__ import annotations

import fnmatch
import glob
import os
import re
import shlex
from pathlib import Path

# 走査しないフォルダ（中身の数が多い・成果物ではない）
SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
             ".apercode", ".cache", ".tox", ".idea", ".vscode"}
# 消しても確認しないもの（キャッシュ・ビルドの生成物・一時ファイル）
TEMP_DIRS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".cache", "tmp", "temp", ".tmp", "build", "dist",
             ".apercode", "htmlcov", ".tox"}
TEMP_EXT = {".pyc", ".pyo", ".tmp", ".temp", ".o", ".obj", ".bak", ".swp", ".coverage"}
MAX_FILES = 200_000


def scan(project: Path, skip: tuple[str, ...] = ()) -> set[str]:
    """ターンの開始時にあるファイルの一覧（作業ディレクトリからの相対パス）。"""
    project = Path(project)
    out: set[str] = set()
    skipset = SKIP_DIRS | set(skip)
    for root, dirs, files in os.walk(project):
        dirs[:] = [d for d in dirs if d not in skipset]
        for f in files:
            out.add(os.path.relpath(os.path.join(root, f), project))
            if len(out) >= MAX_FILES:
                return out
    return out


def is_temp(rel: str) -> bool:
    parts = Path(rel).parts
    return any(p in TEMP_DIRS for p in parts[:-1]) or Path(rel).suffix.lower() in TEMP_EXT


def _files_under(p: Path) -> list[Path]:
    if p.is_file() or p.is_symlink():
        return [p]
    if p.is_dir():
        out = []
        for root, dirs, files in os.walk(p):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            out += [Path(root) / f for f in files]
            if len(out) > 5000:
                break
        return out
    return []


def _expand(arg: str, cwd: Path) -> list[Path]:
    a = os.path.expanduser(arg)
    base = a if os.path.isabs(a) else str(cwd / a)
    if any(ch in a for ch in "*?["):
        return [Path(x) for x in glob.glob(base, recursive=True)]
    return [Path(base)]


def _split(cmd: str) -> list[list[str]]:
    lex = shlex.shlex(cmd.replace("\n", " ; "), posix=True, punctuation_chars=";&|<>()")
    lex.whitespace_split = True
    try:
        toks = list(lex)
    except ValueError:
        toks = cmd.split()
    segs, cur = [], []
    for tk in toks:
        if tk and all(c in ";&|<>()" for c in tk):
            if cur:
                segs.append(cur)
            cur = []
        else:
            cur.append(tk)
    if cur:
        segs.append(cur)
    return segs


_PY_DEL = re.compile(r"\b(os\.remove|os\.unlink|os\.rmdir|shutil\.rmtree|\.unlink\s*\(|\.rmdir\s*\(|send2trash)")
_PY_STR = re.compile(r"""(?:r|f|rf|fr)?(['"])((?:(?!\1).){1,300})\1""")


def _python_targets(code: str, cwd: Path) -> list[Path]:
    """Python のコードが消しそうなファイル: 削除の呼び出しがあれば、コード中の文字列のうちパスらしいものを候補にする。"""
    if not _PY_DEL.search(code):
        return []
    out: list[Path] = []
    for m in _PY_STR.finditer(code):
        s = m.group(2)
        if "/" in s or "*" in s or re.search(r"\.\w{1,5}$", s) or (cwd / s).exists():
            out += _expand(s, cwd)
    return out


def targets(command: str, cwd: Path) -> list[Path]:
    """シェルのコマンド列が消しそうなファイル（存在するものだけ。フォルダは中のファイルに展開）。"""
    cwd = Path(cwd)
    found: list[Path] = []
    for seg in _split(command or ""):
        while seg and re.match(r"^\w+=", seg[0]):            # 先頭の環境変数の代入
            seg = seg[1:]
        if seg and seg[0] in ("sudo", "nice", "nohup", "command", "builtin", "env", "xargs"):
            seg = seg[1:]
        if not seg:
            continue
        exe, args = os.path.basename(seg[0]), seg[1:]
        if exe == "cd" and args:
            nxt = Path(os.path.expanduser(args[0]))
            cwd = nxt if nxt.is_absolute() else (cwd / nxt)
            continue
        if exe in ("rm", "unlink", "rmdir", "shred"):
            for a in args:
                if a.startswith("-") and a != "-":
                    continue
                for p in _expand(a, cwd):
                    found += _files_under(p)
        elif exe == "find" and ("-delete" in args or ("-exec" in args and any(x in ("rm", "/bin/rm") for x in args))):
            roots = []
            for x in args:
                if x.startswith("-") or x in ("!", "("):
                    break
                roots.append(x)
            pats = [args[i + 1] for i, x in enumerate(args[:-1]) if x in ("-name", "-iname")]
            for r in roots or ["."]:
                for p in _expand(r, cwd):
                    for f in _files_under(p):
                        if not pats or any(fnmatch.fnmatch(f.name, pt) for pt in pats):
                            found.append(f)
        elif exe == "git" and args[:1] == ["clean"] and any(re.match(r"-\w*f", a) for a in args[1:]):
            found += _files_under(cwd)
        elif exe in ("python", "python3") and "-c" in args:
            i = args.index("-c")
            if i + 1 < len(args):
                found += [f for p in _python_targets(args[i + 1], cwd) for f in _files_under(p)]
    return found


def protected(paths: list[Path], project: Path, preexisting: set[str] | None) -> list[str]:
    """消えると困るファイル（ターンの開始前からあった、一時ファイルではないもの）の相対パス。"""
    project = Path(project).resolve()
    out: list[str] = []
    for p in paths:
        try:
            rel = os.path.relpath(Path(p).resolve(), project)
        except (OSError, ValueError):
            continue
        if rel.startswith(".."):
            continue                                            # 作業ディレクトリの外はサンドボックス・別の確認が扱う
        if is_temp(rel):
            continue
        if preexisting is None or rel in preexisting:
            out.append(rel)
    return sorted(set(out))


def check(tool: str, args: dict, project: Path, preexisting: set[str] | None) -> list[str]:
    """ツール呼び出しが消しそうな成果物の一覧（空なら確認不要）。"""
    project = Path(project)
    if tool in ("run_command", "process_start"):
        cwd = project
        if args.get("cwd"):
            c = Path(os.path.expanduser(str(args["cwd"])))
            cwd = c if c.is_absolute() else project / c
        paths = targets(str(args.get("command") or ""), cwd)
    elif tool == "repl":
        paths = [f for p in _python_targets(str(args.get("code") or ""), project) for f in _files_under(p)]
    else:
        return []
    return protected(paths, project, preexisting)
