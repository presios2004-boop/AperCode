"""ツールレジストリ。各ツールは Tool を継承し、register() で登録する。"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Awaitable

from ..config import Config


class ToolError(Exception):
    pass


@dataclass
class ToolContext:
    cfg: Config
    project_dir: Path
    depth: int = 0                                     # 0 = メインエージェント, 1 = 子エージェント
    spawn: Callable[[dict[str, Any]], Awaitable[str]] | None = None  # spawn_agent の実体（agent が注入）
    memory: Any = None                                 # MemoryStore（agent が注入。None なら無効）
    backup: Any = None                                 # BackupManager（agent が注入。None なら無効）
    verify: Any = None                                 # VerifyState（agent が注入。ターンの検証状態）

    def resolve(self, path: str) -> Path:
        """ワークスペース外へのアクセスを拒否しつつパスを解決する。"""
        p = Path(path).expanduser()
        if not p.is_absolute():
            p = self.project_dir / p
        p = p.resolve()
        root = self.cfg.workspace_root
        if root != p and root not in p.parents:
            raise ToolError(f"ワークスペース外のパスです: {p}（許可: {root} 配下）")
        return p


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]
    handler: Callable[[ToolContext, dict[str, Any]], Awaitable[str]]
    # UI に表示する要約を作る（承認ダイアログ用）
    summarize: Callable[[dict[str, Any]], str] = field(default=lambda a: "")

    def schema(self) -> dict:
        return {"type": "function", "function": {
            "name": self.name, "description": self.description, "parameters": self.parameters}}


_REGISTRY: dict[str, Tool] = {}


def register(tool: Tool) -> Tool:
    _REGISTRY[tool.name] = tool
    return tool


def get(name: str) -> Tool | None:
    return _REGISTRY.get(name)


def all_tools() -> list[Tool]:
    return list(_REGISTRY.values())


def schemas(names: list[str] | None = None) -> list[dict]:
    from ..i18n import tool_schema
    if names is None:
        return [tool_schema(t.schema()) for t in _REGISTRY.values()]
    return [tool_schema(_REGISTRY[n].schema()) for n in names if n in _REGISTRY]


# サブエージェントのモード別に使えるツール
READ_ONLY_TOOLS = ["read_file", "list_dir", "glob", "grep", "search_memory", "web_search", "fetch_url"]
CODE_TOOLS = READ_ONLY_TOOLS + ["write_file", "edit_file", "run_command", "mt5_compile", "mt5_backtest", "save_memory",
                                "list_backups", "restore_backup", "make_icon", "run_tests", "ask_cloud"]


def load_builtin():
    from . import fs, shell, mt5, subagent, memory_tools, web, backup_tools, icon, verify_tools, cloud_tools  # noqa: F401  (import で登録される)
