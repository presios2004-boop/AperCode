"""表示言語の切り替え（v1.3.0）。

ソースコード中のメッセージは日本語のまま書き、英語表示のときは t() がこの辞書で置き換える。
  - 辞書のキーは日本語のテンプレート。{name} は可変部分（数値・パス等）で、正規表現に変換して照合する
  - テンプレートに完全一致しない文でも、辞書にある固定文（{name} を含まないキー）が部分文字列として
    含まれていれば、その部分だけ置き換える（複数の断片を連結して作るメッセージ向け）
言語は config の ui.language（auto | ja | en）。auto は環境変数 LANG から判定する。
"""
from __future__ import annotations

import os
import re

_LANG = "ja"
SUPPORTED = ("ja", "en")


def detect_language() -> str:
    for var in ("APERCODE_LANG", "LC_ALL", "LC_MESSAGES", "LANG"):
        v = os.environ.get(var, "")
        if v:
            return "ja" if v.lower().startswith("ja") else "en"
    return "ja"


def set_language(lang: str | None) -> str:
    global _LANG
    lang = (lang or "auto").lower()
    if lang == "auto":
        lang = detect_language()
    _LANG = lang if lang in SUPPORTED else "ja"
    return _LANG


def get_language() -> str:
    return _LANG


# ------------------------------------------------------------------ 日本語 → 英語
# キー: ソース中の日本語（テンプレート）。値: 英語。{name} は同名で対応させる。
MSG_EN: dict[str, str] = {
    # ---- agent: 汎用
    "新しいセッション": "New session",
    "\n... (省略)": "\n... (truncated)",
    "\n...(省略)": "\n...(truncated)",
    "\n... (中略) ...\n": "\n... (omitted) ...\n",
    "バックアップからの復元": "restore from backup",
    "危険なコマンド（{pat}）": "dangerous command ({pat})",
    "変更前のファイル {n} 件を {d}/ に退避しました": "Saved {n} pre-change file(s) to {d}/",
    "教訓の抽出がタイムアウトしたためスキップしました": "Lesson extraction timed out; skipped",
    "教訓の抽出をスキップ: {e}": "Lesson extraction skipped: {e}",
    "教訓の抽出に失敗: {e}": "Lesson extraction failed: {e}",
    "今回の作業から教訓を抽出して経験メモリに保存": "extracting lessons from this task into experience memory",
    "経験メモリの検索に失敗: {e}": "Experience memory search failed: {e}",
    "[添付テキスト: {name}]": "[attached text: {name}]",
    "[画像 {n} 枚を添付]": "[{n} image(s) attached]",
    "中断しました": "Cancelled",
    "このモデルは画像に対応していないため、画像を除いて送信します": "This model does not support images; sending without them",
    "LLM エラー: {e}": "LLM error: {e}",
    "内部エラー: {e}": "Internal error: {e}",
    "ユーザーがこの操作を拒否しました。別の方法を検討するか、ユーザーに確認してください。":
        "The user denied this action. Consider another approach or ask the user.",
    "不明または使用不可のツール: {name}": "Unknown or unavailable tool: {name}",
    "エラー: {e}": "Error: {e}",
    "作業ディレクトリの外へのアクセス: ": "Access outside the working directory: ",
    "このセッションでは編集・実行を常に許可": "Always allow edits & runs in this session",
    "このセッションでは常に許可": "Always allow in this session",
    # ---- agent: 行き詰まり
    "同じツール呼び出しを 3 回以上繰り返しています": "The same tool call has been repeated 3+ times",
    "ファイルの変更やテストをせずに調査だけを {n} 回続けています（進捗なし）":
        "{n} consecutive investigation-only calls without editing files or running tests (no progress)",
    "ツールの失敗が {n} 回連続しています": "{n} consecutive tool failures",
    " (5) それでも駄目なら ask_cloud で、目的・エラー・試したこと・関連ファイルを添えてクラウド AI に相談する。":
        " (5) If still stuck, use ask_cloud with the goal, error, what you tried and the relevant files.",
    "【システム】{why}。いったん調査を止めて、次を短く書き出してください: ":
        "[SYSTEM] {why}. Stop investigating for a moment and write down briefly: ",
    "(a) これまでに立てた仮説と、それぞれを検証した結果（否定された仮説は捨てる） (b) まだ確認していない層":
        "(a) the hypotheses so far and the result of checking each (drop the refuted ones) (b) the layers not yet checked",
    "（表示・初期化・ライブラリの呼び出し方・環境・プロセス/ポート） (c) 次に試す 1 つの具体的な変更。":
        " (rendering, initialisation, how the library is called, environment, process/port) (c) the one concrete change to try next.",
    "エラーが出ないのに動かない場合は、コードを読み直す前に「存在確認」（DOM 要素・canvas・プロセス・ポート・ログ行が":
        " If nothing errors but nothing works, check existence first (does the DOM element / canvas / process / port / log line",
    "本当にあるか）を行ってください。ライブラリの初期化・呼び出し方は記憶で書かず、そのバージョンの README を fetch_url で読んで確認してください。":
        " actually exist?) before re-reading code. Do not write library initialisation from memory; read that version's README with fetch_url.",
    " 整理しても原因が絞れなければ、ask_cloud で目的・症状・試したことを添えてクラウド AI に相談してください。":
        " If the cause is still unclear after this, use ask_cloud with the goal, symptoms and what you tried.",
    "【システム】{why}。同じ操作をこれ以上繰り返さないでください。次の手順で別のアプローチを取ってください: ":
        "[SYSTEM] {why}. Do not repeat the same action. Take a different approach in this order: ",
    "(1) 直近のエラー文を読み直して原因の仮説を立てる (2) search_memory で過去の解決策を確認 ":
        "(1) re-read the latest error and form a hypothesis (2) check search_memory for past solutions ",
    "(3) web_search でエラー文・ライブラリ名を検索し fetch_url で解決策を読む (4) 別の方法を試す。":
        "(3) web_search the error text / library name and read solutions with fetch_url (4) try a different method.",
    "それでも解決しない場合は、試したこと・分かったこと・残る選択肢を整理してユーザーに報告して終了してください。":
        " If it still fails, summarise what you tried, what you learned and the remaining options, report to the user and stop.",
    "行き詰まりを検知（{why}）。": "Stuck detected ({why}). ",
    "仮説の整理と別の層の確認を促しました": "Asked the agent to organise hypotheses and check other layers",
    "Web 検索などの別アプローチを促しました": "Asked the agent to try another approach such as web search",
    "ツール呼び出し上限 ({n}) に達しました。状況報告を生成します": "Tool-call limit ({n}) reached. Generating a status report",
    "【システム】ツール呼び出しの上限に達したため、いったん作業を止めます。ツールは使わずに、":
        "[SYSTEM] The tool-call limit was reached, so work stops here for now. Without using tools, ",
    "ここまでに完了したこと・未完了のこと・発生している問題と原因の推測・次に試すべき手順を簡潔に報告してください。":
        "report briefly what is done, what is not, the current problem and likely cause, and the next steps.",
    "ユーザーが「続けて」と送れば作業を再開できます。": " The user can send 'continue' to resume.",
    "状況報告": "status report",
    "状況報告の生成に失敗: {e}": "Failed to generate the status report: {e}",
    "「続けて」と送ると作業を再開します（上限は config.yaml の llm.max_iterations で変更可）":
        "Send 'continue' to resume (the limit is llm.max_iterations in config.yaml)",
    # ---- agent: テスト保護
    "テストが失敗した後は、既存のテストファイルを変更できません（検証の弱体化を防ぐため）: ":
        "After a test failure, existing test files cannot be modified (to prevent weakening the check): ",
    "\nテストではなく実装を修正してください。テスト自体が誤っていると考える場合は、その根拠を":
        "\nFix the implementation, not the tests. If you believe the test itself is wrong, explain why",
    "完了報告に書いてユーザーの判断を仰いでください。": " in the final report and let the user decide.",
    "テスト変更をブロック: {lock}": "Blocked test modification: {lock}",
    "テスト変更を拒否: {lock}": "Test modification denied: {lock}",
    "テスト失敗後のテスト変更（テストを実装に合わせて弱めていないか確認）: ":
        "Test modification after a failure (check it is not being weakened to fit the code): ",
    # ---- agent: 自動検証
    "自動検証 OK: {s}": "Auto-check OK: {s}",
    "自動検証 NG: {s}": "Auto-check FAILED: {s}",
    "## 自動検証": "## Auto-check",
    "このファイルの自動検証が {n} 回連続で NG です。同じ修正を繰り返さず、原因を根本から見直すか、":
        "This file has failed the auto-check {n} times in a row. Do not repeat the same fix; rethink the root cause, or",
    "解決できない理由を整理してユーザーに報告してください。": " explain to the user why it cannot be resolved.",
    "上記の指摘を修正してから次に進んでください（修正後に再度自動検証されます）。":
        "Fix the issues above before continuing (the file will be re-checked after the fix).",
    "テスト実行": "running tests",
    "テスト（未修正のまま）: ": "Tests (nothing changed since the failure): ",
    "テスト: ": "Tests: ",
    "注意: 既存テストが変更されています（{n} 件）。結果の妥当性を確認してください":
        "Warning: {n} existing test file(s) were modified. Check that the result is still meaningful",
    "【システム】完了報告の前にテストを自動実行したところ失敗しました。\n":
        "[SYSTEM] Tests were run automatically before the final report and they failed.\n",
    "自動差し戻しの上限に達しました。「テストは失敗している」と正直に書き、失敗の内容と原因の推測、":
        "The automatic retry limit was reached. State honestly that the tests are failing, and report the failure, the likely cause",
    "対処案をユーザーに報告してください。": " and a proposed fix to the user.",
    "失敗の原因を実装側で直してから、run_tests で再実行して完了報告してください。":
        "Fix the cause in the implementation, re-run run_tests and then give the final report.",
    "テストが通っていない状態で「完了」「PASS」と報告しないでください。":
        " Do not report 'done' or 'PASS' while the tests are failing.",
    "原因が分からなければ web_search、それでも駄目なら ask_cloud で相談してください。":
        " If the cause is unclear, use web_search, and if still stuck, ask_cloud.",
    "テスト: 0 件実行（{cmd}）": "Tests: 0 tests ran ({cmd})",
    "【システム】テストを実行しましたが 1 件も実行されませんでした。\n": "[SYSTEM] Tests were run but none were collected.\n",
    "テストが実行できる状態にして（必要なら pytest のインストールや tests/__init__.py の追加）、":
        "Make the tests runnable (install pytest or add tests/__init__.py if needed),",
    "run_tests で通ることを確認してから完了報告してください。": " confirm they pass with run_tests, then give the final report.",
    "テスト: コマンドが見つかりません（作成を促します）": "Tests: no test command found (asking the agent to create tests)",
    "【システム】このプロジェクトにはテストが見つかりません。完了報告の前に、今回変更した機能に対する":
        "[SYSTEM] No tests were found in this project. Before the final report, create minimal tests for the changed functionality",
    "最小限のテスト（Python なら tests/test_*.py、Node なら package.json の scripts.test 等）を作成し、":
        " (tests/test_*.py for Python, package.json scripts.test for Node, etc.),",
    "run_tests で実行して通ることを確認してください。テストが本当に不要な場合（設定ファイルのみの変更など）は、":
        " run them with run_tests and make sure they pass. If tests are truly unnecessary (e.g. config-only changes),",
    "その理由を書いて完了報告してください。": " say so in the final report.",
    "コードレビュー（{n} 行）": "code review ({n} lines)",
    "レビュー: 指摘なし（{n} 行）": "Review: no issues ({n} lines)",
    "レビュー: {k} 件の指摘（{n} 行）": "Review: {k} issue(s) ({n} lines)",
    "  対処案: ": "  Suggested fix: ",
    "【レビュー指摘】レビュー担当の子エージェントが以下を指摘しました。妥当なものは修正し、":
        "[REVIEW] The reviewer sub-agent reported the issues below. Fix the valid ones,",
    "修正後は run_tests で確認してから完了報告してください。妥当でない指摘は理由を完了報告に書いてください。\n":
        " verify with run_tests, then give the final report. For issues you consider invalid, explain why in the report.\n",
    "\n（レビューはこれが最後です。残る指摘は完了報告に含めてください）": "\n(This was the last review round. Include any remaining issues in the final report.)",
    "(不明)": "(unknown)",
    "変更 {n} ファイルのレビュー": "review of {n} changed file(s)",
    "レビューをスキップ: {e}": "Review skipped: {e}",
    # ---- agent: サブエージェント / 圧縮
    "サブエージェントは無効化されています": "Sub-agents are disabled",
    "サブエージェントの深さ上限 ({n}) に達しています。自分で作業してください": "Sub-agent depth limit ({n}) reached. Do the work yourself",
    "(子エージェントは最終報告を返しませんでした)\n最後のツール結果:\n": "(The sub-agent returned no final report)\nLast tool result:\n",
    "なし": "none",
    "[子エージェント ({mode}) 完了: ツール呼び出し {n} 回]": "[sub-agent ({mode}) finished: {n} tool call(s)]",
    "履歴が短いため要約は不要です": "History is short; no compaction needed",
    "会話を続けられるように履歴を圧縮しています… (推定 {a} / {b} tokens)": "Compacting history so the conversation can continue… (est. {a} / {b} tokens)",
    "要約に失敗しました: {e}": "Summarisation failed: {e}",
    "(要約なし)": "(no summary)",
    "【これまでの作業の要約（自動圧縮）】\n": "[Summary of the work so far (auto-compacted)]\n",
    "要約を確認しました。この内容を踏まえて作業を続けます。": "Summary acknowledged. Continuing from here.",
    "[部分 {i}/{n} の要約]\n": "[summary of part {i}/{n}]\n",
    "以下は会話記録を分割して要約したものです。重複を除いて 1 つに統合してください。\n\n":
        "The following are summaries of parts of the conversation. Merge them into one, removing duplicates.\n\n",
    # ---- server
    "設定値": "configured value",
    "設定値（自動調整オフ）": "configured value (auto-sizing off)",
    "設定済み": "set",
    "設定が不完全です（プロバイダ・モデル・API キー）": "Settings incomplete (provider / model / API key)",
    "ワークスペース外です: {p}\n（許可範囲: {root}。config.yaml の workspace.root で変更できます）":
        "Outside the workspace: {p}\n(allowed: {root}; change workspace.root in config.yaml)",
    "ワークスペース外です: {p}": "Outside the workspace: {p}",
    "ディレクトリではありません: {p}": "Not a directory: {p}",
    "ディレクトリがありません: {p}": "Directory not found: {p}",
    "作成できません: {e}": "Cannot create: {e}",
    "経験メモリは無効です (config.yaml memory.enabled)": "Experience memory is disabled (config.yaml memory.enabled)",
    "セッションがありません": "Session not found",
    "前の処理が実行中です": "The previous request is still running",
    "処理中は要約できません": "Cannot compact while a request is running",
    "モデル {m} を使用（前回 UI で選択。config.yaml の値に戻すには ~/.apercode/state.json の model を削除）":
        "using model {m} (chosen in the UI last time; delete 'model' in ~/.apercode/state.json to revert to config.yaml)",
    # ---- tools: fs / shell
    "ファイルがありません: {p}": "File not found: {p}",
    "\n... (省略: 全{n}行。start_line/end_line で範囲指定してください)": "\n... (truncated: {n} lines total; use start_line/end_line)",
    "(空ファイル)": "(empty file)",
    "（変更前を退避: {b}）": " (previous version saved to {b})",
    "上書き: {p} ({n} 文字)": "Overwrote {p} ({n} chars)",
    "作成: {p} ({n} 文字)": "Created {p} ({n} chars)",
    "old_string がファイル中に見つかりません。read_file で正確な文字列を確認してください":
        "old_string was not found in the file. Use read_file to get the exact text",
    "old_string が {n} 箇所に一致します。周辺行を含めて一意にするか replace_all=true を指定してください":
        "old_string matches {n} places. Include surrounding lines to make it unique, or set replace_all=true",
    "編集完了: {p} ({n} 箇所)": "Edited {p} ({n} place(s))",
    "(空)": "(empty)",
    "\n... (他 {n} 件)": "\n... ({n} more)",
    "(該当なし)": "(no matches)",
    "... (300件で打ち切り)": "... (stopped at 300)",
    "(タイムアウト {t}s)": "(timeout {t}s)",
    "cwd がありません: {p}": "cwd not found: {p}",
    "ワークスペース外のパスです: {p}（許可: {root} 配下）": "Path is outside the workspace: {p} (allowed: under {root})",
    # ---- tools: verify / cloud
    "テストコマンドを自動判定できませんでした。tests/ に test_*.py を作成するか、":
        "Could not detect a test command. Create tests/test_*.py,",
    "package.json の scripts.test を定義するか、command を指定してください": " define scripts.test in package.json, or pass command",
    "(自動判定)": "(auto-detect)",
    "テストコマンドが見つかりません": "no test command found",
    "{p}: スキップ（{why}）": "{p}: skipped ({why})",
    "tsc が無い": "tsc not installed", "node が無い": "node not installed", "go が無い": "go not installed",
    "cargo / Cargo.toml が無い": "cargo / Cargo.toml not found", "{cc} が無い": "{cc} not installed",
    "JSON が不正です: {e}": "Invalid JSON: {e}", "YAML が不正です: {e}": "Invalid YAML: {e}",
    "タイムアウト {t}s": "timeout {t}s", "チェック失敗: {e}": "check failed: {e}",
    "\n(注: pytest が入っていないため unittest で実行しました。pytest 形式（関数 test_*）のテストは ":
        "\n(note: pytest is not installed, so unittest was used. pytest-style tests (test_* functions)",
    "pytest が必要です: pip install pytest)": " need pytest: pip install pytest)",
    " (削除)": " (deleted)",
    "\n... (差分が長いため省略)": "\n... (diff truncated)",
    "\n... (省略: 全 {n} 行。範囲は path:開始-終了 で指定可)": "\n... (truncated: {n} lines total; use path:start-end)",
    "クラウド相談は無効です（画面左の「クラウド相談」で API キーを設定し有効化してください）":
        "Cloud consultation is disabled (set an API key and enable it under 'Cloud consult' in the sidebar)",
    "クラウド相談の設定が不完全です（プロバイダ・モデル・API キーを確認してください）":
        "Cloud consultation settings are incomplete (check provider / model / API key)",
    "まだクラウド相談は使えません（失敗・行き詰まり {a} 回 / 必要 {b} 回）。":
        "Cloud consultation is not available yet ({a} failure(s)/stalls, {b} required). ",
    "先にエラー文を読み直し、search_memory と web_search で解決策を探して試してください":
        "Re-read the error first and look for solutions with search_memory and web_search",
    "このターンのクラウド相談は上限（{n} 回）に達しました。得られたヒントを基に自分で進めるか、":
        "The cloud consultation limit for this turn ({n}) was reached. Continue with the hints you have, or",
    "試したこと・分かったことを整理してユーザーに報告してください": " summarise what you tried and learned and report to the user",
    "goal（目的）と tried（試したことと結果）は必須です。丸投げではなく相談になるように書いてください":
        "goal and tried (what you tried and the results) are required. Make it a consultation, not a hand-off",
    "クラウド相談に失敗: {e}": "Cloud consultation failed: {e}",
    "[クラウド相談: {t} / 送信 {n} 文字": "[cloud consultation: {t} / sent {n} chars",
    ", 秘密情報 {n} 件をマスク": ", {n} secret(s) masked",
    "\n\n（上記はヒントです。そのまま信用せず、確認方法を実行して裏を取り、修正後は必ずテストで検証してください。":
        "\n\n(These are hints. Do not trust them blindly: run the checks to confirm, and verify with tests after fixing.",
    "解決したら原因と対処を save_memory に「（参考: クラウド相談）」を付けて保存してください）":
        " Once solved, save the cause and fix with save_memory, tagged '(source: cloud consultation)'.)",
    "API キーが設定されていません（cloud.api_key または環境変数 ": "API key is not set (cloud.api_key or environment variable ",
    "Gemini から応答がありません: {d}": "No response from Gemini: {d}",
    "cloud.base_url が設定されていません（custom プロバイダ）": "cloud.base_url is not set (custom provider)",
    "応答がありません: {d}": "No response: {d}",
    "（API キーが無効か、権限がありません）": " (invalid API key or no permission)",
    "（モデル名が間違っている可能性）": " (the model name may be wrong)",
    "（レート制限または残高不足）": " (rate limited or out of credit)",
    "クラウド API エラー {c}{h}: {t}": "Cloud API error {c}{h}: {t}",
    "OpenAI 互換（カスタム URL）": "OpenAI-compatible (custom URL)",
    # ---- tools: subagent / web / memory / backup
    "この環境ではサブエージェントを使えません": "Sub-agents are not available here",
    "mode は explore または code を指定してください": "mode must be explore or code",
    "task は必須です": "task is required",
    "（回答あり）": " (answered)",
    "Web 検索は無効です (config.yaml web.enabled)": "Web search is disabled (config.yaml web.enabled)",
    "query は必須です": "query is required",
    "{name}: 結果なし（ブロックされた可能性）": "{name}: no results (possibly blocked)",
    "検索に失敗しました（すべてのエンジンで失敗）: ": "Search failed (all engines failed): ",
    "\n対処: ネットワーク接続を確認する。.venv/bin/pip install ddgs で ddgs パッケージを入れる":
        "\nFix: check the network. Install the ddgs package (.venv/bin/pip install ddgs)",
    "（ブラウザ相当の TLS で検索サイトの 403 を回避できる）。config.yaml の web.searxng_url に":
        " (browser-like TLS avoids 403 from search sites). Set web.searxng_url in config.yaml to",
    "自前の SearXNG を設定する。それでも無理なら Web 検索なしで進める": " a self-hosted SearXNG. Otherwise continue without web search",
    "検索結果がありません。別のキーワード（英語、エラーメッセージの一部、ライブラリ名など）で試してください":
        "No results. Try other keywords (English, part of the error message, the library name)",
    "検索: {q}（{e}）": "Search: {q} ({e})",
    "詳細を読むには fetch_url を使ってください": "Use fetch_url to read a result in full",
    "Web アクセスは無効です (config.yaml web.enabled)": "Web access is disabled (config.yaml web.enabled)",
    "http(s):// で始まる URL を指定してください": "URL must start with http(s)://",
    "取得に失敗しました: {e}": "Fetch failed: {e}",
    "タイトル: {t}\n": "Title: {t}\n",
    "\n... (省略: 全 {n} 文字。必要なら max_chars を増やす)": "\n... (truncated: {n} chars total; raise max_chars if needed)",
    "経験メモリは無効です": "Experience memory is disabled",
    "該当する経験はありません": "No matching experience",
    "    行動: ": "    action: ",
    "lesson は必須です": "lesson is required",
    "（参考: {u}）": " (ref: {u})",
    "バックアップは無効です (config.yaml backup.enabled)": "Backups are disabled (config.yaml backup.enabled)",
    "バックアップは無効です": "Backups are disabled",
    "バックアップはありません": "No backups",
    "バックアップ先: {p}": "Backup folder: {p}",
    " ファイル  ": " file(s)  ",
    "{s}: 復元対象がありません": "{s}: nothing to restore",
    "{s} から {n} ファイルを復元しました（復元前の状態も新しい世代に退避済み）:\n":
        "Restored {n} file(s) from {s} (the pre-restore state was saved as a new generation):\n",
    "最新": "latest",
    "バックアップがありません: {s}": "Backup not found: {s}",
    # ---- llm / vram
    "LLM サーバーに接続できません ({u})。Ollama が起動しているか確認してください": "Cannot connect to the LLM server ({u}). Is Ollama running?",
    "LLM との接続が途中で切れました（Ollama が落ちた可能性。メモリ不足なら num_ctx を減らす）: {e}":
        "Connection to the LLM dropped (Ollama may have crashed; reduce num_ctx if out of memory): {e}",
    "LLM からの応答がタイムアウトしました。モデルのロード中か、負荷が高い可能性があります":
        "The LLM did not respond in time (model loading or heavy load)",
    "LLM サーバーエラー {c}（モデル名が間違っている可能性: {m}）": "LLM server error {c} (the model name may be wrong: {m})",
    "\n[tool_call の JSON 解析に失敗しました]\n": "\n[failed to parse tool_call JSON]\n",
    "ANTHROPIC_API_KEY が設定されていません": "ANTHROPIC_API_KEY is not set",
    "モデル情報が取得できないため設定値を使用": "model info unavailable; using the configured value",
    "メモリ情報が取得できないため設定値を使用": "memory info unavailable; using the configured value",
    "（{n} 枚合計: ": " ({n} GPUs total: ",
    "（RAM 退避分 +{n} MB を含む。GPU に載りきらない分は遅くなる）": " (incl. +{n} MB RAM offload; the offloaded part is slower)",
    "空き{d}メモリ {a} MB がモデル {b} MB に足りないため最小値": "free {d} memory {a} MB is less than the model {b} MB; using the minimum",
    "{d} 空き {a} MB{g} − モデル {m} MB − 予備 {r} MB{o} → ": "{d} free {a} MB{g} − model {m} MB − reserve {r} MB{o} → ",
    "KV {k} KB/token ({t}) → 約 {n} tokens、上限 {u}": "KV {k} KB/token ({t}) → ~{n} tokens, cap {u}",
    "コンテキストサイズを自動設定: {n} tokens": "Context size auto-set: {n} tokens",
}

# ツール説明の英語版（name -> (description, {param: description}))
TOOL_EN: dict[str, tuple[str, dict[str, str]]] = {
    "read_file": ("Read a file with line numbers. For large files, pass start_line/end_line.",
                  {"path": "file path (project-relative or absolute)"}),
    "write_file": ("Create a file or overwrite it entirely. Use edit_file for partial changes to existing files.",
                   {"path": "file path", "content": "full file content"}),
    "edit_file": ("Replace old_string with new_string in a file. old_string must be unique in the file.",
                  {"path": "file path", "old_string": "exact text to replace", "new_string": "replacement text",
                   "replace_all": "replace every occurrence"}),
    "list_dir": ("List the contents of a directory.", {"path": "directory (default: project root)"}),
    "glob": ("Find files matching a pattern recursively (e.g. **/*.mq5, src/*.py).", {"pattern": "glob pattern", "path": "base directory"}),
    "grep": ("Search file contents with a regular expression.", {"pattern": "regular expression", "path": "base directory", "glob": "file name pattern, e.g. *.mq5"}),
    "run_command": ("Run a shell command (bash) for builds, tests, git, etc. Set timeout for long jobs.",
                    {"command": "command line", "cwd": "working directory (default: project)", "timeout": "seconds (default 120)"}),
    "run_tests": ("Run the project's tests and summarise the result. The command is auto-detected (pytest / unittest / npm test / "
                  "go test / cargo test / make test). Always run this before the final report after changing code; fix failures and re-run. "
                  "If the project has no tests, create tests for the main functionality first.",
                  {"command": "test command (default: auto-detect)", "timeout": "seconds (default 600)"}),
    "spawn_agent": ("Delegate a sub-task to a child agent with its own context that reports back at the end. Use it to split large work, "
                    "for broad investigation, or to save the parent's context. mode=explore is read-only; mode=code can edit files and run commands. "
                    "Write the task with the goal, target files, completion criteria and what to report; the child cannot see this conversation.",
                    {"task": "self-contained instructions for the child", "mode": "explore=read-only, code=can edit", "context": "extra context (design decisions, constraints)"}),
    "search_memory": ("Search past experience (lessons from successes/failures, verified facts). Use before similar work, on errors, or when unsure about settings or steps.",
                      {"query": "situation or error in natural language", "tags": "filter by language/tool tags (optional)"}),
    "save_memory": ("Save a lesson or fact for the future: causes and fixes of errors, environment-specific settings, procedures that worked. "
                    "Solutions found on the web that actually worked must be saved with the url. Do not save transient state.",
                    {"lesson": "lesson or fact (1-2 sentences, concrete)", "situation": "in what situation (optional)", "action": "what was done (optional)",
                     "outcome": "success | failure | info", "tags": "language / framework / tool names", "url": "source URL if found on the web"}),
    "web_search": ("Search the web (DuckDuckGo → Bing → … automatic fallback) for error messages, library usage and configuration when local information is not enough. "
                   "Searching the exact error text works well. Use engine=mdn for JavaScript / DOM / WebSocket / fetch / CSS / HTTP reference, "
                   "engine=stackexchange for programming Q&A, engine=github for known library issues.",
                   {"query": "search terms (English works best; paste error text as-is)", "engine": "optional: mdn | stackexchange | github | wikipedia | duckduckgo | bing | brave",
                    "max_results": "default 5"}),
    "fetch_url": ("Fetch a page as text: to read a search result in full, official docs, or a GitHub issue / README.",
                  {"url": "URL", "max_chars": "default 12000"}),
    "list_backups": ("List backup generations (backup/<timestamp>/) of files changed by the agent. Check this first when you want to undo changes.", {}),
    "restore_backup": ("Write files back from a backup generation into the project (latest if stamp is omitted; files narrows the set). "
                       "The current state is backed up first, so this is safe to retry.",
                       {"stamp": "generation name, e.g. 20260920-153000 (default: latest)", "files": "files to restore, project-relative (default: all)"}),
    "make_icon": ("Generate an app icon set (PNG 16-512px, .ico, .svg): initials or text, a shape (circle/ring/chevron/bolt), an embedded image, colours and corner radius.",
                  {"out": "output base name without extension (default assets/icon)", "text": "text drawn in the centre (1-4 chars)", "image": "existing image to embed (optional)",
                   "border": "border colour (optional)", "radius": "corner radius 0-0.5 (default 0.2)"}),
    "ask_cloud": ("Consult a strong cloud AI for hints when stuck. Use only after search_memory and web_search did not help (it is unavailable until a number of failures). "
                  "Only the goal, error, what you tried and short code excerpts are sent, not the conversation. You get hypotheses and a fix proposal; you implement and verify yourself.",
                  {"goal": "what you are trying to achieve (1-3 sentences)", "error": "full error / stack trace / symptoms",
                   "tried": "what you tried and the result of each (required)", "files": "relevant files (max 6; 'path' or 'path:start-end'; first 200 lines are sent)",
                   "question": "specific question (optional)"}),
    "mt5_compile": ("Compile an MQL5 source (.mq5) with MetaEditor (wine) and return errors/warnings. Always run after writing an EA.", {"path": "path to the .mq5 file"}),
    "mt5_backtest": ("Back-test a compiled EA in the strategy tester and return the key metrics (net profit, PF, drawdown...). Slow.",
                     {"path": "path to the .mq5 or .ex5", "set_file": "parameter .set file name (optional)"}),
}

# ---- テンプレート → 正規表現
_compiled: list[tuple[re.Pattern, str]] | None = None
_literals: list[tuple[str, str]] | None = None


def _compile() -> None:
    global _compiled, _literals
    tmpl, lits = [], []
    for ja, en in MSG_EN.items():
        if "{" in ja:
            names = re.findall(r"\{(\w+)\}", ja)
            parts = re.split(r"\{\w+\}", ja)
            rx = ""
            for i, part in enumerate(parts):
                rx += re.escape(part)
                if i < len(names):
                    rx += f"(?P<{names[i]}>.*?)"
            # テンプレートの後ろに続く文（連結されたメッセージ）は _rest として再帰的に翻訳する
            tmpl.append((re.compile("^" + rx + "(?P<_rest>.*)$", re.S), en))
        else:
            lits.append((ja, en))
    lits.sort(key=lambda x: -len(x[0]))
    _compiled, _literals = tmpl, lits


def t(text: str) -> str:
    """日本語メッセージを現在の言語に変換する（ja ならそのまま）。"""
    if _LANG == "ja" or not text or not _has_jp(text):
        return text
    if _compiled is None:
        _compile()
    if text in MSG_EN:
        return MSG_EN[text]
    best = None
    for rx, en in _compiled:
        m = rx.match(text)
        if m:
            rest = m.group("_rest")
            # 最も長く一致した（残りが短い）テンプレートを採用
            if best is None or len(rest) < len(best[2]):
                best = (m, en, rest)
    if best:
        m, en, rest = best
        try:
            vals = {k: t(v) for k, v in m.groupdict().items() if k != "_rest"}
            return en.format(**vals) + (t(rest) if rest else "")
        except (KeyError, IndexError):
            pass
    # 断片の置き換え（連結して作られたメッセージ向け）
    out = text
    for ja, en in _literals:
        if ja in out:
            out = out.replace(ja, en)
    return out


_JP = re.compile(r"[぀-ヿ㐀-鿿＀-￯]")


def _has_jp(s: str) -> bool:
    return bool(_JP.search(s))


def tool_schema(schema: dict) -> dict:
    """ツールの JSON スキーマの説明文を現在の言語に置き換える。"""
    if _LANG == "ja":
        return schema
    fn = schema.get("function", {})
    ent = TOOL_EN.get(fn.get("name", ""))
    if not ent:
        return schema
    desc, params = ent
    import copy
    out = copy.deepcopy(schema)
    out["function"]["description"] = desc
    props = out["function"].get("parameters", {}).get("properties", {})
    for k, v in props.items():
        if k in params and isinstance(v, dict):
            v["description"] = params[k]
    return out
