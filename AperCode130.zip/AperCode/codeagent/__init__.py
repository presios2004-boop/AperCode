"""AperCode - ローカル LLM で動く汎用コーディングエージェント"""
__version__ = "1.3.0"
__app_name__ = "AperCode"
